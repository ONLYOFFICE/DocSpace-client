# markdown-preview (old_skill)

- pluginName: `MarkdownPreview`  version: `1.0.0`  scopes: `["ContextMenu","API"]`
- zip built: yes

## src/dialog.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  ButtonSize,
  Components,
  IBox,
  IMessage,
  IModalDialog,
  ModalDisplayType,
} from "@onlyoffice/docspace-plugin-sdk";

import { t } from "./locales";
import { parseMarkdown } from "./markdown";
import { createRenderBudget, renderBlocks } from "./render";

export type TApiParts = { origin: string; proxy: string; prefix: string };
export type TApiGetter = () => TApiParts;

/** Documents beyond this size are truncated before parsing: the plugin shares
 *  the portal's event loop, so a synchronous parse of a huge file would
 *  freeze the whole UI. */
const MAX_SOURCE_LENGTH = 500_000;

/** Builds the REST base URL from the parts the portal supplied via setAPI.
 *  Built lazily - on click, never at module scope - because setAPI runs only
 *  after the bundle executes. */
const buildApiUrl = (getApi: TApiGetter): string => {
  const { origin, proxy, prefix } = getApi();

  let url = (origin || window.location.origin).replace(/\/+$/, "");

  for (const part of [proxy, prefix]) {
    if (!part) continue;
    const clean = part.trim().replace(/^\/+/, "");
    if (!clean) continue;
    url += url.endsWith("/") ? clean : `/${clean}`;
  }

  return url;
};

const messageBody = (text: string, isError: boolean): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  paddingProp: "8px 0",
  children: [
    {
      component: Components.text,
      props: {
        text,
        fontSize: "13px",
        lineHeight: "20px",
        color: isError ? "var(--error-color, #f2665a)" : undefined,
      },
    },
  ],
});

const loadingBody = (): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [
    { component: Components.skeleton, props: { width: "45%", height: "24px" } },
    { component: Components.skeleton, props: { width: "100%", height: "16px" } },
    { component: Components.skeleton, props: { width: "100%", height: "16px" } },
    { component: Components.skeleton, props: { width: "70%", height: "16px" } },
  ],
});

const contentBody = (source: string, truncated: boolean): IBox => {
  const budget = createRenderBudget();
  const children = renderBlocks(parseMarkdown(source), budget);

  if (truncated) {
    children.push({
      component: Components.text,
      props: {
        text: t("preview.truncated"),
        fontSize: "13px",
        lineHeight: "20px",
        color: "#8a9199",
        isItalic: true,
      },
    });
  }

  return {
    displayProp: "flex",
    flexDirection: "column",
    className: "mdpreview-root",
    children,
  };
};

const footer = (): IBox => ({
  displayProp: "flex",
  flexDirection: "row",
  children: [
    {
      component: Components.button,
      props: {
        label: t("dialog.close"),
        size: ButtonSize.normal,
        primary: true,
        scale: false,
        onClick: (): IMessage => ({ actions: [Actions.closeModal] }),
      },
    },
  ],
});

type TLoaded = { header?: string; body: IBox };

const loadPreview = async (
  id: string | number,
  getApi: TApiGetter,
): Promise<TLoaded> => {
  const apiUrl = buildApiUrl(getApi);

  const metaResponse = await fetch(`${apiUrl}/files/file/${id}`, {
    credentials: "include",
  });
  if (!metaResponse.ok) return { body: messageBody(t("error.metadata"), true) };

  // Every DocSpace endpoint wraps its payload in a "response" field.
  const file = (await metaResponse.json()).response;
  if (!file || !file.viewUrl) return { body: messageBody(t("error.metadata"), true) };

  const header: string = typeof file.title === "string" ? file.title : t("dialog.header");

  // The portal expects plugins to respect the security map; the file's bytes
  // come from viewUrl, which is a download in the portal's eyes.
  if (file.security && file.security.Download === false) {
    return { header, body: messageBody(t("error.noPermission"), true) };
  }

  const contentResponse = await fetch(file.viewUrl, { credentials: "include" });
  if (!contentResponse.ok) return { header, body: messageBody(t("error.download"), true) };

  const source = await contentResponse.text();
  if (!source.trim()) return { header, body: messageBody(t("preview.emptyFile"), false) };

  const truncated = source.length > MAX_SOURCE_LENGTH;
  return {
    header,
    body: contentBody(truncated ? source.slice(0, MAX_SOURCE_LENGTH) : source, truncated),
  };
};

/**
 * The whole preview flow lives in the modal's onLoad: the click opens the
 * dialog immediately with a skeleton, and the fetch + parse + render happens
 * asynchronously. Everything is caught - an unhandled rejection here would be
 * a dead dialog, since no portal code wraps plugin callbacks.
 */
export const previewDialog = (
  id: string | number,
  getApi: TApiGetter,
): IModalDialog => ({
  displayType: ModalDisplayType.modal,
  dialogHeader: t("dialog.header"),
  dialogBody: loadingBody(),
  dialogFooter: footer(),
  autoMaxWidth: true,
  autoMaxHeight: true,
  onClose: (): IMessage => ({ actions: [Actions.closeModal] }),
  onLoad: async () => {
    try {
      const { header, body } = await loadPreview(id, getApi);
      return {
        newDialogHeader: header ?? t("dialog.header"),
        newDialogBody: body,
        newDialogFooter: footer(),
      };
    } catch {
      return {
        newDialogHeader: t("dialog.header"),
        newDialogBody: messageBody(t("error.generic"), true),
        newDialogFooter: footer(),
      };
    }
  },
});
```

## src/index.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  FilesType,
  IApiPlugin,
  IContextMenuItem,
  IContextMenuPlugin,
  IPlugin,
  PluginLocale,
  PluginStatus,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

import { previewDialog, TApiGetter } from "./dialog";
import { currentLocale, setLocale, t } from "./locales";

const markdownPreviewContextMenuItem = (getApi: TApiGetter): IContextMenuItem => ({
  key: "markdown-preview-context-menu",
  label: t("contextMenu.label"),
  icon: "icon-16.svg",
  // Shown only for files with a Markdown extension; the host honours fileExt
  // only when fileType includes FilesType.file.
  fileType: [FilesType.file],
  fileExt: [".md", ".markdown"],
  onItemClick: async (id: string | number) => {
    try {
      // The modal opens immediately with a skeleton; fetching and rendering
      // happen in its onLoad so a slow network never blocks the click.
      return {
        actions: [Actions.showModal],
        modalDialogProps: previewDialog(id, getApi),
      };
    } catch {
      return {
        actions: [Actions.showToast],
        toastProps: [{ type: ToastType.error, title: t("toast.openFailed") }],
      };
    }
  },
});

class MarkdownPreview
  implements
    IPlugin,
    IContextMenuPlugin,
    IApiPlugin
{
  status: PluginStatus = PluginStatus.active;

  contextMenuItems: Map<string, IContextMenuItem> = new Map();

  origin = "";

  proxy = "";

  prefix = "";

  setOrigin = (origin: string): void => {
    this.origin = origin;
  };

  getOrigin = (): string => this.origin;

  setProxy = (proxy: string): void => {
    this.proxy = proxy;
  };

  getProxy = (): string => this.proxy;

  setPrefix = (prefix: string): void => {
    this.prefix = prefix;
  };

  getPrefix = (): string => this.prefix;

  setAPI = (origin: string, proxy: string, prefix: string): void => {
    this.origin = origin;
    this.proxy = proxy;
    this.prefix = prefix;
  };

  getAPI = (): { origin: string; proxy: string; prefix: string } => ({
    origin: this.origin,
    proxy: this.proxy,
    prefix: this.prefix,
  });

  // Register items here rather than at module scope. Both are read in time, but
  // setLanguage and setAPI only run after the bundle executes - so a factory that
  // translates a label or calls getAPI() at module scope would capture empty values.
  onLoadCallback = async (): Promise<void> => {
    this.addContextMenuItem(markdownPreviewContextMenuItem(this.getAPI));
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  // The portal calls this when the interface language changes. Labels were
  // captured when the items were built, so the items have to be rebuilt.
  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
    this.updateContextMenuItem(markdownPreviewContextMenuItem(this.getAPI));
  };

  getLanguage = (): PluginLocale => currentLocale();

  addContextMenuItem = (item: IContextMenuItem): void => {
    this.contextMenuItems.set(item.key, item);
  };

  getContextMenuItems = (): Map<string, IContextMenuItem> => this.contextMenuItems;

  getContextMenuItemsKeys = (): string[] => Array.from(this.contextMenuItems.keys());

  updateContextMenuItem = (item: IContextMenuItem): void => {
    this.contextMenuItems.set(item.key, item);
  };
}

const plugin = new MarkdownPreview();

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.MarkdownPreview = plugin || {};

export default plugin;
```

## src/locales.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 */
export type TStrings = {
  "contextMenu.label": string;
  "dialog.header": string;
  "dialog.close": string;
  "preview.image": string;
  "preview.truncated": string;
  "preview.emptyFile": string;
  "error.metadata": string;
  "error.noPermission": string;
  "error.download": string;
  "error.generic": string;
  "toast.openFailed": string;
};

const en: TStrings = {
  "contextMenu.label": "Preview as HTML",
  "dialog.header": "Markdown preview",
  "dialog.close": "Close",
  "preview.image": "Image",
  "preview.truncated": "The document is too large - only the beginning is shown.",
  "preview.emptyFile": "This file is empty.",
  "error.metadata": "Could not read the file information from the portal.",
  "error.noPermission": "You do not have permission to download this file.",
  "error.download": "Could not download the file content.",
  "error.generic": "Could not load the preview. Please try again.",
  "toast.openFailed": "Could not open the Markdown preview.",
};

const ru: TStrings = {
  "contextMenu.label": "Просмотр как HTML",
  "dialog.header": "Просмотр Markdown",
  "dialog.close": "Закрыть",
  "preview.image": "Изображение",
  "preview.truncated": "Документ слишком большой — показано только начало.",
  "preview.emptyFile": "Файл пуст.",
  "error.metadata": "Не удалось получить сведения о файле.",
  "error.noPermission": "У вас нет прав на скачивание этого файла.",
  "error.download": "Не удалось загрузить содержимое файла.",
  "error.generic": "Не удалось загрузить предпросмотр. Попробуйте ещё раз.",
  "toast.openFailed": "Не удалось открыть предпросмотр Markdown.",
};

const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.EN_US]: en,
  [PluginLocale.RU]: ru,
};

let locale: PluginLocale = PluginLocale.EN_US;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.EN_US;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings): string => (translations[locale] ?? en)[key];
```

## src/markdown.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * A small, dependency-free Markdown parser producing a block tree.
 *
 * The plugin cannot inject raw HTML into the portal (the UI is declarative),
 * so instead of markdown -> HTML string we parse markdown -> typed blocks and
 * render those blocks with the portal's own components (see render.ts).
 *
 * Supported: ATX + setext headings, paragraphs, fenced and indented code
 * blocks, blockquotes (nested), ordered/unordered/task lists (nested), GFM
 * tables, thematic breaks, and inline bold / italic / strikethrough / code /
 * links / autolinks / images / escapes.
 */

export type TInlineStyle = {
  bold?: boolean;
  italic?: boolean;
  strike?: boolean;
};

export type TInline =
  | ({ kind: "text"; text: string } & TInlineStyle)
  | { kind: "code"; text: string }
  | { kind: "link"; text: string; href: string }
  | { kind: "image"; alt: string; src: string };

export type TListItem = {
  inlines: TInline[];
  task?: "todo" | "done";
  children: TBlock[];
};

export type TAlign = "left" | "center" | "right";

export type TBlock =
  | { kind: "heading"; level: number; inlines: TInline[] }
  | { kind: "paragraph"; inlines: TInline[] }
  | { kind: "codeBlock"; language: string; lines: string[] }
  | { kind: "quote"; children: TBlock[] }
  | { kind: "list"; ordered: boolean; start: number; items: TListItem[] }
  | { kind: "table"; aligns: TAlign[]; header: TInline[][]; rows: TInline[][][] }
  | { kind: "hr" };

/* ------------------------------------------------------------------ */
/* Escapes are masked into a private-use character range before any    */
/* pattern matching, and unmasked when literal text is emitted, so an  */
/* escaped marker (\*) can never be mistaken for formatting.           */
/* ------------------------------------------------------------------ */

const MASK_BASE = 0xe000;

const maskEscapes = (text: string): string =>
  text.replace(/\\([!-/:-@[-`{-~])/g, (_whole, ch: string) =>
    String.fromCharCode(MASK_BASE + ch.charCodeAt(0)),
  );

const unmaskEscapes = (text: string): string =>
  text.replace(/[-]/g, (ch: string) =>
    String.fromCharCode(ch.charCodeAt(0) - MASK_BASE),
  );

/* ---------------------------- inline ------------------------------ */

type TInlinePattern = {
  regex: RegExp;
  apply: (match: RegExpExecArray, out: TInline[], style: TInlineStyle) => void;
};

const pushText = (out: TInline[], text: string, style: TInlineStyle): void => {
  if (!text) return;
  out.push({ kind: "text", text: unmaskEscapes(text), ...style });
};

const INLINE_PATTERNS: TInlinePattern[] = [
  {
    // Code span: `code` or ``code with ` inside``
    regex: /(`{1,3})([\s\S]+?)\1(?!`)/,
    apply: (m, out) => out.push({ kind: "code", text: unmaskEscapes(m[2]).trim() }),
  },
  {
    // Image: ![alt](src "title")
    regex: /!\[([^\]]*)\]\(\s*<?([^)\s>]*)>?(?:\s+["'][^)]*["'])?\s*\)/,
    apply: (m, out) =>
      out.push({ kind: "image", alt: unmaskEscapes(m[1]), src: unmaskEscapes(m[2]) }),
  },
  {
    // Link: [text](href "title")
    regex: /\[([^\]]+)\]\(\s*<?([^)\s>]*)>?(?:\s+["'][^)]*["'])?\s*\)/,
    apply: (m, out) =>
      out.push({
        kind: "link",
        text: unmaskEscapes(m[1]).replace(/[*_~`]/g, ""),
        href: unmaskEscapes(m[2]),
      }),
  },
  {
    // Autolink: <https://example.com>
    regex: /<(https?:\/\/[^>\s]+)>/,
    apply: (m, out) => out.push({ kind: "link", text: m[1], href: m[1] }),
  },
  {
    // Bold + italic: ***text*** or ___text___
    regex: /(\*{3}|_{3})([^\s*_](?:[\s\S]*?[^\s*_])?)\1/,
    apply: (m, out, style) => parseStyled(m[2], { ...style, bold: true, italic: true }, out),
  },
  {
    // Bold: **text** or __text__
    regex: /(\*{2}|_{2})([^\s*_](?:[\s\S]*?[^\s])?)\1/,
    apply: (m, out, style) => parseStyled(m[2], { ...style, bold: true }, out),
  },
  {
    // Strikethrough: ~~text~~
    regex: /~~([^\s~](?:[\s\S]*?[^\s~])?)~~/,
    apply: (m, out, style) => parseStyled(m[1], { ...style, strike: true }, out),
  },
  {
    // Italic (asterisk): *text*
    regex: /\*([^\s*](?:[^*]*?[^\s*])?)\*/,
    apply: (m, out, style) => parseStyled(m[1], { ...style, italic: true }, out),
  },
  {
    // Italic (underscore): _text_, not inside a word such as snake_case
    regex: /(?<![A-Za-z0-9_])_([^\s_](?:[^_]*?[^\s_])?)_(?![A-Za-z0-9_])/,
    apply: (m, out, style) => parseStyled(m[1], { ...style, italic: true }, out),
  },
];

const parseStyled = (text: string, style: TInlineStyle, out: TInline[]): void => {
  let rest = text;

  while (rest) {
    let bestPattern: TInlinePattern | null = null;
    let bestMatch: RegExpExecArray | null = null;

    for (const pattern of INLINE_PATTERNS) {
      const match = pattern.regex.exec(rest);
      if (match && (!bestMatch || match.index < bestMatch.index)) {
        bestPattern = pattern;
        bestMatch = match;
      }
    }

    if (!bestPattern || !bestMatch) {
      pushText(out, rest, style);
      return;
    }

    pushText(out, rest.slice(0, bestMatch.index), style);
    bestPattern.apply(bestMatch, out, style);
    rest = rest.slice(bestMatch.index + bestMatch[0].length);
  }
};

export const parseInlines = (text: string): TInline[] => {
  const out: TInline[] = [];
  parseStyled(maskEscapes(text), {}, out);
  return out;
};

/* ---------------------------- blocks ------------------------------ */

const BLANK = /^\s*$/;
const FENCE_OPEN = /^( {0,3})(`{3,}|~{3,})\s*([^`\s]*).*$/;
const ATX_HEADING = /^ {0,3}(#{1,6})(?:\s+(.*?))?\s*#*\s*$/;
const THEMATIC_BREAK = /^ {0,3}(?:(?:\*[ \t]*){3,}|(?:-[ \t]*){3,}|(?:_[ \t]*){3,})$/;
const QUOTE_PREFIX = /^ {0,3}> ?/;
const LIST_ITEM = /^( *)([-*+]|\d{1,9}[.)])( +)(.*)$/;
const INDENTED_CODE = /^(?: {4}|\t)(.*)$/;
const SETEXT_H1 = /^ {0,3}=+\s*$/;
const SETEXT_H2 = /^ {0,3}-+\s*$/;
const TABLE_SEPARATOR = /^ {0,3}\|?[ \t]*:?-+:?[ \t]*(?:\|[ \t]*:?-+:?[ \t]*)*\|?[ \t]*$/;
const TASK_PREFIX = /^\[([ xX])\]\s+/;

const leadingSpaces = (line: string): number => {
  const match = /^ */.exec(line);
  return match ? match[0].length : 0;
};

const nextNonBlank = (lines: string[], from: number): number => {
  for (let j = from; j < lines.length; j += 1) {
    if (!BLANK.test(lines[j])) return j;
  }
  return -1;
};

const splitTableCells = (line: string): string[] => {
  const sentinel = String.fromCharCode(0xe07c);
  let trimmed = line.trim().replace(/\\\|/g, sentinel);
  if (trimmed.startsWith("|")) trimmed = trimmed.slice(1);
  if (trimmed.endsWith("|")) trimmed = trimmed.slice(0, -1);
  return trimmed.split("|").map((cell) => cell.trim().replace(new RegExp(sentinel, "g"), "\\|"));
};

const isTableStart = (lines: string[], index: number): boolean => {
  if (index + 1 >= lines.length) return false;
  const header = lines[index];
  const separator = lines[index + 1];
  if (!header.includes("|")) return false;
  if (!TABLE_SEPARATOR.test(separator) || !separator.includes("-")) return false;
  return splitTableCells(separator).length === splitTableCells(header).length;
};

const isBlockInterrupter = (line: string): boolean =>
  ATX_HEADING.test(line) ||
  FENCE_OPEN.test(line) ||
  THEMATIC_BREAK.test(line) ||
  QUOTE_PREFIX.test(line) ||
  LIST_ITEM.test(line);

type TCursor = { index: number };

const readFence = (lines: string[], cursor: TCursor, blocks: TBlock[]): void => {
  const open = FENCE_OPEN.exec(lines[cursor.index]);
  if (!open) return;

  const indent = open[1].length;
  const fence = open[2];
  const closeRegex = new RegExp(`^ {0,3}${fence[0]}{${fence.length},}\\s*$`);
  const body: string[] = [];

  let i = cursor.index + 1;
  while (i < lines.length && !closeRegex.test(lines[i])) {
    const line = lines[i];
    const strip = Math.min(indent, leadingSpaces(line));
    body.push(line.slice(strip));
    i += 1;
  }

  blocks.push({ kind: "codeBlock", language: open[3] || "", lines: body });
  cursor.index = i < lines.length ? i + 1 : i;
};

const readIndentedCode = (lines: string[], cursor: TCursor, blocks: TBlock[]): void => {
  const body: string[] = [];
  let i = cursor.index;

  while (i < lines.length) {
    const match = INDENTED_CODE.exec(lines[i]);
    if (match) {
      body.push(match[1]);
      i += 1;
      continue;
    }
    if (BLANK.test(lines[i])) {
      const next = nextNonBlank(lines, i);
      if (next !== -1 && INDENTED_CODE.test(lines[next])) {
        for (let j = i; j < next; j += 1) body.push("");
        i = next;
        continue;
      }
    }
    break;
  }

  blocks.push({ kind: "codeBlock", language: "", lines: body });
  cursor.index = i;
};

const readQuote = (lines: string[], cursor: TCursor, blocks: TBlock[]): void => {
  const inner: string[] = [];
  let i = cursor.index;

  while (i < lines.length) {
    const line = lines[i];
    if (QUOTE_PREFIX.test(line)) {
      inner.push(line.replace(QUOTE_PREFIX, ""));
      i += 1;
      continue;
    }
    // Lazy continuation: a plain line directly after a quoted one.
    if (!BLANK.test(line) && !isBlockInterrupter(line) && inner.length > 0) {
      inner.push(line);
      i += 1;
      continue;
    }
    break;
  }

  blocks.push({ kind: "quote", children: parseBlockLines(inner) });
  cursor.index = i;
};

const readTable = (lines: string[], cursor: TCursor, blocks: TBlock[]): void => {
  const headerCells = splitTableCells(lines[cursor.index]);
  const separatorCells = splitTableCells(lines[cursor.index + 1]);

  const aligns: TAlign[] = separatorCells.map((cell) => {
    const left = cell.startsWith(":");
    const right = cell.endsWith(":");
    if (left && right) return "center";
    if (right) return "right";
    return "left";
  });

  const rows: TInline[][][] = [];
  let i = cursor.index + 2;

  while (i < lines.length && !BLANK.test(lines[i]) && lines[i].includes("|")) {
    const cells = splitTableCells(lines[i]);
    const row: TInline[][] = [];
    for (let c = 0; c < headerCells.length; c += 1) {
      row.push(parseInlines(cells[c] ?? ""));
    }
    rows.push(row);
    i += 1;
  }

  blocks.push({
    kind: "table",
    aligns,
    header: headerCells.map((cell) => parseInlines(cell)),
    rows,
  });
  cursor.index = i;
};

const readList = (lines: string[], cursor: TCursor, blocks: TBlock[]): void => {
  const firstMatch = LIST_ITEM.exec(lines[cursor.index]);
  if (!firstMatch) return;

  const ordered = /\d/.test(firstMatch[2][0]);
  const start = ordered ? parseInt(firstMatch[2], 10) || 1 : 1;
  const items: TListItem[] = [];

  let i = cursor.index;
  let listEnded = false;

  while (!listEnded && i < lines.length) {
    const itemMatch = LIST_ITEM.exec(lines[i]);
    if (!itemMatch || THEMATIC_BREAK.test(lines[i])) break;

    // A change of marker type (bullet <-> number) starts a new list.
    if (items.length > 0 && /\d/.test(itemMatch[2][0]) !== ordered) break;

    const contentIndent =
      itemMatch[1].length + itemMatch[2].length + itemMatch[3].length;
    const textParts: string[] = [itemMatch[4]];
    const buffer: string[] = [];
    i += 1;

    while (i < lines.length) {
      const line = lines[i];

      if (BLANK.test(line)) {
        const next = nextNonBlank(lines, i);
        if (next === -1) {
          i = lines.length;
          listEnded = true;
          break;
        }
        const nextLine = lines[next];
        if (leadingSpaces(nextLine) >= contentIndent) {
          for (let j = i; j < next; j += 1) buffer.push("");
          i = next;
          continue;
        }
        i = next;
        if (!LIST_ITEM.exec(nextLine)) listEnded = true;
        break;
      }

      const nested = LIST_ITEM.exec(line);
      if (nested && nested[1].length < contentIndent) break; // next sibling item

      if (leadingSpaces(line) >= contentIndent) {
        buffer.push(line.slice(contentIndent));
        i += 1;
        continue;
      }

      if (isBlockInterrupter(line)) {
        listEnded = true;
        break;
      }

      // Lazy continuation of the item's own paragraph.
      textParts.push(line.trim());
      i += 1;
    }

    let text = textParts.join(" ").trim();
    let task: TListItem["task"];
    const taskMatch = TASK_PREFIX.exec(text);
    if (taskMatch) {
      task = taskMatch[1] === " " ? "todo" : "done";
      text = text.slice(taskMatch[0].length);
    }

    items.push({ inlines: parseInlines(text), task, children: parseBlockLines(buffer) });
  }

  blocks.push({ kind: "list", ordered, start, items });
  cursor.index = i;
};

const readParagraph = (lines: string[], cursor: TCursor, blocks: TBlock[]): void => {
  const parts: string[] = [lines[cursor.index].trim()];
  let i = cursor.index + 1;

  while (i < lines.length) {
    const line = lines[i];
    if (BLANK.test(line)) break;

    // A setext underline turns the accumulated paragraph into a heading.
    if (SETEXT_H1.test(line) || SETEXT_H2.test(line)) {
      const level = SETEXT_H1.test(line) ? 1 : 2;
      blocks.push({ kind: "heading", level, inlines: parseInlines(parts.join(" ")) });
      cursor.index = i + 1;
      return;
    }

    if (isBlockInterrupter(line) || isTableStart(lines, i)) break;

    parts.push(line.trim());
    i += 1;
  }

  blocks.push({ kind: "paragraph", inlines: parseInlines(parts.join(" ")) });
  cursor.index = i;
};

const parseBlockLines = (lines: string[]): TBlock[] => {
  const blocks: TBlock[] = [];
  const cursor: TCursor = { index: 0 };

  while (cursor.index < lines.length) {
    const line = lines[cursor.index];

    if (BLANK.test(line)) {
      cursor.index += 1;
      continue;
    }

    if (FENCE_OPEN.test(line)) {
      readFence(lines, cursor, blocks);
      continue;
    }

    const atx = ATX_HEADING.exec(line);
    if (atx) {
      blocks.push({
        kind: "heading",
        level: atx[1].length,
        inlines: parseInlines(atx[2] || ""),
      });
      cursor.index += 1;
      continue;
    }

    if (THEMATIC_BREAK.test(line)) {
      blocks.push({ kind: "hr" });
      cursor.index += 1;
      continue;
    }

    if (QUOTE_PREFIX.test(line)) {
      readQuote(lines, cursor, blocks);
      continue;
    }

    if (LIST_ITEM.test(line)) {
      readList(lines, cursor, blocks);
      continue;
    }

    if (isTableStart(lines, cursor.index)) {
      readTable(lines, cursor, blocks);
      continue;
    }

    if (INDENTED_CODE.test(line)) {
      readIndentedCode(lines, cursor, blocks);
      continue;
    }

    readParagraph(lines, cursor, blocks);
  }

  return blocks;
};

export const parseMarkdown = (source: string): TBlock[] =>
  parseBlockLines(source.split(/\r\n|\r|\n/));
```

## src/render.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Renders the parsed Markdown block tree (markdown.ts) into the portal's
 * declarative component tree. Plugins never touch the DOM, so "rendered HTML"
 * here means the portal's own box/text/link components arranged to look like
 * a rendered document. Colors use translucent grays and the portal's CSS
 * variables where known, so the preview follows the light and dark themes.
 *
 * Class names (mdpreview-*) hook into dist/plugin.css for the few things
 * props cannot express (monospace fonts, single-side borders). If the CSS is
 * ever not applied, everything still renders - just without those touches.
 */

import { Component, Components, LinkTarget, LinkType } from "@onlyoffice/docspace-plugin-sdk";

import { TBlock, TInline, TListItem } from "./markdown";
import { t } from "./locales";

const BODY_FONT_SIZE = "13px";
const BODY_LINE_HEIGHT = "20px";
const CODE_FONT_SIZE = "12px";
const CODE_LINE_HEIGHT = "18px";

const BORDER_COLOR = "rgba(128, 128, 128, 0.3)";
const SOFT_BACKGROUND = "rgba(128, 128, 128, 0.12)";
const QUOTE_BACKGROUND = "rgba(128, 128, 128, 0.08)";
const TABLE_HEAD_BACKGROUND = "rgba(128, 128, 128, 0.1)";
const MUTED_COLOR = "#8a9199";
const LINK_COLOR = "var(--color-scheme-main-accent, #4781d1)";

const HEADING_FONT_SIZES: Record<number, string> = {
  1: "21px",
  2: "18px",
  3: "16px",
  4: "14px",
  5: "13px",
  6: "12px",
};

/** Hard cap on emitted components so a pathological document cannot freeze
 *  the portal's renderer (there is no error boundary around plugin UI). */
const MAX_COMPONENTS = 4000;

type TBudget = { left: number };

const NBSP = " ";

/** Non-breaking spaces survive HTML whitespace collapsing, so code keeps its
 *  indentation and alignment even before the plugin stylesheet applies. */
const preserveSpaces = (line: string): string =>
  line.replace(/\t/g, NBSP + NBSP + NBSP + NBSP).replace(/ /g, NBSP);

const textNode = (
  text: string,
  props: Record<string, unknown> = {},
): Component => ({
  component: Components.text,
  props: {
    text,
    fontSize: BODY_FONT_SIZE,
    lineHeight: BODY_LINE_HEIGHT,
    ...props,
  },
});

const inlineClass = (strike?: boolean): string =>
  strike ? "mdpreview-inline mdpreview-strike" : "mdpreview-inline";

const renderInline = (
  inline: TInline,
  fontSize: string,
  lineHeight: string,
  forceBold: boolean,
): Component[] => {
  if (inline.kind === "code") {
    return [
      textNode(inline.text || NBSP, {
        fontSize: CODE_FONT_SIZE,
        lineHeight,
        display: "inline",
        className: "mdpreview-inline mdpreview-inline-code",
      }),
    ];
  }

  if (inline.kind === "link") {
    return [
      {
        component: Components.link,
        props: {
          text: inline.text || inline.href,
          href: inline.href,
          type: LinkType.page,
          target: LinkTarget.blank,
          color: LINK_COLOR,
          fontSize,
          lineHeight,
          display: "inline",
          className: "mdpreview-inline",
        },
      },
    ];
  }

  if (inline.kind === "image") {
    // External images would be blocked by the portal's CSP, and relative
    // sources cannot be resolved from inside a plugin - so images render as
    // an honest placeholder, with a link when the source is absolute.
    const label = `[${t("preview.image")}: ${inline.alt || inline.src || "?"}]`;
    if (/^https?:\/\//.test(inline.src)) {
      return [
        {
          component: Components.link,
          props: {
            text: label,
            href: inline.src,
            type: LinkType.page,
            target: LinkTarget.blank,
            color: MUTED_COLOR,
            fontSize,
            lineHeight,
            display: "inline",
            className: "mdpreview-inline",
          },
        },
      ];
    }
    return [
      textNode(label, {
        fontSize,
        lineHeight,
        color: MUTED_COLOR,
        isItalic: true,
        display: "inline",
        className: "mdpreview-inline",
      }),
    ];
  }

  return [
    textNode(inline.text, {
      fontSize,
      lineHeight,
      isBold: forceBold || Boolean(inline.bold),
      isItalic: Boolean(inline.italic),
      display: "inline",
      className: inlineClass(inline.strike),
    }),
  ];
};

const renderInlines = (
  inlines: TInline[],
  budget: TBudget,
  fontSize: string = BODY_FONT_SIZE,
  lineHeight: string = BODY_LINE_HEIGHT,
  forceBold = false,
): Component[] => {
  const out: Component[] = [];
  for (const inline of inlines) {
    if (budget.left <= 0) break;
    for (const component of renderInline(inline, fontSize, lineHeight, forceBold)) {
      out.push(component);
      budget.left -= 1;
    }
  }
  if (out.length === 0) out.push(textNode(NBSP, { fontSize, lineHeight }));
  return out;
};

const box = (
  props: Record<string, unknown>,
  children: Component[],
): Component => ({
  component: Components.box,
  props: { ...props, children },
});

const renderHeading = (level: number, inlines: TInline[], budget: TBudget): Component => {
  const clamped = Math.min(Math.max(level, 1), 6);
  const fontSize = HEADING_FONT_SIZES[clamped];
  const lineHeight = `${parseInt(fontSize, 10) + 8}px`;
  return box(
    {
      marginProp: clamped <= 2 ? "8px 0 10px 0" : "6px 0 8px 0",
      className: `mdpreview-h mdpreview-h${clamped}`,
    },
    renderInlines(inlines, budget, fontSize, lineHeight, true),
  );
};

const renderCodeBlock = (lines: string[], budget: TBudget): Component => {
  const children: Component[] = [];
  for (const line of lines) {
    if (budget.left <= 0) break;
    children.push(
      textNode(line ? preserveSpaces(line) : NBSP, {
        fontSize: CODE_FONT_SIZE,
        lineHeight: CODE_LINE_HEIGHT,
        className: "mdpreview-code",
      }),
    );
    budget.left -= 1;
  }
  return box(
    {
      displayProp: "flex",
      flexDirection: "column",
      paddingProp: "10px 14px",
      marginProp: "0 0 12px 0",
      backgroundProp: SOFT_BACKGROUND,
      borderProp: { color: BORDER_COLOR, radius: "6px", style: "solid", width: "1px" },
      overflowProp: "auto",
      className: "mdpreview-pre",
    },
    children,
  );
};

const renderListItem = (
  item: TListItem,
  marker: string,
  markerWidth: string,
  budget: TBudget,
): Component => {
  const content: Component[] = [
    ...renderInlines(item.inlines, budget),
    ...renderBlocks(item.children, budget),
  ];
  return box(
    {
      displayProp: "flex",
      flexDirection: "row",
      alignItems: "flex-start",
      marginProp: "0 0 4px 0",
    },
    [
      box(
        { flexProp: "0 0 auto", widthProp: markerWidth },
        [textNode(marker, { textAlign: "left" })],
      ),
      box({ flexProp: "1 1 0", overflowProp: "hidden" }, content),
    ],
  );
};

const listMarker = (
  ordered: boolean,
  start: number,
  index: number,
  task?: "todo" | "done",
): string => {
  if (task === "done") return "☑"; // checked box
  if (task === "todo") return "☐"; // empty box
  if (ordered) return `${start + index}.`;
  return "•";
};

const renderList = (
  ordered: boolean,
  start: number,
  items: TListItem[],
  budget: TBudget,
): Component => {
  const markerWidth = ordered ? "30px" : "20px";
  const children: Component[] = [];
  for (let index = 0; index < items.length; index += 1) {
    if (budget.left <= 0) break;
    budget.left -= 1;
    children.push(
      renderListItem(items[index], listMarker(ordered, start, index, items[index].task), markerWidth, budget),
    );
  }
  return box(
    { displayProp: "flex", flexDirection: "column", marginProp: "0 0 10px 0" },
    children,
  );
};

const renderTableRow = (
  cells: TInline[][],
  aligns: string[],
  isHeader: boolean,
  budget: TBudget,
): Component => {
  const children = cells.map((cell, column) =>
    box(
      {
        flexProp: "1 1 0",
        paddingProp: "6px 10px",
        textAlign: aligns[column] || "left",
        overflowProp: "hidden",
        className: isHeader ? "mdpreview-th" : "mdpreview-td",
      },
      renderInlines(cell, budget, BODY_FONT_SIZE, BODY_LINE_HEIGHT, isHeader),
    ),
  );
  return box(
    {
      displayProp: "flex",
      flexDirection: "row",
      backgroundProp: isHeader ? TABLE_HEAD_BACKGROUND : undefined,
    },
    children,
  );
};

const renderTable = (
  aligns: string[],
  header: TInline[][],
  rows: TInline[][][],
  budget: TBudget,
): Component => {
  const children: Component[] = [renderTableRow(header, aligns, true, budget)];
  for (const row of rows) {
    if (budget.left <= 0) break;
    budget.left -= 1;
    children.push(renderTableRow(row, aligns, false, budget));
  }
  return box(
    {
      displayProp: "flex",
      flexDirection: "column",
      marginProp: "0 0 12px 0",
      borderProp: { color: BORDER_COLOR, radius: "6px", style: "solid", width: "1px" },
      overflowProp: "auto",
      className: "mdpreview-table",
    },
    children,
  );
};

const renderBlock = (block: TBlock, budget: TBudget): Component => {
  switch (block.kind) {
    case "heading":
      return renderHeading(block.level, block.inlines, budget);
    case "codeBlock":
      return renderCodeBlock(block.lines, budget);
    case "quote":
      return box(
        {
          paddingProp: "6px 12px",
          marginProp: "0 0 12px 0",
          backgroundProp: QUOTE_BACKGROUND,
          className: "mdpreview-quote",
        },
        renderBlocks(block.children, budget),
      );
    case "list":
      return renderList(block.ordered, block.start, block.items, budget);
    case "table":
      return renderTable(block.aligns, block.header, block.rows, budget);
    case "hr":
      return box(
        { heightProp: "1px", backgroundProp: BORDER_COLOR, marginProp: "14px 0" },
        [],
      );
    default:
      return box(
        { marginProp: "0 0 10px 0", className: "mdpreview-p" },
        renderInlines(block.inlines, budget),
      );
  }
};

export const renderBlocks = (blocks: TBlock[], budget: TBudget): Component[] => {
  const out: Component[] = [];
  for (const block of blocks) {
    if (budget.left <= 0) {
      out.push(
        textNode(t("preview.truncated"), {
          color: MUTED_COLOR,
          isItalic: true,
        }),
      );
      break;
    }
    budget.left -= 1;
    out.push(renderBlock(block, budget));
  }
  return out;
};

export const createRenderBudget = (): TBudget => ({ left: MAX_COMPONENTS });
```
