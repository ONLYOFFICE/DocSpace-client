# Interface: IBox

Defined in: [interfaces/components/IBox.ts:108](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L108)

A container that lays out its contents in one direction.
Box provides general CSS capabilities like flexbox layout, paddings, background color, border, and animation.

## Example

Flexible input container with gradient background

```typescript
const newInputProps: IInput = {
  value: "",
  onChange: () => {},
  scale: true,
  placeholder: "",
}

const inputComponent: InputGroup = {
  component: Components.input,
  props: newInputProps,
}

const inputBox: IBox = {
  widthProp: "100px",
  paddingProp: "10px",
  displayProp: "flex",
  flexDirection: "row",
  alignItems: "center",
  borderProp: {
    color: "blue",
    radius: "10px",
    style: "solid",
    width: "2px"
  },
  alignContent: "center",
  alignSelf: "center",
  backgroundProp: "linear-gradient(to right, #ff0000, #00ff00)",
  flexBasis: "50%",
  flexProp: "1",
  flexWrap: "wrap",
  children: inputComponent
}
```

## Appearance

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/IBox.ts:270](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L270)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

***

### id?

> `optional` **id**: `string`

Defined in: [interfaces/components/IBox.ts:277](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L277)

Unique identifier.

## Children

Properties that define the child components to be rendered within the box container.

### children?

> `optional` **children**: [`Component`](../type-aliases/Component.md)[]

Defined in: [interfaces/components/IBox.ts:284](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L284)

The child components to render within this box

## Layout

Properties that control flexbox, grid, positioning, spacing, borders, and dimensions of the box.

### widthProp?

> `optional` **widthProp**: `string`

Defined in: [interfaces/components/IBox.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L114)

Defines the border width of the element area

***

### paddingProp?

> `optional` **paddingProp**: `string`

Defined in: [interfaces/components/IBox.ts:122](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L122)

Defines the padding area of all four sides of the element.
This is a shorthand for "padding-top", "padding-right", "padding-bottom", and "padding-left"

***

### displayProp?

> `optional` **displayProp**: `string`

Defined in: [interfaces/components/IBox.ts:130](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L130)

Specifies whether the element is treated as a block or inline element and also determines the layout
used for its children, such as flow layout, grid or flex

***

### flexDirection?

> `optional` **flexDirection**: `string`

Defined in: [interfaces/components/IBox.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L138)

Sets how the flex items are placed in the flex container defining the main axis (column or row)
and the direction (normal or reversed)

***

### alignItems?

> `optional` **alignItems**: `string`

Defined in: [interfaces/components/IBox.ts:147](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L147)

Sets the "alignSelf" value on all direct children as a group. In flexbox, it controls the alignment
of items on the cross-axis. In grid layout, it controls the alignment of items on the block axis
within their grid area

***

### borderProp?

> `optional` **borderProp**: `string` \| [`IBorderProp`](IBorderProp.md)

Defined in: [interfaces/components/IBox.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L153)

Defines the element border. It sets the values of border width, border style, and border color

***

### alignContent?

> `optional` **alignContent**: `string`

Defined in: [interfaces/components/IBox.ts:161](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L161)

Defines the distribution of space between and around content items along the flexbox cross-axis
or the grid block axis

***

### alignSelf?

> `optional` **alignSelf**: `string`

Defined in: [interfaces/components/IBox.ts:169](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L169)

Overrides a grid or flex item "alignItems" value. In grid, it aligns the item inside the grid area.
In flexbox, it aligns the item on the cross-axis

***

### backgroundProp?

> `optional` **backgroundProp**: `string`

Defined in: [interfaces/components/IBox.ts:176](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L176)

Defines all background style properties at once, such as color, image, origin and size, or repeat method

***

### flexBasis?

> `optional` **flexBasis**: `string`

Defined in: [interfaces/components/IBox.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L184)

Defines the initial main size of the flex item. It sets the size of the content box unless
otherwise set with "box-sizing"

***

### flexProp?

> `optional` **flexProp**: `string`

Defined in: [interfaces/components/IBox.ts:192](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L192)

Defines how the flex item will grow or shrink to fit the space available in its flex container.
It is a shorthand for "flex-grow", "flex-shrink", and "flex-basis"

***

### flexWrap?

> `optional` **flexWrap**: `string`

Defined in: [interfaces/components/IBox.ts:200](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L200)

Defines whether flex items are forced onto one line or can wrap onto multiple lines.
If wrapping is allowed, it sets the direction that lines are stacked

***

### gridArea?

> `optional` **gridArea**: `string`

Defined in: [interfaces/components/IBox.ts:210](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L210)

Defines a shorthand property for "grid-row-start", "grid-column-start", "grid-row-end",
and "grid-column-end", specifying the size of the grid item and location within the grid
by contributing a line, a span, or nothing (automatic) to its grid placement,
thereby specifying the edges of its grid area.

***

### heightProp?

> `optional` **heightProp**: `string`

Defined in: [interfaces/components/IBox.ts:217](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L217)

Defines the border height of the element area

***

### justifyContent?

> `optional` **justifyContent**: `string`

Defined in: [interfaces/components/IBox.ts:225](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L225)

Defines how the browser distributes space between and around content items along the main axis
of a flex container, and the inline axis of a grid container

***

### justifyItems?

> `optional` **justifyItems**: `string`

Defined in: [interfaces/components/IBox.ts:233](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L233)

Defines the default "justifySelf" for all items of the box, giving them all a default way
of justifying each box along the appropriate axis

***

### justifySelf?

> `optional` **justifySelf**: `string`

Defined in: [interfaces/components/IBox.ts:240](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L240)

Defines the way the box is justified inside its alignment container along the appropriate axis

***

### marginProp?

> `optional` **marginProp**: `string`

Defined in: [interfaces/components/IBox.ts:248](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L248)

Defines the margin area on all four sides of an element. It is a shorthand for "margin-top",
"margin-right", "margin-bottom", and "margin-left"

***

### overflowProp?

> `optional` **overflowProp**: `string`

Defined in: [interfaces/components/IBox.ts:255](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L255)

Specifies what to do when the element content is too big to fit in its block formatting context

***

### textAlign?

> `optional` **textAlign**: `string`

Defined in: [interfaces/components/IBox.ts:262](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L262)

Defines the horizontal alignment of a block element or table-cell box
