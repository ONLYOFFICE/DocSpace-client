#!/usr/bin/env node

/*
 * Self-test for validate-plugin.mjs. Builds throwaway plugin projects in the OS
 * temp dir (hand-written bundles, no webpack needed), runs the validator against
 * them with --json and asserts which finding codes it must and must not produce.
 *
 * Run it after editing the validator:
 *   node scripts/test-validator.mjs
 *
 * Exit code 1 on the first failing expectation.
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

import {
  COMPONENT_PROPS,
  DEVICES,
  EVENT_TYPES,
  KNOWN_ACTIONS,
  SDK_PACKAGE as SDK,
  USERS_TYPES,
} from "./contract.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const validator = path.join(here, "validate-plugin.mjs");

const root = fs.mkdtempSync(path.join(os.tmpdir(), "plugin-validator-"));
const results = [];

const writeProject = (name, { pkg, bundle, assets = ["logo.svg"], src }) => {
  const dir = path.join(root, name);

  fs.mkdirSync(path.join(dir, "src"), { recursive: true });
  fs.mkdirSync(path.join(dir, "dist"), { recursive: true });
  fs.mkdirSync(path.join(dir, "assets"), { recursive: true });

  fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify(pkg, null, 2));
  fs.writeFileSync(path.join(dir, "src", "index.ts"), src);
  fs.writeFileSync(path.join(dir, "dist", "plugin.js"), bundle);

  for (const asset of assets)
    fs.writeFileSync(path.join(dir, "assets", asset), "<svg xmlns='http://www.w3.org/2000/svg'/>");

  return dir;
};

const run = (dir, extra = []) => {
  const proc = spawnSync(process.execPath, [validator, dir, "--json", ...extra], {
    encoding: "utf8",
  });

  try {
    return JSON.parse(proc.stdout);
  } catch {
    console.error(`Validator produced no JSON for ${dir}:\n${proc.stdout}\n${proc.stderr}`);
    process.exit(1);
  }
};

const codes = (report, level) =>
  report.findings.filter((f) => f.level === level).map((f) => f.code);

const check = (label, condition, detail) => {
  results.push({ label, ok: condition, detail });
  if (!condition) console.log(`FAIL  ${label}${detail ? ` - ${detail}` : ""}`);
  else console.log(`ok    ${label}`);
};

// --- a plugin that satisfies the contract -------------------------------------

const goodPkg = {
  name: "fixture-good",
  pluginName: "FixtureGood",
  version: "1.0.0",
  logo: "logo.svg",
  scopes: ["ContextMenu"],
  scripts: { build: "webpack && npx build-docspace-plugin" },
};

const goodBundle = `
window.Plugins.FixtureGood = {
  status: "active",
  items: new Map(),
  onLoadCallback: async function () {
    this.items.set("fixture-good-item", {
      key: "fixture-good-item",
      label: "Do the thing",
      icon: "logo.svg",
      // "Owner" is the UsersType *value*; "owner" is the enum key and matches nobody.
      usersTypes: ["Owner"],
      onItemClick: async function () {
        return { actions: ["show-toast"], toastProps: [{ type: "success", title: "done" }] };
      },
    });
  },
  updateStatus: function (s) { this.status = s; },
  getStatus: function () { return this.status; },
  setOnLoadCallback: function (cb) { this.onLoadCallback = cb; },
  addContextMenuItem: function (item) { this.items.set(item.key, item); },
  getContextMenuItems: function () { return this.items; },
};
`;

const goodSrc = `
window.Plugins.FixtureGood = plugin || {};
addContextMenuItem(item);
getContextMenuItems();
const item = { icon: "logo.svg" };
`;

const good = run(writeProject("good", { pkg: goodPkg, bundle: goodBundle, src: goodSrc }), [
  "--invoke",
]);

check("valid plugin passes", good.ok, `errors: ${codes(good, "ERROR").join(", ")}`);
check("valid plugin loads in the sandbox", good.runtime.loaded);
check(
  "valid plugin reports its item count",
  good.runtime.items.ContextMenu === 1,
  JSON.stringify(good.runtime.items),
);

// --- every silent-failure pattern the host has -------------------------------

const badPkg = {
  name: "Fixture-Bad",
  pluginName: "FixtureBad",
  version: "1.0.0",
  logo: "missing-logo.svg",
  runtime: "react",
  scopes: ["ContextMenu", "MainButton", "InfoPanel", "NotAScope"],
  scripts: { build: "webpack && node ./createZip.js" },
};

// Registers under the wrong name, uses the wrong filter field for MainButton,
// returns an action without its payload, points at an asset that is not there.
const badBundle = `
window.Plugins.SomethingElse = {
  status: "active",
  contextItems: new Map(),
  mainItems: new Map(),
  onLoadCallback: async function () {
    this.contextItems.set("k", { key: "k", label: "l", icon: "nope.svg", usersType: ["owner"],
      onItemClick: async function () { return { actions: ["show-toast"] }; } });
    this.mainItems.set("m", { key: "m", label: "l", icon: "logo.svg", usersTypes: ["owner"],
      onClick: async function () { return { actions: ["show-modal"] }; } });
  },
  updateStatus: function (s) { this.status = s; },
  getStatus: function () { return this.status; },
  setOnLoadCallback: function (cb) { this.onLoadCallback = cb; },
  getContextMenuItems: function () { return this.contextItems; },
  getMainButtonItems: function () { return this.mainItems; },
  getInfoPanelItems: function () { return new Map(); },
};
`;

const badSrc = `
window.Plugins.SomethingElse = plugin || {};
getContextMenuItems();
getMainButtonItems();
getInfoPanelItems();
const item = { icon: "nope.svg" };
// const commented = { icon: "also-missing.svg" };
`;

const bad = run(writeProject("bad", { pkg: badPkg, bundle: badBundle, src: badSrc }), ["--invoke"]);

const badErrors = codes(bad, "ERROR");
const badWarnings = codes(bad, "WARN");
const messages = bad.findings.map((f) => f.message).join("\n");

check("broken plugin fails", !bad.ok);
check("upper case name is an error", badErrors.includes("pkg.name"));
check("unknown scope is an error", messages.includes('unknown scope "NotAScope"'));
check("dead createZip build script is an error", badErrors.includes("pkg.scripts"));
check("missing logo asset is an error", badErrors.includes("pkg.logo"));
check("react runtime is a warning", badWarnings.includes("pkg.runtime"));
check(
  "pluginName mismatch is reported",
  messages.includes("window.Plugins.FixtureBad"),
  "the host merges window.Plugins[pluginName] and silently gets nothing",
);
check("missing icon asset is an error", badErrors.includes("icon"));
check(
  "commented-out icon is ignored",
  !messages.includes("also-missing.svg"),
  "comments must be stripped before scanning for references",
);
// --- item, message and dead-scope checks need a bundle that does register -----

const filterPkg = { ...badPkg, name: "fixture-filter", pluginName: "FixtureFilter", scopes: ["ContextMenu", "MainButton", "InfoPanel"], logo: "logo.svg", scripts: { build: "webpack && npx build-docspace-plugin" } };
delete filterPkg.runtime;

const filter = run(
  writeProject("filter", {
    pkg: filterPkg,
    bundle: badBundle.replace("window.Plugins.SomethingElse", "window.Plugins.FixtureFilter"),
    src: badSrc.replace("window.Plugins.SomethingElse", "window.Plugins.FixtureFilter"),
  }),
  ["--invoke"],
);

const filterMessages = filter.findings.map((f) => f.message).join("\n");

check(
  "usersType on a ContextMenu item is an error",
  filterMessages.includes("ContextMenu") && filterMessages.includes("host reads usersTypes"),
);
check(
  "usersTypes on a MainButton item is an error",
  filterMessages.includes("MainButton") && filterMessages.includes("host reads usersType for"),
);
check(
  "show-toast without toastProps is an error",
  filterMessages.includes('action "show-toast" without toastProps'),
);
check(
  "show-modal without modalDialogProps is an error",
  filterMessages.includes('action "show-modal" without modalDialogProps'),
);
check(
  "a scope whose items are never registered is an error",
  filterMessages.includes('scope "InfoPanel" is declared but addInfoPanelItem'),
);

// --- registration through a constant ------------------------------------------
//
// Plugins often lift the global name into a constant. Reading only the dotted
// form would reject a perfectly working plugin, which is worse than missing a
// broken one - hence this guard.

const constPkg = { ...goodPkg, name: "fixture-const", pluginName: "FixtureConst" };

const constSrc = `
const PLUGIN_GLOBAL_NAME = "FixtureConst";
window.Plugins = window.Plugins || {};
window.Plugins[PLUGIN_GLOBAL_NAME] = plugin;
addContextMenuItem(item);
getContextMenuItems();
const item = { icon: "logo.svg" };
`;

const viaConst = run(
  writeProject("const", {
    pkg: constPkg,
    bundle: goodBundle.replace(/FixtureGood/g, "FixtureConst"),
    src: constSrc,
  }),
);

check(
  "registration through a constant is accepted",
  !codes(viaConst, "ERROR").includes("registration"),
  `errors: ${codes(viaConst, "ERROR").join(", ")}`,
);

// --- a scope the portal does not know ----------------------------------------
//
// This one is worth guarding: a scope the SDK on a developer's disk exports but
// the portal cannot host lets the project compile, pack and upload without
// complaint - and then render nothing. A build error is far kinder than that.

const navPkg = {
  ...goodPkg,
  name: "fixture-nav",
  pluginName: "FixtureNav",
  scopes: ["ContextMenu", "Dashboard"],
};

const nav = run(
  writeProject("nav", {
    pkg: navPkg,
    bundle: goodBundle.replace(/FixtureGood/g, "FixtureNav"),
    src: goodSrc.replace(/FixtureGood/g, "FixtureNav"),
  }),
);

const navMessages = nav.findings.map((f) => f.message).join("\n");

check(
  "a scope outside the contract is rejected",
  !nav.ok &&
    codes(nav, "ERROR").includes("pkg.scopes") &&
    navMessages.includes("Dashboard"),
  `errors: ${codes(nav, "ERROR").join(", ")}`,
);
check(
  "the rejection lists the scopes that are supported",
  navMessages.includes("ContextMenu") && navMessages.includes("ArticleButton"),
);

// --- a bundle that throws ------------------------------------------------------
//
// The most expensive failure the host has: the portal awaits onLoadCallback
// during installation, so a throw there leaves no CSS, no items and an empty
// console. Softening it into a warning would hand the user a clean report for
// the one defect this whole tool exists to catch.

const throwingPlugin = (body) => `
window.Plugins.FixtureThrow = {
  status: "active", items: new Map(),
  onLoadCallback: async function () { ${body} },
  updateStatus: function (s) { this.status = s; },
  getStatus: function () { return this.status; },
  setOnLoadCallback: function (cb) { this.onLoadCallback = cb; },
  addContextMenuItem: function (i) { this.items.set(i.key, i); },
  getContextMenuItems: function () { return this.items; },
};
`;

const throwPkg = { ...goodPkg, name: "fixture-throw", pluginName: "FixtureThrow" };
const throwSrc = goodSrc.replace(/FixtureGood/g, "FixtureThrow");

const onLoadThrows = run(
  writeProject("throws", {
    pkg: throwPkg,
    bundle: throwingPlugin(`throw new Error("settings fetch failed");`),
    src: throwSrc,
  }),
);

check(
  "a throwing onLoadCallback is an error",
  !onLoadThrows.ok && codes(onLoadThrows, "ERROR").includes("runtime"),
  `errors: ${codes(onLoadThrows, "ERROR").join(", ")}`,
);

const topLevelThrows = run(
  writeProject("throws-top", {
    pkg: throwPkg,
    bundle: `throw new Error("bad top-level work");\n${throwingPlugin("")}`,
    src: throwSrc,
  }),
);

check(
  "a bundle that throws at module scope is an error",
  !topLevelThrows.ok && codes(topLevelThrows, "ERROR").includes("runtime"),
  `errors: ${codes(topLevelThrows, "ERROR").join(", ")}`,
);

// A global we failed to stub is our gap, not the plugin's - the portal has the
// real one. That case has to stay a warning, or every plugin touching an
// uncommon browser API would be reported as broken.

const missingApi = run(
  writeProject("missing-api", {
    pkg: throwPkg,
    bundle: throwingPlugin(`IntersectionObserver.observe();`),
    src: throwSrc,
  }),
);

check(
  "an unstubbed browser API stays a warning",
  missingApi.ok && codes(missingApi, "WARN").includes("runtime"),
  `errors: ${codes(missingApi, "ERROR").join(", ")}`,
);

// --- values the host compares exactly -----------------------------------------

const valuePkg = { ...goodPkg, name: "fixture-values", pluginName: "FixtureValues" };

const valueBundle = goodBundle
  .replace(/FixtureGood/g, "FixtureValues")
  .replace('usersTypes: ["Owner"]', 'usersTypes: ["admin"], devices: ["phone"]');

const values = run(
  writeProject("values", {
    pkg: valuePkg,
    bundle: valueBundle,
    src: goodSrc.replace(/FixtureGood/g, "FixtureValues"),
  }),
);

const valueMessages = values.findings.map((f) => f.message).join("\n");

check(
  "a usersTypes value outside the enum is an error",
  valueMessages.includes('usersTypes contains "admin"'),
  "the enum keys are camelCase but the host matches the PascalCase values",
);
check("a devices value outside the enum is an error", valueMessages.includes('contains "phone"'));

// --- the declarative tree the host renders without a net ----------------------

const uiPkg = { ...goodPkg, name: "fixture-ui", pluginName: "FixtureUi" };

// A modal with no onLoad (the SDK marks it required) holding a button with
// neither size nor onClick. Both throw during render, and the nearest error
// boundary is the portal shell.
const uiBundle = goodBundle.replace(/FixtureGood/g, "FixtureUi").replace(
  `return { actions: ["show-toast"], toastProps: [{ type: "success", title: "done" }] };`,
  `return { actions: ["show-modal"], modalDialogProps: {
         displayType: "modal",
         dialogBody: { children: [{ component: "button", props: { label: "Go" } }] },
         onClose: function () { return { actions: ["close-modal"] }; },
       } };`,
);

const ui = run(
  writeProject("ui", {
    pkg: uiPkg,
    bundle: uiBundle,
    src: goodSrc.replace(/FixtureGood/g, "FixtureUi"),
  }),
  ["--invoke"],
);

const uiMessages = ui.findings.map((f) => f.message).join("\n");

check("a modal without onLoad is an error", uiMessages.includes("onLoad is not a function"));
check(
  "a component missing a required prop is an error",
  uiMessages.includes("button without size") && uiMessages.includes("button without onClick"),
);

// --- values that compile against the SDK and render wrong on the portal --------
//
// ButtonSize.extraSmall emits "extra-small" where the host stylesheet only has
// "extraSmall"; InputSize.big/huge have no host styles at all; a comboBox is
// matched by label and crashes without keys; a string borderProp is ignored.

const visualPkg = { ...goodPkg, name: "fixture-visual", pluginName: "FixtureVisual" };

const visualBundle = goodBundle.replace(/FixtureGood/g, "FixtureVisual").replace(
  `return { actions: ["show-toast"], toastProps: [{ type: "success", title: "done" }] };`,
  `return { actions: ["show-modal"], modalDialogProps: {
         displayType: "modal",
         dialogBody: { borderProp: "1px solid red", children: [
           { component: "button", props: { label: "Go", size: "extra-small", onClick: function () {} } },
           { component: "input", props: { value: "", size: "big", onChange: function () {} } },
           { component: "comboBox", props: {
             options: [{ key: "a", label: "Same" }, { key: "b", label: "Same" }],
             selectedOption: { key: "a", label: "Same" },
           } },
           { component: "comboBox", props: {
             options: [{ label: "No key" }],
             selectedOption: { key: "x", label: "No key" },
           } },
         ] },
         onClose: function () { return { actions: ["close-modal"] }; },
         onLoad: async function () { return { newDialogBody: { children: [] } }; },
       } };`,
);

const visual = run(
  writeProject("visual", {
    pkg: visualPkg,
    bundle: visualBundle,
    src: goodSrc.replace(/FixtureGood/g, "FixtureVisual"),
  }),
  ["--invoke"],
);

const visualWarns = visual.findings.filter((f) => f.level === "WARN").map((f) => f.message).join("\n");
const visualErrors = visual.findings.filter((f) => f.level === "ERROR").map((f) => f.message).join("\n");

check(
  'the dead "extra-small" button size is a warning',
  visualWarns.includes('button size "extra-small"'),
);
check('the dead "big" input size is a warning', visualWarns.includes('input size "big"'));
check(
  "duplicate comboBox labels are a warning",
  visualWarns.includes("duplicate option labels"),
);
check(
  "a comboBox option without key is an error",
  visualErrors.includes("has no key"),
);
check(
  "a string borderProp is a warning",
  visualWarns.includes("borderProp is a CSS string"),
);

// --- a scope with no way to refresh itself ------------------------------------
//
// Every other scope can be filled after installation with an update*Items
// action. ArticleButton has none in the SDK, so an empty map there is terminal
// rather than merely suspicious - the advice to "register later" is impossible.

const abPkg = { ...goodPkg, name: "fixture-ab", pluginName: "FixtureAb", scopes: ["ArticleButton"] };

const abBundle = `
window.Plugins.FixtureAb = {
  status: "active", ab: new Map(),
  onLoadCallback: async function () {},
  updateStatus: function (s) { this.status = s; },
  getStatus: function () { return this.status; },
  setOnLoadCallback: function (cb) { this.onLoadCallback = cb; },
  addArticleButtonItem: function (i) { this.ab.set(i.key, i); },
  getArticleButtonItems: function () { return this.ab; },
};
`;

const ab = run(
  writeProject("article-button", {
    pkg: abPkg,
    bundle: abBundle,
    src: `window.Plugins.FixtureAb = plugin || {};\naddArticleButtonItem(item);\ngetArticleButtonItems();\n`,
  }),
);

check(
  "an empty ArticleButton map is an error, not a warning",
  !ab.ok &&
    ab.findings.some((f) => f.message.includes("no updateArticleButtonItems action to refresh it")),
  `errors: ${codes(ab, "ERROR").join(", ")}`,
);

// --- callbacks get the argument the host would pass ---------------------------
//
// Handing every callback a bare id made correct File plugins look like they
// throw, which trains people to ignore the warnings.

const filePkg = { ...goodPkg, name: "fixture-file", pluginName: "FixtureFile", scopes: ["File"] };

const fileBundle = `
window.Plugins.FixtureFile = {
  status: "active", files: new Map(),
  onLoadCallback: async function () {
    this.files.set(".thing", { extension: ".thing", fileTypeName: "Thing",
      onClick: async function (file) {
        return { actions: ["show-toast"], toastProps: [{ type: "info", title: file.title.toUpperCase() }] };
      } });
  },
  updateStatus: function (s) { this.status = s; },
  getStatus: function () { return this.status; },
  setOnLoadCallback: function (cb) { this.onLoadCallback = cb; },
  addFileItem: function (i) { this.files.set(i.extension, i); },
  getFileItems: function () { return this.files; },
};
`;

const file = run(
  writeProject("file", {
    pkg: filePkg,
    bundle: fileBundle,
    src: `window.Plugins.FixtureFile = plugin || {};\naddFileItem(item);\ngetFileItems();\n`,
  }),
  ["--invoke"],
);

check(
  "a File onClick reading its file argument does not look like a throw",
  file.ok && !file.findings.some((f) => f.message.includes("threw")),
  `findings: ${file.findings.map((f) => f.message).join(" | ")}`,
);

// --- action strings the host will not match -----------------------------------
//
// The same shape of mistake as usersTypes: ["owner"] - reaching for the enum key
// where the host compares the value. `Actions.showModal` is "show-modal".

const actionPkg = { ...goodPkg, name: "fixture-action", pluginName: "FixtureAction" };

const action = run(
  writeProject("action", {
    pkg: actionPkg,
    bundle: goodBundle
      .replace(/FixtureGood/g, "FixtureAction")
      .replace('actions: ["show-toast"]', 'actions: ["showToast"]'),
    src: goodSrc.replace(/FixtureGood/g, "FixtureAction"),
  }),
  ["--invoke"],
);

check(
  "an action given as the enum key is an error",
  !action.ok &&
    action.findings.some(
      (f) => f.message.includes('"showToast"') && f.message.includes('the value is "show-toast"'),
    ),
  action.findings.map((f) => f.message).join(" | "),
);

// --- drift between this tool and the installed SDK ----------------------------
//
// The tables in contract.mjs describe a released portal, not the SDK, so they
// cannot be generated from it. They can be *compared* to it, which is what turns
// "remember to check when a new SDK lands" into something that speaks up.

const fakeSdk = (dir, { version, extraAction, extraUserType }) => {
  const sdkDir = path.join(dir, "node_modules", "@onlyoffice", "docspace-plugin-sdk");
  fs.mkdirSync(sdkDir, { recursive: true });

  fs.writeFileSync(
    path.join(sdkDir, "package.json"),
    JSON.stringify({ name: SDK, version, type: "module", main: "index.js" }),
  );

  // Built from the contract itself, so "no extras" really means an SDK that
  // agrees with it - otherwise the quiet case would only look quiet by accident.
  const asEnum = (values) =>
    `{ ${values.map((v, i) => `k${i}: ${JSON.stringify(v)}`).join(", ")} }`;

  fs.writeFileSync(
    path.join(sdkDir, "index.js"),
    `export const UsersType = ${asEnum([...USERS_TYPES, ...(extraUserType ? [extraUserType] : [])])};
export const Devices = ${asEnum(DEVICES)};
export const Events = ${asEnum(EVENT_TYPES)};
export const Components = ${asEnum(Object.keys(COMPONENT_PROPS))};
export const Actions = ${asEnum([...KNOWN_ACTIONS, ...(extraAction ? [extraAction] : [])])};
`,
  );
};

const driftDir = writeProject("drift", {
  pkg: { ...goodPkg, name: "fixture-drift", pluginName: "FixtureDrift" },
  bundle: goodBundle.replace(/FixtureGood/g, "FixtureDrift"),
  src: goodSrc.replace(/FixtureGood/g, "FixtureDrift"),
});

fakeSdk(driftDir, { version: "2.1.0", extraAction: "show-settings-modal", extraUserType: "Guest" });

const drift = run(driftDir);
const driftMessages = drift.findings
  .filter((f) => f.code === "sdk-drift")
  .map((f) => f.message)
  .join("\n");

check(
  "a value the installed SDK added is reported",
  driftMessages.includes("Guest") && driftMessages.includes("show-settings-modal"),
  driftMessages || "no sdk-drift findings",
);
check(
  "drift does not fail the plugin, which is not at fault",
  drift.ok,
  `errors: ${codes(drift, "ERROR").join(", ")}`,
);

const majorDir = writeProject("drift-major", {
  pkg: { ...goodPkg, name: "fixture-major", pluginName: "FixtureMajor" },
  bundle: goodBundle.replace(/FixtureGood/g, "FixtureMajor"),
  src: goodSrc.replace(/FixtureGood/g, "FixtureMajor"),
});

fakeSdk(majorDir, { version: "3.0.0" });

const major = run(majorDir);

check(
  "an SDK major this tool was not written against is reported",
  major.findings.some((f) => f.code === "sdk-drift" && f.message.includes("3.0.0")),
  major.findings
    .filter((f) => f.code === "sdk-drift")
    .map((f) => f.message)
    .join(" | "),
);

// A project whose tables agree with its SDK must stay quiet, or the warning
// becomes noise everyone learns to skip.
const agreeDir = writeProject("drift-agree", {
  pkg: { ...goodPkg, name: "fixture-agree", pluginName: "FixtureAgree" },
  bundle: goodBundle.replace(/FixtureGood/g, "FixtureAgree"),
  src: goodSrc.replace(/FixtureGood/g, "FixtureAgree"),
});

fakeSdk(agreeDir, { version: "2.1.0" });

const agree = run(agreeDir);

check(
  "an SDK that matches the contract produces no drift noise",
  !agree.findings.some((f) => f.code === "sdk-drift"),
  agree.findings
    .filter((f) => f.code === "sdk-drift")
    .map((f) => f.message)
    .join(" | "),
);

// --- unbuilt project ----------------------------------------------------------

const unbuiltDir = writeProject("unbuilt", { pkg: goodPkg, bundle: goodBundle, src: goodSrc });
fs.rmSync(path.join(unbuiltDir, "dist"), { recursive: true, force: true });

const unbuilt = run(unbuiltDir);

check("unbuilt project warns instead of failing", unbuilt.ok && codes(unbuilt, "WARN").includes("dist"));

// --- summary ------------------------------------------------------------------

fs.rmSync(root, { recursive: true, force: true });

const failed = results.filter((r) => !r.ok);

console.log(`\n${results.length - failed.length}/${results.length} expectations passed`);

process.exit(failed.length > 0 ? 1 : 0);
