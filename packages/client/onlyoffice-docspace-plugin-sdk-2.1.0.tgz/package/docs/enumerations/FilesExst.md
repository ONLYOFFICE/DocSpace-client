# Enumeration: FilesExst

Defined in: [enums/Files.ts:42](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L42)

Defines the supported file extensions.

## Enumeration Members

### doc

> **doc**: `".doc"`

Defined in: [enums/Files.ts:45](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L45)

Microsoft Word document

***

### docx

> **docx**: `".docx"`

Defined in: [enums/Files.ts:47](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L47)

Microsoft Word document (XML-based)

***

### docm

> **docm**: `".docm"`

Defined in: [enums/Files.ts:49](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L49)

Microsoft Word macro-enabled document

***

### dotx

> **dotx**: `".dotx"`

Defined in: [enums/Files.ts:51](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L51)

Microsoft Word template

***

### odt

> **odt**: `".odt"`

Defined in: [enums/Files.ts:53](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L53)

OpenDocument text format

***

### fodt

> **fodt**: `".fodt"`

Defined in: [enums/Files.ts:55](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L55)

OpenDocument flat XML text format

***

### ott

> **ott**: `".ott"`

Defined in: [enums/Files.ts:57](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L57)

OpenDocument text template

***

### rtf

> **rtf**: `".rtf"`

Defined in: [enums/Files.ts:59](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L59)

Rich Text Format

***

### txt

> **txt**: `".txt"`

Defined in: [enums/Files.ts:61](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L61)

Plain text

***

### pdf

> **pdf**: `".pdf"`

Defined in: [enums/Files.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L63)

Portable Document Format

***

### docxf

> **docxf**: `".docxf"`

Defined in: [enums/Files.ts:65](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L65)

Form document (DOCX-based)

***

### oform

> **oform**: `".oform"`

Defined in: [enums/Files.ts:67](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L67)

Form document (OpenDocument-based)

***

### xls

> **xls**: `".xls"`

Defined in: [enums/Files.ts:71](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L71)

Microsoft Excel spreadsheet

***

### xlsx

> **xlsx**: `".xlsx"`

Defined in: [enums/Files.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L73)

Microsoft Excel spreadsheet (XML-based)

***

### xlsm

> **xlsm**: `".xlsm"`

Defined in: [enums/Files.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L75)

Microsoft Excel macro-enabled spreadsheet

***

### ods

> **ods**: `".ods"`

Defined in: [enums/Files.ts:77](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L77)

OpenDocument spreadsheet

***

### ots

> **ots**: `".ots"`

Defined in: [enums/Files.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L79)

OpenDocument spreadsheet template

***

### ppt

> **ppt**: `".ppt"`

Defined in: [enums/Files.ts:83](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L83)

Microsoft PowerPoint presentation

***

### pptx

> **pptx**: `".pptx"`

Defined in: [enums/Files.ts:85](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L85)

Microsoft PowerPoint presentation (XML-based)

***

### pptm

> **pptm**: `".pptm"`

Defined in: [enums/Files.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L87)

Microsoft PowerPoint macro-enabled presentation

***

### odp

> **odp**: `".odp"`

Defined in: [enums/Files.ts:89](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L89)

OpenDocument presentation

***

### otp

> **otp**: `".otp"`

Defined in: [enums/Files.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L91)

OpenDocument presentation template

***

### pps

> **pps**: `".pps"`

Defined in: [enums/Files.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L93)

PowerPoint show format

***

### ppsx

> **ppsx**: `".ppsx"`

Defined in: [enums/Files.ts:95](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L95)

PowerPoint show format (XML-based)

***

### pot

> **pot**: `".pot"`

Defined in: [enums/Files.ts:97](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L97)

PowerPoint template

***

### avi

> **avi**: `".avi"`

Defined in: [enums/Files.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L103)

Video file (AVI format)

***

### flv

> **flv**: `".flv"`

Defined in: [enums/Files.ts:105](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L105)

Video file (FLV format)

***

### mkv

> **mkv**: `".mkv"`

Defined in: [enums/Files.ts:107](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L107)

Video file (MKV format)

***

### mov

> **mov**: `".mov"`

Defined in: [enums/Files.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L109)

Video file (MOV format)

***

### mp4

> **mp4**: `".mp4"`

Defined in: [enums/Files.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L111)

Video file (MP4 format)

***

### mpg

> **mpg**: `".mpg"`

Defined in: [enums/Files.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L113)

Video file (MPEG format)

***

### webm

> **webm**: `".webm"`

Defined in: [enums/Files.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L115)

Video file (WebM format)

***

### m2ts

> **m2ts**: `".m2ts"`

Defined in: [enums/Files.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L117)

Video file (M2TS format)

***

### dvd

> **dvd**: `".dvd"`

Defined in: [enums/Files.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L119)

Video file (DVD format)

***

### svg

> **svg**: `".svg"`

Defined in: [enums/Files.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L121)

Scalable Vector Graphics

***

### csv

> **csv**: `".csv"`

Defined in: [enums/Files.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L125)

Comma-separated values

***

### djvu

> **djvu**: `".djvu"`

Defined in: [enums/Files.ts:127](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L127)

DjVu format

***

### epub

> **epub**: `".epub"`

Defined in: [enums/Files.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L129)

E-book format (EPUB)

***

### fb2

> **fb2**: `".fb2"`

Defined in: [enums/Files.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L131)

E-book format (FB2)

***

### pb2

> **pb2**: `".pb2"`

Defined in: [enums/Files.ts:133](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L133)

E-book format (PB2)

***

### iaf

> **iaf**: `".iaf"`

Defined in: [enums/Files.ts:135](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L135)

Archive format (IAF)

***

### ics

> **ics**: `".ics"`

Defined in: [enums/Files.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L137)

Calendar format (ICS)

***

### mht

> **mht**: `".mht"`

Defined in: [enums/Files.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L139)

Web archive (MHT)

***

### xps

> **xps**: `".xps"`

Defined in: [enums/Files.ts:141](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L141)

XML Paper Specification

***

### xml

> **xml**: `".xml"`

Defined in: [enums/Files.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L143)

Extensible Markup Language
