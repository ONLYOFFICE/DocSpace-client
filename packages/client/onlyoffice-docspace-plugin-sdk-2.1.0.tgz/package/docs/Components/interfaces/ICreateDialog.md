# Interface: ICreateDialog

Defined in: [interfaces/components/ICreateDialog.ts:118](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L118)

Modal dialog for creating certain item (file, folder, etc.).
The user gets the full access to the functionality but cannot control the layout.

## Example

Document creation dialog with multiple format options

```typescript
const newDocumentDialog: ICreateDialog = {
  title: "Create New Document",
  startValue: "Untitled",
  visible: true,
  options: [
    {
      key: "docx",
      label: "Word Document",
      icon: "word.svg"
    },
    {
      key: "xlsx",
      label: "Excel Spreadsheet",
      icon: "excel.svg"
    },
    {
      key: "pptx",
      label: "PowerPoint Presentation",
      icon: "powerpoint.svg"
    }
  ],
  selectedOption: {
    key: "docx",
    label: "Word Document",
    icon: "word.svg"
  },
  onSelect: (option) => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        selectedOption: option,
        extension: option.key
      }
    };
  },
  onSave: async (e, value) => {
    try {
      // Create the document
      await createDocument(value, selectedOption.key);

      return {
        actions: [Actions.updateProps, Actions.showToast],
        newProps: {
          visible: false
        },
        toastProps: [{
          title: "Success",
          type: "success",
          message: `Document "${value}" created successfully`
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Error",
          type: "error",
          message: "Failed to create document. Please try again."
        }]
      };
    }
  },
  onCancel: (e) => {
    // Clean up any temporary state if needed
  },
  onClose: (e) => {
    // Additional cleanup or analytics
  },
  isCreateDialog: true,
  extension: "docx"
}
```

## Behavior

Callback functions for handling user interactions, validation, save, cancel, and error events.

### onSelect()?

> `optional` **onSelect**: (`option`) => `void` \| `IMessage`

Defined in: [interfaces/components/ICreateDialog.ts:180](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L180)

Sets a function which is triggered whenever the modal dialog option is selected.

#### Parameters

##### option

[`IComboBoxItem`](IComboBoxItem.md)

#### Returns

`void` \| `IMessage`

***

### onChange()?

> `optional` **onChange**: (`value`) => `void` \| `IMessage`

Defined in: [interfaces/components/ICreateDialog.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L187)

Sets a function which is triggered whenever the input value changes.

#### Parameters

##### value

`string`

#### Returns

`void` \| `IMessage`

***

### onSave()?

> `optional` **onSave**: (`e`, `value`) => `void` \| `Promise`\<`void`\> \| `IMessage` \| `Promise`\<`IMessage`\>

Defined in: [interfaces/components/ICreateDialog.ts:194](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L194)

Sets a function which is triggered whenever the data in the modal dialog is saved.

#### Parameters

##### e

`any`

##### value

`string`

#### Returns

`void` \| `Promise`\<`void`\> \| `IMessage` \| `Promise`\<`IMessage`\>

***

### onCancel()?

> `optional` **onCancel**: (`e`) => `void`

Defined in: [interfaces/components/ICreateDialog.ts:204](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L204)

Sets a function which is triggered whenever an action in the modal dialog is canceled.

#### Parameters

##### e

`any`

#### Returns

`void`

***

### onClose()?

> `optional` **onClose**: (`e`) => `void`

Defined in: [interfaces/components/ICreateDialog.ts:211](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L211)

Sets a function which is triggered whenever the modal dialog is closed.

#### Parameters

##### e

`any`

#### Returns

`void`

***

### onError()?

> `optional` **onError**: (`e`) => `void` \| `Promise`\<`void`\> \| `IMessage` \| `Promise`\<`IMessage`\>

Defined in: [interfaces/components/ICreateDialog.ts:218](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L218)

Sets a function which is triggered whenever an error occurs during the onSave operation.

#### Parameters

##### e

`any`

#### Returns

`void` \| `Promise`\<`void`\> \| `IMessage` \| `Promise`\<`IMessage`\>

## Content

Properties that define the dialog's title, input value, options, extension, and displayed text.

### title

> **title**: `string`

Defined in: [interfaces/components/ICreateDialog.ts:124](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L124)

Defines the modal dialog title.

***

### startValue

> **startValue**: `string`

Defined in: [interfaces/components/ICreateDialog.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L131)

Defines the modal dialog start value.

***

### options?

> `optional` **options**: [`IComboBoxItem`](IComboBoxItem.md)[]

Defined in: [interfaces/components/ICreateDialog.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L159)

Defines an array of the modal dialog options.

***

### selectedOption?

> `optional` **selectedOption**: [`IComboBoxItem`](IComboBoxItem.md)

Defined in: [interfaces/components/ICreateDialog.ts:166](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L166)

Defines the selected modal dialog option.

***

### extension?

> `optional` **extension**: `string`

Defined in: [interfaces/components/ICreateDialog.ts:239](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L239)

Defines an extension of an item which will be created (file, folder, etc.).

## State

Properties that control the dialog's visibility, button states, error states, and focus behavior.

### visible

> **visible**: `boolean`

Defined in: [interfaces/components/ICreateDialog.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L138)

Specifies if the modal dialog is visible or not.

***

### isCreateDisabled?

> `optional` **isCreateDisabled**: `boolean`

Defined in: [interfaces/components/ICreateDialog.ts:145](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L145)

Specifies if the create button is disabled.

***

### isCloseAfterCreate?

> `optional` **isCloseAfterCreate**: `boolean`

Defined in: [interfaces/components/ICreateDialog.ts:152](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L152)

Specifies if the modal dialog should be closed after the create action.

***

### errorText?

> `optional` **errorText**: `string`

Defined in: [interfaces/components/ICreateDialog.ts:173](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L173)

Error text to display when validation fails or an error occurs.

***

### isCreateDialog

> **isCreateDialog**: `boolean`

Defined in: [interfaces/components/ICreateDialog.ts:225](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L225)

Specifies if this modal dialog is for creating certain item (file, folder, etc.).

***

### isAutoFocusOnError?

> `optional` **isAutoFocusOnError**: `boolean`

Defined in: [interfaces/components/ICreateDialog.ts:232](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L232)

Specifies if this modal dialog should automatically focus on the error input field when an error occurs during the onSave operation.
