# Interface: IText

Defined in: [interfaces/components/IText.ts:80](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L80)

Plain text.

## Examples

Bold centered heading with custom typography

```typescript
const heading: IText = {
  text: "Document Management",
  fontSize: "24px",
  fontWeight: 600,
  lineHeight: "32px",
  color: "#333333",
  isBold: true,
  noSelect: true,
  textAlign: "center"
}
```

Truncated description with hover tooltip

```typescript
const description: IText = {
  text: "This is a long description that will be truncated if it exceeds the container width...",
  fontSize: "14px",
  lineHeight: "20px",
  color: "#666666",
  truncate: true,
  title: "Full description shown on hover"
}
```

Inline processing status with custom styling

```typescript
const status: IText = {
  text: "Processing",
  fontSize: "12px",
  isInline: true,
  isItalic: true,
  color: "#0066cc",
  display: "inline-flex",
  fontWeight: 500
}
```

## Appearance

Properties that control typography, styling, alignment, and visual presentation of the text.

### fontSize?

> `optional` **fontSize**: `string`

Defined in: [interfaces/components/IText.ts:97](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L97)

Defines the text font size

***

### fontWeight?

> `optional` **fontWeight**: `string` \| `number`

Defined in: [interfaces/components/IText.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L103)

Defines the text font weight

***

### truncate?

> `optional` **truncate**: `boolean`

Defined in: [interfaces/components/IText.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L109)

Specifies whether the word wrapping is set

***

### isBold?

> `optional` **isBold**: `boolean`

Defined in: [interfaces/components/IText.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L115)

Specifies whether the text font weight is set to bold

***

### isItalic?

> `optional` **isItalic**: `boolean`

Defined in: [interfaces/components/IText.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L121)

Specifies whether the text style is set to italic

***

### isInline?

> `optional` **isInline**: `boolean`

Defined in: [interfaces/components/IText.ts:127](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L127)

Specifies whether the "display: inline-block" property is set

***

### textAlign?

> `optional` **textAlign**: `string`

Defined in: [interfaces/components/IText.ts:133](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L133)

Specifies whether the "text-align" property is set

***

### noSelect?

> `optional` **noSelect**: `boolean`

Defined in: [interfaces/components/IText.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L139)

Specifies whether the text selection is disabled

***

### display?

> `optional` **display**: `string`

Defined in: [interfaces/components/IText.ts:145](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L145)

Specifies whether the "display" property is set

***

### lineHeight?

> `optional` **lineHeight**: `string`

Defined in: [interfaces/components/IText.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L151)

Defines the text line height

***

### color?

> `optional` **color**: `string`

Defined in: [interfaces/components/IText.ts:157](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L157)

Defines the text color

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/IText.ts:165](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L165)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Content

Properties that define the text content, title, and displayed information.

### text

> **text**: `string`

Defined in: [interfaces/components/IText.ts:85](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L85)

Defines the text

***

### title?

> `optional` **title**: `string`

Defined in: [interfaces/components/IText.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L91)

Defines the text title
