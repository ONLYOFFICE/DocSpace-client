# Enumeration: ButtonSize

Defined in: [interfaces/components/IButton.ts:26](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L26)

Defines button size options

## Enumeration Members

### extraSmall

> **extraSmall**: `"extra-small"`

Defined in: [interfaces/components/IButton.ts:28](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L28)

Extra small button size

***

### small

> **small**: `"small"`

Defined in: [interfaces/components/IButton.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L30)

Small button size

***

### normal

> **normal**: `"normal"`

Defined in: [interfaces/components/IButton.ts:32](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L32)

Normal button size

***

### medium

> **medium**: `"medium"`

Defined in: [interfaces/components/IButton.ts:34](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L34)

Medium button size
