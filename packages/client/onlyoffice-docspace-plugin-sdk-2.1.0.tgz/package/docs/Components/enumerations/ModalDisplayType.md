# Enumeration: ModalDisplayType

Defined in: [interfaces/components/IModalDialog.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L27)

The supported modal dialog types.

## Enumeration Members

### modal

> **modal**: `"modal"`

Defined in: [interfaces/components/IModalDialog.ts:29](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L29)

Modal dialog displayed in the center of the screen

***

### aside

> **aside**: `"aside"`

Defined in: [interfaces/components/IModalDialog.ts:31](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L31)

Modal dialog displayed as a side panel
