# Enumeration: ToastType

Defined in: [interfaces/components/IToast.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L24)

The supported toast types.

## Enumeration Members

### success

> **success**: `"success"`

Defined in: [interfaces/components/IToast.ts:26](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L26)

Success toast with green color scheme

***

### error

> **error**: `"error"`

Defined in: [interfaces/components/IToast.ts:28](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L28)

Error toast with red color scheme

***

### warning

> **warning**: `"warning"`

Defined in: [interfaces/components/IToast.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L30)

Warning toast with yellow color scheme

***

### info

> **info**: `"info"`

Defined in: [interfaces/components/IToast.ts:32](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L32)

Info toast with blue color scheme
