# Type Alias: TSelectorLifecycleEvents

> **TSelectorLifecycleEvents** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:511](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L511)

Lifecycle callback properties for selectors.

## Behavior

### onLoad()?

> `optional` **onLoad**: () => `TReturnMessage`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:517](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L517)

A callback function that is triggered when the selector is loaded.

#### Returns

`TReturnMessage`

***

### onClose()?

> `optional` **onClose**: () => `TReturnMessage`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:523](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L523)

A callback function that is triggered when the selector is closed.

#### Returns

`TReturnMessage`
