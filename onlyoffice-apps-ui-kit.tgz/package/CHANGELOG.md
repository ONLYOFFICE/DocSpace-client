# Change Log

## Unreleased

Every story now has a play function, and the faults they turned up are fixed below, most of
them keyboard and screen-reader gaps. Several change element types, roles, test ids or event
timing; each such change is listed under _Changed_, so read it before upgrading.

### Changed

- **`SearchInput`'s `id` is on the `<input>` alone.** It was set on the outer `<div>` too, so the
  page held the id twice and a `<label htmlFor>` or a `FieldContainer`'s `labelFor` found the
  `<div>` first and named nothing. The label now names the field. A selector or a test that
  found the outer element by `#id` finds the field instead; use `dataTestId` for the block
- **`Button` keeps a passed `aria-label`, `aria-disabled` and `aria-busy`.** All three were
  overwritten: the name always came from `label`, so an icon-only button could not be named. A
  passed `aria-label` now wins over `label`, which stays the fallback. `isDisabled` and
  `isLoading` still set the other two to `true`. Drop an `aria-label` that only repeats `label`
  in another language, or the button is named in that language
- **`ProgressBar` keeps a passed `aria-label` and `aria-busy`.** Both were overwritten: the name
  always came from `label`, and `aria-busy` was dropped unless `isInfiniteProgress` was set. A
  passed `aria-label` now wins over `label`, which stays the fallback
- **`AddButton` puts a passed `aria-*` on the wrapper that has the role.** It landed on the inner
  square, a `<div>` with no role, so it could not name or describe the button. A passed
  `aria-disabled` and `aria-busy` are kept unless `isDisabled` or `isLoading` sets them. Read them
  from `selector-add-button-container`, not from the square
- **`Tabs` puts a passed `aria-*` on the tab list.** It landed on the outer `<div>`, so the tab
  list could not be named. Name it with `aria-label` or `aria-labelledby`; read the attributes
  from the `tablist`, not from the wrapper
- **`TabItem` keeps its own `aria-selected` over a passed one.** The rest of the props were spread
  after it, so a passed `aria-selected` won over the pill's state
- **`ThemeProviderComponent` hands the page back when it unmounts.** It left `data-theme`,
  `data-dir`, the body classes and every custom property behind. Now the provider mounted last
  writes the page, and when it goes the one around it writes again, or the page returns to what it
  was before any provider. A colour scheme without `main`, or none, takes the previous accent off
  instead of keeping it. A theme without `isBase` is light in the React context too, as it already
  was in the body class
- **`ImageEditor`'s test ids are `data-testid`, and its file input has an id of its own.** The
  outer element and the cropper wrapper carried `image-editor` and `image-cropper-wrapper` under
  the misspelt `data-test-id`; select them with `getByTestId` now. The hidden input's fixed id
  `customFileInput`, which a page's own upload input often carries too, is now generated per
  editor: reach the input as the `input[type="file"]` inside the replace control
- **`Filter`'s `onSortButtonClick` gets `true` when the sort menu opens and `false` when it
  closes.** It got the opposite, and `true` once on mount. The first render now reports nothing.
  A handler that relied on the old values, such as one that hides a button while the menu is open
  with `setVisible(value)`, needs `setVisible(!value)`
- **`Navigation`'s `hideInfoPanel` is a `boolean`.** It was typed as a callback but never called:
  any truthy value hid the info panel toggle, so passing the handler the type asked for hid the
  button. Pass `true` to hide it; a function no longer type-checks, and passing one still hides it
- **`EmptyView`'s title and description sit in a `<div>`, not a `<header>`.** Outside a `main`,
  `section` or `article` the `<header>` was a `banner` landmark, a second one beside the page's
  own. The view now adds no landmark; a selector for `header` inside it finds nothing, while the
  class stays
- **Every component's README, prop JSDoc and story texts follow the documentation rules, and what
  they said wrong is corrected.** The text changed, not the components: the defects the rewrite
  found are under _Fixed_. A corrected statement may be one your code relied on. `Button`'s
  `accent` has no accent border, its `ref` is always the `<button>`, and a passed `aria-label` is
  overwritten even without `label`. `ContextMenu` reads `global` and `autoZIndex`.
  `SelectionArea`'s examples put an item's key in `data-value`, where it reads `value`.
  `DragAndDrop` has `role="presentation"` and no keyboard, not `role="button"`. The controls of
  `Filter`, `Row` and `Table` that were called mouse-only take the keyboard. `ThemeProvider` writes
  the React context too
- **`FileTile`'s `--tile-option-button-padding-end` is now `--tile-option-button-margin-end`,
  default `8px`.** The actions button pads its icon alike on every side, so its keyboard focus
  ring sits around the icon, and the room to the tile's edge is a margin after it. The space to
  the edge is the same as before: an old padding of `X` is a margin of `X - 8px` (`8px` was
  `16px`, `0px` was `8px`). A consumer still setting the old name sets nothing
- **React and React DOM 19.2 are required.** The peer range moves from `^19.0.0` to `^19.2.0`:
  the kit calls `useEffectEvent` (Selector's list, `useUnmount`, `useCloseOnAnchorCovered`, the
  AI agent's platform provider), which React 19.0 and 19.1 do not export. A consumer on those
  versions gets a peer warning on install and a crash where the hook is reached
- **`ModalDialog` and `Aside` keep the keyboard focus inside while open.** The new
  `useFocusTrap` hook (`hooks/useFocusTrap`) takes Tab and Shift+Tab on the document while the
  container is open: the last stop wraps to the first and back, and the page behind is out of
  reach; of nested traps only the top one acts. Between the ends the focus moves in the browser's
  own order, positive tabIndex values first, so a dialog that sets them keeps its order. `Aside`'s `<aside>` carries `tabIndex={-1}`, so
  a panel with nothing to tab to holds the focus itself. A consumer that relied on tabbing out of
  an open dialog or panel no longer can
- **`Filter`'s tags are keyboard buttons.** A value tag is `role="button"` with `aria-pressed`,
  "Other" is one with `aria-haspopup="dialog"`; both take `tabIndex={0}`, Enter and Space, and a
  focus ring. The panel used to offer the keyboard only its close cross and Cancel. Escape on the
  selector step that "Other" opens goes back to the filter, as its arrow does, instead of closing
  the whole panel. When that step closes - a pick, the arrow or Escape - the focus goes to the
  tag that opens the group's selector rather than the page's body; a picked value's label opens
  the selector again and its cross (named "Remove") clears the value, each a Tab stop of its own
- **Escape closes one layer at a time.** `Selector` (with an `onCancel`) and the "New" row's menu
  consume the Escape they close on, keyup included: a selector opened from a `ModalDialog` used
  to close that dialog along with itself, as the dialog closes on an Escape keyup on the window.
  The "New" menu's Enter is consumed the same way, so picking an entry never also submits the
  selector
- **`Aside` takes the focus when it opens and gives it back when it closes**, as `ModalDialog`
  already did. Both use the new `useFocusReturn` hook (`hooks/useFocusReturn`): the container
  takes the focus unless its content focused a control of its own, and on close the focus goes
  back to the element that had it before, if it is still in the page. A panel used to leave the
  focus behind its backdrop on open and drop it on the page's body on close
- **`Selector`'s list is a listbox and takes the keyboard.** The scroll container is one Tab stop
  (`role="listbox"`, named by the header's title, `aria-activedescendant` on the row the keyboard
  is on). Focused, it marks the selected row on screen or the first row; the arrows, Home and
  End move between the rows that can be picked, and Enter or Space click the row - open a
  folder, pick an item, start "New". Enter on the row already picked in single select still
  submits. The row's checkbox and the "New" row's button are no Tab stops of their own, the
  "New" row's menu takes the arrows and Escape, and the new-name field gives the focus back to
  the list when it goes. The search box lost its `tabIndex={1}`. A consumer test that pressed
  Enter in the focused list to submit now picks the marked row unless it is the picked one. A
  row pressed with the pointer takes the keyboard off its row: Enter submits that pick, as it
  did before, and the next arrow goes on from the row pressed. A dimmed list (a refresh under
  way) takes the arrows but not Enter or Space, as the pointer cannot reach it. Enter and Escape
  in the new-name row are consumed with their keyup, so the row no longer closes the dialog
  around the selector or submits the selector along with it
- **`Tabs` ties each tab to its panel.** The body is `role="tabpanel"`, labelled by the selected
  tab, which points at it with `aria-controls`; a panel with nothing to tab to is a Tab stop
  (`tabIndex={0}`). The segmented bar's scroll arrows left the Tab order, so Tab goes from the
  bar straight into the panel
- **Focus rings on the keyboard's controls.** `Checkbox`, `RadioButton`, `ToggleButton`,
  `FileInput`, `ComboBox`, `GroupMenuItem` and `Article`'s back button draw a 2px accent ring
  under `:focus-visible` (themable through `--checkbox-focus-ring-color`,
  `--radio-button-focus-ring-color`, `--toggle-button-focus-ring-color`,
  `--file-input-focus-ring-color`, `--combobox-focus-ring-color`); `Article`'s back button and
  `PasswordInput`'s eye (named "Show" or "Hide", through `InputBlock`'s new `iconAriaLabel`) are
  keyboard buttons now
- **A `Link` with an `onClick` and no `href` is a Tab stop.** It used to be out of the keyboard's
  reach; it now takes `tabIndex={0}` and a key handler. An `action` link is `role="button"`,
  pressed by Enter and Space, and a `page` link `role="link"`, followed by Enter. Every such link
  a consumer renders gains a Tab stop: pass `tabIndex={-1}` where something around the link is
  the control already, or `role` or `onKeyDown` to wire the keyboard yourself. A `tabIndex` of 0
  or more only places the stop: the keys still press the link
- **Two inner controls left the Tab order.** `Dropzone`'s link is `tabIndex={-1}`, as the area
  around it is the keyboard's button already, and `DropDownItem`'s external-link icon is
  `tabIndex={-1}` when it has no `onClickExternalLink`, where it did nothing on a press
- **`ComboBox` walks the rows of marked components with the arrows.** Custom `advancedOptions`
  were walked only when their children were `DropDownItem`s; a component marked with
  `markAsDropDownItem` (see _Added_) counts as one too
- **`FilesSelector` lists AI rooms instead of AI agents at its root.** `withAIAgentsTreeFolder`
  is gone; `withAIRoomsTreeFolder` (on by default) lists the AI rooms root (`FolderType.AiHub`)
  after Forms, whenever the portal serves it. The section holds the Instructions and Knowledge
  rooms, never the AI projects, which hold no files, and offers no room creation or Recent /
  Favorites rows. With `roomsSectionTypes` it keeps only the AI types named there, moves them
  out of the Rooms section, and is left out when it names neither. A host that passed
  `withAIAgentsTreeFolder` drops it. The chat's save dialog turns the section off: neither room
  type takes a chat export.
- **`FilesSelector` has no AI agents list any more.** `onCreateAIAgent` and
  `agentsEmptyDescription` are gone, and `getIsDisabled`, `initSelectedItemType` and
  `setSelectedItemType` take `"rooms" | "files"` only: the `"agents"` item type could only be
  reached from the AI agents root. A host that compared against `"agents"` drops that check.
  `AIAgentSelector` keeps its own agents list.
- **`FolderType.AiHub` is 41 and `FolderType.AiProjects` is gone**, after the server moved the AI
  projects under the AI rooms root: one root now keeps the Instructions rooms, the Knowledge rooms
  and the AI projects
- **Several context and knowledge rooms per chat**, on `@onlyoffice/ai-chat` 1.0.2:
  `AiChatPresetSettings` carries `contextRooms` and `knowledgeRooms` (arrays) in place of
  `contextRoom` / `knowledgeRoom`; `AiChatPanelSave` hands the host every connected room;
  `ContextRoomSync` connects each offered room that holds skills and `ContextRoomWatcher`
  follows every connected room on its own (one losing its skills is disconnected alone)
- `@onlyoffice/ai-chat` peer requirement raised to `^1.0.2`
- **`AiAgentProviders`' `entityId` is the AI project the chat is open in, `contextEntityId` the
  location.** With the AI agents gone, threads are global per user and nothing but a project
  scopes the chat; the folder or room the user is in goes in `contextEntityId`, which the AI
  service uses for the prompt's location line and for generated files, and device uploads and
  drops follow it too (`contextEntityId ?? entityId`, else My documents). A connected
  Instructions room no longer becomes the round's scope (`contextRoomScopesRounds` off): it
  contributes its skills only. `AiChatStore.folderContextPickerEnabled` and the composer's
  empty Context slot are removed; the context folder is picked in the AI project itself
- **`Uploader`'s progress bar moves while a chunk is being sent.** The percentage used to grow
  only when a whole chunk (5 MB by default) had been answered, so a file under one chunk went
  from 0 to done in a single step; it now also counts the bytes of chunks still on their way,
  from axios's upload progress. `onUploadProgress` is unchanged and still reports per chunk
- **`ComboBox`'s `onToggle` may receive a keyboard event.** The keys that open and close the
  list call it too, so its first argument is typed
  `React.MouseEvent<HTMLDivElement> | React.KeyboardEvent<HTMLDivElement>`. A handler declared
  to take only a mouse event no longer compiles, and one that reads `clientX` or `button` has
  to check which event it got
- **The segmented `Tabs` bar is a real tab list and no longer takes the Tab key.** It used to
  listen for Tab on `window`, cancel it and pull focus onto itself, so a keyboard user could not
  leave it (WCAG 2.1.2). It is now `role="tablist"` with `role="tab"`, `aria-selected` and
  `aria-disabled`, one Tab stop (roving `tabindex`, on the selected tab), and a key handler on the
  list itself: arrows (swapped in RTL), Home and End move the focus, Enter or Space selects and
  swallows its own `keyup`, so a field the new content focuses does not get it, Tab moves on.
  `PrimaryTabs` follows the same model. Keyboard navigation no longer needs `hotkeysId`, which
  now only adds its `secondary-tabs-scroll-<hotkeysId>` class, and no `...-undefined` class is set without it. The
  document-wide `mouseup` listener is gone, and the keyboard highlight is drawn on
  `:focus-visible` instead of the `focused` class
- **`Loader` is a `role="status"` region and draws the oval by default.** Its `label` is the
  region's visually hidden text for every animation type (`rombs` included), defaulting to
  `Common:LoadingProcessing` ("Loading..."); the animations are `aria-hidden` and lose their
  built-in English titles ("dual ring", "oval", "track"), and the wrapper no longer sets
  `aria-busy`. A `Loader` without `type` now draws a 40px oval where it used to render an empty
  span, and `Loader.default` is `{ type: oval, size: "40px", label: "Loading..." }` instead of
  `{ type: base, label: "Loading content, please wait." }`; `LoaderTypes.base` still renders the
  label as visible text, which without a `label` is now "Loading...". Every loader without
  `isDecorative` adds that hidden text to whatever it sits in, a table cell included. A loader
  inside a control takes the new `isDecorative` prop, which leaves the animation alone and
  `aria-hidden`, so the status text does not become part of the control's name; `Button`, the
  combo box, `AddButton`, `FileInput`, `Dropzone`, rows and tiles use it, and a loader you place
  inside your own button or busy row should too.
- **`ErrorContainer` writes fewer fixed element ids.** The `button-container`, `button` and
  illustration ids (`background`, `birds`, `baloon`, ...) are gone; the parts are styled through
  module classes. `container-inner`, `header`, `text` and `customized-text` stay, because the
  portal's stylesheets select them (the preparation portal dialog sizes the illustration through
  `#container-inner`); two error pages in one document still share those four. A stylesheet or
  test that targeted one of the removed ids must select by role or by the outer element's
  `className` instead.
- **`Card`'s outer element is a `<section>`, and a string `title` is a heading.** Its `<header>`
  and `<footer>` no longer become page-level `banner` / `contentinfo` landmarks. A string `title`
  renders as an `<h3>` (new `titleLevel` prop for another level) with the same look; a node
  `title` is rendered as given. A selector written against `div` for the card or the title needs
  updating.
- **The `Tags` create tag's test id is `tag_item_create`**, not `tag_item_`, and it no longer
  renders an empty label element
- **`RoomIcon`'s hidden file input no longer has the id `customFileInput`.** The id is generated
  per instance, so two editable tiles no longer share one and the client's
  `document.getElementById("customFileInput")` lookups stop finding the logo input. Use the ref
  the upload entry of `model` is handed, or `data-testid="customFileInput"`
- **`Avatar` is a button only when a click does something.** With `onClick`, or when editable
  (`onChangeFile` without `noClick`), it carries `role="button"`, `tabindex="0"` and an
  `aria-label` from `userName`, and Enter and Space click it; otherwise it has no role at all,
  where it used to claim `role="button"` always. A picture's `alt` is `userName` (empty without
  one) instead of the literal `"avatar"`, and the hidden file input's id is generated per
  instance instead of `customAvatarInput`
- **`MCPIcon` is one image named after its server.** The tile is `role="img"` with
  `aria-label` set to `title`, with or without a picture; the `<img>` inside has `alt=""`
  instead of the fixed `"mcp icon"`, and the letter is hidden, so a screen reader no longer
  reads a bare letter. With an empty `title` the icon is `aria-hidden`
- **`MainButton.model` is optional with `isDropdown={false}`, and `opened` no longer reaches the DOM.** `opened` was never read and is now deprecated.
- **`MainButtonMobile` is operable from the keyboard and reports every open and close.** The floating button carries `aria-haspopup="menu"` and `aria-expanded`; the sheet is a `menu` of `menuitem`s that the arrow keys, Home, End, Enter and Escape operate; the alert badge is a button named "Alert" with `withAlertClick`. `onClose` now fires whenever the sheet closes (button, backdrop, item, Escape, Back) and never on opening, regardless of `isOpenButton`; the new `onOpen` reports opening. `isOpenButton` and five other ignored props are deprecated.
- **The `QuickActions` strip is a horizontal toolbar.** The arrow keys (mirrored in RTL), Home and End move focus between tiles and scroll the focused tile into view; Tab still visits every tile.
- **`TimePicker`'s fields are `type="text"` and take translated names.** They were
  `type="search"` and were announced as search fields. New `ariaLabel`, `hoursLabel` and
  `minutesLabel` props name the group and the fields (defaults "Time picker", "Hours",
  "Minutes"); `hasError` now sets `aria-invalid` on both fields; and `autoAdvance={false}` keeps
  the focus where the user put it instead of jumping between fields (default `true`, as before).
- **`ColorPicker` is a `role="group"`, not a `role="dialog"`, and Escape calls `onClose`.** It
  never trapped, moved or returned focus. A selector for `[role="dialog"]` no longer finds it. The
  group is named by the new `ariaLabel` prop and the cross by the new `closeButtonLabel` prop.
- **`ColorPicker`'s hex field is named by its caption, and the buttons are translated by
  default.** The "Hex code" caption is now a `<label>` for the field, so the field's name is
  `hexCodeLabel` ("Hex code:") rather than "Hex color value"; left out, `applyButtonLabel` and
  `cancelButtonLabel` use the kit's `Common:ApplyButton` and `Common:CancelButton` translations,
  and "Apply" and "Cancel" while no translation is loaded. `ColorInput`'s hex field likewise
  falls back to "Color" rather than an empty name.
- **`InfiniteLoader` takes its scroll element as `scrollElement`.** Without it the loader still
  looks for the portal's `#sectionScroll` (`#customScrollBar` on mobile) scroller and falls back
  to the window, so the portal sees no change.
- **`SelectionArea` can start a drag outside `#sectionScroll`.** The new `startAreaSelector` prop
  names the region a drag may start in; the default stays `#sectionScroll`.
- **`hideProfilePicker` is documented as the lock it is.** `@onlyoffice/ai-chat` 0.6.0 and later lock the composer's model picker instead of removing it (its menu also carries the Effort row). The prop's JSDoc, the AiChatPanel docs page and the `WithoutModelPicker` story said it removed the picker; nothing in this package's behaviour changed.
- **`Tags`' `onOptionTagClick` says which tag was clicked.** It is called with `"overflow"` or
  `"create"` (the new `TOptionTagKind` type), because the overflow tag and the create tag can now
  be on screen together. A handler that takes no argument keeps working.
- **`ColorPicker`'s `onClose` has no default, and Escape needs one.** Without `onClose` Escape is
  left to whatever listens further up, so a picker in a `ModalDialog` no longer stops Escape from
  closing the dialog; with one, Escape is consumed and calls it as before.
- **`EmptyScreenContainer` is no live region, and `ec-header` is one class.** An empty state is
  read like the rest of the page instead of being announced on every route load. The header's
  19px size and 700 weight are set through `Text`'s variables by a single class, so a rule of
  your own of two classes or more on `ec-header` wins by specificity, not by stylesheet order. It
  used to be an inline size that no stylesheet rule could beat: the portal's template gallery
  error view (`.errorView .ec-header`) now gets its own 23px (21px on mobile).
- **`SnackBar` announces through a hidden region, and `SnackBar.close()` unmounts a microtask
  later.** The visible bar is no longer `role="status"`; a visually hidden region beside it
  (`data-testid="snackbar-announcement"`) carries the header and text. `close()` clears the
  bar's bookkeeping at once but unmounts on the next microtask, so it is safe to call while React
  renders (from the countdown's `onComplete`); a test that checks the DOM right after `close()`
  has to wait for it.
- **An `ArticleItem` link reports its click before the router navigates.** The link calls
  `onClick` itself, so a `preventDefault()` there cancels the navigation again; the click is
  still reported once.
- **`Dropzone`'s format line sits beside the drop area, not inside it.** The drop area
  (`dropzone-input-area`) still covers the whole box, and clicks and drops on a plain format line
  reach it as before; with `fullExstsText` the line takes its own clicks, but a drop on it still
  reaches the area. A selector that expected `dropzone-file-types` inside the area must look
  beside it.
- **`MainButton` draws its focus ring in the accent**, through the new
  `--main-button-focus-color`, instead of in its background colour.
- **`PublicRoomBar` is announced only with the new `live` prop.** Its header and body are drawn
  at once and no longer sit in a `role="status"` region; with `live` a visually hidden status
  region beside them (`data-testid="public_room_bar_announcement"`) takes their text 100 ms
  after mount. Set it on a bar that appears in response to something; a bar that is part of a
  panel or dialog from the start is read with it.
- **`ColumnarInfoBar` announces through a hidden region.** The default and `neutral` bars' heading
  and columns are drawn at once and are no `role="status"` region any more; a visually hidden one
  beside them carries their text. A test that looked for the content inside `role="status"`
  must look for its text there instead.
- **Busy rows and tiles carry `aria-busy`.** `Row` and the base, file and folder tiles set it
  while `inProgress`, since their loader is decorative.
- **`RadioButtonGroup` is a `role="radiogroup"`.** Its wrapper `<div>` was a plain container, so
  `FieldContainer`, which describes radios through the group around them, put `aria-invalid`,
  `aria-required` and the error's `aria-describedby` on nothing. A query for the group by role now
  finds it; it still has no accessible name of its own.
- **`Checkbox` focuses its input, not its icon.** `tabIndex` now goes on the visually hidden
  `<input type="checkbox">`, which takes the keyboard focus; the box icon is decorative,
  `aria-hidden` and no tab stop. A test that focused the `svg` or waited for it to be focused
  must use the input (`getByRole("checkbox")`) instead. The focused box still draws its border
  in the focus colour.
- **The AI chat panel keeps its width.** A dragged docked width used to last until the panel
  closed; `AiChatStore` now saves it in `localStorage` under `chatPanelWidth` and starts every
  open and every visit from it. The new `utils/panel-width` holds that storage
  (`createPanelWidthStorage`), so a host keeps the info panel's width the same way, and
  `CHAT_PANEL_MIN_WIDTH`, the 360px the chat cannot be dragged below.

### Added

- **`AsideHeader`'s `headerIcons` take a `label`**, the icon button's accessible name. `Aside` and
  `ModalDialog` pass it on
- **`RoomIcon` takes `badgeLabel`**, the accessible name of a badge that `onBadgeClick` makes a
  button
- **`CategoryItem` takes `className` and `style`**, both on its outer element. It took neither,
  so its variables could only be set on an ancestor
- **`PortalLogo` takes `dataTestId`**, `portal-logo` by default, on the wrapper or on the
  fallback logo that replaces it. It carried no test id at all
- **`ComboBox` and `AccessRightSelect` take `ariaLabel`**, the accessible name of the button.
  Without it the button is still named by the option it shows.
- **`FolderType.PrivateRooms` (42)**: the root of the Private section. It holds no rooms
  itself; private rooms stay under the Rooms root and are listed through the `PrivateRooms`
  search area
- **`FilesSelector` can list the Private section.** `withPrivateTreeFolder` (off by default) adds a
  Private entry at the root, after Forms and off the Rooms root. It lists private rooms through
  the `PrivateRooms` search area, which the Rooms listing never returns, and offers no room
  creation and no Recent / Favorites rows. With it on, the path of a folder inside a private room
  starts at that entry in place of Rooms. The host's `Common` namespace needs the `Private` key
- **`hasTabStop(root)`** (`hooks/useFocusTrap`): whether `root` holds a Tab stop, by the rule of
  `getTabStops`, reading the layout no further than the first one
- **`markAsDropDownItem(component)`** (`utils/drop-down-item-mark`): marks a component that renders
  a `DropDownItem` from the props it takes - a wrapper adding labels, say - so that `ComboBox`
  walks its rows with the arrow keys
- **`Text`'s `onKeyDown` and `aria-haspopup`**, passed to the element unchanged: what a
  `role="button"` text needs to take the keyboard and say what it opens
- **`RoomType`'s `isDisabled`** greys out any room type, marks it `aria-disabled` and stops its
  `onClick`, as `disabledFormRoom` and `disabledPublicRoom` do for their own types
- `AiAgentProviders` takes `chatIntro`: what an empty chat shows above the suggestion chips in place of the default illustration and tagline (an AI project puts its logo, name and sources there).
- `RoomsType.AiProjectRoom` (12), `FolderType.AiProjectRoom` (40) and `FolderType.AiProjects`
  (41) for the AI projects of the DocSpace client; `RoomLogo` and the room type title /
  description helpers know the new type (the AI room icon stands in until a dedicated one lands)
- `AiChatStore.openProject` and `AiChatProjectSettings`: a project opens the chat with its model
  and the lists of its Instructions / Knowledge rooms, every one of them connected
- `AiAgentProviders` takes `contextRoom` as one room or a list; `ContextRoomProvider` gets a
  `rooms` prop and `useContextRooms`

- **`FormWrapper` can be the form.** A new `onSubmit` prop renders the card as a `<form>` that
  calls the handler with the browser's navigation prevented, so Enter in a field submits it;
  `aria-label` / `aria-labelledby` make it a named form landmark. Without `onSubmit` it is a
  `<div>` as before. The README now states that `--form-wrapper-min-width` /
  `--form-wrapper-max-width` size the content, so the card is that width plus twice the padding.
- **`IconButton` takes `role` and `ariaLabel`.** Its element is a `<div>` with no role, and its
  props had none to give it, so an icon button could be made keyboard-operable with `tabIndex`
  and `onKeyDown` but not announced as a button without a cast. Both props are rendered on the
  element, as `Link`'s are; nothing changes for a button that passes neither.
- Section: the info panel can be resized from its inline-start edge on a desktop. `isInfoPanelResizable` turns it on, with the host's width in `infoPanelWidth` and a setter in `setInfoPanelWidth`. The edge drags from 400px to 800px (`INFO_PANEL_WIDTH`, and the new `INFO_PANEL_MAX_WIDTH` in `utils/device`) while the section keeps 416px, narrows to fit a narrower window without saving it, and a double click restores 400px. It shares its resizer with the chat panel, whose edge now also takes a finger or a pen and narrows the panel to a narrower window, a chat opened after mount included, without calling `setChatPanelWidth` for it. `onShownInfoPanelWidthChange` reports the width the open info panel, or the chat open in its place, takes on screen (`0` when neither does), for floating buttons a host draws itself; it follows a resize drag once per frame, and below a desktop the info panel counts as 400px and the chat as `0`
- Article: `infoPanelWidth`, and the same prop on `ArticleLiveChat`, sets how far the live chat launcher moves clear of the open info panel, or of the AI chat open in its place, for a host whose panels are resizable; `0` when neither is. Unset, `isInfoPanelVisible` still assumes `INFO_PANEL_WIDTH`. The `isInfoPanelVisible` docs no longer call it unread: the launcher has moved clear of the info panel again since the switch to the Zendesk messaging API
- `OperationsProgressButton` takes `infoPanelWidth`. Inside `Section` the button gets the width through `--operations-progress-info-panel-width` on the section container instead: the width the open info panel, or the chat open in its place, takes on a desktop, updated on every frame of a resize drag, so the button stays 24px clear of the panel instead of sitting 424px in, under it

### Fixed

- **A clickable `Tag`, `ImageEditor`'s replace control and `ButtonDelete` take the keyboard.**
  Each was a `<div>` with a click handler and no tab stop. Each is now `role="button"` in the tab
  order, pressed with Enter or Space; a disabled or deleted tag stays out of it
- **`Calendar`'s title opens the month and year views from the keyboard.** It was an `<h2>` that
  answered the mouse only. When the view changes, the focus moves to the new view's title instead
  of falling back to the page
- **`AvatarEditorDialog`, `RoomLogoCoverDialog` and the filter panel are named by their
  heading**: `title`, `t("Common:RoomCover")` and `filterHeader`. Each was announced as an
  unnamed dialog. A passed `aria-label` or `aria-labelledby` still wins
- **Images beside their own label have an empty `alt`**: the plugin icons of `ContextMenu` and
  `DropDownItem`, `Dropzone`'s icon, `Selector`'s empty-screen picture, `FileTile`'s thumbnail,
  `RoomIcon`'s hover image and the burger images of `Navigation` and `Article`. Each was
  announced by English filler such as "plugin-logo" or "Thumbnail-img"
- **Logos are named by what they show.** A `RoomIcon` logo is named by `title`, like the
  initials it replaces, and the logos of `Navigation` and `Article` by the product name as the
  portal brands it. They read "room icon", "logo" and "burger-logo"
- **`PortalLogo`'s `alt` defaults to the product name** as the portal brands it, instead of the
  English "portal logo"
- **`Calendar`'s month arrows are named in the kit's translations**, "Previous" and "Next"
- **The kit's own icon-only buttons are named**, in its translations. Each was a focusable button
  announced only as "button": the crosses of `Tag`, `SelectedItem` and the filter chips
  ("Remove"), `Textarea`'s copy button ("Copy to clipboard"), the table group menu's cross and
  info panel toggle ("Close", "Info panel"), the back arrows of `Navigation` and of
  `ContextMenu`'s mobile submenu ("Back"), the filter panel's clear icon ("Clear filter"), and the
  pencils and pluses of `Avatar` and `RoomIcon` ("Edit", or "Upload picture" for `Avatar`'s plus)
- **`RoomLogoCoverDialog`'s custom colour plus and pencil are named** by `t("Common:Color")`, the
  text already shown above the swatches
- **Some icon buttons take their name from a prop that was only a tooltip.** `Filter`'s sort
  button is named by `sortByTitle`, and the table's cog by `TableHeader`'s `settingsTitle`, or
  "Settings". `Navigation`'s plus is named by `titles.actions`, or "Actions", and its folder
  button by `titles.contextMenu`, which nothing read, or "More options"
- **`Avatar`, `RoomType`, `SelectedItem` and `CategoryItem` forward a passed `aria-*` to the
  element with the role**: the avatar's button, the row, the chip and the title link. Each
  dropped every one. A passed `aria-label` wins over `userName`, the row's text, the chip's label
  and the title; `aria-expanded`, `aria-pressed` and a disabled row's `aria-disabled` stay the
  component's
- **`AvatarEditorDialog` and `RoomLogoCoverDialog` forward a passed `aria-*` to the dialog**, so
  `aria-label` or `aria-labelledby` can name it. Neither dialog had a name, nor a way to give one
- **`ImageEditor` forwards a passed `aria-*` to its region.** A passed `aria-label` replaces the
  English "Image editor"
- **`PortalLogo` and `MCPIcon` forward a passed `aria-*` to their image.** A passed `aria-label`
  wins over `alt` and `title`, and a passed `aria-hidden` lets `MCPIcon` stay silent beside the
  server's name in text
- **`RoomIcon` and `RoomLogo` forward a passed `aria-*` to their outer element.** Each dropped
  every one. Neither element has a role, so a name there is not read; `aria-hidden` works
- **`Row`, `RowContainer`, `RowContent` and every part of the table forward a passed `aria-*` to
  their outer element.** Each dropped every one. None of those elements has a role, so a name
  there is not read
- **Every tile forwards a passed `aria-*` to its outer element.** `BaseTile`, `FolderTile`,
  `RoomTile`, `TemplateTile`, `TileContainer` and `TileContent` dropped them; `FileTile` already
  passed them on and now declares them. `inProgress` still sets `aria-busy` over a passed value
- **`Filter`, `Paging` and `Selector` forward a passed `aria-*` to their outer element.** Each
  dropped every one
- **`Dropzone` forwards a passed `aria-*` to its drop area**, the library's `role="button"`. A
  passed `aria-label` wins over the English "File upload area" or "Folder upload area"
- **`InfiniteLoader` names its virtual grid with a passed `aria-label`.** react-virtualized named
  it `grid` and forwards no other `aria-*`
- **`ModalDialog` puts every passed `aria-*` on the dialog.** Beyond `aria-label`,
  `aria-labelledby` and `aria-describedby` they went to the header, which dropped them. The
  header gets none now; `aria-modal` stays the component's
- **`DropDown` and `ContextMenu` forward a passed `aria-*` to the menu.** Both dropped every one;
  `DropDown` lets a passed `aria-label` win over `ariaLabel`. `ContextMenu` puts it on the panel
  that takes `id`. `LinkWithDropdown` keeps the attributes on its link and off its list
- **`NavMenu` and `QuickActions` forward a passed `aria-*` to their landmark and toolbar.** Both
  dropped every one, so neither the `<nav>` nor the `toolbar` could be named
- **`Card` and `CollapsibleCard` forward a passed `aria-*`.** `Card` puts it on its `<section>`,
  which a name makes a `region` landmark, and `CollapsibleCard` on its toggle button
- **`Article`, `Section`, `Navigation`, `AsideHeader`, `ColumnarInfoBar`, `EmptyView` and
  `EmptyScreenContainer` forward a passed `aria-*` to their outer element.** Each dropped every
  one. None of those elements has a role, so a name there is not read
- **`ComboBox` and `AccessRightSelect` forward a passed `aria-*` to the button.** Both dropped
  every one but `ariaLabel`. A passed `aria-label` wins over `ariaLabel`; the open state and
  `aria-disabled` while `isDisabled` stay the component's
- **`ColorPicker`, `TimePicker` and `Tags` forward a passed `aria-*` to their group.** Each took
  only `ariaLabel`, which a passed `aria-label` now wins over
- **`RadioButton` and `RadioButtonGroup` forward a passed `aria-*`.** The button puts it on its
  input, and the group on its `radiogroup`, which can be named at last
- **`DateTimePicker` is a named group, and forwards a passed `aria-*` to it.** Its
  `selectDateText` name sat on a `<div>` with no role, where screen readers ignore it
- **`DatePicker` forwards a passed `aria-*` to the select-date control, and `Calendar` to its
  outer element.** Both dropped every one. A passed `aria-label` wins over `selectDateText`
- **`Loader`, `AppLoader`, `LoaderWrapper`, `StatusMessage` and `Tag` forward a passed
  `aria-*`.** Each dropped every one. The loaders put it on their status region, and `Tag` lets
  a passed `aria-label` win over `label`
- **`FloatingButton`, `OperationsProgressButton` and `MainButtonMobile` forward a passed `aria-*`
  to the circle.** All three dropped it, so the badge could only be named after its icon in
  English. A passed `aria-label` wins over `label`, and names the progress bar too. Pass a
  translated `aria-label` to `MainButtonMobile`
- **`ContextMenuButton` forwards a passed `aria-*` to its button.** It was dropped. A passed
  `aria-label` wins over `title`. In `toggle` mode a passed `aria-haspopup`, `aria-expanded` and
  `aria-controls` are kept, to describe the menu `onClick` opens
- **`LoadingButton` forwards a passed `aria-*` to its progress bar.** It was dropped. A passed
  `aria-label` wins over `progressLabel`, and the component keeps its own value attributes
- **`ToggleButton` and `TwoStateToggle` forward a passed `aria-*` to the control.** Both dropped
  it. `ToggleButton` puts it on its checkbox and `TwoStateToggle` on its switch, where a passed
  `aria-label` wins over `label` and `ariaLabel`. The checked state stays the component's
- **`HelpButton` forwards a passed `aria-*` to its anchor.** It was dropped. It lands on the info
  icon, or on the element around `children`
- **`QuantityPicker` forwards a passed `aria-*` to the number field.** It was dropped, so the
  field could not be named. Pass `aria-label` or `aria-labelledby` to name it
- **`PasswordInput` and `SearchInput` forward a passed `aria-*` to the `<input>`.** Both dropped
  it. `PasswordInput`'s type took every input attribute but handed the field none, and
  `SearchInput`'s type took no `aria-*` at all. Name either field with `aria-label` or
  `aria-labelledby`
- **`Textarea` and `Slider` forward every passed `aria-*`.** `Textarea` kept only `aria-label`,
  `aria-labelledby` and `aria-describedby`, and `Slider` those and `aria-valuetext`; the rest were
  dropped. `Slider` leaves out `aria-valuenow`, `aria-valuemin` and `aria-valuemax`, which the
  native range reports from `value`, `min` and `max`
- **`ColorInput` forwards a passed `aria-*` to its hex field.** It dropped every one, so the field
  could be named only through `inputLabel`. A passed `aria-label` wins over `inputLabel`, and
  `hasError` still sets `aria-invalid` to `true` over a passed value
- **`Label` forwards a passed `aria-*` to the `<label>`.** It dropped every one
- **`FileInput` takes every `aria-*` in its type and keeps `aria-disabled` while inert.** The type
  took only `aria-label` and `aria-description`, though the wrapper received any `aria-*`. A
  passed `aria-disabled` also overwrote the `true` that `isDisabled` and `isLoading` set
- **Arabic gets the system font in any region.** `getFontFamilyDependingOnLanguage`, and with it
  `ThemeProvider`, matched only `ar-SA`; `ar` and `ar-EG` got Open Sans, which has no Arabic
  glyphs
- **`RoomType` works the same for the pointer and the keys, and needs no portal for its accent.**
  A `dropdownButton` ignored the disabled props for a click but not for Enter and Space; now it
  ignores them for both. The pressed and open borders fall back to the theme's accent, not the
  text colour. Leaving out `roomType` leaves the row blank, as an unknown value does, instead of
  borrowing the form room's texts
- **`RoomIcon`'s empty state draws one button.** With `withEditing` the pencil sat over the plus
  in the same corner, each with a menu of its own; the plus is left. Its circle takes the theme's
  accent without the portal too, where it had no background and the white plus was invisible
- **`Avatar`'s badge colours can be set on an ancestor.** The avatar declared
  `--avatar-owner-fill`, `--avatar-administrator-fill` and their strokes on itself, so a value from
  above never reached the badge
- **`ImageEditor` keeps the file dialog shut while `isDisabled`.** The replace control still opened
  it, and the file chosen there was dropped
- **`AvatarEditorDialog` cannot be closed while `isLoading`.** The header cross, Escape and the
  backdrop still closed it, and the close reset the image the save was sending
- **`RoomLogoCoverDialog`'s "without icon" stays chosen while no glyph is.** The first click turned
  it off, and nothing turned it back on. Its label asks for `Common:WithoutIcon`, so a `t` whose
  default namespace is not `Common` finds it
- **`PortalLogo`'s phone bar takes the portal's `--header-background-color`.** The logo declared
  that token on itself, hiding the portal's value, and left the bar with no colour outside a
  `.light` or `.dark` ancestor
- **`MCPIcon` draws the first letter after leading spaces, and a leading emoji whole.** It drew the
  space, a blank tile, or half of the emoji's surrogate pair
- **`SelectedItem` applies `style`, and its cross carries no `undefined` class.** `style` was
  declared and never read; without `classNameCloseButton` the cross got the literal class
- **`isManagement()` is true only under the management app's `/management`.** It matched the word
  anywhere in the path, so `CategoryItem` hid its paid badge on a page such as
  `/portal-settings/management/...`
- **`FormWrapper`'s width variables hold on a tablet, and a class can restyle it on a phone.** A
  tablet fixed the width at 416px whatever the variables said; on a phone the shadow and background
  were removed with `!important`
- **`InfiniteLoader`'s row skeletons line up with the right edge in a right-to-left layout.** The
  rule that moves them named `.row-loade`, a class nothing carries
- **`SelectionArea` reports at most once per animation frame, and a release cancels the report
  still scheduled.** Each move and scroll built a scheduler of its own, so several moves within one
  frame gave several reports, and the release cancelled a new, empty one
- **`Dropzone`'s format line opens nothing while `isDisabled`.** It had left the tab order, but a
  click still opened the full list. The line now carries `aria-disabled` as well
- **Clearing `Scrollbar`'s `paddingInlineEnd` brings the default space back.** The value was
  written only while the prop was set, so the last one stayed
- **A click on a tile's three-dot button calls `tileContextClick` once.** `BaseTile`, `FileTile`
  and `FolderTile` called it as the button read its options, with no argument, and again with
  `false` as it reported the click. Only the second call is left
- **`FileTile`'s `isBlockingOperation` turns the pointer off.** Its rule matched only a descendant
  of the tile, so hover, clicks and right-clicks still reached a blocked file. The dead
  `contextButtonSpacerWidth` and `sideColor` no longer reach the DOM as unknown attributes
- **A `RowContainer` with any `id` gets rows of its own width.** The virtual list measured
  `document.getElementById("rowContainer")`, so another id laid the rows out zero wide and a
  second container took the first one's width. A `row` list of `InfiniteLoaderComponent` now
  measures the element it sits in and follows it as it resizes, or measures it once where there is
  no `ResizeObserver`, as in jsdom; `table` and `tile` still look up their ids
- **`TableHeader` gives the free width to the wide column on a window resize.** When the columns
  stopped fitting, a resize handed it only to a `default` column that also set `minWidth`, and to
  any column with `minWidth` and `default: false`. The wide column could end at `0px` with the
  rest. A layout reset was not affected
- **`TableRow` and `TableBody` add no class named `undefined`.** `hideColumns` and the body's
  `infoPanelVisible` each looked up a class their stylesheet does not define. The props change
  nothing else
- **`RowContent` adds no class named `undefined`.** `sectionWidth` looked up a class its
  stylesheet does not define; the prop changes nothing else
- **`Article` survives a `showArticle` value in local storage that is not JSON.** The parse ran
  unguarded in an effect, so such a value threw on mount and on every device change. It now
  counts as its raw text, and storage that cannot be read counts as an absent key
- **`NavMenu` draws the line of `withTopSeparator` without any setup.** The border fell back to
  `--quick-buttons-color`, which the kit does not define, so with neither that nor
  `--nav-menu-separator-color` set there was no line. The theme now supplies a divider grey last;
  both variables still win over it
- **`Navigation`'s header holds up in four corner cases.** The room title with `rootRoomTitle` and
  a single crumb threw on click; it now only closes the drop box. Each title icon's tooltip has
  its own id, where every header shared `iconTooltip`. `withLogo={true}` no longer draws an
  `<img>` with an empty `src`. The extra button's place in the row follows `currentDeviceType`, as
  the rest of the layout does, instead of the window's width at render
- **`Tabs` passes each bar only its own props.** A prop of the other type, such as `scaled` on
  the primary bar, reached the wrapper `<div>` and React warned about an unknown attribute
- **A click on a `Toast` spreads out its own deck only, and the deck closes again.** The click
  set `position: static` on every `.Toastify__toast` in the document and never undid it, so a
  later toast stacked over the spread ones. The container now carries a class until its last
  toast is gone. The `visualViewport` listener that wrote `--toast-top-offset` on `<html>`, where
  nothing read it, is removed
- **`ColumnarInfoBar`'s close cross follows `--cib-color`.** Its `fill: var(--gray)` named a
  variable the kit does not define, so the cross kept the asset's fixed grey in both themes
- **A swipe down no longer closes a `ModalDialog` that cannot close.** The swipe called
  `onClose` directly, past the guard the cross and Escape go through, so `isCloseable={false}`
  and `embedded` did not stop it on a phone. It goes through that guard now, and such a dialog
  is not dragged at all
- **`ContextMenu`'s mobile sheet shows a `badgeLabel` without `isPaidBadge`.** The sheet drew a
  badge only for a paid item, while the desktop list drew a plain one in blue; both draw it now
- **`DropDownItem` draws an `icon` passed as an element or a memoised component.** An element
  such as `<Icon />`, or a component wrapped in `memo` or `forwardRef`, fell through to
  `react-svg` with an empty address and drew nothing, though the type allows both
- **`DropDown`'s virtual list keeps the markup of a child of its own.** With `maxHeight` every
  child was rendered again as a `DropDownItem` built from its props, so a component of your own
  lost its markup. A `DropDownItem` is still drawn that way; any other child is placed in its
  row as it is
- **An open `DropDown` takes only the arrows and Enter from the page.** Its virtual list, with
  `maxHeight` and keyboard navigation on, prevented the default of every key press on the page
  before looking at the key, so a text field elsewhere took no characters and Tab did not move.
  Only the three keys it acts on are prevented now
- **`Calendar` leaves the day of `minDate` selectable, and keeps the seconds.** A day was
  compared at midnight with `minDate` and its time, so a `minDate` of now disabled today; it is
  compared with the day `minDate` falls on now. A picked day kept the old hours and minutes but
  dropped the seconds; it keeps them too. `DatePicker` and `DateTimePicker` show the calendar
  and gain both
- **`DatePicker` writes the chip's date in `locale`.** The month name followed the date's own
  Luxon locale, so a German picker showed "15 Mar 2024"; it shows "15 März 2024". `DateTimePicker`
  gains the same
- **`TimePicker` reports a change of `meridiem`, and keeps the zone of `initialTime`.** A new
  AM or PM reported nothing until the next keystroke; it now reports the typed time in the new
  half. Every value is `initialTime` with the typed hour and minute set on it, so it keeps that
  date's seconds and time zone; it used to be parsed again in the local zone with the seconds
  at zero. `DateTimePicker` reports a value equal to its current one only once
- **`Badge` merges a passed `style` over its own.** The style was spread after the badge's own,
  so it replaced `height`, `border`, `borderRadius` and the background colour as a whole; now
  only the keys it names change
- **`LinkWithDropdown` renders on a server and finds entries with a numeric `key`.** It read
  `window.orientation` while it was created, which threw where there is no `window`. An entry's
  `onClick` was looked up by comparing its `key` with a DOM attribute, so a numeric key never
  matched and the click only closed the menu
- **`Tag` styles its label.** The label never got the stylesheet's label class, so a deleted tag
  was not struck through, a disabled one not greyed, and `--tag-text-color`, `--tag-size` and
  `--tag-lh` changed nothing. All of them reach the label now. Its size comes from `--tag-size`,
  13px by default, instead of an inline style
- **`Heading` no longer carries a class named `undefined`.** It asked for a `not-selectable`
  class its stylesheet never defined. Headings stay selectable, as they were
- **`RadioButton`s sharing a `name` clear each other.** Without `onChange` each button held its
  own dot, and React restored the group from those stale dots: a click on a second button left
  its input unchecked and the first one's dot drawn. A button checked that way now clears the
  others of its name in the same form
- **`RadioButtonGroup` takes several captions.** Every `type: "text"` entry had the key
  `radio-text`, so a second caption collided with the first; each is keyed by its position now
- **A loading `Button` no longer repeats its `id` on the spinner.** The button passed its own
  `id` to the `track` loader, so while it loaded the page held two elements with that id. A
  loader without an `id` now gets a unique one, so its gradients stay apart from every other
  track's; before, tracks without an `id` shared one set and a secondary button's spinner drew
  in the primary's white
- **`TextInput`'s `keepCharPositions` works.** The prop reached only a `data-` attribute and
  never the mask, so typing or deleting in the middle shifted the rest. With a `mask` every
  character now keeps its slot: typing into a filled slot is refused, and a deletion leaves the
  slot empty. The attribute is still set
- **`EmailInput` keeps a passed `className`.** Its own class was set after the rest of the props
  and replaced it; the two are now joined
- **`PasswordInput` generates passwords from the cryptographic generator.** The generate link
  and the handle's `onGeneratePassword` drew every character and the final shuffle from
  `Math.random`, which is predictable, while consumers use the result as an account password
  and as the passphrase of an encryption key. They draw from `crypto.getRandomValues` now, with
  no fallback, without the bias of a modulo, and shuffle with Fisher-Yates. The free characters
  come evenly from every allowed character; before, a character set was picked first, so each
  of the eight symbols came up about three times as often as each letter. Length and rules are
  unchanged
- **`OperationsProgressButton` names its button after what is running.** The button and its
  progress bar were named after the icon ("dots button", "upload button"); they carry the
  operation's label now, or the count of processes when several run.
- **`PeopleSelector` and `GroupsSelector` load past their first page.** Both took the list's
  size from the answer's `count`, which is the items in that answer - one page of 100 at most -
  so the list never had a next page and scrolling to its end loaded nothing. They read the
  envelope's `total` now, through `getListTotal` (`selectors/utils/getListTotal`).
- **`PeopleSelector` counts the rows it leaves out once, and pages by the rows loaded.** It asked
  for the next page by the rows drawn, fewer than the rows loaded once the current user, an
  excluded or a disabled account was left out, so pages overlapped and the rows left out were
  counted again; with `withOutCurrentAuthorizedUser` the user was also counted off on every
  page, and off lists they are not in. The total ran short and the list could end before its
  last rows. Pages now start after the rows the portal has sent, the user is counted off on the
  page they come with, and the list ends when the portal has no more rows.
- **`PeopleSelector` loads on past a page with every row left out.** `Selector` asks for the
  next page from the rows it draws, so a first page whose every account was excluded or
  disabled left a loader and no request behind it. The pages are now asked for until one brings
  a row or the portal has no more.
- **`Selector` keeps its place when a page moves a row up the list.** `PeopleSelector` puts the
  current user first on whichever page they come with, and a list with another first row counted
  as a new list: with the focus on it, as it is from mount, the list scrolled back to its top.
  A list that holds every row it held before is the same list - nothing scrolls, and the
  keyboard follows its row to its new index.
- **`Selector` asks for a next page of one row.** The row after the loaded ones draws the loader,
  and the list asks for the row after that one. With `totalItems` one above the loaded rows - 101
  items after a page of 100 - or counted short by the caller, no such row was in range, and the
  list ended on its loader. While `hasNextPage` is set the row is always in range, so
  `loadNextPage` is now also called where `hasNextPage` stays set at exactly `totalItems` rows.
- **`Filter`'s button keeps its icon while the panel is open.** The open button turned its icon
  white but lost the grey background it had before the move from the client, so the icon vanished
  on the light theme. The background is back, and `--filter-btn-open-bg` overrides it.
- **Secondary `Tabs` in a row too narrow for one tab between the arrows keep their width.** No
  tab fit between the two arrows, the tab size was divided by that zero, and every tab got an
  `Infinity` width the browser dropped. The tabs now keep the width they were measured at.
- **No i18next advertisement in the console.** i18next 25 printed a notice for its hosted
  service when the kit's translation instance initialised, in every app that loads the kit;
  the instance now sets `showSupportNotice: false`.
- **Tab from a menu over a dialog goes on from the control that opened it.** A context menu or a
  drop-down a control in a `ModalDialog` or `Aside` opens lives in a portal, outside the focus
  trap, and Tab there went to the dialog's first stop (Shift+Tab to its last) wherever the menu
  came from. The trap now goes on from the element inside it that had the focus last
- **`Selector`'s `aria-activedescendant` names only a drawn row.** Home, End or the wheel took the
  keyboard's row past what the virtualized list renders, and the list pointed at an id no
  element had, which a screen reader announced as nothing. It points at the row once it is drawn
- **The "New" menu gives the focus back when the picked entry moves it nowhere.** An entry whose
  action focuses nothing of its own left the focus on the page's body as the menu closed
- **`InputBlock` names its icon only when the icon is a button.** With `iconAriaLabel` but no
  `onIconClick` the icon carried an `aria-label` and no role, which ARIA does not allow
- **The focus trap looks a radio group up once per key press.** It searched the trap for each
  radio's group, once per radio
- **A tab panel no longer lays out all its controls on every change.** `useTabPanel` re-read the
  panel on each frame its content changed and listed every Tab stop to learn whether there was
  one; it now asks `hasTabStop`, which stops at the first
- The focus trap leaves out controls inside a `<fieldset disabled>`: they take no focus, though
  their own `disabled` is false, and Tab stood still on them
- `Selector`'s list says `aria-multiselectable="true"` in multi select, so a screen reader no longer
  announces it as a single choice
- `Selector`'s new-name row leaves an Enter that ends an input method composition (Chinese,
  Japanese, Korean) to it, instead of accepting the name half typed
- **An AI project opens on its own model, not on the default.** `AiChatStoresBridge` looked the
  project's model up among the assigned profiles only (`init`); a model outside them missed and
  the chat fell back to the default. It now waits for the whole list (`ensureProfiles`) first.
- The composer's link to a context or knowledge room opens it in the AI rooms section
  (`/ai-rooms/{id}`), not in Rooms
- `ContextRoomWatcher` refreshes the picker's room list right after it connects an offered room
  that gained its first skill (the scheduled refresh was cancelled by the effect rerun)
- `ContextRoomSync` no longer reads the skills a second time when the store already did
- **`ComboBox` no longer throws when `options` is missing.** A caller that renders it before
  its options are loaded passed `undefined`, and reading its length threw "Cannot read
  properties of undefined (reading 'length')". A missing list is now treated as an empty one.
- **`FileTile`'s `--tile-height` sizes the whole tile.** The thumbnail area kept its 156px and
  the name row its 64px, so a taller tile ended in an empty band under the name row, outside the
  hover and checked background. The thumbnail area now takes whatever the name row leaves; at
  the default 222px nothing changes.
- **`PortalLogo`'s fallback follows the theme.** When `logo.ashx` fails, the bundled logo it
  draws instead was always the light one, whose dark lettering vanished on a dark page and left
  only the mark; the dark theme now gets the light-lettered version. `ErrorContainer` shows it.
- **`Article`'s logo starts at the panel's edge.** The header gives the logo a 211px box, sized
  for a white-label logo, and a narrower one such as the default ONLYOFFICE mark was centred in
  it; it now sits at the start of the row, on the right in a right-to-left interface.
- **`SnackBar` no longer calls `onAction` after it unmounts.** A click into an iframe schedules
  `onAction` half a second later, and that timer survived the bar, so a bar closed in the
  meantime reported an action anyway.
- **No `[i18n] Missing translation` error without translations.** `getCommonTranslation` logged
  it whenever `window.i18n` was absent, so an app with no `TranslationProvider` got one on every
  render of a component with a translated default (`Loader`, `Toast`, `Tags`, `SnackBar`). With
  no `window.i18n` it now returns `""` silently and the component uses its English default; a key
  missing from translations that are loaded is still logged.
- **Default accessible names are translated where the portal has a key.** The close buttons of
  `Toast`, `SnackBar`, `PublicRoomBar` and `ColumnarInfoBar` default to `Common:CloseButton` ("Close"), the `Tags`
  row to `Common:Tags` ("Tags", was the English "Tags container"), and `Loader` and `AppLoader`
  to `Common:LoadingProcessing` ("Loading...", was the English "Loading content, please wait."),
  and a `ContextMenuButton` without `title` to `Common:MoreOptions` ("More options"; it had no
  name at all, though it is a Tab stop). The four keys are in `locales/en/Common.json`. Names with no key in the portal yet (the
  colour picker's, `TimePicker`'s, `FloatingButton`'s, `LoadingButton`'s "Progress" and
  `PortalLogo`'s `alt`) stay English defaults of their props.
- **Keys a component handles no longer reach the page's or a dialog's listeners.** The keyboard
  support added to `ComboBox`, `ColorPicker`, `ContextMenuButton`, `LinkWithDropdown`, `Tags`,
  `QuickActions`, `MainButtonMobile` and `Dropzone` let its keys bubble on, so Escape in a menu inside a
  `ModalDialog` (which closes on an Escape `keyup` on `window`) closed the dialog too, and in
  the portal's file list Enter on a tag or in a menu also opened the selected item, the arrows
  moved the selection and Escape cleared it. Each now stops the key it acts on and swallows the
  matching `keyup`, however long the key is held.
- `ComboBox` works from the keyboard. The button answered no key, so a list could not be opened
  without a pointer, and the ArrowDown and Enter handler on the document looked for options by a
  test id its own options never carry — so it moved nothing, and while a list was open it
  swallowed Enter for the whole page. The button now answers Enter, Space and the arrows to open
  the list, the arrows to move a highlight that skips options which cannot be picked, Enter or
  Space to pick, and Escape or Tab to close. This holds with `dropDownMaxHeight` too, where the
  virtual list used to draw its own highlight over the combo box's and to prevent every key on
  the page, Tab included; the combo box now turns that listener off and scrolls the highlighted
  row into view. Nothing listens on the document any more. The button carries
  `aria-activedescendant`, but on `role="button"` screen readers ignore it, so the highlight is
  visible and not yet announced. The list's element takes `dropDownId` as its `id`, or a
  generated one. An advanced row keeps the `id` its caller gave it, and Enter looks the row up
  inside the open list only, so two lists whose rows share an id (two Filters' sort items) each
  pick their own
- `Checkbox` toggles from the keyboard and keeps the focus. Tab reached the box icon, which
  answered no key, so Space did nothing — a form could not be filled in without a pointer. And
  each state is drawn by its own icon, so a toggle replaced the focused icon: the focus fell to
  the page and the next Tab did not move on from the checkbox. The input now takes the focus
  (see _Changed_): Space toggles it as on any native checkbox, firing the same `onChange` a
  pointer does, Enter does nothing, the focus stays put, and a screen reader announces the
  focused control with its label and state
- `Button`'s `tooltipText` opens only its own tooltip. A button with no `id` named its tooltip
  `button-tooltip`, the same as every other such button, and each tooltip opens for any anchor
  carrying its name — so hovering one of three buttons opened three tooltips, and the page held
  three elements with one `id`. A button without an `id` now gets a generated one; a button
  with an `id` is unchanged
- **A click under a `Tabs` label selects the tab.** When the underlined row overflows, its
  horizontal scroll track — 16px tall, at the bottom of the 32px bar — lay over the lower half
  of every tab, so a click on the bottom of a label or just under it reached the track, which
  scrolled the row instead of selecting the tab. The track now lets the pointer through; the
  wheel and the trackpad still scroll the row
- **A disabled `Tabs` item cannot be selected.** The click handlers of both bars, the segmented
  keyboard and the overflow arrows now refuse it; before, only CSS `pointer-events: none` kept
  the pointer off it, and the arrows selected it
- **A closed `ModalDialog` is hidden from assistive technology.** With `visible={false}` it stayed
  mounted as `role="dialog"` with `aria-modal="true"`, so a screen reader was told the page behind
  an invisible dialog was unavailable, and its controls stayed in the Tab order. The outer element
  is now `aria-hidden` and `inert` while closed, and the surface drops `aria-modal`
- **`ModalDialog` takes the focus on open and hands it back on close.** The focus stayed on the
  page behind an open dialog, so the keyboard kept acting there. The dialog's surface
  (`#modal-dialog`, now `tabindex="-1"`) takes the focus unless a field inside it is autofocused,
  and on close the focus returns to the element that had it, also when `hideContent` recreated
  the content while the dialog was open. A dialog whose field takes the focus as it mounts
  (`autoFocus`, or a focus in the content's own effect) hands it back too: the opener is read
  before the commit that shows the dialog touches the DOM, where that field used to pass for it
- **`TwoStateToggle`'s default strings name the product through `getBrandName("ProductName")`.**
  `title`, `confirmBody` and `ariaLabel` said "DocSpace"; they now follow the portal's branding,
  and say "ONLYOFFICE Apps" when no brand lookup is registered. Explicit props are unaffected
- **`Label` no longer puts `aria-required` or `aria-invalid` on the `<label>`**, where ARIA does
  not allow them and nothing announced them. `FieldContainer` now puts them where they belong: the
  control in its body (the one `labelFor` names, or its first `input`, `textarea` or `select`)
  gets `aria-required` with `isRequired`, `aria-invalid` with `hasError`, and `aria-describedby`
  pointing at the error message while it shows. Attributes the control already carries are left
  alone, and what it added is taken off only while it still holds that value. A control that
  mounts after the container is described too, and a radio button stands for its
  `role="radiogroup"`. A bare `Label` with `isRequired` or `error` is now visual only; put `required` and
  `aria-invalid` on your input
- **`Checkbox`'s `truncate` cuts the label with an ellipsis.** The text ran out of a narrow
  container on one line instead, because its wrapper could not shrink and the span could not
  carry `text-overflow`
- **`Slider` accepts `aria-label`, `aria-labelledby`, `aria-describedby` and `aria-valuetext`**
  and passes them to the `<input>`; before, they were dropped and the slider could only be named
  by a `<label>`
- **`DropDown` renders one backdrop.** An open menu in the default mode used to paint two
  `Backdrop`s on top of each other; it now renders exactly one, beside the menu or inside the
  portal with `usePortalBackdrop`, and a `backDrop` you pass replaces it rather than adding to it.
- **`DropDown` closes on an outside tap on mobile devices.** The listener was registered for one
  event named `"click, touchend"`, which never fires; it now listens for `click` and `touchend`
  separately, and ignores the tap that opened the menu, which is still bubbling when the
  listeners are attached. A menu rendered open from the start also gets its `eventTypes`
  listeners now.
- **`DropDownItem`'s external-link icon is a real link when it can navigate.** With
  `onExternalLinkClick` it is `<a href={externalLinkPath}>`, focusable and named "Open <label>"
  (override with the new `externalLinkLabel`); a plain click goes to the callback and the `href`
  is not followed, so router-based handlers keep working. A middle, Ctrl-, Cmd- or Shift-click
  is left to the browser, which opens the `href` in a new tab, and does not call the callback.
  Without the callback it has no `href` and does nothing, as before.
- **`LinkWithDropdown` works from the keyboard.** The trigger is in the tab order (out of it while
  `isDisabled`), Enter and Space toggle the menu and Escape closes it; `aria-haspopup` is now
  `"listbox"`. The arrows open the menu and move focus into it, then between its items; Home and
  End jump, Enter and Space choose, and Escape returns focus to the link.
- **`LinkWithDropdown`'s `manualWidth` can exceed 200px.** The 200px cap now applies only to a menu
  that sizes itself.
- **`Dropzone`'s full format list closes on a click outside** and is keyboard-operable: with
  `fullExstsText` the format line is `role="button"` with `aria-expanded`, Enter and Space toggle
  the list, Escape closes it.
- **`Dropzone` uploads a folder from the keyboard.** In folder mode the area stays in the tab
  order and Enter or Space opens the directory picker.
- **`FileInput` accepts any file by default.** The old default `accept` of `[""]` refused every
  file with a MIME type; a missing, empty or `[""]` `accept` now means any file.
- **`FileInput` is inert while `isDisabled` or `isLoading`.** A drop, Enter and Space no longer
  open or fill it, it leaves the tab order, and `aria-disabled` is `"true"` under `isLoading` too.
  The read-only field and the `buttonLabel` button inside it are no longer separate tab stops.
  A new `onReject` prop receives the files `accept` refused; while it is set no toast is shown.
- **`ContextMenuButton` is a keyboard-operable menu button.** The icon is `role="button"` in the
  tab order, named by `title`, with `aria-haspopup="menu"`, `aria-expanded` and `aria-controls`;
  the menu is `role="menu"` with `menuitem` items, and Enter, Space, the arrow keys, Escape and
  Tab work as in the WAI-ARIA menu button pattern. `DropDown` gains a `role` prop and applies its
  `id`; `DropDownItem` gains a `role` prop.
- **`ContextMenuButton.onClick` fires when the menu opens**, not on the click that closes it, and
  `onClose` fires on every close, a second click on the button and a chosen item included, so
  the two pair up (a caller that locks scrolling in `onClick` and unlocks it in `onClose` is no
  longer left locked). Every prop now reaches the component (the memo compared only four). Without `getData` the
  button shows `data` instead of throwing, and `onMouseOver` / `onMouseOut` fire on mouseover and
  mouseout rather than mousedown and mouseup. Opened from the keyboard, in either mode, `onClick`
  gets a click event at the button's lower start corner (bottom-right in RTL, where the menu's
  right edge is aligned with it), with the button as `target` and
  `currentTarget`, so `ContextMenu.show(e)` places the menu there instead of at NaN and a
  handler typed for a mouse event never receives a keyboard one. It is never dispatched, but it
  carries `isDefaultPrevented()`, `isPropagationStopped()` and `persist()`, so a handler written
  for React's event can call them. A handler that told a key from a click by `e.key` or `e.type`
  no longer can.
- **`ProgressBar` announces what it shows.** `percent` is clamped to 0..100 at both ends (a
  non-number counts as 0); `isInfiniteProgress` leaves `aria-valuenow` out and sets `aria-busy`,
  so the bar is no longer announced as "0 %"; the status line sits in an always-mounted polite
  live region and the error line is a `role="alert"`.
- **`PreparationPortalProgress` is a progress bar to assistive technology.** It now carries
  `role="progressbar"`, `aria-valuemin`/`aria-valuemax`, an `aria-valuenow` from a clamped
  `percent`, and `text` as its name; the `role` and `aria-*` props still override them. A
  `percent` outside 0..100 no longer overflows the track.
- **`SnackBar`'s controls are keyboard-operable buttons.** The close cross is a
  `<button type="button">` (it no longer submits a surrounding form) named by the new
  `closeButtonLabel` prop, defaulting to the translated `Common:CloseButton` ("Close"); the
  `btnText` action and the campaign banner's cross are buttons too. The bar is `role="status"`
  with `aria-live="polite"`; its `countDownTime` counter is hidden from it, so the ticks are not
  announced.
- **`SnackBar.show`/`SnackBar.close` manage one React root.** Repeated `show` calls mount a fresh
  bar in the same root (its `onLoad` runs each time) instead of stacking new roots and new
  `#snackbar` divs, and a `show` right after `close`, even inside a commit, takes that root back; `close()` unmounts it with or
  without `parentElementId` and removes the `#snackbar` node `show` created. The bar's DOM id is
  now the `id` prop (default `snackbar-container`), and `isMaintenance`, `onClose` and `skipBlur`
  no longer leak onto the DOM.
- **Every toast can be closed from the keyboard.** The cross is now a
  `<button type="button">` named by the new `Toast` prop `closeButtonLabel` (default `"Close"`)
  instead of an unnamed, unfocusable `IconButton`; a toast opened without `withCross` carries the
  same button, visually hidden until it takes focus, so a toast with `timeout` 0 can always be
  closed with Tab and Enter. The cross keeps the grey it had as an `IconButton`.
- **`Toast` follows the interface direction.** `react-toastify`'s `rtl` flag comes from
  `ThemeProvider`'s interface direction instead of being on in every language.
- **`toastr.*` no longer shows an empty toast for a number** (numbers, booleans and objects with
  their own `toString()` are shown as text), and the default titles fall back to the English
  `Done`/`Warning`/`Alert`/`Info` when no `TranslationProvider` is mounted.
- **`AppLoader` announces the wait.** The loader inside it is a status region reading the new
  `label` prop (default `Common:LoadingProcessing`, "Loading..."), and the sheet carries
  `aria-busy="true"`.
- **`LoadingButton` can be cancelled from the keyboard and reports its progress.** With
  `onClick`, the disc in the middle is a `role="button"` in the tab order, pressed with Enter or
  Space and named by the new `cancelLabel` prop (default: the translated "Cancel"). The ring is a
  `role="progressbar"` named by the new `progressLabel` prop, reporting the clamped `percent`
  (no value while it spins at 0). `id`, `className` and `style`, previously ignored, now land on
  the outer square.
- **`StatusMessage` no longer stays behind invisible.** The swap or removal that waited only for
  `transitionend` now also happens on a 0.4s fallback, so a message changed again before the fade
  started (a new text, then `""` in the next frame) is removed instead of sitting in the DOM at
  zero opacity. Returning to the text on screen calls the fade off.
- **`StatusMessage` announces itself and repaints on `isWarning`.** An error bar is
  `role="alert"`, a warning bar `role="status"`, both `aria-atomic`; changing `isWarning` alone
  now repaints the bar at once. The bar carries `data-testid="status-message"`.
- **`StatusMessage` keeps a JSX message that has not changed.** A JSX message is a new element on
  every render of its parent, so the bar faded out and in again and, being a live region,
  re-announced the error on every keystroke. Messages are now compared by their text.
- **`FloatingButton` is operable and readable without a mouse.** With `onClick` the circle is a
  `role="button"` in the tab order, activated by Enter and Space, and named by the new `label`
  prop (the old `"<icon> button"` string remains the fallback). Its progress is a visually hidden
  `role="progressbar"`; the cancel cross is a `<button type="button">` named by the new
  `cancelLabel` prop (default: the translated "Cancel") that also appears on keyboard focus; an
  `iconUrl` image is decorative (`alt=""`).
- **A click on an `OperationsProgressButton` row's icon opens its panel once.** The icon carried
  the row's `onOpenPanel` handler as well, so the click called `showPanel(true)` twice. The
  row label's `progressHeader` class, lost to a stray comma operator, is now applied (without
  changing the layout).
- **`ErrorContainer`'s illustration is hidden from screen readers and follows the dark theme.**
  Its thirteen SVGs sit under an `aria-hidden` wrapper, and their colours come from private
  custom properties with a dark-theme variant instead of literal fills.
- **`PortalLogo` can be named.** A new `alt` prop (default `"portal logo"`) sets the image's
  `alt` and the `aria-label` of the bundled fallback mark, which previously had no name; pass
  `alt=""` to make both decorative.
- **`EmptyView` suggestion cards and `action` options work from the keyboard.** Enter and Space
  activate them as a click does; a card with a `model` opens its context menu under the card.
- **`EmptyView` link options without `LinkRouter` (or with `isNext`) are real links.** They carry
  `to` as their `href`, so they are in the Tab order and announced as links. With an `onClick`,
  a plain click still runs only the handler; a modified or middle click opens `to` in a new tab
  without also running it, and an option without `onClick` now navigates to `to` instead of
  doing nothing. An option whose `to` is empty is a button instead (`role="button"`, no `href`),
  and every click on it runs `onClick`, a modified one included, since it has no address to open.
- **`EmptyScreenContainer` has a heading and announces itself.** `headerText` renders as an
  `<h3>` (a new `headingLevel` prop picks another level), the subheading as a `<p>` and the
  description as a block, inside a `role="status"` wrapper that takes no layout space. The
  header's 19px bold size now comes from the stylesheet rather than an inline style.
- **`EmptyScreenContainer` forwards `id` and `style`** to the outer element; both were typed
  but dropped.
- **`FormWrapper`'s README sign-in example names its field.** The example, and the story
  sources, now pass `labelFor` with a matching control `id`, so the Email caption is the
  field's accessible name.
- **`ColumnarInfoBar`'s pairs are a description list.** Labels and values render as `<dt>` and
  `<dd>` inside a `<dl>`, so a screen reader ties each value to its label. The layout is unchanged.
- **`ColumnarInfoBar variant="neutral"` no longer cuts off long content.** The reveal animation
  kept its 150px height cap forever; the cap now lifts when the animation ends.
- **`PublicRoomBar`'s close cross is a real button.** It was an `IconButton` `div` with no role,
  focus or name; it is now a native `<button type="button">` named by a new `closeLabel` prop
  (default `"Close"`), reachable with Tab and pressed with Enter or Space. It keeps
  `data-testid="icon-button"`, and `--public-room-bar-close-icon` now paints it.
- **`CircleSkeleton` server-renders without a hydration mismatch.** It takes a `uniqueKey` prop
  and falls back to `useId()`, as `RectangleSkeleton` does.
- **`CircleSkeleton`'s default circle is whole, and an untitled one is hidden.** The default `x`
  is now `12` (it was `3`, which clipped the circle); without a `title` the SVG is `aria-hidden`
  instead of an unnamed image. Callers that pass `x`, `y` and `radius` render as before.
- **A disabled `CategoryItem` stays reachable and looks disabled.** Its title keeps
  `role="link"`, `tabIndex={0}` and `aria-disabled="true"` (still no `href` or handler), and the
  title, subtitle and arrow take `--category-item-disabled-color`, now a lighter grey than the
  subtitle in the light theme.
- **`Tags` can be used from the keyboard.** Every tag in the row, the overflow and create tags
  included, is now `role="button"` with `tabindex="0"` and answers Enter and Space. The built-in
  `...` tag carries `aria-haspopup="listbox"` and `aria-expanded`, moves the focus into its menu,
  and the menu takes the arrow keys, Enter, Space and Escape. The row is a `role="group"` named
  by a new `ariaLabel` prop (still `"Tags container"` by default)
- **`Tags` gives the create tag a name, keeps it on overflow and honours `TagType.onClick`.**
  The plus tag of `showCreateTag` is named by a new `createTagLabel` prop (the translated "Add"
  by default) instead of an empty `aria-label`; it now stays, after the overflow tag, when the
  tags overflow, and `optionTagRef` points at the overflow tag when both are drawn. A tag with
  its own `onClick` calls it instead of `onSelectTag`. Two tags with the same label no longer
  collide on the React key, and a `ResizeObserver` re-measures the row when it is resized
- **A click on a `RoomTile` tag no longer opens the room, and the generated tags reach
  `selectOption`.** The tile's open handler now ignores clicks inside the tag row (`.room-tags`)
  and on any `.tag`, overflow-menu entries included, so `thumbnailClick` stops firing alongside
  `selectTag`. The third-party and room-type tags the tile generates call `selectOption` with
  `typeProvider` / `defaultTypeRoom` as documented; until now every click went to `selectTag`
- **`RoomIcon`'s logo menu toggles once per click and only when there is a menu.** The pencil,
  the plus and the hover overlay no longer toggle it alongside the tile, picking an entry no
  longer reaches the tile's toggle, and a tile with no `model` entries (or nothing that draws
  the menu) ignores clicks. A colourless logo object whose image fails to load now gets black
  initials in the light theme and `data-is-wrong-image` on the tile; that state was unreachable
- **`RoomType` rows can be chosen from the keyboard.** The `listItem`, `dropdownButton` and
  `dropdownItem` layouts are now `role="button"` with `tabindex="0"`; Enter and Space click them,
  so `onClick` still receives a mouse event, and a focus ring in the accent colour shows.
  `dropdownButton` carries `aria-expanded`. A disabled row stays focusable with `aria-disabled`
  and refuses the keys as it refuses the click
- **`Avatar`'s tooltip id is stable, its pencil toggles the menu once, and `.svg` detection reads
  the URL path.** The role tooltip's anchor id comes from `useId` instead of `Math.random()` on
  every render. The pencil and the menu entries keep their clicks from reaching the avatar, so
  the menu no longer depends on two toggles cancelling out. A source is drawn as an icon only
  when its URL path ends in `.svg` - `photo.svg.png` and `?file=x.svg` are pictures now - and a
  `data:` URL, an inline SVG included, is always a picture
- **A broken `<img>` inside `MCPIcon`'s `imgNode` falls back to the letter**, as a broken `imgSrc`
  already did, and a new `imgSrc` or `imgNode` is tried again after one failed. A node with a
  string `src` is remembered by it, so one rebuilt on every render does not retry, and flash,
  the same broken picture each time
- **`MainButton` can be reached and opened from the keyboard.** It is now a native `<button type="button">` (user agent styles reset, so it looks the same): Enter and Space open the menu or call `onAction`, `aria-haspopup`, `aria-expanded` and `aria-controls` follow the menu, and `isDisabled` sets `aria-disabled` while leaving the button focusable. The Enter that opens the menu no longer also picks its first item.
- **`MainButtonMobile`'s iOS scroll background works, and a page without `.section-scroll` no longer throws.** Two comparisons read ref objects instead of their values, so the sheet never darkened on scrolling up.
- **`--main-button-mobile-badge-size` scales the alert badge's icon**, not only the box around it.
- **`QuickActions` tooltips no longer collide across banners.** A tile's tooltip anchor id now comes from `useId` instead of the item's `id`, so two banners offering the same tile, or an id with a space or colon, each keep their own tooltip.
- **`ArticleItem` rows are operable from the keyboard.** Each row's control is a transparent layer over the row: without a `LinkRouter` a `role="button"` in the tab order that Enter and Space activate, with one the router link itself (no longer wrapped around the whole row), on which Enter calls `onClick` and a middle click is left to the browser. The active row's control has `aria-current="page"`, the control is named by `text` even when the label is not drawn, the badge is a named button beside the control (not inside it) when `onClickBadge` is set, and label truncation is re-measured when `text` changes.
- **`Calendar` names each day by its full date and marks the selected day and today.** A day
  button's accessible name is now its full date in `locale` ("October 15, 2023") while its text
  stays the number, the selected day has `aria-pressed="true"` (every other day `"false"`) and
  today `aria-current="date"`. A test that found a day with `getByRole("button", { name: "15" })`
  must use the full date or `getByText("15")`.
- **`Calendar` keeps the selection visible when the selected day is today.** It used to draw
  only today's fill; it now draws the selection ring around the fill as well.
- **`DatePicker`'s "Select date" control is one button that opens from the keyboard.** The
  `AddButton` inside it is now `aria-hidden`, so screen readers and `getAllByRole("button")` meet
  one button named `selectDateText` instead of two, and Enter and Space toggle the calendar as a
  click does.
- **`DateTimePicker`'s time opens from the keyboard and is spoken as shown.** Enter and Space on
  the time display open the editor, and its `aria-label` uses the displayed clock
  (`Current time: 02:30 PM` on a 12-hour locale) instead of always the 24-hour one.
- **`DateTimePicker`'s AM/PM drop-down sets the half of the day instead of shifting by twelve
  hours.** Choosing the half the time is already in no longer moves the value into the next or
  previous day; it changes nothing and does not call `onChange`.
- **`ColorInput`'s picker opens on the colour the field holds.** It used to keep the colour it
  first mounted with, so after typing a code the first move in the picker brought back the old
  colour's saturation and brightness and overwrote the typed one.
- **`ColorInput`'s swatch is a real button and the hex field has a name.** The swatch was a
  `<span>` that could not be reached from the keyboard; it is now a `<button type="button">`
  named by the new `pickerButtonLabel` prop, with `aria-expanded`, disabled with the field, and
  the focus returns to it when the picker closes from its cross or Escape. The field is named by
  the new `inputLabel` prop (the kit's "Color" by default) and gets `aria-invalid` under
  `hasError`.
- **`InfiniteLoader` keeps its own skeleton flag.** A `showSkeleton` passed in props used to
  override the flag the loader sets after a scroll jump of more than 800px; it is now ignored, as
  its documentation always said. The long-jump skeletons also work when the loader falls back to
  the window.
- **`SelectionArea` reports `clear` and works without a `scrollClass` match.** `onMove` now gets
  one call with `clear: true` and empty `added`/`removed` when a drag passes 10px; it was never
  sent before. When nothing carries `scrollClass`, the page's own scroller is used instead of none,
  so items are covered at all.
- **The `Section` chat panel resizer no longer grows the panel by 1px per grab.** It measured the
  panel with its border and wrote that to `--chat-panel-width`, which sets the content box: a click
  on the edge committed 401 for a 400px panel. `setChatPanelWidth` now receives the content width,
  and a grab released without moving commits nothing.
- **A `Section` panel resize no longer outlives its mouse button.** A drag whose button was
  released where the page could not see it, in another window after Alt+Tab or over the Start
  menu, went on moving the panel with the pointer and kept the resize cursor until the next click.
  The drag now ends, committing the width it reached, as soon as the window loses focus or the
  pointer moves without the button.
- **A late search result no longer overwrites a newer edit in `Filter`'s search box.** A query the
  host applied after the user had already changed or cleared the box came back into it and was
  searched again. Such a stale value, or a new `getSelectedInputValue` returning the value already
  shown, now leaves the field alone; any other value is still shown, and focused when not empty.
- **`SearchInput` no longer puts back the term it has just reported.** A parent that stores the
  `onChange` value and passes it back as `value` could re-render after the user had already
  typed on or cleared the field; the field took the old term back and searched it again. That
  echo is now ignored; any other change of `value` still re-seeds the field.
- **The errors story helper is no longer published.** `dist/types/errors/stories.utils`, a
  Storybook-only i18n stand-in, was reachable as `./errors/stories.utils`; the declaration build
  now excludes it.
- **`AIAgentSelector` keeps the `initItems` it is given.** With `withInit` the selector still fetched the first page from the portal on mount and replaced the pre-loaded list with the answer. The first page is no longer requested while `excludeItems` and `disableBySecurity` are what `initItems` were shown with; once one of them changes it is fetched as usual. A change of language alone, as hydration makes on a page served in English, keeps the items. A search, clearing one, and further pages (`initHasNextPage`) are fetched as before.
- **The system MCP server's label no longer repeats the brand.** `MCPServersSelector` labelled the portal's own server `OrganizationName ProductName`, which read "ONLYOFFICE ONLYOFFICE" where the product name is ONLYOFFICE. The organisation is now prefixed only when the product name does not already contain it: "ONLYOFFICE DocSpace" is unchanged, "ONLYOFFICE" and "ONLYOFFICE Apps" are shown as they are.
- **`PeopleSelector`'s Groups tab lists groups when there is no `roomId`.** It used to run the people search and showed every user, guests included. It now loads the portal's groups (`groupApi.getGroups`); with a `roomId` the room's sharing query is used as before.
- **`FilesSelector` calls `headerProps.onCloseClick`.** The header's close cross always called `onCancel`, ignoring the handler passed in `headerProps`. The caller's `onCloseClick` now runs, with `onCancel` as the fallback when it is absent; the footer's Cancel button still calls `onCancel`. A consumer that passed a no-op `onCloseClick` and relied on the cross cancelling should pass `onCancel` there.
- **`Uploader` accepts any file with `accept="*"`.** `accept` went to react-dropzone unchanged, where `"*"` and `"*/*"` refuse every file - including in the README's own examples. `"*"`, `"*/*"`, `""` and a missing `accept` now all mean any file, and `accept` is optional in `UploaderProps`. A list is passed on trimmed and without blank entries: `".pdf,"` used to let every file with no MIME type through.
- **The legal sample's relative dates are in English.** "updated yesterday" and "Sent 5 days ago" followed the browser's locale inside an otherwise English page; they are now formatted in English.
- **`Loader`, `SnackBar`, `ColumnarInfoBar` and a `live` `PublicRoomBar` are announced when they
  appear.** Each was a status region inserted together with its text, which screen readers mostly
  do not read; the announcing region now mounts empty and receives its text 100 ms later, while
  what is drawn appears at once. `SnackBar`, `ColumnarInfoBar` and `PublicRoomBar` read that text
  from what they draw, and read it again whenever it changes, a part that updates on its own
  included.
- **`LinkWithDropdown`'s keys skip separators and headers**, and a caller's `onKeyDown` or
  `tabIndex` no longer switches the keyboard support off: unknown props go first, and a caller's
  `onKeyDown` runs before the built-in keys and can opt out with `preventDefault()`.
- **An open `DropDown` closes on an outside click that re-renders its owner.** The listener
  ignored that click as the one that opened the menu whenever `clickOutsideAction` changed
  identity, which `ContextMenuButton` and `LinkWithDropdown` do on every render.
- **`ComboBox` leaves its optional block's keys alone**, as its click handler does -- its own
  block only, so a combo box placed in another's block keeps its keys -- and lets the arrows
  scroll an `advancedOptions` panel instead of cancelling them, still keeping them from the
  page's hotkeys.
- **The segmented `Tabs` arrows start from the focused tab**, after a click on the tab already
  selected too, and a shorter item list no longer leaves the bar without a Tab stop.
- **`Filter`'s search remembers at most 20 unreported queries**, so a host that never reports
  its value back does not grow the list without end. A report of the value the field already has
  settles the queries before it, so after "a", "ab", "a" a later "ab" of the host's own (Back, a
  saved filter) is shown instead of being dropped as a stale echo, and after `clearSearch` the
  host's previous value is shown again when it comes back.
- **`SearchInput` takes a value set after its cross was used**, even one equal to the last value
  it reported.
- **`MainButton` leaves the keys of its menu alone.** Its Enter handling also caught keys
  bubbling from the open menu, so Enter on a link in it lost its native activation.
- **`StatusMessage` no longer sticks mid-fade** after its effects are replayed (StrictMode, a
  re-shown `Activity`).
- **`toastr` shows nothing instead of throwing** for an object with no prototype.
- **`EmptyView`'s keyboard-opened context menu opens at the item's start corner in RTL.**
- **A held Space toggles `Checkbox` once.**
- **`FieldContainer` keeps its error in the control's description** when the control rewrites its
  own `aria-describedby`.
- **`DateTimePicker`'s AM/PM sets the hour** instead of shifting by 12 hours, which was an hour off
  on a day the clocks change.
- **The samples' declarations are no longer published.** `dist/types/docs` is gone.
- **A key pressed during a `QuickActions` arrow's scroll still brings its tile into view.** The
  key stops the arrow's smooth scroll where it has got to, and in Chromium on Linux the tile's
  own scroll was lost with it, leaving the first tile clipped after Home.
- **`PeopleSelector` loads every group with `withOutCurrentAuthorizedUser`.** It took one off the
  total of a list of groups too, where the current user never is, so the last group of a
  paginated list was never requested.
- **The segmented `Tabs` arrows run the tab's own `onClick`**, as a click on the tab does, and
  scroll the tab they select into view. They used to call `onSelect` alone.
- **`ArticleItem`'s badge passes Enter and Space to a `badgeComponent`'s own click.** The keys
  clicked the wrapper, so a badge that opens something in its own click handler (the portal's
  new-files badge) did nothing from the keyboard.
- **`MainButtonMobile`'s alert badge is named without an `I18nextProvider`.** It read
  "Common:Alert" outside the portal; it now uses the kit's translation lookup with "Alert" as the
  fallback.
- `Selector` leaves search mode whenever `searchValue` becomes empty, not only when its own clear button is used. A host that cleared the value itself - on opening another folder, say - left the selector searching: an empty list kept the search field and the "nothing found" screen instead of its own empty screen, and "Select all" stayed hidden
- The AI agent's editor tool calls go to the portal's own origin only. They carry what the
  model writes into a document, and were posted to the editor panel's iframe and to the
  generated-file tab with the target origin `"*"`, so a window that had meanwhile navigated
  elsewhere — a sign-in redirect, a link followed in the tab — would have received them. Both
  windows open the portal's `/doceditor`, so the calls are now addressed to
  `window.location.origin` and the browser drops one whose window holds any other page.
- Table: a column reset no longer squeezes the name column below its own minimum. With many columns on and a narrow list, for instance beside the AI chat, the reset took every other column's minimum out of the name column's share, down to a negative width that broke the grid: the header lost its title and the rows came out empty. The name column now keeps its minimum, and when the other columns cannot fit next to it the table shows the name column alone, as a resize already does
- Table: a column reset no longer empties a table that has no name column, such as the billing transaction history. In a narrow list the reset fell back to showing the name column alone, so with no name column every column got zero width: the header lost its titles and the cells piled on top of each other. That fallback now applies only when the table has a name column

## 4.1.0

### Added

- `FilesSelector` takes three optional props for files whose title on the server is not
  their name, such as end-to-end encrypted files: `resolveItemTitle` supplies the title a
  file row shows (and the selected file's title in `onSubmit`), `itemTitlesVersion`
  redraws the rows when those titles change, and `onFilesLoaded` reports each loaded page
  of files with the folder, the room on its path and whether that room is private. File
  rows carry `encrypted`. Search and sorting still use the server's titles
- `FilesSelector` takes `withRoomsTreeFolder` (default `true`) to leave Rooms out of the
  root list, for a portal where the Rooms app is switched off. Forms no longer depends
  on Rooms being listed: it is shown whenever `withFormsTreeFolder` is on

### Changed

- `@onlyoffice/document-editor-react` peer raised from `2.1.1` to `2.2.0`. That release
  dropped its own `IConfig` and takes the editor configuration type, `Config`, from
  `@onlyoffice/doceditor-types`, which is now an optional peer here as well (`^9.3.1`)
- `document-editor` still exports `IConfig`, now as an alias of that `Config`
- `@onlyoffice/document-editor-react` peer raised further to `2.3.0`, and the
  `@onlyoffice/doceditor-types` peer widened to `>=9.3.1` so that its `10.0.0` line
  (the types for ONLYOFFICE Docs 10.0, which drop the deprecated `showReviewChanges`,
  `reviewDisplay` and `trackChanges` customization keys) satisfies it the same way it
  satisfies `document-editor-react` itself
- `document-editor` folds its `width`, `height` and `events_*` props into `config`
  before handing it to `document-editor-react`, which deprecated those flat props in
  2.3.0. The component's own props are unchanged; a value set in `config` wins over the
  matching prop, and `events_onAppReady` still receives the editor instance
- `@onlyoffice/ai-chat` peer requirement raised to `^1.0.4` (the composer's tool cards follow the round's context scope; files and images share one attachment cap)
- AI settings: `McpServers` takes a `toolPrefsScope` prop. Pass `"tenant"` where the viewer administers the portal, so a tool switched off there is off for every user; omitted, the page edits the viewer's own list (Bug 84381)

### Added

- Filter: a group can draw itself. An item marked `isCustom` is rendered by the new `renderCustomItem` prop, which gets the group's pending value, `onChange` to set it and `openPanel` / `closePanel` for a nested step; the value is a string key, applied and compared like any other
- Filter: a selected item can carry `chips`, drawn as one chip each under the bar. Removing one calls `removeSelectedItem` with that chip's key and the item's group; the panel still treats the item as one value
- Filter: `hideSearch` leaves the search field out of the bar and keeps the main button, for a listing whose content the server cannot search (end-to-end encrypted rooms). `SearchInput` gains the `hideField` prop it is built on

### Fixed

- `InputBlock` passes the `TextInput` props it does not name itself on to the inner `<input>`.
  Its type has always accepted every `TextInput` prop, but the component forwarded only a fixed
  list, so `inputMode`, `aria-label` and any other `aria-*` were dropped without a warning: the
  field had no accessible name and a phone showed the full keyboard. They now reach the
  `<input>`; the props it names keep going where they went
- `Selector` no longer scrolls the page when it mounts. The list's scroll container takes focus
  on mount, and so does the new-name field when it appears; both focused with a plain `focus()`,
  which scrolls the page to the element. They now pass `preventScroll`, so the focus still lands
  in the selector and the page stays where it was. Every selector built on it follows
- `RoomLogoCoverDialog` fits the window the first time it opens. Its `Portal` mounts the body
  after the first render, so the height was computed before there was anything to measure and
  stayed at the 648px (desktop) or 854px (tablet) preset, past the bottom of a short window; only
  a second opening measured it. The body is now measured once it is mounted. `RoomLogoCover`'s
  `forwardedRef` accepts a callback ref as well as a ref object
- `MCPServersSelector` loads the portal's logo from the portal. The system server's icon
  was a relative `/logo.ashx?logotype=3`, which the browser resolves against the page's own
  origin — the portal only when the application is served from it. Anywhere else the icon was a
  broken image. It is now built from the `baseUrl` of the nearest `ApiProvider`
- Secondary `Tabs` with `scaled` judged overflow by the tabs' own widths, which are the
  container's shares, so two tabs in a 480px row were "overflowing" and shown one at a time
  behind arrows. The check now measures the labels
- `RoomIcon` with no `logo` rendered an empty `<img>` unless `showDefault` was passed. It now
  draws the initials, which is what `showDefault` forces when a logo exists
- `Uploader`'s `targetId` was typed `string`, and a string id is what sends the upload down the
  third-party route; a portal folder's numeric id could only be passed through a cast. It is
  `string | number` now, and the README says which route each takes
- `ModalDialog` added a `touchend` listener inside its effect's teardown, where every sibling
  line removed one; each re-run left another listener behind
- `ThemeProvider` follows a `colorTheme` that arrives after the first render, instead of only
  reading it once
- The committed `locales/en` lacked six keys the source asks for: `Filter`'s forms variant
  (`SpaceGroups`, `AllSpaces`, `ManageGroupSpaces`) showed the raw key names, and the AI
  agent's export labels (`ExportPdfDocument`, `ExportDocxDocument`, `ExportMdFile`) had no
  entry, so only their inline English default could show
- Two mounted `Toast`s threw `Cannot set properties of undefined (setting 'toggle')` once one
  of them remounted while the other still showed a toast: `react-toastify` keys its registry by
  container id, and every `Toast` uses the same one. That happens on any Storybook docs page
  with several stories, and to a plugin that mounts its own next to the portal's. Only the
  first mounted `Toast` renders the container now, and the next takes over when it unmounts;
  the `className` and `style` of the others are ignored
- `AIAgentSelector` and the Files selector's agent list no longer disable every agent when
  `disableBySecurity` names a right that a folder's security never carries, such as the
  file-only `AskAi` of the chat's attach picker. Only a right set to `false`, or a missing
  security object, disables an agent now. The initial items (`withInit`) and the pages loaded
  after them follow the same rule; before, the initial items still disabled every agent
- AI chat: the copy buttons (message, code block, tool card) work on a portal served over plain HTTP. The platform adapter now supplies `copyToClipboard`, which falls back to `copy-to-clipboard` where the Clipboard API is unavailable outside a secure context (Bug 84481)
- Files and images share one 5-attachment cap on a message, including the Forms section's single slot (Bug 84379)
- The E2E Docker image copies the vendored ai-chat tarball before `pnpm install`
- Filter: removing a chip no longer hides a chip of another group that shares its key
- Context menu (desktop and mobile sheet) and `DropDownItem`: a string icon is fetched and inlined through `react-svg` only when it is a `.svg` on the page's own origin or, where it already was, an SVG data URL. Anything else, a cross-origin `.svg` included, is an `<img>`, so a custom action whose icon lives on the integrator's domain no longer needs CORS headers there and no longer loses its icon. The old rule looked for `images/` or `.svg` in the path and inlined such icons from any origin; a cross-origin SVG now keeps its own colours instead of taking the text colour

## 4.0.1

### Changed

- `@onlyoffice/ai-chat` peer requirement raised to `^1.0.1`

## 4.0.0

First release under its own name and from its own repository. It was `@docspace/ui-kit@0.0.1`,
a workspace package of the DocSpace client resolved to its source root; it is now
`@onlyoffice/apps-ui-kit`, built and consumed as a package. The version follows the
ONLYOFFICE Apps 4.0 line.

### Changed

- **Renamed** from `@docspace/ui-kit` to `@onlyoffice/apps-ui-kit`
- **ESM only**: `dist/esm/**` and `.d.mts` declarations in `dist/types/**`; no CJS output
- **An `exports` map decides what resolves**: `.`, `./styles.css`, `./package.json`,
  `./locales/*`, `./styles/*` and a `./*` wildcard onto `<subpath>/index.js`. A plain
  (non-module) stylesheet is reached only through the module that imports it
- **One CSS file per module**, imported by that module; `dist/styles.css` still holds the
  whole sheet
- **Dependencies split three ways**: 32 `dependencies`; `react`, `react-dom`, `i18next` and
  `react-i18next` as required peers; 15 optional peers needed only by the portal-internal
  modules (`@onlyoffice/ai-chat` `^1.0.0`, `mobx`, `mobx-react`, `axios`, `socket.io-client`,
  `react-router`, the markdown/KaTeX stack, `@onlyoffice/document-editor-react`)
- `@onlyoffice/docspace-api-sdk` comes from npm (`^3.7.0`); `react`/`react-dom` peers are
  `^19.0.0`; `i18next` 25, `react-i18next` 15, `react-svg` 16.4.2
- `providers/api` and `providers/Providers` left `providers/index.ts`; import them by subpath
- The `hooks` barrel is exported from the root
- **`Article` / `ArticleLiveChat`** drive Zendesk through the messaging API; `zendeskEmail`,
  `chatDisplayName` and `Zendesk`'s `config` are gone
- **`DocumentEditor`** takes either `documentServerUrl` + `config`, or `fileId`; with neither
  it reports through `onLoadComponentError` instead of opening file `1`
- **The section header has its height (69/61/53px) and background back.** This changes the
  portal's layout
- **`TextInput`, `Textarea`, `Checkbox`, `ComboBox`** no longer default `tabIndex` to `-1`
- **`ModalDialog`** puts `role="dialog"` and `aria-modal` on the dialog surface, not the
  overlay
- **`Aside`** is a flex column whose body fills the remaining height; only `aria-*` props go
  to the `<aside>`, everything else to the header
- `DateTimePickerProps` includes the required `translations`
- **`TwoStateToggle`** defaults name the product ONLYOFFICE Apps: `title` is
  "ONLYOFFICE Apps design", `ariaLabel` "Switch ONLYOFFICE Apps design", and `confirmBody` ends
  "…the classic ONLYOFFICE Apps view." A test querying the old accessible name fails
- `ThemeProvider` no longer fetches the portal palette (the call never worked); pass
  `colorTheme`

### Added

- `FilterInput` and `StatusMessage` as named exports
- `Text`, `Heading`, `Link`: `role`, `aria-label`, `aria-live`, `aria-hidden`
- `Textarea` and `ModalDialog`: `aria-label`, `aria-labelledby`, `aria-describedby`
- `FieldContainer`: `labelFor`
- A README for every component and public provider; `docs/getting-started.md`,
  `docs/components.md` and `docs/public-api.md`
- `docs/plugin-surface.json`: every name the root barrel exports, with its kind and module

### Fixed

- `ImageEditor` crash on render; icons keep their `viewBox`
- `Selector` no longer scrolls the page on mount
- `RoomLogoCoverDialog` fits the window on first open
- `MCPServersSelector` loads the portal logo from the `ApiProvider`'s `baseUrl`
- Secondary scaled `Tabs` no longer report false overflow
- `RoomIcon` without `logo` draws initials
- `Uploader`'s `targetId` accepts `string | number`
- `ModalDialog` no longer leaks `touchend` listeners
- `ThemeProvider` follows a `colorTheme` that arrives after the first render
- Two mounted `Toast`s no longer throw
- `AIAgentSelector` no longer disables every agent for a right the folder never carries
- Missing `locales/en` keys for `Filter` and the AI agent export labels
- Brand and constant lookups survive a second module instance

### Known issues

- The root barrel needs `mobx`, `mobx-react`, `react-router` and `axios` to build (via
  `billing` and `uploader`); import by subpath to avoid them
