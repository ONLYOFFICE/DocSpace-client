# Interface: IFrame

Defined in: [interfaces/components/IFrame.ts:76](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L76)

A component that is used to embed a third-party website into a modal window or the settings page.

## Examples

Embedding a PDF viewer in a modal window

```typescript
const pdfViewer: IFrame = {
  src: "https://example.com/pdf-viewer",
  width: "100%",
  height: "80%",
  name: "pdf-viewer-frame",
  sandbox: "allow-scripts allow-same-origin allow-forms",
  id: "pdf-viewer-iframe",
  style: {
    border: "none",
    borderRadius: "8px",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)"
  }
}
```

Embedding a settings configuration page

```typescript
const settingsConfig: IFrame = {
  src: "https://example.com/plugin-settings",
  width: "100%",
  height: "100%",
  name: "plugin-settings",
  sandbox: "allow-scripts allow-same-origin allow-forms allow-popups",
  id: "settings-iframe",
  style: {
    border: "1px solid #eceef1",
    backgroundColor: "#ffffff",
    padding: "16px"
  }
}
```

## Appearance

Properties that control the visual styling, dimensions, and layout of the frame.

### width?

> `optional` **width**: `string`

Defined in: [interfaces/components/IFrame.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L87)

Defines the frame width measured in percent

***

### height?

> `optional` **height**: `string`

Defined in: [interfaces/components/IFrame.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L93)

Defines the frame height measured in percent

***

### style?

> `optional` **style**: `object`

Defined in: [interfaces/components/IFrame.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L117)

Defines the frame style

#### Index Signature

\[`key`: `string`\]: `string`

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/IFrame.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L125)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Behavior

Properties that control security, sandboxing, and interaction behavior of the frame.

### sandbox?

> `optional` **sandbox**: `string`

Defined in: [interfaces/components/IFrame.ts:105](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L105)

Defines the frame sandbox

## Content

Properties that define the frame's source URL, identifiers, and embedded content.

### src

> **src**: `string`

Defined in: [interfaces/components/IFrame.ts:81](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L81)

Defines the base URL to a modal window or the settings page. It is used to generate links

***

### name?

> `optional` **name**: `string`

Defined in: [interfaces/components/IFrame.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L99)

Defines the name of the object inserted into the page

***

### id?

> `optional` **id**: `string`

Defined in: [interfaces/components/IFrame.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L111)

Defines the element ID
