# room-space-info

Shows room storage usage and owner in an Info panel tab; highlights the size in red when it exceeds an admin-defined threshold in GB.

## Build

```sh
npm install
npm run build
```

The uploadable archive is `dist/plugin.zip`.

## Install

Upload `dist/plugin.zip` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump `version` in `package.json` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

## Scopes

- `InfoPanel`
- `Settings`
- `API`
