# Interface: ILabel

Defined in: [interfaces/components/ILabel.ts:64](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L64)

Field name in the form.

## Examples

Required field label with inline display

```typescript
const emailLabel: ILabel = {
  text: "Email Address",
  isRequired: true,
  error: false,
  isInline: true,
  title: "Enter your email address",
  htmlFor: "email-input",
  display: "flex"
}
```

Error state label with truncation and block display

```typescript
const longFieldLabel: ILabel = {
  text: "Document Processing Configuration Settings",
  isRequired: false,
  error: true,
  truncate: true,
  title: "Configure document processing settings",
  htmlFor: "doc-settings",
  display: "block"
}
```

## Appearance

Properties that control the visual styling, display mode, truncation, and required indicator.

### isRequired?

> `optional` **isRequired**: `boolean`

Defined in: [interfaces/components/ILabel.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L75)

Specifies whether the field to which the label is attached is required

***

### truncate?

> `optional` **truncate**: `boolean`

Defined in: [interfaces/components/ILabel.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L96)

Specifies whether the word wrapping is disabled

***

### htmlFor?

> `optional` **htmlFor**: `string`

Defined in: [interfaces/components/ILabel.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L102)

Defines the field ID to which the label is attached

***

### display?

> `optional` **display**: `string`

Defined in: [interfaces/components/ILabel.ts:108](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L108)

Specifies whether the "display" property is set

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/ILabel.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L116)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Content

Properties that define the label's text, title, error state, and associated form field.

### text

> **text**: `string`

Defined in: [interfaces/components/ILabel.ts:69](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L69)

Defines the element text

***

### error?

> `optional` **error**: `boolean`

Defined in: [interfaces/components/ILabel.ts:81](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L81)

Specifies whether the field to which the label is attached is incorrect

***

### title?

> `optional` **title**: `string`

Defined in: [interfaces/components/ILabel.ts:90](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L90)

Specifies whether the "display: inline-block" property is set
isInline?: boolean;

/** Defines the label title
 *
 *
