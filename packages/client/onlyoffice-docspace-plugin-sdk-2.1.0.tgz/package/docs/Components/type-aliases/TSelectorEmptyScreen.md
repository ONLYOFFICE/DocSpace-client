# Type Alias: TSelectorEmptyScreen

> **TSelectorEmptyScreen** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:531](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L531)

Empty screen message properties for selectors.

## Content

### emptyScreenHeader?

> `optional` **emptyScreenHeader**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:537](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L537)

The header text to display when there are no items to show.

***

### emptyScreenDescription?

> `optional` **emptyScreenDescription**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:543](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L543)

The description text to display when there are no items to show.
