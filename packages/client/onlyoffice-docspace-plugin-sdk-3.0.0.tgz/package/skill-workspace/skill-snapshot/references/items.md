# Item shapes per scope

What goes into each scope's map. Required fields first; get one wrong and the item is dropped or misbehaves without a message.

The user-type filter field differs per scope and is the single most common mistake — it is repeated in every table below rather than stated once, because that is where it gets missed.

## ContextMenu

| Field | Required | Notes |
|---|---|---|
| `key` | ✔ | prefix with the plugin name — the map is portal-wide |
| `label` | ✔ | |
| `icon` | ✔ | file name only, 16×16 |
| `onItemClick` | | `(id: string \| number) => IMessage`. Prefer this over the deprecated `onClick` |
| `onGroupClick` | | `(items: GroupItem[]) => IMessage`, where `GroupItem` is `{ id, itemType: "file" \| "folder" \| "room" }` |
| `isGroupAction` | | when `true` the item is **hidden** for single selection and its click handlers never fire |
| `items` | | submenu; max nesting depth 2. Defining it disables the parent's own click |
| `fileType` | | `FilesType[]` — `room`, `file`, `folder`, `image`, `video` |
| `fileExt` | | only honoured when `fileType` includes `FilesType.file` |
| `usersTypes` | | **plural** for this scope |
| `devices` | | |
| `security`, `itemSecurity` | | if every child is filtered out, the parent disappears too |
| `placement` | | `"top"` or `"topLast"`; not allowed on nested items |

## MainButton

| Field | Required | Notes |
|---|---|---|
| `key`, `label`, `icon` | ✔ | icon 16×16 |
| `onItemClick` | | `(id: number \| string) => IMessage` — the id is the current folder |
| `items` | | submenu; defining it disables the parent's own click |
| `usersType` | | **singular** for this scope |
| `devices` | | |

## ProfileMenu

| Field | Required | Notes |
|---|---|---|
| `key`, `label`, `icon` | ✔ | icon 16×16 |
| `onClick` | ✔ | takes **no arguments**; there is no `onItemClick` here |
| `usersType` | | **singular** |
| `devices` | | |

## InfoPanel

| Field | Required | Notes |
|---|---|---|
| `key` | ✔ | |
| `subMenu` | ✔ | `{ name: string; onClick?: (id: number) => IMessage }` — the tab label |
| `body` | ✔ | `IBox` — the tab content |
| `onLoad` | | `() => Promise<{ body: IBox }>` for async content |
| `isHeaderVisible` | | defaults to `true` |
| `filesType`, `filesExsts` | | restrict which files show the tab |
| `usersTypes` | | **plural** |
| `devices` | | |

## EventListener

| Field | Required | Notes |
|---|---|---|
| `key` | ✔ | |
| `eventType` | ✔ | `Events`: `CREATE`, `RENAME`, `ROOM_CREATE`, `ROOM_EDIT`, `CHANGE_COLUMN`, `CHANGE_USER_TYPE`, `CREATE_PLUGIN_FILE` |
| `eventHandler` | ✔ | takes **no arguments** |
| `usersTypes` | | **plural** |
| `devices` | | |

After an event fires the host honours only item updates and toasts — other actions in the returned message are ignored. This scope also has no `update*Item` method; re-add to replace.

## File

| Field | Required | Notes |
|---|---|---|
| `extension` | ✔ | also the map key. If two plugins claim it, the last loaded wins |
| `onClick` | ✔ | `(file: File) => IMessage`, where `File` carries `id`, `title`, `folderId`, `fileExst`, `viewUrl`, `webUrl`, … |
| `fileTypeName` | | label shown for the type |
| `fileRowIcon` | | 32×32 |
| `fileTileIcon` | | 96×96 |
| `fileSecurity`, `security` | | |
| `usersType` | | **singular** |
| `devices` | | checked inside `onClick` rather than by the host |

## ArticleButton

| Field | Required | Notes |
|---|---|---|
| `key` | ✔ | |
| `body` | ✔ | `IBox`, recommended 32×32 |
| `onLoad` | | `() => Promise<{ body: IBox }>` |
| `usersTypes` | | **plural** |
| `devices` | | |

The portal shows at most **five** article buttons across all installed plugins combined, so treat placement here as a scarce resource.

## Enum values worth having at hand

`UsersType` — keys are camelCase, values PascalCase: `owner: "Owner"`, `docSpaceAdmin: "DocSpaceAdmin"`, `roomAdmin: "RoomAdmin"`, `collaborator: "Collaborator"`, `user: "User"`.

`Devices` — `mobile`, `tablet`, `desktop`.

`FilesType` — `room`, `file`, `folder`, `image`, `video`.

`ToastType` — `success`, `error`, `warning`, `info`.

`PluginLocale` — 33 locales, values like `EN_US = "en-US"`, `RU = "ru"`, `PT_BR = "pt-BR"`, `ZH_CN = "zh-CN"`.

`FilesExst` covers the document, spreadsheet, presentation, media and archive extensions DocSpace knows; a plain string works too when the extension is your own.
