# markdown-preview

Adds a **Preview as HTML** item to the context menu of `.md` / `.markdown`
files. Clicking it opens a modal that fetches the file through the DocSpace
REST API and shows the Markdown rendered with the portal's own UI components
(headings, lists, task lists, tables, blockquotes, code blocks, links,
bold/italic/strikethrough), following the portal theme. English and Russian
interface languages are included.

Notes:

- Images are shown as `[Image: alt]` placeholders (external images would be
  blocked by the portal CSP); absolute image URLs are clickable.
- Files without Download permission show a permission message instead of
  content; very large documents are truncated with a notice.
- `assets/icon-16.svg` and `assets/logo.svg` are generated placeholders -
  replace them with real icons if you have them.

## Build

```sh
npm install
npm run build
```

The uploadable archive is `dist/plugin.zip`.

## Install

Upload `dist/plugin.zip` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump `version` in `package.json` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

## Scopes

- `ContextMenu`
- `API`
