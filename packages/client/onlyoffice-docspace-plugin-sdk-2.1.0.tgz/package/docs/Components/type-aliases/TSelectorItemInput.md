# Type Alias: TSelectorItemInput

> **TSelectorItemInput** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:230](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L230)

Defines properties for an item that functions as an input field.

## Behavior

### onAcceptInput()

> **onAcceptInput**: (`value`) => `TReturnMessage`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:248](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L248)

A callback function that is triggered when the user accepts the input value.

#### Parameters

##### value

`string`

#### Returns

`TReturnMessage`

***

### onCancelInput()

> **onCancelInput**: () => `TReturnMessage`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:254](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L254)

A callback function that is triggered when the user cancels the input.

#### Returns

`TReturnMessage`

## Content

### defaultInputValue

> **defaultInputValue**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:242](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L242)

The default value to display in the input field.

## State

### isInputItem

> **isInputItem**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:236](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L236)

If true, this item will be rendered as an input field.
