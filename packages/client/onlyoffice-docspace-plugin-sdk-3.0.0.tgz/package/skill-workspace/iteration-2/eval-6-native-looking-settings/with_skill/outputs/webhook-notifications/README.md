# webhook-notifications

Webhook endpoint settings for DocSpace notifications

## Build

```sh
npm install
npm run build
```

The uploadable archive is `dist/plugin.zip`.

## Install

Upload `dist/plugin.zip` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump `version` in `package.json` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

## Scopes

- `Settings` — an admin-only block opened from Settings → Integration → Plugins →
  **Webhook notifications**. It renders in the portal's own aside panel with the
  portal's own components:

  | Control | Stored as |
  |---|---|
  | `Webhook URL` (required, validated as `http(s)://…`) | `webhookUrl` |
  | `Environment` combo box — Production / Staging | `environment` |
  | `Send notifications` toggle | `notificationsEnabled` |

  **Save** writes the three values as one JSON string via `Actions.saveSettings`
  and shows the portal's success toast. The URL is validated while typing and
  again on save; an invalid value turns the field red and replaces the hint line
  under it with the error, and nothing is saved until it is fixed.

## Notes

- All colors come from the portal's theme variables (`--input-error-color`,
  `--row-side-color`, `--border-service-color`), so the block follows the light
  and dark themes — and a re-branded accent — without any plugin code.
- Interface strings are available in English and Russian and are rebuilt when the
  portal calls `setLanguage`.
- Stored settings arrive after installation and are **wiped when the plugin is
  disabled**, so the block falls back to its defaults on an empty or malformed
  value rather than breaking.
- `assets/logo.svg` is the generated placeholder — replace it with a real logo.
