# Type Alias: LabelGroup

> **LabelGroup** = `object`

Defined in: [interfaces/components/Component.ts:337](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L337)

Defines the label component.

## Example

```typescript
import { ILabel, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const label: ILabel = {
  text: "Plugin Settings",
  isRequired: true,
  error: false,
  isInline: false,
  title: "Configure plugin settings",
  htmlFor: "settings-form",
  display: "block",
  truncate: true
};

const labelGroup: Component = {
  component: Components.label,
  props: label,
  contextName: "settingsLabel"
};
```

## Properties

### component

> **component**: [`label`](../../enumerations/Components.md#label)

Defined in: [interfaces/components/Component.ts:339](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L339)

Defines the "label" component type

***

### props

> **props**: [`ILabel`](../interfaces/ILabel.md)

Defined in: [interfaces/components/Component.ts:341](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L341)

Defines the label component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:343](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L343)

Defines the label component context name that updates the component via React context
