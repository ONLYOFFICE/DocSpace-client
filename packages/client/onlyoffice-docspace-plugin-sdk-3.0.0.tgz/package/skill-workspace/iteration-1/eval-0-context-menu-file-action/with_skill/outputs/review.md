# markdown-preview (with_skill)

- pluginName: `MarkdownPreview`  version: `1.0.0`  scopes: `["ContextMenu","API"]`
- zip built: yes

## src/index.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  FilesSecurity,
  FilesType,
  IApiPlugin,
  IContextMenuItem,
  IContextMenuPlugin,
  IPlugin,
  PluginLocale,
  PluginStatus,
} from "@onlyoffice/docspace-plugin-sdk";

import { currentLocale, setLocale, t } from "./locales";
import { previewDialog } from "./preview";

const markdownPreviewContextMenuItem = (): IContextMenuItem => ({
  key: "markdown-preview-preview-html",
  label: t("contextMenu.label"),
  icon: "icon-16.svg",
  fileType: [FilesType.file],
  // Include the dot - the host matches against the file's fileExst verbatim.
  fileExt: [".md"],
  // The preview reads the bytes via viewUrl (a download), so the item is
  // hidden for users who could not open it anyway.
  itemSecurity: [FilesSecurity.Download],
  // The menu callback only opens the dialog; fetching and rendering happen in
  // the dialog's own onLoad, so the click responds instantly.
  onItemClick: (id: string | number) => ({
    actions: [Actions.showModal],
    modalDialogProps: previewDialog(id, () => plugin.getAPI()),
  }),
});

class MarkdownPreview
  implements
    IPlugin,
    IContextMenuPlugin,
    IApiPlugin
{
  status: PluginStatus = PluginStatus.active;

  contextMenuItems: Map<string, IContextMenuItem> = new Map();

  origin = "";

  proxy = "";

  prefix = "";

  setOrigin = (origin: string): void => {
    this.origin = origin;
  };

  getOrigin = (): string => this.origin;

  setProxy = (proxy: string): void => {
    this.proxy = proxy;
  };

  getProxy = (): string => this.proxy;

  setPrefix = (prefix: string): void => {
    this.prefix = prefix;
  };

  getPrefix = (): string => this.prefix;

  setAPI = (origin: string, proxy: string, prefix: string): void => {
    this.origin = origin;
    this.proxy = proxy;
    this.prefix = prefix;
  };

  getAPI = (): { origin: string; proxy: string; prefix: string } => ({
    origin: this.origin,
    proxy: this.proxy,
    prefix: this.prefix,
  });

  // Register items here rather than at module scope. Both are read in time, but
  // setLanguage and setAPI only run after the bundle executes - so a factory that
  // translates a label or calls getAPI() at module scope would capture empty values.
  onLoadCallback = async (): Promise<void> => {
    this.addContextMenuItem(markdownPreviewContextMenuItem());
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  // The portal calls this when the interface language changes. Labels were
  // captured when the items were built, so the items have to be rebuilt.
  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
    this.updateContextMenuItem(markdownPreviewContextMenuItem());
  };

  getLanguage = (): PluginLocale => currentLocale();

  addContextMenuItem = (item: IContextMenuItem): void => {
    this.contextMenuItems.set(item.key, item);
  };

  getContextMenuItems = (): Map<string, IContextMenuItem> => this.contextMenuItems;

  getContextMenuItemsKeys = (): string[] => Array.from(this.contextMenuItems.keys());

  updateContextMenuItem = (item: IContextMenuItem): void => {
    this.contextMenuItems.set(item.key, item);
  };
}

const plugin = new MarkdownPreview();

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.MarkdownPreview = plugin || {};

export default plugin;
```

## src/locales.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 */
export type TStrings = {
  "contextMenu.label": string;
  "dialog.header": string;
  "dialog.close": string;
  "error.load": string;
  "error.noPermission": string;
  "notice.truncated": string;
  "notice.empty": string;
};

const en: TStrings = {
  "contextMenu.label": "Preview as HTML",
  "dialog.header": "Markdown preview",
  "dialog.close": "Close",
  "error.load": "Could not load the file preview. Please try again.",
  "error.noPermission": "You do not have permission to view this file.",
  "notice.truncated": "This file is large - only the beginning is shown.",
  "notice.empty": "This file is empty.",
};

const ru: TStrings = {
  "contextMenu.label": "Просмотр как HTML",
  "dialog.header": "Предпросмотр Markdown",
  "dialog.close": "Закрыть",
  "error.load": "Не удалось загрузить предпросмотр файла. Попробуйте ещё раз.",
  "error.noPermission": "У вас нет прав на просмотр этого файла.",
  "notice.truncated": "Файл слишком большой — показано только начало.",
  "notice.empty": "Файл пуст.",
};

const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.EN_US]: en,
  [PluginLocale.RU]: ru,
};

let locale: PluginLocale = PluginLocale.EN_US;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.EN_US;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings): string => (translations[locale] ?? en)[key];
```

## src/markdown.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Component,
  Components,
  IBox,
  IText,
  LinkTarget,
  LinkType,
} from "@onlyoffice/docspace-plugin-sdk";

/**
 * Renders Markdown into the declarative component tree the portal displays
 * with its own React components. No HTML string is produced anywhere, so the
 * preview inherits the portal theme automatically and file content can never
 * inject markup into the page.
 *
 * Supported: ATX headings, paragraphs, bold / italic / inline code, links,
 * images (shown as links), fenced code blocks, ordered / unordered / task
 * lists, blockquotes, tables and horizontal rules. Anything unrecognised
 * degrades to a plain paragraph rather than disappearing.
 */

const NBSP = " ";

const BLOCK_MARGIN = "0 0 12px 0";

// --- inline parsing ----------------------------------------------------------

type TInlineRun = {
  text: string;
  bold?: boolean;
  italic?: boolean;
  code?: boolean;
  href?: string;
};

const MAX_INLINE_DEPTH = 4;

const LINK_RE = /^\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/;
const IMAGE_RE = /^!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/;

const isWordChar = (ch: string | undefined): boolean =>
  !!ch && /[A-Za-z0-9]/.test(ch);

const plainTextOf = (runs: TInlineRun[]): string =>
  runs.map((run) => run.text).join("");

/**
 * Finds the closing emphasis marker: the content must not start or end with a
 * space, so `2 * 3 * 4` stays literal while `*emphasis*` is recognised.
 */
const findEmphasisEnd = (source: string, marker: string, from: number): number => {
  if (from >= source.length || source[from] === " ") return -1;

  let searchFrom = from;
  for (;;) {
    const at = source.indexOf(marker, searchFrom + 1);
    if (at === -1) return -1;
    if (source[at - 1] !== " ") return at;
    searchFrom = at;
  }
};

const parseInline = (source: string, depth = 0): TInlineRun[] => {
  const runs: TInlineRun[] = [];
  let plain = "";

  const flush = () => {
    if (plain) {
      runs.push({ text: plain });
      plain = "";
    }
  };

  let i = 0;
  while (i < source.length) {
    const ch = source[i];

    // Backslash escape: the next character is literal.
    if (ch === "\\" && i + 1 < source.length) {
      plain += source[i + 1];
      i += 2;
      continue;
    }

    // Inline code: `code` (no nesting inside).
    if (ch === "`") {
      const end = source.indexOf("`", i + 1);
      if (end > i + 1) {
        flush();
        runs.push({ text: source.slice(i + 1, end), code: true });
        i = end + 1;
        continue;
      }
    }

    // Links and images. Images become links labelled with their alt text -
    // the portal cannot inline arbitrary external images (CSP), so a link to
    // the source is the honest rendering.
    if (
      depth < MAX_INLINE_DEPTH &&
      (ch === "[" || (ch === "!" && source[i + 1] === "["))
    ) {
      const isImage = ch === "!";
      const match = (isImage ? IMAGE_RE : LINK_RE).exec(source.slice(i));
      if (match) {
        flush();
        const label =
          plainTextOf(parseInline(match[1], depth + 1)) ||
          (isImage ? "image" : match[2]);
        runs.push({ text: label, href: match[2], italic: isImage || undefined });
        i += match[0].length;
        continue;
      }
    }

    // Bold (** or __) and italic (* or _).
    if (depth < MAX_INLINE_DEPTH && (ch === "*" || ch === "_")) {
      const double = source[i + 1] === ch;
      const marker = double ? ch + ch : ch;
      // _mid_word_ underscores (snake_case identifiers) stay literal.
      const midWord = ch === "_" && isWordChar(source[i - 1]);
      const start = i + marker.length;
      const end = midWord ? -1 : findEmphasisEnd(source, marker, start);

      if (end !== -1) {
        flush();
        const inner = parseInline(source.slice(start, end), depth + 1);
        for (const run of inner)
          runs.push(double ? { ...run, bold: true } : { ...run, italic: true });
        i = end + marker.length;
        continue;
      }
    }

    plain += ch;
    i += 1;
  }

  flush();
  return runs;
};

// --- run rendering -----------------------------------------------------------

/**
 * Inline runs render as inline-block paragraphs, and the browser collapses
 * their leading/trailing spaces - so edge spaces become non-breaking ones.
 */
const nbspEdges = (text: string): string =>
  text
    .replace(/^ +/, (m) => NBSP.repeat(m.length))
    .replace(/ +$/, (m) => NBSP.repeat(m.length));

const isAbsoluteUrl = (url: string): boolean => /^https?:\/\//i.test(url);

type TTextStyle = {
  fontSize?: string;
  lineHeight?: string;
  bold?: boolean;
};

const inlineCode = (text: string, style: TTextStyle): Component => ({
  component: Components.box,
  props: {
    displayProp: "inline-block",
    backgroundProp: "var(--filled-button-background-color)",
    paddingProp: "0 4px",
    borderProp: {
      width: "0",
      style: "none",
      color: "transparent",
      radius: "3px",
    },
    children: [
      {
        component: Components.text,
        props: {
          // NBSP keeps internal spacing; the enclosing block still wraps
          // between neighbouring runs.
          text: text.replace(/ /g, NBSP) || NBSP,
          fontSize: "12px",
          lineHeight: style.lineHeight ?? "20px",
          isInline: true,
        },
      },
    ],
  },
});

const runComponent = (run: TInlineRun, style: TTextStyle): Component => {
  if (run.code) return inlineCode(run.text, style);

  if (run.href && isAbsoluteUrl(run.href)) {
    return {
      component: Components.link,
      props: {
        text: nbspEdges(run.text),
        href: run.href,
        type: LinkType.page,
        target: LinkTarget.blank,
        color: "accent",
        isInline: true,
        fontSize: style.fontSize,
        lineHeight: style.lineHeight,
        isItalic: run.italic,
      },
    };
  }

  const props: IText = {
    text: nbspEdges(run.text),
    isInline: true,
    fontSize: style.fontSize,
    lineHeight: style.lineHeight ?? "20px",
  };
  if (run.bold || style.bold) props.fontWeight = 600;
  if (run.italic) props.isItalic = true;

  return { component: Components.text, props };
};

/**
 * A run of inline content. A single unstyled run renders as one normal text
 * paragraph (natural word wrapping); mixed runs render as inline-block
 * fragments that flow together.
 */
const inlineComponents = (runs: TInlineRun[], style: TTextStyle = {}): Component[] => {
  if (runs.length === 0)
    return [{ component: Components.text, props: { text: NBSP } }];

  if (runs.length === 1 && !runs[0].code && !runs[0].href && !runs[0].italic) {
    const only = runs[0];
    const props: IText = {
      text: only.text,
      fontSize: style.fontSize,
      lineHeight: style.lineHeight ?? "20px",
    };
    if (only.bold || style.bold) props.fontWeight = 600;
    return [{ component: Components.text, props }];
  }

  return runs.map((run) => runComponent(run, style));
};

// --- block rendering ---------------------------------------------------------

const box = (props: IBox): Component => ({ component: Components.box, props });

const paragraphBlock = (source: string): Component =>
  box({ marginProp: BLOCK_MARGIN, children: inlineComponents(parseInline(source)) });

const HEADING_STYLES: { fontSize: string; lineHeight: string; marginProp: string }[] = [
  { fontSize: "20px", lineHeight: "28px", marginProp: "8px 0" },
  { fontSize: "18px", lineHeight: "26px", marginProp: "8px 0" },
  { fontSize: "16px", lineHeight: "24px", marginProp: "8px 0 6px 0" },
  { fontSize: "14px", lineHeight: "20px", marginProp: "8px 0 4px 0" },
  { fontSize: "13px", lineHeight: "20px", marginProp: "8px 0 4px 0" },
  { fontSize: "12px", lineHeight: "18px", marginProp: "8px 0 4px 0" },
];

const headingBlock = (level: number, source: string): Component => {
  const style = HEADING_STYLES[level - 1];
  return box({
    marginProp: style.marginProp,
    children: inlineComponents(parseInline(source), { ...style, bold: true }),
  });
};

const ruleBlock = (): Component =>
  box({
    heightProp: "1px",
    backgroundProp: "var(--border-service-color)",
    marginProp: "4px 0 16px 0",
  });

const codeBlock = (lines: string[]): Component =>
  box({
    marginProp: BLOCK_MARGIN,
    paddingProp: "8px 12px",
    backgroundProp: "var(--filled-button-background-color)",
    borderProp: {
      width: "1px",
      style: "solid",
      color: "var(--border-service-color)",
      radius: "6px",
    },
    overflowProp: "auto",
    // The portal copies unlisted camelCase props on a box into style verbatim;
    // fontFamily is outside the SDK type, hence the cast. Code lines inherit it.
    ...({ fontFamily: 'ui-monospace, SFMono-Regular, Consolas, "Courier New", monospace' } as IBox),
    children: lines.map((line) => ({
      component: Components.text,
      props: {
        // NBSP preserves indentation and alignment, and keeps each code line
        // unwrapped - long lines scroll inside the block instead.
        text: line.replace(/\t/g, "    ").replace(/ /g, NBSP) || NBSP,
        fontSize: "12px",
        lineHeight: "18px",
      },
    })),
  });

const quoteBlock = (children: Component[]): Component =>
  box({
    marginProp: BLOCK_MARGIN,
    paddingProp: "0 0 0 12px",
    ...({ borderLeft: "3px solid var(--border-service-color)" } as IBox),
    children,
  });

const listItemBlock = (indentChars: number, marker: string, source: string): Component => {
  const level = Math.min(3, Math.floor(indentChars / 2));
  const ordered = /^\d/.test(marker);

  // Task list checkboxes render as text glyphs - the preview is read-only.
  let content = source;
  const task = /^\[([ xX])\]\s+(.*)$/.exec(content);
  if (task) content = `${task[1] === " " ? "☐" : "☑"} ${task[2]}`;

  const bullet = ordered ? marker.replace(")", ".") : "•";

  return box({
    displayProp: "flex",
    alignItems: "flex-start",
    marginProp: `0 0 4px ${level * 16}px`,
    children: [
      box({
        widthProp: ordered ? "24px" : "16px",
        flexProp: "0 0 auto",
        children: [
          {
            component: Components.text,
            props: { text: bullet, lineHeight: "20px" },
          },
        ],
      }),
      box({
        flexProp: "1 1 auto",
        children: inlineComponents(parseInline(content)),
      }),
    ],
  });
};

const splitTableRow = (line: string): string[] => {
  let s = line.trim();
  if (s.charAt(0) === "|") s = s.slice(1);
  if (s.charAt(s.length - 1) === "|") s = s.slice(0, -1);
  return s.split("|").map((cell) => cell.trim());
};

const tableBlock = (header: string[], rows: string[][]): Component => {
  const cell = (source: string, bold: boolean): Component =>
    box({
      flexProp: "1 1 0",
      paddingProp: "6px 8px",
      children: inlineComponents(parseInline(source), bold ? { bold: true } : {}),
    });

  const row = (cells: string[], bold: boolean): Component =>
    box({
      displayProp: "flex",
      ...({ borderBottom: "1px solid var(--border-service-color)" } as IBox),
      // Every row shows the header's column count so the grid stays aligned.
      children: header.map((_, index) => cell(cells[index] ?? "", bold)),
    });

  return box({
    marginProp: BLOCK_MARGIN,
    overflowProp: "auto",
    children: [
      box({
        borderProp: {
          width: "1px",
          style: "solid",
          color: "var(--border-service-color)",
          radius: "6px",
        },
        children: [row(header, true), ...rows.map((cells) => row(cells, false))],
      }),
    ],
  });
};

// --- block parsing -----------------------------------------------------------

const HEADING_RE = /^(#{1,6})\s+(.*)$/;
const FENCE_RE = /^\s*(```|~~~)/;
const RULE_RE = /^\s*(-{3,}|\*{3,}|_{3,})\s*$/;
const QUOTE_RE = /^\s*>/;
const LIST_RE = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/;
const TABLE_SEPARATOR_RE = /^\s*\|?[\s:|-]+\|?\s*$/;

const startsNewBlock = (line: string): boolean =>
  HEADING_RE.test(line) ||
  FENCE_RE.test(line) ||
  RULE_RE.test(line) ||
  QUOTE_RE.test(line) ||
  LIST_RE.test(line);

const isTableStart = (line: string, next: string | undefined): boolean =>
  line.indexOf("|") !== -1 &&
  !!next &&
  next.indexOf("-") !== -1 &&
  TABLE_SEPARATOR_RE.test(next);

const parseBlocks = (lines: string[], depth: number): Component[] => {
  const blocks: Component[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    if (!line.trim()) {
      i += 1;
      continue;
    }

    const fence = FENCE_RE.exec(line);
    if (fence) {
      const closeRe = fence[1] === "```" ? /^\s*```/ : /^\s*~~~/;
      const code: string[] = [];
      let j = i + 1;
      while (j < lines.length && !closeRe.test(lines[j])) {
        code.push(lines[j]);
        j += 1;
      }
      blocks.push(codeBlock(code));
      i = j + 1;
      continue;
    }

    const heading = HEADING_RE.exec(line);
    if (heading) {
      const text = heading[2].replace(/\s+#+\s*$/, "");
      blocks.push(headingBlock(heading[1].length, text));
      i += 1;
      continue;
    }

    if (RULE_RE.test(line)) {
      blocks.push(ruleBlock());
      i += 1;
      continue;
    }

    if (QUOTE_RE.test(line) && depth < 3) {
      const quoted: string[] = [];
      let j = i;
      while (j < lines.length && QUOTE_RE.test(lines[j])) {
        quoted.push(lines[j].replace(/^\s*>\s?/, ""));
        j += 1;
      }
      blocks.push(quoteBlock(parseBlocks(quoted, depth + 1)));
      i = j;
      continue;
    }

    if (isTableStart(line, lines[i + 1])) {
      const header = splitTableRow(line);
      const rows: string[][] = [];
      let j = i + 2;
      while (j < lines.length && lines[j].trim() && lines[j].indexOf("|") !== -1) {
        rows.push(splitTableRow(lines[j]));
        j += 1;
      }
      blocks.push(tableBlock(header, rows));
      i = j;
      continue;
    }

    const list = LIST_RE.exec(line);
    if (list) {
      const items: Component[] = [];
      let j = i;
      while (j < lines.length) {
        const item = LIST_RE.exec(lines[j]);
        if (!item) break;
        items.push(listItemBlock(item[1].length, item[2], item[3]));
        j += 1;
      }
      blocks.push(box({ marginProp: BLOCK_MARGIN, children: items }));
      i = j;
      continue;
    }

    // Paragraph: consecutive plain lines joined with a space.
    const paragraph: string[] = [line.trim()];
    let j = i + 1;
    while (
      j < lines.length &&
      lines[j].trim() &&
      !startsNewBlock(lines[j]) &&
      !isTableStart(lines[j], lines[j + 1])
    ) {
      paragraph.push(lines[j].trim());
      j += 1;
    }
    blocks.push(paragraphBlock(paragraph.join(" ")));
    i = j;
  }

  return blocks;
};

// --- entry point ---------------------------------------------------------------

export const renderMarkdown = (source: string): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  paddingProp: "0 0 16px 0",
  children: parseBlocks(source.replace(/\r\n?/g, "\n").split("\n"), 0),
});
```

## src/preview.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  ButtonSize,
  Component,
  Components,
  IBox,
  IModalDialog,
  ModalDisplayType,
} from "@onlyoffice/docspace-plugin-sdk";

import { t } from "./locales";
import { renderMarkdown } from "./markdown";

/** The portal hands these to the plugin through the API scope. */
export type TApiParts = { origin: string; proxy: string; prefix: string };

/**
 * Reading beyond this many characters risks blocking the portal's event loop
 * while parsing and rendering - the plugin shares it. Longer files are
 * truncated with a visible notice.
 */
const MAX_CHARS = 200_000;

/** Joins origin/proxy/prefix defensively - any part may be empty or carry stray slashes. */
const buildApiUrl = (parts: TApiParts): string => {
  let url = parts.origin.replace(/\/+$/, "");

  for (const part of [parts.proxy, parts.prefix]) {
    if (!part) continue;
    const clean = part.trim().replace(/^\/+/, "");
    if (!clean) continue;
    url += url.endsWith("/") ? clean : `/${clean}`;
  }

  return url;
};

const loadingBody = (): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [
    {
      component: Components.box,
      props: {
        marginProp: "0 0 12px 0",
        children: [
          { component: Components.skeleton, props: { width: "60%", height: "20px" } },
        ],
      },
    },
    {
      component: Components.box,
      props: {
        marginProp: "0 0 8px 0",
        children: [
          { component: Components.skeleton, props: { width: "100%", height: "12px" } },
        ],
      },
    },
    {
      component: Components.box,
      props: {
        marginProp: "0 0 12px 0",
        children: [
          { component: Components.skeleton, props: { width: "90%", height: "12px" } },
        ],
      },
    },
    { component: Components.skeleton, props: { width: "100%", height: "120px" } },
  ],
});

const messageBody = (message: string): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [{ component: Components.text, props: { text: message, lineHeight: "20px" } }],
});

const noticeRow = (message: string): IBox => ({
  marginProp: "0 0 12px 0",
  children: [
    {
      component: Components.text,
      props: {
        text: message,
        fontSize: "12px",
        color: "var(--status-warning)",
        lineHeight: "16px",
      },
    },
  ],
});

const dialogFooter = (): IBox => ({
  displayProp: "flex",
  children: [
    {
      component: Components.button,
      props: {
        label: t("dialog.close"),
        size: ButtonSize.normal,
        primary: true,
        scale: true,
        onClick: () => ({ actions: [Actions.closeModal] }),
      },
    },
  ],
});

/** All three sections must always be returned together - a partial result wipes the omitted ones. */
const sections = (header: string, body: IBox) => ({
  newDialogHeader: header,
  newDialogBody: body,
  newDialogFooter: dialogFooter(),
});

/**
 * The preview aside. It opens instantly with a skeleton; the fetch and the
 * Markdown rendering happen in the dialog's own onLoad, never in the menu
 * callback - and every failure resolves to an error body, because a rejected
 * onLoad would leave the skeleton on screen forever.
 */
export const previewDialog = (
  fileId: number | string,
  getApi: () => TApiParts,
): IModalDialog =>
  ({
    displayType: ModalDisplayType.aside,
    dialogHeader: t("dialog.header"),
    dialogBody: loadingBody(),
    dialogFooter: dialogFooter(),
    onClose: () => ({ actions: [Actions.closeModal] }),
    onLoad: async () => {
      try {
        const apiUrl = buildApiUrl(getApi());

        // Requests ride the signed-in user's session; every payload is wrapped
        // in a `response` field.
        const metaResponse = await fetch(`${apiUrl}/files/file/${fileId}`, {
          credentials: "include",
        });
        if (!metaResponse.ok) return sections(t("dialog.header"), messageBody(t("error.load")));

        const file = (await metaResponse.json()).response;
        const header = String(file?.title ?? t("dialog.header"));

        // The bytes come from viewUrl, which is a download - respect the
        // file's own permission map before touching it.
        if (!file?.security?.Download)
          return sections(header, messageBody(t("error.noPermission")));

        const contentResponse = await fetch(file.viewUrl, { credentials: "include" });
        if (!contentResponse.ok) return sections(header, messageBody(t("error.load")));

        let content = await contentResponse.text();

        if (!content.trim()) return sections(header, messageBody(t("notice.empty")));

        const truncated = content.length > MAX_CHARS;
        if (truncated) content = content.slice(0, MAX_CHARS);

        const children: Component[] = [];
        if (truncated)
          children.push({ component: Components.box, props: noticeRow(t("notice.truncated")) });
        children.push({ component: Components.box, props: renderMarkdown(content) });

        return sections(header, { displayProp: "flex", flexDirection: "column", children });
      } catch {
        // Nothing on the portal catches plugin errors for us.
        return sections(t("dialog.header"), messageBody(t("error.load")));
      }
    },
    // Outside the SDK type but honoured by the portal: managed scrolling for
    // long aside bodies.
    withBodyScroll: true,
  }) as IModalDialog;
```
