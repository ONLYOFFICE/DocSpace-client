# IBox

Defined in: [interfaces/components/IBox.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L70)

A container that lays out its contents in one direction.
Box provides general CSS capabilities like flexbox layout, paddings, background color, border, and animation.

![box](/assets/images/docspace/box.png#gh-light-mode-only)![box](/assets/images/docspace/box.dark.png#gh-dark-mode-only)

## Properties

### widthProp?

```ts
optional widthProp: string;
```

Defined in: [interfaces/components/IBox.ts:74](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L74)

Defines the width of the element area

### paddingProp?

```ts
optional paddingProp: string;
```

Defined in: [interfaces/components/IBox.ts:80](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L80)

Defines the padding area of all four sides of the element.
This is a shorthand for "padding-top", "padding-right", "padding-bottom", and "padding-left"

### displayProp?

```ts
optional displayProp: string;
```

Defined in: [interfaces/components/IBox.ts:86](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L86)

Specifies whether the element is treated as a block or inline element and also determines the layout
used for its children, such as flow layout, grid or flex

### flexDirection?

```ts
optional flexDirection: string;
```

Defined in: [interfaces/components/IBox.ts:92](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L92)

Sets how the flex items are placed in the flex container defining the main axis (column or row)
and the direction (normal or reversed)

### alignItems?

```ts
optional alignItems: string;
```

Defined in: [interfaces/components/IBox.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L99)

Sets the "alignSelf" value on all direct children as a group. In flexbox, it controls the alignment
of items on the cross-axis. In grid layout, it controls the alignment of items on the block axis
within their grid area

### borderProp?

```ts
optional borderProp: string | IBorderProp;
```

Defined in: [interfaces/components/IBox.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L103)

Defines the element border. It sets the values of border width, border style, and border color

### alignContent?

```ts
optional alignContent: string;
```

Defined in: [interfaces/components/IBox.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L109)

Defines the distribution of space between and around content items along the flexbox cross-axis
or the grid block axis

### alignSelf?

```ts
optional alignSelf: string;
```

Defined in: [interfaces/components/IBox.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L115)

Overrides a grid or flex item "alignItems" value. In grid, it aligns the item inside the grid area.
In flexbox, it aligns the item on the cross-axis

### backgroundProp?

```ts
optional backgroundProp: string;
```

Defined in: [interfaces/components/IBox.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L120)

Defines all background style properties at once, such as color, image, origin and size, or repeat method

### flexBasis?

```ts
optional flexBasis: string;
```

Defined in: [interfaces/components/IBox.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L126)

Defines the initial main size of the flex item. It sets the size of the content box unless
otherwise set with "box-sizing"

### flexProp?

```ts
optional flexProp: string;
```

Defined in: [interfaces/components/IBox.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L132)

Defines how the flex item will grow or shrink to fit the space available in its flex container.
It is a shorthand for "flex-grow", "flex-shrink", and "flex-basis"

### flexWrap?

```ts
optional flexWrap: string;
```

Defined in: [interfaces/components/IBox.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L138)

Defines whether flex items are forced onto one line or can wrap onto multiple lines.
If wrapping is allowed, it sets the direction that lines are stacked

### gridArea?

```ts
optional gridArea: string;
```

Defined in: [interfaces/components/IBox.ts:146](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L146)

Defines a shorthand property for "grid-row-start", "grid-column-start", "grid-row-end",
and "grid-column-end", specifying the size of the grid item and location within the grid
by contributing a line, a span, or nothing (automatic) to its grid placement,
thereby specifying the edges of its grid area.

### heightProp?

```ts
optional heightProp: string;
```

Defined in: [interfaces/components/IBox.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L151)

Defines the height of the element area

### justifyContent?

```ts
optional justifyContent: string;
```

Defined in: [interfaces/components/IBox.ts:157](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L157)

Defines how the browser distributes space between and around content items along the main axis
of a flex container, and the inline axis of a grid container

### justifyItems?

```ts
optional justifyItems: string;
```

Defined in: [interfaces/components/IBox.ts:163](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L163)

Defines the default "justifySelf" for all items of the box, giving them all a default way
of justifying each box along the appropriate axis

### justifySelf?

```ts
optional justifySelf: string;
```

Defined in: [interfaces/components/IBox.ts:168](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L168)

Defines the way the box is justified inside its alignment container along the appropriate axis

### marginProp?

```ts
optional marginProp: string;
```

Defined in: [interfaces/components/IBox.ts:174](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L174)

Defines the margin area on all four sides of an element. It is a shorthand for "margin-top",
"margin-right", "margin-bottom", and "margin-left"

### overflowProp?

```ts
optional overflowProp: string;
```

Defined in: [interfaces/components/IBox.ts:179](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L179)

Specifies what to do when the element content is too big to fit in its block formatting context

### textAlign?

```ts
optional textAlign: string;
```

Defined in: [interfaces/components/IBox.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L184)

Defines the horizontal alignment of a block element or table-cell box

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IBox.ts:190](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L190)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

### id?

```ts
optional id: string;
```

Defined in: [interfaces/components/IBox.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L195)

Unique identifier.

### children?

```ts
optional children: Component[];
```

Defined in: [interfaces/components/IBox.ts:200](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L200)

The child components to render within this box

***

## Example

Flexible input container with gradient background

```typescript
const newInputProps: IInput = {
  value: "",
  onChange: () => {},
  scale: true,
  placeholder: "",
}

const inputComponent: InputGroup = {
  component: Components.input,
  props: newInputProps,
}

const inputBox: IBox = {
  widthProp: "100px",
  paddingProp: "10px",
  displayProp: "flex",
  flexDirection: "row",
  alignItems: "center",
  borderProp: {
    color: "blue",
    radius: "10px",
    style: "solid",
    width: "2px"
  },
  alignContent: "center",
  alignSelf: "center",
  backgroundProp: "linear-gradient(to right, #ff0000, #00ff00)",
  flexBasis: "50%",
  flexProp: "1",
  flexWrap: "wrap",
  children: inputComponent
}
```

## IBorderProp

Defined in: [interfaces/components/IBox.ts:219](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L219)

Defines the border properties for a box element.

### Properties

#### color

```ts
color: string;
```

Defined in: [interfaces/components/IBox.ts:221](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L221)

Defines the border color of the element area

#### radius

```ts
radius: string;
```

Defined in: [interfaces/components/IBox.ts:224](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L224)

Defines the border radius of the element area

#### style

```ts
style: string;
```

Defined in: [interfaces/components/IBox.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L227)

Defines the border style of the element area

#### width

```ts
width: string;
```

Defined in: [interfaces/components/IBox.ts:230](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L230)

Defines the border width of the element area

### Example

Border properties with custom styling

```typescript
const borderProps: IBorderProp = {
  color: "blue",
  radius: "10px",
  style: "solid",
  width: "2px"
}
```

