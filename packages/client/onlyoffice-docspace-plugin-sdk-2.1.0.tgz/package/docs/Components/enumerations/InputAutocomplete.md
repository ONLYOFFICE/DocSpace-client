# Enumeration: InputAutocomplete

Defined in: [interfaces/components/IInput.ts:54](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L54)

The input autocomplete feature.

## Enumeration Members

### on

> **on**: `"on"`

Defined in: [interfaces/components/IInput.ts:58](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L58)

Autocomplete is enabled.

***

### off

> **off**: `"off"`

Defined in: [interfaces/components/IInput.ts:62](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L62)

Autocomplete is disabled.
