# IPlugin

Defined in: [interfaces/plugins/IPlugin.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L73)

The default plugin.
This interface must be implemented in each plugin because without the plugin status it will not be built in.

## Methods

### updateStatus()

```ts
updateStatus(status: PluginStatus): void;
```

Defined in: [interfaces/plugins/IPlugin.ts:90](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L90)

Update the plugin status

#### Parameters

##### status

[`PluginStatus`](../../enums/Plugins.md#pluginstatus)

#### Returns

`void`

### getStatus()

```ts
getStatus(): PluginStatus;
```

Defined in: [interfaces/plugins/IPlugin.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L93)

Get the current plugin status

#### Returns

[`PluginStatus`](../../enums/Plugins.md#pluginstatus)

### setOnLoadCallback()

```ts
setOnLoadCallback(callback: () => Promise<void>): void;
```

Defined in: [interfaces/plugins/IPlugin.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L96)

Sets the onLoadCallback variable to the plugin

#### Parameters

##### callback

() => `Promise`\<`void`\>

#### Returns

`void`

## Properties

### status

```ts
status: PluginStatus;
```

Defined in: [interfaces/plugins/IPlugin.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L75)

The plugin status (active or hide)

### language?

```ts
optional language: PluginLocale;
```

Defined in: [interfaces/plugins/IPlugin.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L78)

The plugin language

### setLanguage()?

```ts
optional setLanguage: (language: PluginLocale) => void;
```

Defined in: [interfaces/plugins/IPlugin.ts:81](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L81)

The method is called on the portal side when the portal language is changed.

#### Parameters

##### language

[`PluginLocale`](../../enums/Plugins.md#pluginlocale)

#### Returns

`void`

### getLanguage()?

```ts
optional getLanguage: () => PluginLocale;
```

Defined in: [interfaces/plugins/IPlugin.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L84)

The method is called on the portal side to get the plugin language.

#### Returns

[`PluginLocale`](../../enums/Plugins.md#pluginlocale)

### onLoadCallback()

```ts
onLoadCallback: () => Promise<void>;
```

Defined in: [interfaces/plugins/IPlugin.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IPlugin.ts#L87)

Callback which will be executed when uploading the plugin to the portal

#### Returns

`Promise`\<`void`\>

## Example

Every plugin class implements `IPlugin` (usually together with one or more
type-specific interfaces such as `IContextMenuPlugin`). DocSpace reads the
plugin status via `getStatus` and runs `onLoadCallback` when the plugin is
uploaded to the portal. The optional `language` field and its `setLanguage`/
`getLanguage` methods let the portal keep the plugin in sync with the current
portal language.

```typescript
import { type IPlugin, PluginStatus, PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

class Plugin implements IPlugin {
  status: PluginStatus = PluginStatus.active;
  language: PluginLocale = PluginLocale.EN_US;

  onLoadCallback = async (): Promise<void> => {
    try {
      await initializeAnalyzer();
    } catch (error) {
      // Hide the plugin if it cannot be initialized
      this.status = PluginStatus.hide;
    }
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => {
    return this.status;
  };

  // Called by the portal when the portal language changes
  setLanguage = (language: PluginLocale): void => {
    this.language = language;
  };

  // Called by the portal to read the current plugin language
  getLanguage = (): PluginLocale => {
    return this.language;
  };

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };
}
```

