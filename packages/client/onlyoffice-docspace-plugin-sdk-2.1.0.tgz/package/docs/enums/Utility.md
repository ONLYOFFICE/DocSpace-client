# FilterType

Defined in: [enums/Utility.ts:2](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Utility.ts#L2)

Enum for filter type used in file selectors.

## Enumeration Members

### None

```ts
None: 0;
```

Defined in: [enums/Utility.ts:4](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Utility.ts#L4)

No filter applied.

### FilesOnly

```ts
FilesOnly: 1;
```

Defined in: [enums/Utility.ts:6](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Utility.ts#L6)

Show files only (excludes folders).

### FoldersOnly

```ts
FoldersOnly: 2;
```

Defined in: [enums/Utility.ts:8](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Utility.ts#L8)

Show folders only (excludes files).

### DocumentsOnly

```ts
DocumentsOnly: 3;
```

Defined in: [enums/Utility.ts:10](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Utility.ts#L10)

Show document files only (e.g. .docx, .odt).

### PresentationsOnly

```ts
PresentationsOnly: 4;
```

Defined in: [enums/Utility.ts:12](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Utility.ts#L12)

Show presentation files only (e.g. .pptx, .odp).

### SpreadsheetsOnly

```ts
SpreadsheetsOnly: 5;
```

Defined in: [enums/Utility.ts:14](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Utility.ts#L14)

Show spreadsheet files only (e.g. .xlsx, .ods).

### ImagesOnly

```ts
ImagesOnly: 7;
```

Defined in: [enums/Utility.ts:16](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Utility.ts#L16)

Show image files only (e.g. .png, .jpg, .gif).
