# Enumeration: RoomsType

Defined in: [enums/Rooms.ts:18](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L18)

Defines the different types of rooms available in the system.

## Enumeration Members

### PublicRoom

> **PublicRoom**: `"public-room"`

Defined in: [enums/Rooms.ts:20](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L20)

A public room accessible to a wide audience.

***

### FormRoom

> **FormRoom**: `"form-room"`

Defined in: [enums/Rooms.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L22)

A room designed for filling out forms.

***

### EditingRoom

> **EditingRoom**: `"editing-room"`

Defined in: [enums/Rooms.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L24)

A room focused on collaborative document editing.

***

### VirtualDataRoom

> **VirtualDataRoom**: `"virtual-data-room"`

Defined in: [enums/Rooms.ts:26](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L26)

A secure room for data storage and review.

***

### CustomRoom

> **CustomRoom**: `"custom-room"`

Defined in: [enums/Rooms.ts:28](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L28)

A room with custom permissions and settings.
