# `usersType` или `usersTypes`? Правильны оба — но каждый только в своём скоупе

**Короткий ответ:** это не синонимы и не опечатка в одном из мест. У каждого скоупа своё имя поля-фильтра, и портал читает **ровно одно** имя на скоуп:

| Поле | Скоупы |
|---|---|
| `usersTypes` (множественное) | `ContextMenu`, `InfoPanel`, `EventListener`, `ArticleButton` |
| `usersType` (единственное) | `MainButton`, `ProfileMenu`, `File` |

Проверено на актуальной паре: SDK `@onlyoffice/docspace-plugin-sdk` 2.1.0 ↔ DocSpace 3.7.2.

Так что если ты видел `usersTypes` в элементе контекстного меню, а `usersType` — в элементе главной кнопки или меню профиля, то оба места были написаны правильно.

## Почему компилируются оба

Потому что оба имени честно существуют в SDK — просто в разных интерфейсах, и оба с одинаковым типом `UsersType[]`:

- `usersTypes?: UsersType[]` — в `IContextMenuItem`, `IInfoPanelItem`, `IEventListenerItem`, `IArticleButtonItem`;
- `usersType?: UsersType[]` — в `IMainButtonItem`, `IProfileMenuItem`, `IFileItem`.

А если написать *не то* поле для данного скоупа, TypeScript тоже часто промолчит. Причины две:

1. Оба поля опциональные — отсутствие «правильного» поля ошибкой не является.
2. Лишнее свойство TS ловит только на «свежем» объектном литерале в явно типизированной позиции (excess property check). Стоит собрать элемент в переменную без аннотации типа — и проверка не срабатывает:

```ts
// Так TS поймает: свежий литерал с явным типом
const item: IContextMenuItem = {
  key: "myplugin-x", label: "X", icon: "x.svg",
  usersType: [UsersType.user],   // ошибка: лишнее свойство
};

// А так — молча скомпилируется и молча не сработает на портале
const item = {
  key: "myplugin-x", label: "X", icon: "x.svg",
  usersType: [UsersType.user],   // не то поле для ContextMenu
};
this.contextMenuItems.set(item.key, item);
```

## Что происходит, если ошибиться

Худший вариант из возможных — **тихий сбой**. Загрузчик портала для каждого скоупа читает только «своё» имя; неправильное он просто не замечает. Фильтр молча пропускается, и **пункт показывается всем пользователям** — без единой ошибки в консоли. По опыту это самая частая ошибка в полях элементов докспейсовых плагинов: плагин собирается, ставится, работает — но «протекает» не тем ролям.

## Почему так устроено

Это не принцип, а случайность — историческая непоследовательность SDK и портала. Вывести правило логически нельзя, его можно только запомнить или подсмотреть в таблице выше. Практический приём: всегда явно аннотируй тип элемента (`const item: IContextMenuItem = {...}`) — тогда и автодополнение в IDE подскажет правильное имя, и excess property check поймает неправильное.

## Как этим пользоваться

Значения — из энума `UsersType` (ключи camelCase, значения PascalCase): `owner`, `docSpaceAdmin`, `roomAdmin`, `collaborator`, `user`. Если поле не указать вовсе — пункт виден всем.

```ts
import { UsersType } from "@onlyoffice/docspace-plugin-sdk";

// Контекстное меню — МНОЖЕСТВЕННОЕ число
const ctxItem: IContextMenuItem = {
  key: "myplugin-convert",
  label: "Convert to PDF",
  icon: "convert.svg",
  onItemClick: (id) => ({ actions: [] }),
  usersTypes: [UsersType.docSpaceAdmin, UsersType.roomAdmin],
};

// Меню профиля — ЕДИНСТВЕННОЕ число
const profileItem: IProfileMenuItem = {
  key: "myplugin-profile",
  label: "My tools",
  icon: "tools.svg",
  onClick: () => ({ actions: [] }),
  usersType: [UsersType.owner, UsersType.docSpaceAdmin],
};
```

Кстати, для `ContextMenu` фильтры вычисляются в момент открытия меню, а не при регистрации — смена роли пользователя применяется «вживую», без переустановки плагина.

## Подстраховка

Именно эту ошибку ловит валидатор из тулкита: он загружает собранный бандл в песочнице и проверяет, что имя фильтра соответствует скоупу и что значения ролей — из тех, что портал распознаёт (класс находок `item`):

```sh
node "C:\Users\Abobadance\docspace-plugin-sdk\skill\scripts\validate-plugin.mjs" <папка-плагина> --invoke
```

Из той же серии, чтобы два раза не вставать: поле `devices` портал читает во всех скоупах, но в `File` проверка устройства происходит не при отображении, а уже в момент клика.
