# Type Alias: BoxGroup

> **BoxGroup** = `object`

Defined in: [interfaces/components/Component.ts:65](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L65)

Defines the box component.

## Example

```typescript
import { IBox, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const box: IBox = {
  widthProp: "200px",
  paddingProp: "16px",
  displayProp: "flex",
  flexDirection: "column",
  alignItems: "center",
  borderProp: {
    color: "#333333",
    radius: "8px",
    style: "solid",
    width: "1px"
  },
  backgroundProp: "#f8f9f9"
};

const boxGroup: Component = {
  component: Components.box,
  props: box,
  contextName: "container"
};
```

## Properties

### component

> **component**: [`box`](../../enumerations/Components.md#box)

Defined in: [interfaces/components/Component.ts:67](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L67)

Defines the "box" component type

***

### props

> **props**: [`IBox`](../interfaces/IBox.md)

Defined in: [interfaces/components/Component.ts:69](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L69)

Defines the box component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:71](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L71)

Defines the box component context name that updates the component via React context
