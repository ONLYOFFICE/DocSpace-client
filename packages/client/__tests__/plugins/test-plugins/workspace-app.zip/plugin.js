import { useEffect as e, useState as t } from "react";
import { Button as n, ButtonSize as r, Heading as i, HeadingLevel as a, HeadingSize as o, SelectedItem as s, Text as c, ToggleButton as l } from "@onlyoffice/apps-ui-kit";
import { useCurrentUser as u, usePluginAPI as d, usePluginActions as f, usePluginSettings as p } from "@onlyoffice/docspace-plugin-sdk/react";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
// \0rolldown/runtime.js
var _ = (e, t) => () => (t || (e((t = { exports: {} }).exports, t, t.exports), e = null), t.exports), v = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Actions = void 0;
	var t;
	(function(e) {
		e.updateProps = "update-props", e.updateContext = "update-context", e.updateStatus = "update-status", e.updateContextMenuItems = "update-context-menu-items", e.updateInfoPanelItems = "update-info-panel-items", e.updateMainButtonItems = "update-main-button-items", e.updateProfileMenuItems = "update-profile-menu-items", e.updateFileItems = "update-file-items", e.updateEventListenerItems = "update-event-listener-items", e.updateArticleNavigationItems = "update-article-navigation-items", e.updateDashboardWidgetItems = "update-dashboard-widget-items", e.updateArticleButtonItems = "update-article-button-items", e.showToast = "show-toast", e.showCreateDialogModal = "show-create-dialog-modal", e.updateCreateDialogModal = "update-create-dialog-modal", e.showModal = "show-modal", e.closeModal = "close-modal", e.sendPostMessage = "send-post-message", e.saveSettings = "save-settings", e.showSelector = "show-selector", e.updateSelector = "update-selector", e.closeSelector = "close-selector", e.addFloatingOperationsButton = "add-floating-operations-button", e.updateFloatingOperationsButton = "update-floating-operations-button", e.removeFloatingOperationsButton = "remove-floating-operations-button", e.navigate = "navigate", e.openInfoPanel = "open-info-panel", e.showMediaViewer = "show-media-viewer", e.updateMediaViewer = "update-media-viewer", e.closeMediaViewer = "close-media-viewer";
	})(t || (e.Actions = t = {}));
})), y = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Events = void 0;
	var t;
	(function(e) {
		e.CREATE = "create", e.RENAME = "rename", e.ROOM_CREATE = "create_room", e.ROOM_EDIT = "edit_room", e.CHANGE_COLUMN = "change_column", e.CHANGE_USER_TYPE = "change_user_type", e.CREATE_PLUGIN_FILE = "create_plugin_file";
	})(t || (e.Events = t = {}));
})), b = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.PluginLocale = e.PluginStatus = void 0;
	var t;
	(function(e) {
		e.active = "active", e.hide = "hide";
	})(t || (e.PluginStatus = t = {}));
	var n;
	(function(e) {
		e.AZ = "az", e.CS = "cs", e.DE = "de", e.EN_GB = "en-GB", e.EN_US = "en-US", e.ES = "es", e.FR = "fr", e.IT = "it", e.LV = "lv", e.NL = "nl", e.PL = "pl", e.PT_BR = "pt-BR", e.PT = "pt", e.RO = "ro", e.SK = "sk", e.SL = "sl", e.SQ_AL = "sq-AL", e.FI = "fi", e.VI = "vi", e.TR = "tr", e.EL_GR = "el-GR", e.BG = "bg", e.RU = "ru", e.SR_CYRL_RS = "sr-Cyrl-RS", e.SR_LATN_RS = "sr-Latn-RS", e.UK_UA = "uk-UA", e.HY_AM = "hy-AM", e.AR_SA = "ar-SA", e.SI = "si", e.LO_LA = "lo-LA", e.ZH_CN = "zh-CN", e.JA_JP = "ja-JP", e.KO_KR = "ko-KR";
	})(n || (e.PluginLocale = n = {}));
})), x = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.FilesSecurity = e.FilesExst = e.FilesType = void 0;
	var t;
	(function(e) {
		e.room = "room", e.file = "file", e.folder = "folder", e.image = "image", e.video = "video";
	})(t || (e.FilesType = t = {}));
	var n;
	(function(e) {
		e.doc = ".doc", e.docx = ".docx", e.docm = ".docm", e.dotx = ".dotx", e.odt = ".odt", e.fodt = ".fodt", e.ott = ".ott", e.rtf = ".rtf", e.txt = ".txt", e.pdf = ".pdf", e.docxf = ".docxf", e.oform = ".oform", e.xls = ".xls", e.xlsx = ".xlsx", e.xlsm = ".xlsm", e.ods = ".ods", e.ots = ".ots", e.ppt = ".ppt", e.pptx = ".pptx", e.pptm = ".pptm", e.odp = ".odp", e.otp = ".otp", e.pps = ".pps", e.ppsx = ".ppsx", e.pot = ".pot", e.avi = ".avi", e.flv = ".flv", e.mkv = ".mkv", e.mov = ".mov", e.mp4 = ".mp4", e.mpg = ".mpg", e.webm = ".webm", e.m2ts = ".m2ts", e.dvd = ".dvd", e.svg = ".svg", e.csv = ".csv", e.djvu = ".djvu", e.epub = ".epub", e.fb2 = ".fb2", e.pb2 = ".pb2", e.iaf = ".iaf", e.ics = ".ics", e.mht = ".mht", e.xps = ".xps", e.xml = ".xml";
	})(n || (e.FilesExst = n = {}));
	var r;
	(function(e) {
		e.Convert = "Convert", e.Copy = "Copy", e.CustomFilter = "CustomFilter", e.Delete = "Delete", e.Download = "Download", e.Duplicate = "Duplicate", e.Edit = "Edit", e.EditHistory = "EditHistory", e.FillForms = "FillForms", e.Lock = "Lock", e.Move = "Move", e.Read = "Read", e.ReadHistory = "ReadHistory", e.Rename = "Rename", e.Review = "Review", e.SubmitToFormGallery = "SubmitToFormGallery", e.StopFilling = "StopFilling", e.ResetFilling = "ResetFilling", e.EditForm = "EditForm", e.Comment = "Comment", e.CreateRoomFrom = "CreateRoomFrom", e.CopyLink = "CopyLink", e.Embed = "Embed";
	})(r || (e.FilesSecurity = r = {}));
})), S = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.UsersType = void 0;
	var t;
	(function(e) {
		e.owner = "Owner", e.docSpaceAdmin = "DocSpaceAdmin", e.roomAdmin = "RoomAdmin", e.collaborator = "Collaborator", e.user = "User";
	})(t || (e.UsersType = t = {}));
})), C = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.UserRole = void 0;
	var t;
	(function(e) {
		e.owner = "Owner", e.fullAdmin = "FullAdmin", e.roomAdmin = "RoomAdmin", e.user = "PortalUser", e.guest = "Guest";
	})(t || (e.UserRole = t = {}));
})), w = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Components = void 0;
	var t;
	(function(e) {
		e.box = "box", e.button = "button", e.checkbox = "checkbox", e.input = "input", e.label = "label", e.text = "text", e.textArea = "textArea", e.toggleButton = "toggleButton", e.img = "img", e.iFrame = "iFrame", e.comboBox = "comboBox", e.skeleton = "skeleton", e.iconButton = "iconButton", e.link = "link";
	})(t || (e.Components = t = {}));
})), T = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Devices = void 0;
	var t;
	(function(e) {
		e.mobile = "mobile", e.tablet = "tablet", e.desktop = "desktop";
	})(t || (e.Devices = t = {}));
})), E = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Security = void 0;
	var t;
	(function(e) {
		e.Copy = "Copy", e.CopySharedLink = "CopySharedLink", e.CopyTo = "CopyTo", e.Create = "Create", e.Delete = "Delete", e.Download = "Download", e.Duplicate = "Duplicate", e.EditAccess = "EditAccess", e.EditRoom = "EditRoom", e.Move = "Move", e.MoveTo = "MoveTo", e.Mute = "Mute", e.Pin = "Pin", e.Read = "Read", e.Rename = "Rename", e.CreateRoomFrom = "CreateRoomFrom", e.CopyLink = "CopyLink", e.Embed = "Embed";
	})(t || (e.Security = t = {}));
})), D = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.SelectorType = void 0;
	var t;
	(function(e) {
		e.Base = "base", e.Files = "files", e.Groups = "groups", e.People = "people", e.Room = "room";
	})(t || (e.SelectorType = t = {}));
})), O = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.FilterType = void 0;
	var t;
	(function(e) {
		e[e.None = 0] = "None", e[e.FilesOnly = 1] = "FilesOnly", e[e.FoldersOnly = 2] = "FoldersOnly", e[e.DocumentsOnly = 3] = "DocumentsOnly", e[e.PresentationsOnly = 4] = "PresentationsOnly", e[e.SpreadsheetsOnly = 5] = "SpreadsheetsOnly", e[e.ImagesOnly = 7] = "ImagesOnly";
	})(t || (e.FilterType = t = {}));
})), k = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.RoomsType = e.RoomSearchArea = void 0;
	var t;
	(function(e) {
		e.Any = "Any", e.Active = "Active", e.Archive = "Archive", e.Templates = "Templates";
	})(t || (e.RoomSearchArea = t = {}));
	var n;
	(function(e) {
		e.PublicRoom = "public-room", e.FormRoom = "form-room", e.EditingRoom = "editing-room", e.VirtualDataRoom = "virtual-data-room", e.CustomRoom = "custom-room";
	})(n || (e.RoomsType = n = {}));
})), A = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Section = void 0;
	var t;
	(function(e) {
		e.Files = "Files", e.Accounts = "Accounts", e.Settings = "Settings";
	})(t || (e.Section = t = {}));
})), j = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Section = e.RoomsType = e.RoomSearchArea = e.FilterType = e.SelectorType = e.PluginLocale = e.Security = e.Devices = e.UserRole = e.UsersType = e.PluginStatus = e.FilesSecurity = e.FilesType = e.FilesExst = e.Events = e.Components = e.Actions = void 0;
	var t = v();
	Object.defineProperty(e, "Actions", {
		enumerable: !0,
		get: function() {
			return t.Actions;
		}
	});
	var n = y();
	Object.defineProperty(e, "Events", {
		enumerable: !0,
		get: function() {
			return n.Events;
		}
	});
	var r = b();
	Object.defineProperty(e, "PluginStatus", {
		enumerable: !0,
		get: function() {
			return r.PluginStatus;
		}
	}), Object.defineProperty(e, "PluginLocale", {
		enumerable: !0,
		get: function() {
			return r.PluginLocale;
		}
	});
	var i = x();
	Object.defineProperty(e, "FilesExst", {
		enumerable: !0,
		get: function() {
			return i.FilesExst;
		}
	}), Object.defineProperty(e, "FilesType", {
		enumerable: !0,
		get: function() {
			return i.FilesType;
		}
	}), Object.defineProperty(e, "FilesSecurity", {
		enumerable: !0,
		get: function() {
			return i.FilesSecurity;
		}
	});
	var a = S();
	Object.defineProperty(e, "UsersType", {
		enumerable: !0,
		get: function() {
			return a.UsersType;
		}
	});
	var o = C();
	Object.defineProperty(e, "UserRole", {
		enumerable: !0,
		get: function() {
			return o.UserRole;
		}
	});
	var s = w();
	Object.defineProperty(e, "Components", {
		enumerable: !0,
		get: function() {
			return s.Components;
		}
	});
	var c = T();
	Object.defineProperty(e, "Devices", {
		enumerable: !0,
		get: function() {
			return c.Devices;
		}
	});
	var l = E();
	Object.defineProperty(e, "Security", {
		enumerable: !0,
		get: function() {
			return l.Security;
		}
	});
	var u = D();
	Object.defineProperty(e, "SelectorType", {
		enumerable: !0,
		get: function() {
			return u.SelectorType;
		}
	});
	var d = O();
	Object.defineProperty(e, "FilterType", {
		enumerable: !0,
		get: function() {
			return d.FilterType;
		}
	});
	var f = k();
	Object.defineProperty(e, "RoomSearchArea", {
		enumerable: !0,
		get: function() {
			return f.RoomSearchArea;
		}
	}), Object.defineProperty(e, "RoomsType", {
		enumerable: !0,
		get: function() {
			return f.RoomsType;
		}
	});
	var p = A();
	Object.defineProperty(e, "Section", {
		enumerable: !0,
		get: function() {
			return p.Section;
		}
	});
})), M = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.ModalDisplayType = void 0;
	var t;
	(function(e) {
		e.modal = "modal", e.aside = "aside";
	})(t || (e.ModalDisplayType = t = {}));
})), N = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.InputType = e.InputAutocomplete = e.InputSize = void 0;
	var t;
	(function(e) {
		e.base = "base", e.middle = "middle", e.big = "big", e.huge = "huge", e.large = "large";
	})(t || (e.InputSize = t = {}));
	var n;
	(function(e) {
		e.on = "on", e.off = "off";
	})(n || (e.InputAutocomplete = n = {}));
	var r;
	(function(e) {
		e.text = "text", e.password = "password";
	})(r || (e.InputType = r = {}));
})), P = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.ToastType = void 0;
	var t;
	(function(e) {
		e.success = "success", e.error = "error", e.warning = "warning", e.info = "info";
	})(t || (e.ToastType = t = {}));
})), F = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.ButtonSize = void 0;
	var t;
	(function(e) {
		e.extraSmall = "extra-small", e.small = "small", e.normal = "normal", e.medium = "medium";
	})(t || (e.ButtonSize = t = {}));
})), I = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.LinkTarget = e.LinkType = void 0;
	var t;
	(function(e) {
		e.page = "page", e.action = "action";
	})(t || (e.LinkType = t = {}));
	var n;
	(function(e) {
		e.blank = "_blank", e.self = "_self", e.parent = "_parent", e.top = "_top";
	})(n || (e.LinkTarget = n = {}));
})), L = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.FloatingOperationType = void 0;
	var t;
	(function(e) {
		e.Download = "download", e.Convert = "convert", e.Copy = "copy", e.Duplicate = "duplicate", e.MarkAsRead = "markAsRead", e.DeletePermanently = "deletePermanently", e.ExportIndex = "exportIndex", e.Move = "move", e.Trash = "trash", e.Other = "other", e.Upload = "upload", e.DeleteVersionFile = "deleteVersionFile", e.Backup = "backup";
	})(t || (e.FloatingOperationType = t = {}));
})), R = /* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.FloatingOperationType = e.LinkTarget = e.LinkType = e.ModalDisplayType = e.ToastType = e.InputAutocomplete = e.InputType = e.InputSize = e.ButtonSize = void 0;
	var t = M();
	Object.defineProperty(e, "ModalDisplayType", {
		enumerable: !0,
		get: function() {
			return t.ModalDisplayType;
		}
	});
	var n = N();
	Object.defineProperty(e, "InputSize", {
		enumerable: !0,
		get: function() {
			return n.InputSize;
		}
	}), Object.defineProperty(e, "InputType", {
		enumerable: !0,
		get: function() {
			return n.InputType;
		}
	}), Object.defineProperty(e, "InputAutocomplete", {
		enumerable: !0,
		get: function() {
			return n.InputAutocomplete;
		}
	});
	var r = P();
	Object.defineProperty(e, "ToastType", {
		enumerable: !0,
		get: function() {
			return r.ToastType;
		}
	});
	var i = F();
	Object.defineProperty(e, "ButtonSize", {
		enumerable: !0,
		get: function() {
			return i.ButtonSize;
		}
	});
	var a = I();
	Object.defineProperty(e, "LinkType", {
		enumerable: !0,
		get: function() {
			return a.LinkType;
		}
	}), Object.defineProperty(e, "LinkTarget", {
		enumerable: !0,
		get: function() {
			return a.LinkTarget;
		}
	});
	var o = L();
	Object.defineProperty(e, "FloatingOperationType", {
		enumerable: !0,
		get: function() {
			return o.FloatingOperationType;
		}
	});
})), z = (/* @__PURE__ */ _(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.FloatingOperationType = e.RoomsType = e.RoomSearchArea = e.Section = e.FilterType = e.SelectorType = e.Security = e.Devices = e.ModalDisplayType = e.LinkTarget = e.LinkType = e.ToastType = e.InputAutocomplete = e.InputType = e.InputSize = e.ButtonSize = e.UserRole = e.UsersType = e.PluginLocale = e.PluginStatus = e.FilesSecurity = e.FilesType = e.FilesExst = e.Events = e.Components = e.Actions = void 0;
	var t = j();
	Object.defineProperty(e, "Actions", {
		enumerable: !0,
		get: function() {
			return t.Actions;
		}
	}), Object.defineProperty(e, "Components", {
		enumerable: !0,
		get: function() {
			return t.Components;
		}
	}), Object.defineProperty(e, "Events", {
		enumerable: !0,
		get: function() {
			return t.Events;
		}
	}), Object.defineProperty(e, "FilesExst", {
		enumerable: !0,
		get: function() {
			return t.FilesExst;
		}
	}), Object.defineProperty(e, "FilesType", {
		enumerable: !0,
		get: function() {
			return t.FilesType;
		}
	}), Object.defineProperty(e, "FilesSecurity", {
		enumerable: !0,
		get: function() {
			return t.FilesSecurity;
		}
	}), Object.defineProperty(e, "PluginStatus", {
		enumerable: !0,
		get: function() {
			return t.PluginStatus;
		}
	}), Object.defineProperty(e, "UsersType", {
		enumerable: !0,
		get: function() {
			return t.UsersType;
		}
	}), Object.defineProperty(e, "UserRole", {
		enumerable: !0,
		get: function() {
			return t.UserRole;
		}
	}), Object.defineProperty(e, "Devices", {
		enumerable: !0,
		get: function() {
			return t.Devices;
		}
	}), Object.defineProperty(e, "Security", {
		enumerable: !0,
		get: function() {
			return t.Security;
		}
	}), Object.defineProperty(e, "PluginLocale", {
		enumerable: !0,
		get: function() {
			return t.PluginLocale;
		}
	}), Object.defineProperty(e, "SelectorType", {
		enumerable: !0,
		get: function() {
			return t.SelectorType;
		}
	}), Object.defineProperty(e, "FilterType", {
		enumerable: !0,
		get: function() {
			return t.FilterType;
		}
	}), Object.defineProperty(e, "RoomSearchArea", {
		enumerable: !0,
		get: function() {
			return t.RoomSearchArea;
		}
	}), Object.defineProperty(e, "RoomsType", {
		enumerable: !0,
		get: function() {
			return t.RoomsType;
		}
	}), Object.defineProperty(e, "Section", {
		enumerable: !0,
		get: function() {
			return t.Section;
		}
	});
	var n = R();
	Object.defineProperty(e, "ButtonSize", {
		enumerable: !0,
		get: function() {
			return n.ButtonSize;
		}
	}), Object.defineProperty(e, "InputSize", {
		enumerable: !0,
		get: function() {
			return n.InputSize;
		}
	}), Object.defineProperty(e, "InputType", {
		enumerable: !0,
		get: function() {
			return n.InputType;
		}
	}), Object.defineProperty(e, "InputAutocomplete", {
		enumerable: !0,
		get: function() {
			return n.InputAutocomplete;
		}
	}), Object.defineProperty(e, "ToastType", {
		enumerable: !0,
		get: function() {
			return n.ToastType;
		}
	}), Object.defineProperty(e, "ModalDisplayType", {
		enumerable: !0,
		get: function() {
			return n.ModalDisplayType;
		}
	}), Object.defineProperty(e, "FloatingOperationType", {
		enumerable: !0,
		get: function() {
			return n.FloatingOperationType;
		}
	}), Object.defineProperty(e, "LinkType", {
		enumerable: !0,
		get: function() {
			return n.LinkType;
		}
	}), Object.defineProperty(e, "LinkTarget", {
		enumerable: !0,
		get: function() {
			return n.LinkTarget;
		}
	});
})))(), B = {
	restricted: !1,
	users: [],
	groups: []
}, V = (e) => {
	try {
		return {
			...B,
			...JSON.parse(e || "null")
		};
	} catch {
		return B;
	}
}, H = {
	users: (e) => `/people/${e}`,
	groups: (e) => `/group/${e}`
}, U = (e, t) => ({
	actions: [z.Actions.showToast],
	toastProps: [{
		type: e,
		title: t
	}]
}), W = (n, r) => {
	let i = d(), [a, o] = t({});
	return e(() => {
		for (let e of r) a[e] || i.get(H[n](e)).then((t) => t.displayName ?? t.name ?? e, () => e).then((t) => o((n) => ({
			...n,
			[e]: t
		})));
	}, [r]), a;
}, G = ({ list: e, ids: t, title: i, addLabel: a, onAdd: o, onRemove: l }) => {
	let u = W(e, t);
	return /* @__PURE__ */ g("div", {
		style: {
			display: "flex",
			flexDirection: "column",
			gap: "8px"
		},
		children: [
			/* @__PURE__ */ h(c, {
				fontSize: "13px",
				fontWeight: 600,
				children: i
			}),
			t.length > 0 ? /* @__PURE__ */ h("div", {
				style: {
					display: "flex",
					flexWrap: "wrap",
					gap: "4px"
				},
				children: t.map((e) => /* @__PURE__ */ h(s, {
					propKey: e,
					label: u[e] ?? "…",
					onClose: () => l(e)
				}, e))
			}) : null,
			/* @__PURE__ */ h("div", { children: /* @__PURE__ */ h(n, {
				label: a,
				size: r.small,
				onClick: o
			}) })
		]
	});
}, K = () => {
	let n = p(), { showSelector: r, closeSelector: i } = f(), [a, o] = t(() => ({
		...B,
		...n.load()
	})), [s, u] = t(a), d = JSON.stringify(s) !== JSON.stringify(a), _ = s.restricted && !s.users.length && !s.groups.length;
	e(() => {
		n.setSaveButton({
			component: z.Components.button,
			props: {
				label: "Save",
				size: z.ButtonSize.normal,
				isDisabled: !d,
				withLoadingAfterClick: !0,
				onClick: async () => {
					try {
						return await n.save(s), o(s), U(z.ToastType.success, "Access to Deals saved");
					} catch {
						return U(z.ToastType.error, "Access was not saved: the list may be too long");
					}
				}
			}
		});
	}, [
		n,
		s,
		d
	]);
	let v = (e, t) => u((n) => ({
		...n,
		[e]: n[e].filter((e) => e !== t)
	})), y = (e) => r({
		type: z.SelectorType.People,
		props: {
			isMultiSelect: !0,
			withGroups: e === "groups",
			isGroupsOnly: e === "groups",
			excludeItems: s[e],
			withHeader: !0,
			headerProps: {
				label: e === "groups" ? "Add groups" : "Add people",
				isCloseable: !0,
				onCloseClick: i
			},
			submitButtonLabel: "Add",
			withCancelButton: !0,
			cancelButtonLabel: "Cancel",
			onCancel: i,
			onClose: i,
			onSubmit: ({ selectedIds: t }) => {
				u((n) => ({
					...n,
					[e]: [.../* @__PURE__ */ new Set([...n[e], ...t.map(String)])]
				})), i();
			}
		}
	});
	return /* @__PURE__ */ g("div", {
		style: {
			display: "flex",
			flexDirection: "column",
			gap: "16px"
		},
		children: [
			/* @__PURE__ */ h("div", {
				style: {
					position: "relative",
					height: "20px",
					flex: "0 0 auto"
				},
				children: /* @__PURE__ */ h(l, {
					label: "Restrict access",
					isChecked: s.restricted,
					onChange: () => u((e) => ({
						...e,
						restricted: !e.restricted
					}))
				})
			}),
			/* @__PURE__ */ h(c, {
				fontSize: "12px",
				lineHeight: "16px",
				children: s.restricted ? "Only the people and the members of the groups below see Deals in the sidebar and on the Home page." : "Everyone sees Deals in the sidebar and on the Home page."
			}),
			s.restricted ? /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h(G, {
					list: "groups",
					ids: s.groups,
					title: "Groups",
					addLabel: "Add groups",
					onAdd: () => y("groups"),
					onRemove: (e) => v("groups", e)
				}),
				/* @__PURE__ */ h(G, {
					list: "users",
					ids: s.users,
					title: "People",
					addLabel: "Add people",
					onAdd: () => y("users"),
					onRemove: (e) => v("users", e)
				}),
				_ ? /* @__PURE__ */ h(c, {
					fontSize: "12px",
					color: "var(--color-scheme-main-error, red)",
					children: "No one is listed, so no one will see Deals."
				}) : null
			] }) : null
		]
	});
}, q = [
	{
		title: "Annual licence renewal",
		stage: "Negotiation",
		amount: 12400
	},
	{
		title: "Cloud migration",
		stage: "Proposal",
		amount: 8900
	},
	{
		title: "Support extension",
		stage: "Proposal",
		amount: 4100
	},
	{
		title: "Training package",
		stage: "Won",
		amount: 2300
	}
], J = [
	"Proposal",
	"Negotiation",
	"Won"
], Y = (e) => `$${e.toLocaleString("en-US")}`, X = () => {
	let e = u();
	return /* @__PURE__ */ g("div", {
		id: "workspace-app-sample-deals-page",
		style: {
			padding: "20px",
			maxWidth: "640px"
		},
		children: [
			/* @__PURE__ */ h(i, {
				level: a.h1,
				size: o.medium,
				children: "Deals"
			}),
			/* @__PURE__ */ g(c, {
				fontSize: "13px",
				lineHeight: "20px",
				style: { margin: "4px 0 24px" },
				children: [e?.displayName ?? "You", " can open this page: the administrator listed them, or one of their groups, in the plugin settings."]
			}),
			q.map(({ title: e, stage: t, amount: n }) => /* @__PURE__ */ g("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					padding: "8px 0"
				},
				children: [/* @__PURE__ */ h(c, {
					fontSize: "13px",
					fontWeight: 600,
					children: e
				}), /* @__PURE__ */ g(c, {
					fontSize: "13px",
					children: [
						t,
						" · ",
						Y(n)
					]
				})]
			}, e))
		]
	});
}, Z = () => {
	let e = J.map((e) => ({
		stage: e,
		amount: q.filter((t) => t.stage === e).reduce((e, t) => e + t.amount, 0)
	})), t = Math.max(...e.map(({ amount: e }) => e));
	return /* @__PURE__ */ h("div", {
		id: "workspace-app-sample-pipeline",
		style: {
			display: "flex",
			flexDirection: "column",
			gap: "12px",
			padding: "16px",
			border: "var(--tile-border)",
			borderRadius: "var(--tile-border-radius)"
		},
		children: e.map(({ stage: e, amount: n }) => /* @__PURE__ */ g("div", {
			style: {
				display: "flex",
				alignItems: "center",
				gap: "12px"
			},
			children: [
				/* @__PURE__ */ h(c, {
					fontSize: "13px",
					style: {
						width: "96px",
						flex: "0 0 auto"
					},
					children: e
				}),
				/* @__PURE__ */ h("div", {
					style: {
						flex: "1 1 auto",
						minWidth: 0
					},
					children: /* @__PURE__ */ h("div", { style: {
						width: `${n / t * 100}%`,
						height: "8px",
						borderRadius: "4px",
						background: "var(--color-scheme-main-accent, #4781d1)"
					} })
				}),
				/* @__PURE__ */ h(c, {
					fontSize: "13px",
					fontWeight: 600,
					children: Y(n)
				})
			]
		}, e))
	});
}, Q = {
	key: "workspace-app-sample-deals",
	label: "Deals",
	icon: "plugin-icon.svg",
	component: X,
	dashboardCard: {
		description: "Follow the deals of your sales team from proposal to won.",
		buttonLabel: "Open deals"
	}
}, $ = {
	key: "workspace-app-sample-pipeline",
	title: "Pipeline",
	description: "Open deals by stage",
	component: Z
}, ee = new class {
	constructor() {
		this.status = z.PluginStatus.active, this.onLoadCallback = async () => {
			this.setAdminPluginSettings({ component: K });
		}, this.updateStatus = (e) => {
			this.status = e;
		}, this.getStatus = () => this.status, this.setOnLoadCallback = (e) => {
			this.onLoadCallback = e;
		}, this.articleNavigationItems = /* @__PURE__ */ new Map(), this.addArticleNavigationItem = (e) => {
			this.articleNavigationItems.set(e.key, e);
		}, this.getArticleNavigationItems = () => this.articleNavigationItems, this.updateArticleNavigationItem = (e) => {
			this.articleNavigationItems.set(e.key, e);
		}, this.dashboardWidgetItems = /* @__PURE__ */ new Map(), this.addDashboardWidgetItem = (e) => {
			this.dashboardWidgetItems.set(e.key, e);
		}, this.getDashboardWidgetItems = () => this.dashboardWidgetItems, this.updateDashboardWidgetItem = (e) => {
			this.dashboardWidgetItems.set(e.key, e);
		}, this.adminPluginSettings = null, this.setAdminPluginSettings = (e) => {
			this.adminPluginSettings = e;
		}, this.getAdminPluginSettings = () => this.adminPluginSettings, this.setAdminPluginSettingsValue = (e) => {
			let { restricted: t, users: n, groups: r } = V(e), i = t ? {
				users: n,
				groups: r
			} : {};
			this.addArticleNavigationItem({
				...Q,
				...i
			}), this.addDashboardWidgetItem({
				...$,
				...i
			});
		};
	}
}();
export { ee as default };
