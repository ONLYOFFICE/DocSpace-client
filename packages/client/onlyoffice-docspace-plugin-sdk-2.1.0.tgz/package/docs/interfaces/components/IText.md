# IText

Defined in: [interfaces/components/IText.ts:72](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L72)

Plain text.

![text](/assets/images/docspace/text.png#gh-light-mode-only)![text](/assets/images/docspace/text.dark.png#gh-dark-mode-only)

## Extended by

- [`ILink`](ILink.md)

## Properties

### text

```ts
text: string;
```

Defined in: [interfaces/components/IText.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L75)

Defines the text

### title?

```ts
optional title: string;
```

Defined in: [interfaces/components/IText.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L79)

Defines the text title

### fontSize?

```ts
optional fontSize: string;
```

Defined in: [interfaces/components/IText.ts:83](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L83)

Defines the text font size

### fontWeight?

```ts
optional fontWeight: string | number;
```

Defined in: [interfaces/components/IText.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L87)

Defines the text font weight

### truncate?

```ts
optional truncate: boolean;
```

Defined in: [interfaces/components/IText.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L91)

Specifies whether the word wrapping is set

### isBold?

```ts
optional isBold: boolean;
```

Defined in: [interfaces/components/IText.ts:95](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L95)

Specifies whether the text font weight is set to bold

### isItalic?

```ts
optional isItalic: boolean;
```

Defined in: [interfaces/components/IText.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L99)

Specifies whether the text style is set to italic

### isInline?

```ts
optional isInline: boolean;
```

Defined in: [interfaces/components/IText.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L103)

Specifies whether the "display: inline-block" property is set

### textAlign?

```ts
optional textAlign: string;
```

Defined in: [interfaces/components/IText.ts:107](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L107)

Specifies whether the "text-align" property is set

### noSelect?

```ts
optional noSelect: boolean;
```

Defined in: [interfaces/components/IText.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L111)

Specifies whether the text selection is disabled

### display?

```ts
optional display: string;
```

Defined in: [interfaces/components/IText.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L115)

Specifies whether the "display" property is set

### lineHeight?

```ts
optional lineHeight: string;
```

Defined in: [interfaces/components/IText.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L119)

Defines the text line height

### color?

```ts
optional color: string;
```

Defined in: [interfaces/components/IText.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L123)

Defines the text color

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IText.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L129)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Examples

Bold centered heading with custom typography

```typescript
const heading: IText = {
  text: "Document Management",
  fontSize: "24px",
  fontWeight: 600,
  lineHeight: "32px",
  color: "#333333",
  isBold: true,
  noSelect: true,
  textAlign: "center"
}
```

Truncated description with hover tooltip

```typescript
const description: IText = {
  text: "This is a long description that will be truncated if it exceeds the container width...",
  fontSize: "14px",
  lineHeight: "20px",
  color: "#666666",
  truncate: true,
  title: "Full description shown on hover"
}
```

Inline processing status with custom styling

```typescript
const status: IText = {
  text: "Processing",
  fontSize: "12px",
  isInline: true,
  isItalic: true,
  color: "#0066cc",
  display: "inline-flex",
  fontWeight: 500
}
```

