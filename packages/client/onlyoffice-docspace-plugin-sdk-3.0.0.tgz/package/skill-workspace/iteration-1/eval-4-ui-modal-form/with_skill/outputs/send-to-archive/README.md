# send-to-archive

A DocSpace plugin that adds an "Отправить в архив" (Send to archive) entry to the
main button. The entry opens a modal with:

- a field for the archive URL;
- a format combo box — `zip` / `tar.gz`;
- an "Отправить" (Send) button.

Validation is live: as soon as the URL is empty or does not start with `https`,
a red message appears directly under the field and the input border turns red.
The Send button re-checks the value and sends nothing while it is invalid.
On a valid URL the dialog closes and a success toast shows the URL and the
chosen format — the request names no backend, so wire a real call into
`onSendClick` in `src/archiveDialog.ts` when an endpoint exists.

Languages: Russian (default) and English (`src/locales.ts`).

## Build

```sh
npm install
npm run build
```

The uploadable archive is `dist/plugin.zip`.

## Install

Upload `dist/plugin.zip` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump `version` in `package.json` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

Where it appears: plugin entries are grouped under the main button's **More**
sub-menu (and the section "+" menu), after the standard create actions.

## Scopes

- `MainButton`
