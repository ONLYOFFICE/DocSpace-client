# Type Alias: IFrameGroup

> **IFrameGroup** = `object`

Defined in: [interfaces/components/Component.ts:222](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L222)

Defines the iframe component.

## Example

```typescript
import { IFrame, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const iframe: IFrame = {
  src: "https://example.com/embedded-content",
  width: "100%",
  height: "500px",
  name: "content-frame",
  sandbox: "allow-scripts allow-same-origin",
  id: "content-iframe",
  style: {
    border: "1px solid #eceef1",
    borderRadius: "4px",
    backgroundColor: "#ffffff"
  }
};

const iframeGroup: Component = {
  component: Components.iFrame,
  props: iframe,
  contextName: "embeddedContent"
};
```

## Properties

### component

> **component**: [`iFrame`](../../enumerations/Components.md#iframe)

Defined in: [interfaces/components/Component.ts:224](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L224)

Defines the "iFrame" component type

***

### props

> **props**: [`IFrame`](../interfaces/IFrame.md)

Defined in: [interfaces/components/Component.ts:226](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L226)

Defines the iFrame component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:228](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L228)

Defines the iFrame component context name that updates the component via React context
