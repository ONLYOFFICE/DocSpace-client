# IProfileMenuPlugin

Defined in: [interfaces/plugins/IProfileMenuPlugin.ts:74](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L74)

Plugin for embedding items in the profile menu.
This interface must be implemented in each plugin that adds items to the profile menu.

## Methods

### addProfileMenuItem()

```ts
addProfileMenuItem(item: IProfileMenuItem): void;
```

Defined in: [interfaces/plugins/IProfileMenuPlugin.ts:82](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L82)

Add a new profile menu item

#### Parameters

##### item

[`IProfileMenuItem`](../items/IProfileMenuItem.md)

#### Returns

`void`

### getProfileMenuItems()

```ts
getProfileMenuItems(): Map<string, IProfileMenuItem>;
```

Defined in: [interfaces/plugins/IProfileMenuPlugin.ts:85](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L85)

Get all the profile menu items

#### Returns

`Map`\<`string`, [`IProfileMenuItem`](../items/IProfileMenuItem.md)\>

### updateProfileMenuItem()

```ts
updateProfileMenuItem(item: IProfileMenuItem): void;
```

Defined in: [interfaces/plugins/IProfileMenuPlugin.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L88)

Updates an existing profile menu item

#### Parameters

##### item

[`IProfileMenuItem`](../items/IProfileMenuItem.md)

#### Returns

`void`

## Properties

### profileMenuItems

```ts
profileMenuItems: Map<string, IProfileMenuItem>;
```

Defined in: [interfaces/plugins/IProfileMenuPlugin.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IProfileMenuPlugin.ts#L79)

Stores a collection of elements where the keys are the key parameters from the ProfileMenuItem objects.
A list for hooking interactions with profile menu is generated based on this collection.

## Example

The plugin class implements `IProfileMenuPlugin` and registers a "User Settings"
entry in the constructor. DocSpace calls `getProfileMenuItems` to embed the items
into the user profile dropdown.

```typescript
import {
  type IProfileMenuItem,
  type IProfileMenuPlugin,
  Actions,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

class Plugin implements IProfileMenuPlugin {
  profileMenuItems: Map<string, IProfileMenuItem> = new Map();

  constructor() {
    this.addProfileMenuItem({
      key: "user-settings",
      label: "User Settings",
      icon: "settings-icon.svg",
      onClick: async () => {
        await loadUserSettings();
        return {
          actions: [Actions.showToast],
          toastProps: [{
            type: ToastType.success,
            title: "User settings loaded"
          }]
        };
      }
    });
  }

  addProfileMenuItem = (item: IProfileMenuItem): void => {
    this.profileMenuItems.set(item.key, item);
  };

  getProfileMenuItems = (): Map<string, IProfileMenuItem> => {
    return this.profileMenuItems;
  };

  updateProfileMenuItem = (item: IProfileMenuItem): void => {
    this.profileMenuItems.set(item.key, item);
  };
}
```

