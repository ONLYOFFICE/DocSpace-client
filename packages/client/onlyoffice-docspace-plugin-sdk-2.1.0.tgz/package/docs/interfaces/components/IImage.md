# IImage

Defined in: [interfaces/components/IImage.ts:62](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L62)

A component that is used to embed an image not from the assets folder into a modal window or the settings page.

![image](/assets/images/docspace/image.png#gh-light-mode-only)![image](/assets/images/docspace/image.dark.png#gh-dark-mode-only)

## Properties

### src

```ts
src: string;
```

Defined in: [interfaces/components/IImage.ts:65](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L65)

Defines the full path to the image

### alt

```ts
alt: string;
```

Defined in: [interfaces/components/IImage.ts:69](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L69)

Defines the image alt attribute

### width?

```ts
optional width: string;
```

Defined in: [interfaces/components/IImage.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L73)

Defines the image width

### height?

```ts
optional height: string;
```

Defined in: [interfaces/components/IImage.ts:77](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L77)

Defines the image height

### name?

```ts
optional name: string;
```

Defined in: [interfaces/components/IImage.ts:81](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L81)

Defines the image name

### id?

```ts
optional id: string;
```

Defined in: [interfaces/components/IImage.ts:85](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L85)

Defines the image ID

### style?

```ts
optional style: {
[key: string]: string;
};
```

Defined in: [interfaces/components/IImage.ts:89](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L89)

Defines the image style

#### Index Signature

```ts
[key: string]: string
```

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IImage.ts:95](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L95)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Examples

Plugin logo with fixed dimensions and spacing

```typescript
const pluginLogo: IImage = {
  src: "https://example.com/plugin-logo.png",
  alt: "Plugin Logo",
  width: "120px",
  height: "40px",
  name: "plugin-logo",
  id: "settings-logo",
  style: {
    objectFit: "contain",
    marginBottom: "16px"
  }
}
```

Responsive document preview with modern styling

```typescript
const documentPreview: IImage = {
  src: "https://example.com/document-preview.jpg",
  alt: "Document Preview",
  width: "100%",
  height: "auto",
  name: "doc-preview",
  style: {
    borderRadius: "4px",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
    maxWidth: "800px"
  }
}
```

