# Devices

Defined in: [enums/Devices.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Devices.ts#L22)

Defines the supported device types.

## Enumeration Members

### mobile

```ts
mobile: "mobile";
```

Defined in: [enums/Devices.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Devices.ts#L24)

Smartphones and small-screen mobile devices

### tablet

```ts
tablet: "tablet";
```

Defined in: [enums/Devices.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Devices.ts#L27)

Tablet devices and medium-sized screens

### desktop

```ts
desktop: "desktop";
```

Defined in: [enums/Devices.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Devices.ts#L30)

Desktop computers and large-screen devices
