# markdown-preview

Preview Markdown files as rendered HTML in a DocSpace dialog

## Build

```sh
npm install
npm run build
```

The uploadable archive is `dist/plugin.zip`.

## Install

Upload `dist/plugin.zip` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump `version` in `package.json` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

## What it does

Right-click a `.md` (or `.markdown`, `.mdown`, `.mkd`) file in DocSpace and pick
**Preview as HTML**: a side panel opens with the file rendered — headings, bold
and italic runs, links, ordered and unordered lists, quotes, code blocks, tables
and horizontal rules.

A plugin cannot inject HTML into the portal; it returns a description that the
portal renders with its own components. So the Markdown is parsed into that
component tree, which is why the preview follows the portal theme and cannot
carry script or markup from the file into the page.

## Scopes

- `ContextMenu` — the **Preview as HTML** entry, filtered to Markdown files
- `API` — reads the file record (`GET /files/file/{id}`) and its bytes from `viewUrl`

## Limits

- Code blocks are not monospaced: the portal's `text` component takes no font
  family, and shipping CSS would inject unscoped styles into the portal.
- Images are shown as a placeholder label, not fetched — external hosts would
  have to be added to `cspDomains`, which widens the whole portal's CSP.
- Files over 200 000 characters are cut off, with a note at the end, so that
  parsing never blocks the portal's event loop.
