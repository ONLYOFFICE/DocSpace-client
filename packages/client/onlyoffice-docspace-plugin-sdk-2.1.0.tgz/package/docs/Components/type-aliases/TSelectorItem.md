# Type Alias: TSelectorItem

> **TSelectorItem** = `object` & `Partial`\<[`TSelectorItemFile`](TSelectorItemFile.md)\> & `Partial`\<[`TSelectorItemInput`](TSelectorItemInput.md)\> & `Partial`\<[`TSelectorItemNew`](TSelectorItemNew.md)\>

Defined in: [interfaces/components/Selector/IBaseSelector.ts:176](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L176)

Represents a single item within a selector component.

## Type Declaration

### label

> **label**: `string`

The display text for the item.

### id?

> `optional` **id**: `string` \| `number`

A unique identifier for the item.
