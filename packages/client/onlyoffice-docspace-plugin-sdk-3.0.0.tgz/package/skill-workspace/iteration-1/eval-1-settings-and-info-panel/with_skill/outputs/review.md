# room-space-info (with_skill)

- pluginName: `RoomSpaceInfo`  version: `1.0.0`  scopes: `["InfoPanel","Settings","API"]`
- zip built: yes

## src/api.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The portal hands the plugin its base URL parts via setAPI before
 * onLoadCallback runs. The plugin class mirrors them here so the data layer
 * can build request URLs without importing the class (which would be a
 * circular import).
 */

let origin = "";
let proxy = "";
let prefix = "";

export const setApiParts = (
  nextOrigin: string,
  nextProxy: string,
  nextPrefix: string,
): void => {
  origin = nextOrigin;
  proxy = nextProxy;
  prefix = nextPrefix;
};

/**
 * Joined lazily on every use, not cached at load: setAPI is only guaranteed
 * to have run before onLoadCallback, and any part may be empty or carry
 * stray slashes.
 */
export const buildApiUrl = (): string => {
  let url = origin.replace(/\/+$/, "");

  for (const part of [proxy, prefix]) {
    if (!part) continue;
    const clean = part.trim().replace(/^\/+/, "");
    if (!clean) continue;
    url += url.endsWith("/") ? clean : `/${clean}`;
  }

  return url; // e.g. https://portal.example.com/api/2.0
};

/**
 * Every DocSpace endpoint wraps its payload in a `response` field; requests
 * ride the signed-in user's session, so no token is involved.
 */
export const getJson = async <T>(url: string): Promise<T> => {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  return ((await res.json()) as { response: T }).response;
};
```

## src/index.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  IApiPlugin,
  IInfoPanelItem,
  IInfoPanelPlugin,
  IPlugin,
  ISettings,
  ISettingsPlugin,
  PluginLocale,
  PluginStatus,
} from "@onlyoffice/docspace-plugin-sdk";

import { setApiParts } from "./api";
import { initInfoPanel, invalidateInfoPanelBody, roomInfoPanelItem } from "./infoPanel";
import { currentLocale, setLocale } from "./locales";
import { adminSettings, applyStoredSettings } from "./settings";

class RoomSpaceInfo implements IPlugin, IInfoPanelPlugin, ISettingsPlugin, IApiPlugin {
  status: PluginStatus = PluginStatus.active;

  infoPanelItems: Map<string, IInfoPanelItem> = new Map();

  adminPluginSettings: ISettings | null = null;

  setAdminPluginSettings = (settings: ISettings | null): void => {
    this.adminPluginSettings = settings;
  };

  // The portal hands settings back as the raw string the plugin saved earlier,
  // and it arrives *after* installation - so parse defensively.
  setAdminPluginSettingsValue = (settings: string | null): void => {
    applyStoredSettings(settings);
  };

  getAdminPluginSettings = (): ISettings | null => this.adminPluginSettings;

  origin = "";

  proxy = "";

  prefix = "";

  setOrigin = (origin: string): void => {
    this.origin = origin;
    setApiParts(this.origin, this.proxy, this.prefix);
  };

  getOrigin = (): string => this.origin;

  setProxy = (proxy: string): void => {
    this.proxy = proxy;
    setApiParts(this.origin, this.proxy, this.prefix);
  };

  getProxy = (): string => this.proxy;

  setPrefix = (prefix: string): void => {
    this.prefix = prefix;
    setApiParts(this.origin, this.proxy, this.prefix);
  };

  getPrefix = (): string => this.prefix;

  setAPI = (origin: string, proxy: string, prefix: string): void => {
    this.origin = origin;
    this.proxy = proxy;
    this.prefix = prefix;
    setApiParts(origin, proxy, prefix);
  };

  getAPI = (): { origin: string; proxy: string; prefix: string } => ({
    origin: this.origin,
    proxy: this.proxy,
    prefix: this.prefix,
  });

  // Register items here rather than at module scope. Both are read in time, but
  // setLanguage and setAPI only run after the bundle executes - so a factory that
  // translates a label or calls getAPI() at module scope would capture empty values.
  onLoadCallback = async (): Promise<void> => {
    initInfoPanel((item) => this.updateInfoPanelItem(item));
    this.addInfoPanelItem(roomInfoPanelItem());
    this.setAdminPluginSettings(adminSettings());
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  // The portal calls this when the interface language changes. Labels were
  // captured when the items were built, so the items have to be rebuilt.
  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
    invalidateInfoPanelBody();
    this.updateInfoPanelItem(roomInfoPanelItem());
    this.setAdminPluginSettings(adminSettings());
  };

  getLanguage = (): PluginLocale => currentLocale();

  addInfoPanelItem = (item: IInfoPanelItem): void => {
    this.infoPanelItems.set(item.key, item);
  };

  getInfoPanelItems = (): Map<string, IInfoPanelItem> => this.infoPanelItems;

  updateInfoPanelItem = (item: IInfoPanelItem): void => {
    this.infoPanelItems.set(item.key, item);
  };
}

const plugin = new RoomSpaceInfo();

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.RoomSpaceInfo = plugin || {};

export default plugin;
```

## src/infoPanel.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  Component,
  Components,
  FilesType,
  IBox,
  IInfoPanelItem,
  IMessage,
} from "@onlyoffice/docspace-plugin-sdk";

import { t, tf } from "./locales";
import { fetchRoomSpace, TRoomSpace } from "./roomInfo";
import { BYTES_PER_GB, getThresholdGb } from "./settings";

const ITEM_KEY = "room-space-info-storage";

/**
 * Wired by the plugin class in onLoadCallback; a direct import of the plugin
 * instance here would be a circular dependency.
 */
type TRegisterItem = (item: IInfoPanelItem) => void;
let registerItem: TRegisterItem = () => {};
export const initInfoPanel = (register: TRegisterItem): void => {
  registerItem = register;
};

/** The room the info panel currently shows, recorded by subMenu.onClick. */
let currentEntityId: number | null = null;

/** Short-lived cache so onClick + onLoad on the same selection fetch once. */
const cache = new Map<number, { data: TRoomSpace; fetchedAt: number }>();
const CACHE_TTL_MS = 30_000;
const CACHE_MAX_ENTRIES = 50;

const getRoomSpaceCached = async (id: number): Promise<TRoomSpace> => {
  const hit = cache.get(id);
  if (hit && Date.now() - hit.fetchedAt < CACHE_TTL_MS) return hit.data;

  const data = await fetchRoomSpace(id);

  cache.set(id, { data, fetchedAt: Date.now() });
  if (cache.size > CACHE_MAX_ENTRIES) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) cache.delete(oldest);
  }

  return data;
};

// --- presentation --------------------------------------------------------

const formatBytes = (bytes: number): string => {
  const units = [t("unit.b"), t("unit.kb"), t("unit.mb"), t("unit.gb"), t("unit.tb")];

  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }

  const rounded =
    unit === 0
      ? String(Math.round(value))
      : String(parseFloat(value.toFixed(value >= 100 ? 0 : value >= 10 ? 1 : 2)));

  return `${rounded} ${units[unit]}`;
};

const caption = (text: string): Component => ({
  component: Components.text,
  props: { text, fontSize: "12px", lineHeight: "16px", color: "var(--row-side-color)" },
});

const note = (text: string, color?: string): Component => ({
  component: Components.text,
  props: { text, fontSize: "12px", lineHeight: "16px", color },
});

const row = (children: Component[], isLast = false): Component => ({
  component: Components.box,
  props: {
    displayProp: "flex",
    flexDirection: "column",
    marginProp: isLast ? "0" : "0 0 12px 0",
    children,
  },
});

const column = (children: Component[]): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children,
});

const loadingBody = (): IBox =>
  column([
    row([{ component: Components.skeleton, props: { width: "40%", height: "16px" } }]),
    row([{ component: Components.skeleton, props: { width: "70%", height: "16px" } }], true),
  ]);

const messageBody = (text: string): IBox =>
  column([{ component: Components.text, props: { text, lineHeight: "20px" } }]);

const roomBody = (data: TRoomSpace): IBox => {
  const thresholdGb = getThresholdGb();
  const overThreshold =
    thresholdGb !== null &&
    data.sizeBytes !== null &&
    data.sizeBytes > thresholdGb * BYTES_PER_GB;

  const sizeText =
    data.sizeBytes === null
      ? "—"
      : `${data.isExact ? "" : "~ "}${formatBytes(data.sizeBytes)}`;

  const sizeRow: Component[] = [
    caption(t("infoPanel.size")),
    {
      component: Components.text,
      props: {
        text: sizeText,
        fontSize: "13px",
        lineHeight: "20px",
        fontWeight: 600,
        // Theme token, never a hex pair: it must survive dark mode and
        // re-branded portals.
        color: overThreshold ? "var(--input-error-color)" : undefined,
      },
    },
  ];

  if (overThreshold && thresholdGb !== null)
    sizeRow.push(
      note(tf("infoPanel.overThreshold", thresholdGb), "var(--input-error-color)"),
    );

  if (data.sizeBytes !== null && !data.isExact)
    sizeRow.push(note(t("infoPanel.approx"), "var(--row-side-color)"));

  return column([
    row([caption(t("infoPanel.owner")), {
      component: Components.text,
      props: { text: data.ownerName ?? "—", fontSize: "13px", lineHeight: "20px" },
    }]),
    row(sizeRow, true),
  ]);
};

// --- the item ------------------------------------------------------------

/** Body snapshot the next render will show. */
let latestBody: IBox = loadingBody();

/** Drop captured labels on a language switch; data itself is reusable. */
export const invalidateInfoPanelBody = (): void => {
  latestBody = loadingBody();
};

const buildBodyFor = async (id: number): Promise<IBox> => {
  try {
    return roomBody(await getRoomSpaceCached(id));
  } catch {
    // Nothing catches plugin callbacks for us; a rejected onLoad would leave
    // the skeleton on screen forever.
    return messageBody(t("infoPanel.loadFailed"));
  }
};

/**
 * Fires on every selection change, not just on tab clicks. Fetching here (and
 * re-registering the item before returning updateInfoPanelItems) is what keeps
 * an already-open tab in step with the selection - the host does not re-run
 * onLoad for a selection change on its own.
 */
const NO_OP: IMessage = { actions: [] };

const onSelectionChange = async (id: number): Promise<IMessage> => {
  try {
    currentEntityId = id;

    // If the tab mounts while the fetch below is in flight, let it start
    // from a skeleton rather than the previous room's numbers.
    latestBody = loadingBody();
    registerItem(roomInfoPanelItem());

    const body = await buildBodyFor(id);
    if (currentEntityId !== id) return NO_OP; // superseded by a newer selection

    latestBody = body;
    registerItem(roomInfoPanelItem());

    return { actions: [Actions.updateInfoPanelItems] };
  } catch {
    return NO_OP;
  }
};

export const roomInfoPanelItem = (): IInfoPanelItem => ({
  key: ITEM_KEY,
  subMenu: {
    name: t("infoPanel.tab"),
    onClick: onSelectionChange,
  },
  body: latestBody,
  // Rooms only - size and owner are room properties.
  filesType: [FilesType.room],
  onLoad: async () => {
    if (currentEntityId === null) return { body: messageBody(t("infoPanel.noSelection")) };

    latestBody = await buildBodyFor(currentEntityId);
    return { body: latestBody };
  },
});
```

## src/locales.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 */
export type TStrings = {
  "infoPanel.tab": string;
  "infoPanel.owner": string;
  "infoPanel.size": string;
  "infoPanel.approx": string;
  "infoPanel.overThreshold": string;
  "infoPanel.loadFailed": string;
  "infoPanel.noSelection": string;
  "settings.thresholdLabel": string;
  "settings.thresholdPlaceholder": string;
  "settings.thresholdHint": string;
  "settings.thresholdError": string;
  "settings.save": string;
  "settings.saved": string;
  "unit.b": string;
  "unit.kb": string;
  "unit.mb": string;
  "unit.gb": string;
  "unit.tb": string;
};

const en: TStrings = {
  "infoPanel.tab": "Storage",
  "infoPanel.owner": "Owner",
  "infoPanel.size": "Storage used",
  "infoPanel.approx": "Approximate value.",
  "infoPanel.overThreshold": "Exceeds the {0} GB threshold.",
  "infoPanel.loadFailed":
    "Couldn't load room info. Switch tabs or select the room again to retry.",
  "infoPanel.noSelection": "Select a room to see its storage usage and owner.",
  "settings.thresholdLabel": "Red-highlight threshold (GB)",
  "settings.thresholdPlaceholder": "e.g. 10",
  "settings.thresholdHint":
    "Rooms using more storage than this show their size in red in the Info panel. Leave the field empty to disable highlighting.",
  "settings.thresholdError":
    "Enter a non-negative number of gigabytes (e.g. 10 or 0.5), or leave the field empty.",
  "settings.save": "Save",
  "settings.saved": "Settings saved.",
  "unit.b": "B",
  "unit.kb": "KB",
  "unit.mb": "MB",
  "unit.gb": "GB",
  "unit.tb": "TB",
};

const ru: TStrings = {
  "infoPanel.tab": "Хранилище",
  "infoPanel.owner": "Владелец",
  "infoPanel.size": "Занято места",
  "infoPanel.approx": "Приблизительное значение.",
  "infoPanel.overThreshold": "Превышает порог {0} ГБ.",
  "infoPanel.loadFailed":
    "Не удалось загрузить данные комнаты. Переключите вкладку или выберите комнату снова.",
  "infoPanel.noSelection":
    "Выберите комнату, чтобы увидеть занимаемое место и владельца.",
  "settings.thresholdLabel": "Порог подсветки (ГБ)",
  "settings.thresholdPlaceholder": "например, 10",
  "settings.thresholdHint":
    "Если комната занимает больше указанного объёма, её размер в инфопанели выделяется красным. Оставьте поле пустым, чтобы отключить подсветку.",
  "settings.thresholdError":
    "Введите неотрицательное число гигабайт (например, 10 или 0,5) или оставьте поле пустым.",
  "settings.save": "Сохранить",
  "settings.saved": "Настройки сохранены.",
  "unit.b": "Б",
  "unit.kb": "КБ",
  "unit.mb": "МБ",
  "unit.gb": "ГБ",
  "unit.tb": "ТБ",
};

const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.EN_US]: en,
  ru: ru,
};

let locale: PluginLocale = PluginLocale.EN_US;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.EN_US;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings): string => (translations[locale] ?? en)[key];

/** t() with `{0}`, `{1}`… placeholders substituted. */
export const tf = (key: keyof TStrings, ...args: (string | number)[]): string =>
  args.reduce<string>((text, arg, i) => text.split(`{${i}}`).join(String(arg)), t(key));
```

## src/roomInfo.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { buildApiUrl, getJson } from "./api";

/** What the info panel needs to know about a room. */
export type TRoomSpace = {
  ownerName: string | null;
  /** Total content size in bytes, or null when it could not be determined. */
  sizeBytes: number | null;
  /** true when the portal reported the size itself (usedSpace). */
  isExact: boolean;
};

type TFolderDto = {
  id?: number | string;
  title?: string;
  usedSpace?: number;
  createdBy?: { displayName?: string };
};

type TFolderContentDto = {
  files?: { id?: number | string; pureContentLength?: number }[];
  folders?: TFolderDto[];
  total?: number;
};

/**
 * Bounds for the fallback walk on portals whose folder DTO carries no
 * usedSpace. They keep one unlucky selection from flooding the API: at most
 * 30 listing requests of 100 entries each, then the sum is reported as
 * approximate.
 */
const MAX_LIST_REQUESTS = 30;
const PAGE_SIZE = 100;

/**
 * A room is a folder in the files API, so the documented folder-metadata
 * endpoint answers both questions: `createdBy` is the owner the portal shows
 * in room details, and `usedSpace` is the room's storage counter on portals
 * that track it (DocSpace 3.x). When usedSpace is absent (e.g. third-party
 * storage), fall back to summing file sizes with a bounded breadth-first walk.
 */
export const fetchRoomSpace = async (roomId: number): Promise<TRoomSpace> => {
  const api = buildApiUrl();

  const folder = await getJson<TFolderDto>(`${api}/files/folder/${roomId}`);
  const ownerName = folder?.createdBy?.displayName ?? null;

  if (typeof folder?.usedSpace === "number" && Number.isFinite(folder.usedSpace))
    return { ownerName, sizeBytes: folder.usedSpace, isExact: true };

  return { ownerName, ...(await sumContentSize(api, roomId)) };
};

const sumContentSize = async (
  api: string,
  roomId: number,
): Promise<{ sizeBytes: number | null; isExact: boolean }> => {
  const queue: (number | string)[] = [roomId];
  const seenFolders = new Set<string>([String(roomId)]);
  const seenFiles = new Set<string>();

  let bytes = 0;
  let requests = 0;
  let succeeded = 0;

  try {
    while (queue.length > 0) {
      const folderId = queue.shift() as number | string;
      let startIndex = 0;

      for (;;) {
        if (requests >= MAX_LIST_REQUESTS) {
          queue.length = 0; // cap hit: report what was counted so far
          break;
        }
        requests += 1;

        const page = await getJson<TFolderContentDto>(
          `${api}/files/${folderId}?count=${PAGE_SIZE}&startIndex=${startIndex}`,
        );
        succeeded += 1;
        const files = Array.isArray(page?.files) ? page.files : [];
        const folders = Array.isArray(page?.folders) ? page.folders : [];

        // Dedupe by id so a portal that ignores paging parameters cannot
        // double-count entries or loop forever.
        let fresh = 0;

        for (const file of files) {
          const id = String(file?.id ?? "");
          if (!id || seenFiles.has(id)) continue;
          seenFiles.add(id);
          fresh += 1;
          if (typeof file.pureContentLength === "number") bytes += file.pureContentLength;
        }

        for (const sub of folders) {
          const id = String(sub?.id ?? "");
          if (!id || seenFolders.has(id)) continue;
          seenFolders.add(id);
          fresh += 1;
          queue.push(sub.id as number | string);
        }

        const got = files.length + folders.length;
        startIndex += got;

        const total = typeof page?.total === "number" ? page.total : 0;
        if (fresh === 0 || got === 0 || startIndex >= total) break;
      }
    }
  } catch {
    // A partial sum is still a useful lower bound - fall through and report
    // whatever was counted before the failure.
  }

  // No listing succeeded at all: "0 B" would be a lie - report unknown.
  if (succeeded === 0) return { sizeBytes: null, isExact: false };

  // A walked sum counts current file versions only and stops at the request
  // cap, so it is always presented as approximate.
  return { sizeBytes: bytes, isExact: false };
};
```

## src/settings.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  ButtonSize,
  Components,
  IBox,
  IInput,
  ISettings,
  IText,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

import { t } from "./locales";

export const BYTES_PER_GB = 1024 ** 3;

/** Settings travel as one opaque JSON string; the plugin owns the format. */
type TStoredSettings = { thresholdGb: number | null };

/** null = highlighting disabled. */
let thresholdGb: number | null = null;

/** The raw text currently in the settings input. */
let draft = "";

export const getThresholdGb = (): number | null => thresholdGb;

/**
 * Called by the portal after installation with whatever string was saved
 * earlier - and disabling the plugin wipes it, so null/"" and malformed
 * values must all quietly fall back to the defaults.
 */
export const applyStoredSettings = (raw: string | null): void => {
  thresholdGb = null;

  if (raw) {
    try {
      const parsed = JSON.parse(raw) as TStoredSettings;
      if (
        typeof parsed?.thresholdGb === "number" &&
        Number.isFinite(parsed.thresholdGb) &&
        parsed.thresholdGb >= 0
      )
        thresholdGb = parsed.thresholdGb;
    } catch {
      // Keep the defaults rather than breaking installation on a bad value.
    }
  }

  draft = thresholdGb === null ? "" : String(thresholdGb);
};

/** Empty input is valid and means "highlighting off"; commas count as dots. */
const parseDraft = (value: string): { ok: boolean; value: number | null } => {
  const text = value.trim().replace(",", ".");
  if (text === "") return { ok: true, value: null };
  if (!/^\d+(\.\d+)?$/.test(text)) return { ok: false, value: null };

  const parsed = Number(text);
  if (!Number.isFinite(parsed)) return { ok: false, value: null };

  return { ok: true, value: parsed };
};

const ERROR_CONTEXT = "room-space-info-settings-error";

const errorTextProps = (text: string): IText => ({
  text,
  fontSize: "12px",
  lineHeight: "16px",
  color: "var(--input-error-color)",
});

/**
 * updateProps replaces the element's props instead of merging, so the input
 * always sends its complete prop set back.
 */
const thresholdInputProps = (value: string, hasError: boolean): IInput => ({
  value,
  scale: true,
  hasError,
  placeholder: t("settings.thresholdPlaceholder"),
  tabIndex: 0,
  onChange: (next: string) => {
    draft = next;
    const ok = parseDraft(next).ok;

    return {
      actions: [Actions.updateProps, Actions.updateContext],
      newProps: thresholdInputProps(next, !ok),
      contextProps: [
        {
          name: ERROR_CONTEXT,
          props: errorTextProps(ok ? "" : t("settings.thresholdError")),
        },
      ],
    };
  },
});

const settingsBody = (): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [
    {
      component: Components.box,
      props: {
        marginProp: "0 0 4px 0",
        children: [
          {
            component: Components.label,
            props: { text: t("settings.thresholdLabel") },
          },
        ],
      },
    },
    {
      component: Components.box,
      props: {
        marginProp: "0 0 4px 0",
        children: [
          {
            component: Components.input,
            props: thresholdInputProps(draft, !parseDraft(draft).ok),
          },
        ],
      },
    },
    {
      component: Components.text,
      contextName: ERROR_CONTEXT,
      props: errorTextProps(""),
    },
    {
      component: Components.box,
      props: {
        marginProp: "8px 0 0 0",
        children: [
          {
            component: Components.text,
            props: {
              text: t("settings.thresholdHint"),
              fontSize: "12px",
              lineHeight: "16px",
              color: "var(--row-side-color)",
            },
          },
        ],
      },
    },
  ],
});

export const adminSettings = (): ISettings => ({
  settings: settingsBody(),
  saveButton: {
    component: Components.button,
    // The portal renders this in the settings aside's footer and forces its
    // look; only onClick and the loading flags below stay ours.
    props: {
      label: t("settings.save"),
      size: ButtonSize.normal,
      primary: true,
      withLoadingAfterClick: true,
      disableWhileRequestRunning: true,
      onClick: async () => {
        const { ok, value } = parseDraft(draft);

        if (!ok)
          return {
            actions: [Actions.updateContext],
            contextProps: [
              { name: ERROR_CONTEXT, props: errorTextProps(t("settings.thresholdError")) },
            ],
          };

        thresholdGb = value;
        draft = value === null ? "" : String(value);

        return {
          actions: [Actions.saveSettings, Actions.showToast],
          settings: JSON.stringify({ thresholdGb: value } as TStoredSettings),
          toastProps: [{ type: ToastType.success, title: t("settings.saved") }],
        };
      },
    },
  },
  // Rebuild the box every time the aside opens: the stored value may have
  // arrived after the box was first built, and abandoned drafts should not
  // survive a close/reopen.
  onLoad: async () => {
    draft = thresholdGb === null ? "" : String(thresholdGb);
    return { settings: settingsBody() };
  },
});
```
