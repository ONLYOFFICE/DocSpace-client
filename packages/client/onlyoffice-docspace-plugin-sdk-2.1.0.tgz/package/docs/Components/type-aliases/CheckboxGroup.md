# Type Alias: CheckboxGroup

> **CheckboxGroup** = `object`

Defined in: [interfaces/components/Component.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L143)

Defines the checkbox component.

## Example

```typescript
import { ICheckbox, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const checkbox: ICheckbox = {
  isChecked: false,
  label: "Enable notifications",
  onChange: () => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        isChecked: !checkbox.isChecked
      }
    };
  },
  truncate: false,
  tabIndex: 1,
  hasError: false,
  name: "notifications",
  value: "enabled",
  isDisabled: false,
  title: "Notification preferences"
};

const checkboxGroup: Component = {
  component: Components.checkbox,
  props: checkbox,
  contextName: "notificationToggle"
};
```

## Properties

### component

> **component**: [`checkbox`](../../enumerations/Components.md#checkbox)

Defined in: [interfaces/components/Component.ts:145](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L145)

Defines the "checkbox" component type

***

### props

> **props**: [`ICheckbox`](../interfaces/ICheckbox.md)

Defined in: [interfaces/components/Component.ts:147](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L147)

Defines the checkbox component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:149](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L149)

Defines the checkbox component context name that updates the component via React context
