# Enumeration: InputSize

Defined in: [interfaces/components/IInput.ts:26](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L26)

The supported input sizes.

## Enumeration Members

### base

> **base**: `"base"`

Defined in: [interfaces/components/IInput.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L30)

Base size of the input field.

***

### middle

> **middle**: `"middle"`

Defined in: [interfaces/components/IInput.ts:34](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L34)

Middle size of the input field.

***

### big

> **big**: `"big"`

Defined in: [interfaces/components/IInput.ts:38](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L38)

Big size of the input field.

***

### huge

> **huge**: `"huge"`

Defined in: [interfaces/components/IInput.ts:42](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L42)

Huge size of the input field.

***

### large

> **large**: `"large"`

Defined in: [interfaces/components/IInput.ts:46](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L46)

Large size of the input field.
