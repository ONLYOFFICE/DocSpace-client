# Type Alias: ButtonGroup

> **ButtonGroup** = `object`

Defined in: [interfaces/components/Component.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L98)

Defines the button component.

## Example

```typescript
import { IButton, Components, Components, ButtonSize } from "@onlyoffice/docspace-plugin-sdk";

const button: IButton = {
  size: ButtonSize.normal,
  label: "Click me!",
  onClick: () => {
    console.log("Button clicked!");
  },
};

const buttonGroup: Component = {
  component: Components.button,
  props: button,
  contextName: "button",
};
```

## Properties

### component

> **component**: [`button`](../../enumerations/Components.md#button)

Defined in: [interfaces/components/Component.ts:100](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L100)

Defines the "button" component type

***

### props

> **props**: [`IButton`](../interfaces/IButton.md)

Defined in: [interfaces/components/Component.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L102)

Defines the button component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:104](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L104)

Defines the button component context name that updates the component via React context
