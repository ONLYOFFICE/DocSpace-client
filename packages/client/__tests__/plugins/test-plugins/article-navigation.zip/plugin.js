import { useState as e } from "react";
import { Button as t, ButtonSize as n, Heading as r, HeadingLevel as i, HeadingSize as a, Text as o, ToggleButton as s } from "@docspace/ui-kit";
import { useCurrentUser as c, usePluginActions as l } from "@onlyoffice/docspace-plugin-sdk/react";
import { jsx as u, jsxs as d } from "react/jsx-runtime";
//#region \0rolldown/runtime.js
var f = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), p = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Actions = void 0;
	var t;
	(function(e) {
		e.updateProps = "update-props", e.updateContext = "update-context", e.updateStatus = "update-status", e.updateContextMenuItems = "update-context-menu-items", e.updateInfoPanelItems = "update-info-panel-items", e.updateMainButtonItems = "update-main-button-items", e.updateProfileMenuItems = "update-profile-menu-items", e.updateFileItems = "update-file-items", e.updateEventListenerItems = "update-event-listener-items", e.updateArticleNavigationItems = "update-article-navigation-items", e.updateArticleButtonItems = "update-article-button-items", e.showToast = "show-toast", e.showCreateDialogModal = "show-create-dialog-modal", e.updateCreateDialogModal = "update-create-dialog-modal", e.showModal = "show-modal", e.closeModal = "close-modal", e.sendPostMessage = "send-post-message", e.saveSettings = "save-settings", e.showSelector = "show-selector", e.updateSelector = "update-selector", e.closeSelector = "close-selector", e.addFloatingOperationsButton = "add-floating-operations-button", e.updateFloatingOperationsButton = "update-floating-operations-button", e.removeFloatingOperationsButton = "remove-floating-operations-button", e.navigate = "navigate", e.openInfoPanel = "open-info-panel", e.showMediaViewer = "show-media-viewer", e.updateMediaViewer = "update-media-viewer", e.closeMediaViewer = "close-media-viewer";
	})(t || (e.Actions = t = {}));
})), m = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Events = void 0;
	var t;
	(function(e) {
		e.CREATE = "create", e.RENAME = "rename", e.ROOM_CREATE = "create_room", e.ROOM_EDIT = "edit_room", e.CHANGE_COLUMN = "change_column", e.CHANGE_USER_TYPE = "change_user_type", e.CREATE_PLUGIN_FILE = "create_plugin_file";
	})(t || (e.Events = t = {}));
})), h = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.PluginLocale = e.PluginStatus = void 0;
	var t;
	(function(e) {
		e.active = "active", e.hide = "hide";
	})(t || (e.PluginStatus = t = {}));
	var n;
	(function(e) {
		e.AZ = "az", e.CS = "cs", e.DE = "de", e.EN_GB = "en-GB", e.EN_US = "en-US", e.ES = "es", e.FR = "fr", e.IT = "it", e.LV = "lv", e.NL = "nl", e.PL = "pl", e.PT_BR = "pt-BR", e.PT = "pt", e.RO = "ro", e.SK = "sk", e.SL = "sl", e.SQ_AL = "sq-AL", e.FI = "fi", e.VI = "vi", e.TR = "tr", e.EL_GR = "el-GR", e.BG = "bg", e.RU = "ru", e.SR_CYRL_RS = "sr-Cyrl-RS", e.SR_LATN_RS = "sr-Latn-RS", e.UK_UA = "uk-UA", e.HY_AM = "hy-AM", e.AR_SA = "ar-SA", e.SI = "si", e.LO_LA = "lo-LA", e.ZH_CN = "zh-CN", e.JA_JP = "ja-JP", e.KO_KR = "ko-KR";
	})(n || (e.PluginLocale = n = {}));
})), g = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.FilesSecurity = e.FilesExst = e.FilesType = void 0;
	var t;
	(function(e) {
		e.room = "room", e.file = "file", e.folder = "folder", e.image = "image", e.video = "video";
	})(t || (e.FilesType = t = {}));
	var n;
	(function(e) {
		e.doc = ".doc", e.docx = ".docx", e.docm = ".docm", e.dotx = ".dotx", e.odt = ".odt", e.fodt = ".fodt", e.ott = ".ott", e.rtf = ".rtf", e.txt = ".txt", e.pdf = ".pdf", e.docxf = ".docxf", e.oform = ".oform", e.xls = ".xls", e.xlsx = ".xlsx", e.xlsm = ".xlsm", e.ods = ".ods", e.ots = ".ots", e.ppt = ".ppt", e.pptx = ".pptx", e.pptm = ".pptm", e.odp = ".odp", e.otp = ".otp", e.pps = ".pps", e.ppsx = ".ppsx", e.pot = ".pot", e.avi = ".avi", e.flv = ".flv", e.mkv = ".mkv", e.mov = ".mov", e.mp4 = ".mp4", e.mpg = ".mpg", e.webm = ".webm", e.m2ts = ".m2ts", e.dvd = ".dvd", e.svg = ".svg", e.csv = ".csv", e.djvu = ".djvu", e.epub = ".epub", e.fb2 = ".fb2", e.pb2 = ".pb2", e.iaf = ".iaf", e.ics = ".ics", e.mht = ".mht", e.xps = ".xps", e.xml = ".xml";
	})(n || (e.FilesExst = n = {}));
	var r;
	(function(e) {
		e.Convert = "Convert", e.Copy = "Copy", e.CustomFilter = "CustomFilter", e.Delete = "Delete", e.Download = "Download", e.Duplicate = "Duplicate", e.Edit = "Edit", e.EditHistory = "EditHistory", e.FillForms = "FillForms", e.Lock = "Lock", e.Move = "Move", e.Read = "Read", e.ReadHistory = "ReadHistory", e.Rename = "Rename", e.Review = "Review", e.SubmitToFormGallery = "SubmitToFormGallery", e.StopFilling = "StopFilling", e.ResetFilling = "ResetFilling", e.EditForm = "EditForm", e.Comment = "Comment", e.CreateRoomFrom = "CreateRoomFrom", e.CopyLink = "CopyLink", e.Embed = "Embed";
	})(r || (e.FilesSecurity = r = {}));
})), _ = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.UsersType = void 0;
	var t;
	(function(e) {
		e.owner = "Owner", e.docSpaceAdmin = "DocSpaceAdmin", e.roomAdmin = "RoomAdmin", e.collaborator = "Collaborator", e.user = "User";
	})(t || (e.UsersType = t = {}));
})), v = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Components = void 0;
	var t;
	(function(e) {
		e.box = "box", e.button = "button", e.checkbox = "checkbox", e.input = "input", e.label = "label", e.text = "text", e.textArea = "textArea", e.toggleButton = "toggleButton", e.img = "img", e.iFrame = "iFrame", e.comboBox = "comboBox", e.skeleton = "skeleton", e.iconButton = "iconButton", e.link = "link";
	})(t || (e.Components = t = {}));
})), y = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Devices = void 0;
	var t;
	(function(e) {
		e.mobile = "mobile", e.tablet = "tablet", e.desktop = "desktop";
	})(t || (e.Devices = t = {}));
})), b = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Security = void 0;
	var t;
	(function(e) {
		e.Copy = "Copy", e.CopySharedLink = "CopySharedLink", e.CopyTo = "CopyTo", e.Create = "Create", e.Delete = "Delete", e.Download = "Download", e.Duplicate = "Duplicate", e.EditAccess = "EditAccess", e.EditRoom = "EditRoom", e.Move = "Move", e.MoveTo = "MoveTo", e.Mute = "Mute", e.Pin = "Pin", e.Read = "Read", e.Rename = "Rename", e.CreateRoomFrom = "CreateRoomFrom", e.CopyLink = "CopyLink", e.Embed = "Embed";
	})(t || (e.Security = t = {}));
})), x = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.SelectorType = void 0;
	var t;
	(function(e) {
		e.Base = "base", e.Files = "files", e.Groups = "groups", e.People = "people", e.Room = "room";
	})(t || (e.SelectorType = t = {}));
})), S = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.RoomsType = e.RoomSearchArea = void 0;
	var t;
	(function(e) {
		e.Any = "Any", e.Active = "Active", e.Archive = "Archive", e.Templates = "Templates";
	})(t || (e.RoomSearchArea = t = {}));
	var n;
	(function(e) {
		e.PublicRoom = "public-room", e.FormRoom = "form-room", e.EditingRoom = "editing-room", e.VirtualDataRoom = "virtual-data-room", e.CustomRoom = "custom-room";
	})(n || (e.RoomsType = n = {}));
})), C = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Section = void 0;
	var t;
	(function(e) {
		e.Files = "Files", e.Accounts = "Accounts", e.Settings = "Settings";
	})(t || (e.Section = t = {}));
})), w = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.Section = e.RoomsType = e.RoomSearchArea = e.SelectorType = e.PluginLocale = e.Security = e.Devices = e.UsersType = e.PluginStatus = e.FilesSecurity = e.FilesType = e.FilesExst = e.Events = e.Components = e.Actions = void 0;
	var t = p();
	Object.defineProperty(e, "Actions", {
		enumerable: !0,
		get: function() {
			return t.Actions;
		}
	});
	var n = m();
	Object.defineProperty(e, "Events", {
		enumerable: !0,
		get: function() {
			return n.Events;
		}
	});
	var r = h();
	Object.defineProperty(e, "PluginStatus", {
		enumerable: !0,
		get: function() {
			return r.PluginStatus;
		}
	}), Object.defineProperty(e, "PluginLocale", {
		enumerable: !0,
		get: function() {
			return r.PluginLocale;
		}
	});
	var i = g();
	Object.defineProperty(e, "FilesExst", {
		enumerable: !0,
		get: function() {
			return i.FilesExst;
		}
	}), Object.defineProperty(e, "FilesType", {
		enumerable: !0,
		get: function() {
			return i.FilesType;
		}
	}), Object.defineProperty(e, "FilesSecurity", {
		enumerable: !0,
		get: function() {
			return i.FilesSecurity;
		}
	});
	var a = _();
	Object.defineProperty(e, "UsersType", {
		enumerable: !0,
		get: function() {
			return a.UsersType;
		}
	});
	var o = v();
	Object.defineProperty(e, "Components", {
		enumerable: !0,
		get: function() {
			return o.Components;
		}
	});
	var s = y();
	Object.defineProperty(e, "Devices", {
		enumerable: !0,
		get: function() {
			return s.Devices;
		}
	});
	var c = b();
	Object.defineProperty(e, "Security", {
		enumerable: !0,
		get: function() {
			return c.Security;
		}
	});
	var l = x();
	Object.defineProperty(e, "SelectorType", {
		enumerable: !0,
		get: function() {
			return l.SelectorType;
		}
	});
	var u = S();
	Object.defineProperty(e, "RoomSearchArea", {
		enumerable: !0,
		get: function() {
			return u.RoomSearchArea;
		}
	}), Object.defineProperty(e, "RoomsType", {
		enumerable: !0,
		get: function() {
			return u.RoomsType;
		}
	});
	var d = C();
	Object.defineProperty(e, "Section", {
		enumerable: !0,
		get: function() {
			return d.Section;
		}
	});
})), T = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.ModalDisplayType = void 0;
	var t;
	(function(e) {
		e.modal = "modal", e.aside = "aside";
	})(t || (e.ModalDisplayType = t = {}));
})), E = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.InputType = e.InputAutocomplete = e.InputSize = void 0;
	var t;
	(function(e) {
		e.base = "base", e.middle = "middle", e.big = "big", e.huge = "huge", e.large = "large";
	})(t || (e.InputSize = t = {}));
	var n;
	(function(e) {
		e.on = "on", e.off = "off";
	})(n || (e.InputAutocomplete = n = {}));
	var r;
	(function(e) {
		e.text = "text", e.password = "password";
	})(r || (e.InputType = r = {}));
})), D = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.ToastType = void 0;
	var t;
	(function(e) {
		e.success = "success", e.error = "error", e.warning = "warning", e.info = "info";
	})(t || (e.ToastType = t = {}));
})), O = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.ButtonSize = void 0;
	var t;
	(function(e) {
		e.extraSmall = "extra-small", e.small = "small", e.normal = "normal", e.medium = "medium";
	})(t || (e.ButtonSize = t = {}));
})), k = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.LinkTarget = e.LinkType = void 0;
	var t;
	(function(e) {
		e.page = "page", e.action = "action";
	})(t || (e.LinkType = t = {}));
	var n;
	(function(e) {
		e.blank = "_blank", e.self = "_self", e.parent = "_parent", e.top = "_top";
	})(n || (e.LinkTarget = n = {}));
})), A = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.FloatingOperationType = void 0;
	var t;
	(function(e) {
		e.Download = "download", e.Convert = "convert", e.Copy = "copy", e.Duplicate = "duplicate", e.MarkAsRead = "markAsRead", e.DeletePermanently = "deletePermanently", e.ExportIndex = "exportIndex", e.Move = "move", e.Trash = "trash", e.Other = "other", e.Upload = "upload", e.DeleteVersionFile = "deleteVersionFile", e.Backup = "backup";
	})(t || (e.FloatingOperationType = t = {}));
})), j = /* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.FloatingOperationType = e.LinkTarget = e.LinkType = e.ModalDisplayType = e.ToastType = e.InputAutocomplete = e.InputType = e.InputSize = e.ButtonSize = void 0;
	var t = T();
	Object.defineProperty(e, "ModalDisplayType", {
		enumerable: !0,
		get: function() {
			return t.ModalDisplayType;
		}
	});
	var n = E();
	Object.defineProperty(e, "InputSize", {
		enumerable: !0,
		get: function() {
			return n.InputSize;
		}
	}), Object.defineProperty(e, "InputType", {
		enumerable: !0,
		get: function() {
			return n.InputType;
		}
	}), Object.defineProperty(e, "InputAutocomplete", {
		enumerable: !0,
		get: function() {
			return n.InputAutocomplete;
		}
	});
	var r = D();
	Object.defineProperty(e, "ToastType", {
		enumerable: !0,
		get: function() {
			return r.ToastType;
		}
	});
	var i = O();
	Object.defineProperty(e, "ButtonSize", {
		enumerable: !0,
		get: function() {
			return i.ButtonSize;
		}
	});
	var a = k();
	Object.defineProperty(e, "LinkType", {
		enumerable: !0,
		get: function() {
			return a.LinkType;
		}
	}), Object.defineProperty(e, "LinkTarget", {
		enumerable: !0,
		get: function() {
			return a.LinkTarget;
		}
	});
	var o = A();
	Object.defineProperty(e, "FloatingOperationType", {
		enumerable: !0,
		get: function() {
			return o.FloatingOperationType;
		}
	});
})), M = (/* @__PURE__ */ f(((e) => {
	Object.defineProperty(e, "__esModule", { value: !0 }), e.FloatingOperationType = e.RoomsType = e.RoomSearchArea = e.Section = e.SelectorType = e.Security = e.Devices = e.ModalDisplayType = e.LinkTarget = e.LinkType = e.ToastType = e.InputAutocomplete = e.InputType = e.InputSize = e.ButtonSize = e.UsersType = e.PluginLocale = e.PluginStatus = e.FilesSecurity = e.FilesType = e.FilesExst = e.Events = e.Components = e.Actions = void 0;
	var t = w();
	Object.defineProperty(e, "Actions", {
		enumerable: !0,
		get: function() {
			return t.Actions;
		}
	}), Object.defineProperty(e, "Components", {
		enumerable: !0,
		get: function() {
			return t.Components;
		}
	}), Object.defineProperty(e, "Events", {
		enumerable: !0,
		get: function() {
			return t.Events;
		}
	}), Object.defineProperty(e, "FilesExst", {
		enumerable: !0,
		get: function() {
			return t.FilesExst;
		}
	}), Object.defineProperty(e, "FilesType", {
		enumerable: !0,
		get: function() {
			return t.FilesType;
		}
	}), Object.defineProperty(e, "FilesSecurity", {
		enumerable: !0,
		get: function() {
			return t.FilesSecurity;
		}
	}), Object.defineProperty(e, "PluginStatus", {
		enumerable: !0,
		get: function() {
			return t.PluginStatus;
		}
	}), Object.defineProperty(e, "UsersType", {
		enumerable: !0,
		get: function() {
			return t.UsersType;
		}
	}), Object.defineProperty(e, "Devices", {
		enumerable: !0,
		get: function() {
			return t.Devices;
		}
	}), Object.defineProperty(e, "Security", {
		enumerable: !0,
		get: function() {
			return t.Security;
		}
	}), Object.defineProperty(e, "PluginLocale", {
		enumerable: !0,
		get: function() {
			return t.PluginLocale;
		}
	}), Object.defineProperty(e, "SelectorType", {
		enumerable: !0,
		get: function() {
			return t.SelectorType;
		}
	}), Object.defineProperty(e, "RoomSearchArea", {
		enumerable: !0,
		get: function() {
			return t.RoomSearchArea;
		}
	}), Object.defineProperty(e, "RoomsType", {
		enumerable: !0,
		get: function() {
			return t.RoomsType;
		}
	}), Object.defineProperty(e, "Section", {
		enumerable: !0,
		get: function() {
			return t.Section;
		}
	});
	var n = j();
	Object.defineProperty(e, "ButtonSize", {
		enumerable: !0,
		get: function() {
			return n.ButtonSize;
		}
	}), Object.defineProperty(e, "InputSize", {
		enumerable: !0,
		get: function() {
			return n.InputSize;
		}
	}), Object.defineProperty(e, "InputType", {
		enumerable: !0,
		get: function() {
			return n.InputType;
		}
	}), Object.defineProperty(e, "InputAutocomplete", {
		enumerable: !0,
		get: function() {
			return n.InputAutocomplete;
		}
	}), Object.defineProperty(e, "ToastType", {
		enumerable: !0,
		get: function() {
			return n.ToastType;
		}
	}), Object.defineProperty(e, "ModalDisplayType", {
		enumerable: !0,
		get: function() {
			return n.ModalDisplayType;
		}
	}), Object.defineProperty(e, "FloatingOperationType", {
		enumerable: !0,
		get: function() {
			return n.FloatingOperationType;
		}
	}), Object.defineProperty(e, "LinkType", {
		enumerable: !0,
		get: function() {
			return n.LinkType;
		}
	}), Object.defineProperty(e, "LinkTarget", {
		enumerable: !0,
		get: function() {
			return n.LinkTarget;
		}
	});
})))(), N = ({ id: e, title: t, description: n, children: s }) => /* @__PURE__ */ d("div", {
	id: e,
	style: {
		padding: "20px",
		maxWidth: "640px"
	},
	children: [
		/* @__PURE__ */ u(r, {
			level: i.h1,
			size: a.medium,
			children: t
		}),
		/* @__PURE__ */ u(o, {
			fontSize: "13px",
			lineHeight: "20px",
			style: { margin: "4px 0 24px" },
			children: n
		}),
		s
	]
}), P = () => {
	let e = c(), { showToast: r } = l();
	return /* @__PURE__ */ d(N, {
		id: "article-navigation-sample-files-page",
		title: "Sample files page",
		description: "Opened from the sidebar entry that the plugin adds to the Files section.",
		children: [/* @__PURE__ */ d(o, {
			fontSize: "13px",
			lineHeight: "20px",
			style: { marginBottom: "16px" },
			children: [
				"Signed in as ",
				/* @__PURE__ */ u("b", { children: e?.displayName ?? "…" }),
				"."
			]
		}), /* @__PURE__ */ u(t, {
			id: "article-navigation-sample-toast-btn",
			label: "Show a toast",
			size: n.normal,
			primary: !0,
			onClick: () => r({
				type: M.ToastType.success,
				title: `Hello, ${e?.displayName ?? "there"}!`
			})
		})]
	});
}, F = () => {
	let { showToast: t } = l(), [n, r] = e(!1);
	return /* @__PURE__ */ u(N, {
		id: "article-navigation-sample-settings-page",
		title: "Sample settings page",
		description: "Only portal administrators see the sidebar entry that opens this page.",
		children: /* @__PURE__ */ u(s, {
			label: "Enable the sample feature",
			isChecked: n,
			onChange: () => {
				r(!n), t({
					type: M.ToastType.info,
					title: n ? "Sample feature off" : "Sample feature on"
				});
			}
		})
	});
}, I = {
	key: "article-navigation-sample-files",
	label: "Sample files",
	icon: "docspace-icon.svg",
	component: P,
	appears: [M.Section.Files]
}, L = {
	key: "article-navigation-sample-settings",
	label: "Sample settings",
	icon: "docspace-icon.svg",
	component: F,
	appears: [M.Section.Settings],
	usersTypes: [M.UsersType.owner, M.UsersType.docSpaceAdmin]
}, R = new class {
	constructor() {
		this.status = M.PluginStatus.active, this.onLoadCallback = async () => {
			this.addArticleNavigationItem(I), this.addArticleNavigationItem(L);
		}, this.updateStatus = (e) => {
			this.status = e;
		}, this.getStatus = () => this.status, this.setOnLoadCallback = (e) => {
			this.onLoadCallback = e;
		}, this.articleNavigationItems = /* @__PURE__ */ new Map(), this.addArticleNavigationItem = (e) => {
			this.articleNavigationItems.set(e.key, e);
		}, this.getArticleNavigationItems = () => this.articleNavigationItems, this.updateArticleNavigationItem = (e) => {
			this.articleNavigationItems.set(e.key, e);
		};
	}
}();
//#endregion
export { R as default };
