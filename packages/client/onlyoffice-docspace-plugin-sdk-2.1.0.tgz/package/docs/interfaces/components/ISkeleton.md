# ISkeleton

Defined in: [interfaces/components/ISkeleton.ts:60](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L60)

A component that is used to hide components during uploading.

![skeleton](/assets/images/docspace/skeleton.png#gh-light-mode-only)![skeleton](/assets/images/docspace/skeleton.dark.png#gh-dark-mode-only)

## Properties

### width

```ts
width: string;
```

Defined in: [interfaces/components/ISkeleton.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L63)

Defines the skeleton width

### height

```ts
height: string;
```

Defined in: [interfaces/components/ISkeleton.ts:67](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L67)

Defines the skeleton height

### borderRadius?

```ts
optional borderRadius: string;
```

Defined in: [interfaces/components/ISkeleton.ts:71](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L71)

Defines the skeleton border radius

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/ISkeleton.ts:77](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L77)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Examples

Circular avatar placeholder for loading states

```typescript
const avatarSkeleton: ISkeleton = {
  width: "40px",
  height: "40px",
  borderRadius: "50%"
}
```

Responsive content card loading placeholder

```typescript
const cardSkeleton: ISkeleton = {
  width: "100%",
  height: "120px",
  borderRadius: "8px"
}
```

Text line loading animation

```typescript
const textSkeleton: ISkeleton = {
  width: "80%",
  height: "16px",
  borderRadius: "4px"
}
```

