# Type Alias: TSelectorItemNew

> **TSelectorItemNew** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:262](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L262)

Defines properties for an item that allows creating a new entity.

## Behavior

### onCreateClick()

> **onCreateClick**: () => `TReturnMessage`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:274](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L274)

A callback function that is triggered when the user clicks the 'create new' button.

#### Returns

`TReturnMessage`

## State

### isCreateNewItem

> **isCreateNewItem**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:268](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L268)

If true, this item will be rendered as a 'create new' button.
