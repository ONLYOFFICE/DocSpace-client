# Files

Enumerations for file types, supported extensions, and security permissions.

## FilesType

Defined in: [enums/Files.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L27)

Defines the supported file types.

### Enumeration Members

#### room

```ts
room: "room";
```

Defined in: [enums/Files.ts:29](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L29)

DocSpace room or workspace

#### file

```ts
file: "file";
```

Defined in: [enums/Files.ts:32](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L32)

Generic file type

#### folder

```ts
folder: "folder";
```

Defined in: [enums/Files.ts:35](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L35)

Directory or folder

#### image

```ts
image: "image";
```

Defined in: [enums/Files.ts:38](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L38)

Image file (various formats)

#### video

```ts
video: "video";
```

Defined in: [enums/Files.ts:41](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L41)

Video file (various formats)

***

## FilesExst

Defined in: [enums/Files.ts:47](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L47)

Defines the supported file extensions.

### Enumeration Members

#### doc

```ts
doc: ".doc";
```

Defined in: [enums/Files.ts:50](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L50)

Microsoft Word document

#### docx

```ts
docx: ".docx";
```

Defined in: [enums/Files.ts:52](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L52)

Microsoft Word document (XML-based)

#### docm

```ts
docm: ".docm";
```

Defined in: [enums/Files.ts:54](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L54)

Microsoft Word macro-enabled document

#### dotx

```ts
dotx: ".dotx";
```

Defined in: [enums/Files.ts:56](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L56)

Microsoft Word template

#### odt

```ts
odt: ".odt";
```

Defined in: [enums/Files.ts:58](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L58)

OpenDocument text format

#### fodt

```ts
fodt: ".fodt";
```

Defined in: [enums/Files.ts:60](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L60)

OpenDocument flat XML text format

#### ott

```ts
ott: ".ott";
```

Defined in: [enums/Files.ts:62](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L62)

OpenDocument text template

#### rtf

```ts
rtf: ".rtf";
```

Defined in: [enums/Files.ts:64](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L64)

Rich Text Format

#### txt

```ts
txt: ".txt";
```

Defined in: [enums/Files.ts:66](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L66)

Plain text

#### pdf

```ts
pdf: ".pdf";
```

Defined in: [enums/Files.ts:68](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L68)

Portable Document Format

#### docxf

```ts
docxf: ".docxf";
```

Defined in: [enums/Files.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L70)

Form document (DOCX-based)

#### oform

```ts
oform: ".oform";
```

Defined in: [enums/Files.ts:72](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L72)

Form document (OpenDocument-based)

#### xls

```ts
xls: ".xls";
```

Defined in: [enums/Files.ts:76](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L76)

Microsoft Excel spreadsheet

#### xlsx

```ts
xlsx: ".xlsx";
```

Defined in: [enums/Files.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L78)

Microsoft Excel spreadsheet (XML-based)

#### xlsm

```ts
xlsm: ".xlsm";
```

Defined in: [enums/Files.ts:80](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L80)

Microsoft Excel macro-enabled spreadsheet

#### ods

```ts
ods: ".ods";
```

Defined in: [enums/Files.ts:82](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L82)

OpenDocument spreadsheet

#### ots

```ts
ots: ".ots";
```

Defined in: [enums/Files.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L84)

OpenDocument spreadsheet template

#### ppt

```ts
ppt: ".ppt";
```

Defined in: [enums/Files.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L88)

Microsoft PowerPoint presentation

#### pptx

```ts
pptx: ".pptx";
```

Defined in: [enums/Files.ts:90](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L90)

Microsoft PowerPoint presentation (XML-based)

#### pptm

```ts
pptm: ".pptm";
```

Defined in: [enums/Files.ts:92](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L92)

Microsoft PowerPoint macro-enabled presentation

#### odp

```ts
odp: ".odp";
```

Defined in: [enums/Files.ts:94](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L94)

OpenDocument presentation

#### otp

```ts
otp: ".otp";
```

Defined in: [enums/Files.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L96)

OpenDocument presentation template

#### pps

```ts
pps: ".pps";
```

Defined in: [enums/Files.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L98)

PowerPoint show format

#### ppsx

```ts
ppsx: ".ppsx";
```

Defined in: [enums/Files.ts:100](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L100)

PowerPoint show format (XML-based)

#### pot

```ts
pot: ".pot";
```

Defined in: [enums/Files.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L102)

PowerPoint template

#### avi

```ts
avi: ".avi";
```

Defined in: [enums/Files.ts:108](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L108)

Video file (AVI format)

#### flv

```ts
flv: ".flv";
```

Defined in: [enums/Files.ts:110](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L110)

Video file (FLV format)

#### mkv

```ts
mkv: ".mkv";
```

Defined in: [enums/Files.ts:112](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L112)

Video file (MKV format)

#### mov

```ts
mov: ".mov";
```

Defined in: [enums/Files.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L114)

Video file (MOV format)

#### mp4

```ts
mp4: ".mp4";
```

Defined in: [enums/Files.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L116)

Video file (MP4 format)

#### mpg

```ts
mpg: ".mpg";
```

Defined in: [enums/Files.ts:118](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L118)

Video file (MPEG format)

#### webm

```ts
webm: ".webm";
```

Defined in: [enums/Files.ts:120](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L120)

Video file (WebM format)

#### m2ts

```ts
m2ts: ".m2ts";
```

Defined in: [enums/Files.ts:122](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L122)

Video file (M2TS format)

#### dvd

```ts
dvd: ".dvd";
```

Defined in: [enums/Files.ts:124](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L124)

Video file (DVD format)

#### svg

```ts
svg: ".svg";
```

Defined in: [enums/Files.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L126)

Scalable Vector Graphics

#### csv

```ts
csv: ".csv";
```

Defined in: [enums/Files.ts:130](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L130)

Comma-separated values

#### djvu

```ts
djvu: ".djvu";
```

Defined in: [enums/Files.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L132)

DjVu format

#### epub

```ts
epub: ".epub";
```

Defined in: [enums/Files.ts:134](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L134)

E-book format (EPUB)

#### fb2

```ts
fb2: ".fb2";
```

Defined in: [enums/Files.ts:136](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L136)

E-book format (FB2)

#### pb2

```ts
pb2: ".pb2";
```

Defined in: [enums/Files.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L138)

E-book format (PB2)

#### iaf

```ts
iaf: ".iaf";
```

Defined in: [enums/Files.ts:140](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L140)

Archive format (IAF)

#### ics

```ts
ics: ".ics";
```

Defined in: [enums/Files.ts:142](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L142)

Calendar format (ICS)

#### mht

```ts
mht: ".mht";
```

Defined in: [enums/Files.ts:144](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L144)

Web archive (MHT)

#### xps

```ts
xps: ".xps";
```

Defined in: [enums/Files.ts:146](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L146)

XML Paper Specification

#### xml

```ts
xml: ".xml";
```

Defined in: [enums/Files.ts:148](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L148)

Extensible Markup Language

***

## FilesSecurity

Defined in: [enums/Files.ts:154](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L154)

Defines the supported file security parameters.

### Enumeration Members

#### Convert

```ts
Convert: "Convert";
```

Defined in: [enums/Files.ts:156](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L156)

Permission to convert files to other formats

#### Copy

```ts
Copy: "Copy";
```

Defined in: [enums/Files.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L159)

Permission to copy files and folders

#### CustomFilter

```ts
CustomFilter: "CustomFilter";
```

Defined in: [enums/Files.ts:162](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L162)

Permission to apply custom filters

#### Delete

```ts
Delete: "Delete";
```

Defined in: [enums/Files.ts:165](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L165)

Permission to delete items

#### Download

```ts
Download: "Download";
```

Defined in: [enums/Files.ts:168](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L168)

Permission to download files

#### Duplicate

```ts
Duplicate: "Duplicate";
```

Defined in: [enums/Files.ts:171](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L171)

Permission to create duplicates of items

#### Edit

```ts
Edit: "Edit";
```

Defined in: [enums/Files.ts:174](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L174)

Permission to edit files

#### EditHistory

```ts
EditHistory: "EditHistory";
```

Defined in: [enums/Files.ts:177](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L177)

Permission to view and edit file history

#### FillForms

```ts
FillForms: "FillForms";
```

Defined in: [enums/Files.ts:180](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L180)

Permission to fill forms

#### Lock

```ts
Lock: "Lock";
```

Defined in: [enums/Files.ts:183](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L183)

Permission to lock/unlock files

#### Move

```ts
Move: "Move";
```

Defined in: [enums/Files.ts:186](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L186)

Permission to move items

#### Read

```ts
Read: "Read";
```

Defined in: [enums/Files.ts:189](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L189)

Permission to view and read content

#### ReadHistory

```ts
ReadHistory: "ReadHistory";
```

Defined in: [enums/Files.ts:192](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L192)

Permission to read file history

#### Rename

```ts
Rename: "Rename";
```

Defined in: [enums/Files.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L195)

Permission to rename items

#### Review

```ts
Review: "Review";
```

Defined in: [enums/Files.ts:198](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L198)

Permission to review documents

#### SubmitToFormGallery

```ts
SubmitToFormGallery: "SubmitToFormGallery";
```

Defined in: [enums/Files.ts:201](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L201)

Permission to submit forms to gallery

#### StopFilling

```ts
StopFilling: "StopFilling";
```

Defined in: [enums/Files.ts:204](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L204)

Permission to stop form filling process

#### ResetFilling

```ts
ResetFilling: "ResetFilling";
```

Defined in: [enums/Files.ts:207](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L207)

Permission to reset form filling

#### EditForm

```ts
EditForm: "EditForm";
```

Defined in: [enums/Files.ts:210](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L210)

Permission to edit forms

#### Comment

```ts
Comment: "Comment";
```

Defined in: [enums/Files.ts:213](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L213)

Permission to comment on files

#### CreateRoomFrom

```ts
CreateRoomFrom: "CreateRoomFrom";
```

Defined in: [enums/Files.ts:216](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L216)

Permission to create rooms from existing content

#### CopyLink

```ts
CopyLink: "CopyLink";
```

Defined in: [enums/Files.ts:219](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L219)

Permission to copy links to files

#### Embed

```ts
Embed: "Embed";
```

Defined in: [enums/Files.ts:222](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L222)

Permission to embed content
