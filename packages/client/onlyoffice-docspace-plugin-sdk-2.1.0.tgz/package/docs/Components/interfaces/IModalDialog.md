# Interface: IModalDialog

Defined in: [interfaces/components/IModalDialog.ts:210](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L210)

## Remarks

**Important:** `dialogBody` and `dialogFooter` are rendered in separate contexts.
Components in `dialogFooter` cannot update components in `dialogBody` using
`Actions.updateContext`, and vice versa.

## Appearance

### displayType

> **displayType**: [`ModalDisplayType`](../enumerations/ModalDisplayType.md)

Defined in: [interfaces/components/IModalDialog.ts:215](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L215)

Defines the modal dialog display type

***

### autoMaxWidth?

> `optional` **autoMaxWidth**: `boolean`

Defined in: [interfaces/components/IModalDialog.ts:239](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L239)

Specifies whether the "max-width: auto" property is set

***

### autoMaxHeight?

> `optional` **autoMaxHeight**: `boolean`

Defined in: [interfaces/components/IModalDialog.ts:245](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L245)

Specifies whether the "max-height: auto" property is set

***

### withoutBodyPadding?

> `optional` **withoutBodyPadding**: `boolean`

Defined in: [interfaces/components/IModalDialog.ts:251](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L251)

Specifies whether the modal dialog body has no paddings

***

### withoutHeaderMargin?

> `optional` **withoutHeaderMargin**: `boolean`

Defined in: [interfaces/components/IModalDialog.ts:257](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L257)

Specifies whether the modal dialog header has no bottom margins

***

### withFooterBorder?

> `optional` **withFooterBorder**: `boolean`

Defined in: [interfaces/components/IModalDialog.ts:263](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L263)

Specifies whether the border betweeen the body and footer is displayed

***

### fullScreen?

> `optional` **fullScreen**: `boolean`

Defined in: [interfaces/components/IModalDialog.ts:269](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L269)

Specifies whether to display the modal dialog body in the full screen mode without paddings

## Behavior

### eventListeners?

> `optional` **eventListeners**: `object`[]

Defined in: [interfaces/components/IModalDialog.ts:276](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L276)

Defines the event listeners.

#### name

> **name**: `string`

Defines the event listener name.

#### onAction()

> **onAction**: () => `void` \| `Promise`\<`void`\> \| `IMessage` \| `Promise`\<`IMessage`\>

Sets a function which is triggered whenever the event listener is processed.

##### Returns

`void` \| `Promise`\<`void`\> \| `IMessage` \| `Promise`\<`IMessage`\>

***

### onClose()

> **onClose**: () => `void` \| `Promise`\<`void`\> \| `IMessage` \| `Promise`\<`IMessage`\>

Defined in: [interfaces/components/IModalDialog.ts:291](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L291)

Sets a function which is triggered whenever the "Close" button in the modal dialog is clicked

#### Returns

`void` \| `Promise`\<`void`\> \| `IMessage` \| `Promise`\<`IMessage`\>

***

### onLoad()

> **onLoad**: () => `Promise`\<\{ `newDialogHeader?`: `string`; `newDialogBody`: [`IBox`](IBox.md); `newDialogFooter?`: [`IBox`](IBox.md); \}\>

Defined in: [interfaces/components/IModalDialog.ts:298](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L298)

Sets a function which is triggered whenever the modal dialog is loaded.

#### Returns

`Promise`\<\{ `newDialogHeader?`: `string`; `newDialogBody`: [`IBox`](IBox.md); `newDialogFooter?`: [`IBox`](IBox.md); \}\>

## Content

### dialogHeader?

> `optional` **dialogHeader**: `string`

Defined in: [interfaces/components/IModalDialog.ts:221](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L221)

Defines the modal dialog header

***

### dialogBody

> **dialogBody**: [`IBox`](IBox.md)

Defined in: [interfaces/components/IModalDialog.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L227)

Defines the modal dialog body

***

### dialogFooter?

> `optional` **dialogFooter**: [`IBox`](IBox.md)

Defined in: [interfaces/components/IModalDialog.ts:233](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L233)

Defines the modal dialog footer
