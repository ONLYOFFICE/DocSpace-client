# Type Alias: TSelectorCheckbox

> **TSelectorCheckbox** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:439](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L439)

Defines properties for a checkbox in the selector's footer.

## Appearance

### withCheckbox?

> `optional` **withCheckbox**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:445](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L445)

If true, displays a checkbox in the footer.

## Content

### footerCheckboxLabel?

> `optional` **footerCheckboxLabel**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:451](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L451)

The label for the footer checkbox.

## State

### isChecked?

> `optional` **isChecked**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:457](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L457)

The initial checked state of the footer checkbox.
