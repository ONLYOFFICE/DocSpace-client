# Interface: ISkeleton

Defined in: [interfaces/components/ISkeleton.ts:64](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L64)

A component that is used to hide components during uploading.

## Examples

Circular avatar placeholder for loading states

```typescript
const avatarSkeleton: ISkeleton = {
  width: "40px",
  height: "40px",
  borderRadius: "50%"
}
```

Responsive content card loading placeholder

```typescript
const cardSkeleton: ISkeleton = {
  width: "100%",
  height: "120px",
  borderRadius: "8px"
}
```

Text line loading animation

```typescript
const textSkeleton: ISkeleton = {
  width: "80%",
  height: "16px",
  borderRadius: "4px"
}
```

## Appearance

Properties that control the skeleton's dimensions, border radius, and visual styling.

### width

> **width**: `string`

Defined in: [interfaces/components/ISkeleton.ts:69](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L69)

Defines the skeleton width

***

### height

> **height**: `string`

Defined in: [interfaces/components/ISkeleton.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L75)

Defines the skeleton height

***

### borderRadius?

> `optional` **borderRadius**: `string`

Defined in: [interfaces/components/ISkeleton.ts:81](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L81)

Defines the skeleton border radius

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/ISkeleton.ts:89](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ISkeleton.ts#L89)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.
