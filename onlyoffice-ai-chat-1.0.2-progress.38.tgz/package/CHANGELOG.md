# Changelog

## 1.0.2

### Added

- Automatic history compaction, on by default (`compaction: { enabled: false }` on `AIEngineDeps` or `<AIChatWidget compaction={false} />` turns it off). The engine measures the request it is about to send — the last round's reported `metadata.steps[].usage` plus an estimate of what came after it — against the model's context window and, past `threshold` (0.8) of it, asks the model for a recap of everything but the newest `keepRecent` (4) messages. The recap is stored as a user-role message of the thread carrying `metadata.custom.compaction`, so a host's storage needs no new column; the engine yields `context-compacted`, the UI draws the message as a divider with the summary behind a toggle (`onContextCompacted` callback), and every later round sends the summary in place of what it covers. A failed summary request is logged and the round goes ahead on the full history. The window comes from the new `Model.contextWindow` / `Profile.contextWindow` (OpenRouter's and the ONLYOFFICE route's `context_length`, copied onto the profile when it is saved), else the id-based table in `core/providers/context-window.ts` (`getContextWindow(type, model)` in the registry, a static `getContextWindow` on a custom provider), else `defaultContextWindow` (128k). `compactHistory` and its helpers are exported from `core/actions` for a headless host that keeps its own history.
- Prompt caching on every Claude path, not only the ONLYOFFICE route. The native Anthropic provider marks the tool list, the system prompt and the last message with `cache_control` on chat rounds (three of the four breakpoints the API allows); OpenRouter sends the same OpenAI-format markers as the ONLYOFFICE route, on Claude routes only — the other upstreams cache a repeated prefix on their own, or turn a marker into a paid explicit write. On both OpenAI-format paths the trailing breakpoint walks back past a `tool` message and past an assistant turn with no text (`tool_calls` only), so an agent loop keeps its history cached. One-shot actions mark the system prompt only, which every call of an action shares, never the message, which is sent once and would be a cache write billed for nothing. The chat engine sends its tool list sorted by name, so a source answering in a different order no longer invalidates the cached prefix. OpenAI's own host gets the thread id as `prompt_cache_key` on chat completions and the Responses API, so the turns of one thread reach the machine holding the cached prefix; an edited base URL, an External profile and the OpenAI-compatible subclasses do not send it (`OpenAIProvider.cacheKeyFields` for a backend that honours it). The OpenAI-format helper moved from `providers/onlyoffice/cache-control.ts` to `providers/cache-control.ts`.
- Token usage of every provider round is recorded on the reply as `metadata.steps[].usage` (`promptTokens`, `completionTokens`); a tool-call resume appends one step per round. OpenAI chat completions now requests `stream_options.include_usage`.
- `parallelToolCalls` on `AIEngineDeps` and as an `AIChatWidget` prop lets the model call several tools in one turn. Adapter-served tools run side by side; calls that need the consumer still surface as `tool-call-pending` one at a time, and the model is resumed once every call has a result. Honoured by OpenAI (both APIs), Anthropic and Mistral; Gemini always allows it.

- `WidgetConfig.onPickContextRooms` / `onPickKnowledgeRooms` let the host pick the skills rooms and the knowledge bases in a picker of its own: the empty slot opens it instead of the engine's list, the connected rooms' menu offers "Change rooms". `onOpenContextRoom` / `onOpenKnowledgeRoom` open a connected room in the host from that menu.
- `GenerateMeta` action type: a new assignment slot for metadata generation, shown on the Model Assignment page under "Override for tasks" and requiring the `Chat` capability. The server-side enum has to carry the same member before a binding can be saved.
- Tool-prefs scopes: `setDisabled` / `getDisabled` and the `ToolPrefsStorage` disabled quartet take an optional `scope` (`"user"`, the default, or `"tenant"`), and `McpServersPage` takes a `toolPrefsScope` prop. A host that renders the page in its administrator settings passes `"tenant"` so a switched-off tool is off for every user; the composer's web-search toggle stays on the viewer's own list. A host without a tenant list ignores the scope (Bug 84381).

### Changed

- **Skills rooms and knowledge bases show as one pill each.** Two and more connected rooms of a kind collapse into a "Skills" / "Knowledge" pill with their count; the pill's menu lists the rooms, the way out disconnects them all. Skills are no longer switched one by one: every skill of a connected room is used, and `disabledSkillIds` / `setSkillEnabled` stay in the store without a control in the composer.
- **Several context and knowledge rooms per conversation.** The clouds store keeps `selectedContextFolders` and `selectedKnowledgeFolders` (arrays) in place of the single `selectedContextFolder` / `selectedKnowledgeFolder`; `selectContextFolder` / `selectKnowledgeFolder` now add a room, `deselectContextFolder` / `deselectKnowledgeFolder` drop one, `selectContextFolders` / `selectKnowledgeFolders` replace the set, and `clear*` drop every room. `roomSkills` entries carry the `cloud` and `roomId` they were read from (`ConnectedRoomSkill`). Rounds send `actionArgs.contextRooms` and `actionArgs.knowledgeRooms` (arrays) instead of `contextRoom` / `knowledgeRoom`; `resolveRoomSkills` takes the array and merges the rooms' skills, the first room winning a duplicate id, and `read_skill` reads a body from the skill's own room. The composer shows one pill per connected room and its pickers offer only the rooms not yet connected. Only the latest skills read applies, so a read started over fewer rooms never overwrites a later complete one.
- Highlight code blocks through a fine-grained shiki bundle: the two kanagawa themes and 28 common languages (JS/TS/JSX/TSX, JSON, HTML, CSS/SCSS, XML, Markdown, YAML, TOML, INI, shell, PowerShell, Dockerfile, SQL, Python, Java, Kotlin, C#, C, C++, Go, Rust, PHP, Swift, diff), on the JavaScript regex engine. The full bundle `react-shiki` pulled in emitted all 66 themes, ~230 grammars and the oniguruma WASM into every consumer's build (~10 MB of chunks) although only two themes were ever drawn; a fence in any other language now renders as plain text. Each grammar is still fetched only when a block first needs it.
- `shiki` is a new optional peer dependency (`^3.11.0`, already installed alongside `react-shiki`), and `SyntaxHighlighter`'s `theme` prop accepts only `"kanagawa-wave"` / `"kanagawa-lotus"`, since no other theme is loaded.

### Fixed

- Compaction counts the tool results that close the last reply. The reported usage predates them, so one large `read_file` result never triggered a compaction and the next request overflowed.
- Compaction with `profileId` measures against the chat model's window, not the summary model's.
- `regenerateStream` with `keepRecent: 0` no longer folds the re-rolled question into the summary.
- A thread reopened after a compaction keeps its context scope: the summary, a user-role message without `contextEntityId`, is skipped when the scope is derived.
- Mistral streams dropped every tool call of a delta but the first.
- Anthropic history sends a parallel round as one assistant message with one `tool_result` user message instead of alternating pairs.
- Keep the chat alive when the markdown renderer chunk cannot be fetched. The chunk loads with the first message that renders, so in a new chat with the host offline the first send rejected the lazy import, and with no error boundary React tore down the whole widget root, the "no connection" banner included; an existing chat already had the chunk and showed the banner. `MarkdownText` / `MarkdownContent` now fall back to the raw text and retry the renderer on the browser's `online` event.
- Stop sending the assistant message snapshot with an approve / deny. The engine has resumed from the stored message since the finality fix below, so the copy was dead weight — and for `upload_file` it carried the whole document in the tool arguments, which pushed the request past the host's 100 KB body limit and left the approval dialog hanging on a 413. `ToolCallData.message` is now optional and ignored by the engine (Bug 84608).
- Refuse an approve / deny for a tool call that is no longer pending. The decision is now taken on the stored message: a call that already carries a result, or one in an earlier message of the thread, answers 409 instead of overwriting the result and running another assistant round (Bugs 84283, 84285, 84287, 84288, 84291).
- Pin host tools (caller-supplied tools without a `serverType`) under `host_<tool>` everywhere. The approval dialog and the live round used the bare name while the settings routes composed `host_<tool>`, so a permission saved by one side was invisible to the other; a pin saved under the bare name before this change still counts (Bugs 84292, 84293).
- Validate a prompt bundle before any write, in both import modes: non-empty names and text, and case-insensitive uniqueness of folder names and of prompt names per folder inside the bundle. A storage rejection used to arrive after part of a merge was written or after a replace had wiped the library; replace now also restores the previous library if the storage fails anyway (Bugs 84421, 84422, 84424, 84425).
- Send an image attached by path to the model when its record carries real image bytes. The path-only block assumed a host tool would read the image, but none returns pixels, so the model called a text tool on a JPG (Bug 84454).
- Stream `gpt-image-*` generations with partial frames so a long render keeps bytes flowing through the proxies instead of tripping their read timeout with a 504 (Bug 84453).
- Tag only Gemini models that advertise `generateContent` and are not a TTS / Live / AQA / LearnLM / agent-preview / task-specific family as chat models. The catalogue carries no release date, so the model form took the alphabetically first "chat" entry and landed on `antigravity-preview-*`, which rejected the first request (Bug 83730).
- Count files and images against one shared 5-item attachment cap in the composer, instead of 5 of each.
- Keep a single flyout submenu open at a time: opening a sibling row's submenu closes the previous one, while a row's own deeper flyouts keep it open.
- Update the download button icons.
- Hand a refused engine result back as a value when the host answers it with a 4xx status: `callRoute` now reads a non-2xx body and returns it when it is `{ success: false, ... }`, instead of throwing a `RouteError` the prompt dialogs never catch. The prompts engine also tags every refusal with `code` (`required`, `conflict`, `not_found`, `invalid`) so a host can pick the status without parsing the message (Bugs 84307, 84308, 84309, 84310, 84311, 84423, 84429).
- Render the composer's tool cards for the scope the round runs in. With a context scope set (a picked agent, or a connected context room where it scopes rounds) the round reached that scope's tools, while the cards listed and switched the widget entity's, so a toggle had no effect on what the model could call. The servers store gets `toolsEntityId`, which the chat page sets from the round's context scope; custom server configuration stays on the widget entity.
- Link file paths that contain a space. CommonMark rejects a space in an unbracketed link destination, so `[book](/Users/me/My Docs/book.epub)` rendered as raw text; a local-path destination with a space is now wrapped in `<…>` before parsing, and the anchor gets a `%20`-encoded `href`. Drive paths and `sandbox:` targets become `file:///` URLs, which `markdownUrlTransform` would otherwise blank. Code blocks (``` and ~~~ fences, indented code, inline code) and `$$` math are left as written, and web links are untouched (Bugs 84347, 84348).
- Draw dropdown menus with a `--border-divider` border. The menu background matches the chat background in every theme, and the old 10% black border was invisible on the dark ones, so menus blended into the messages behind them (Bug 84030).
- Give the context cloud button the "Add room context" tooltip instead of "Settings", left over from when it was a settings cog (Bug 84328).


## 1.0.1

### Fixed

- Coalesce streamed deltas so a long reasoning block can't freeze the editor. Every delta rendered synchronously; the store is now updated from a timer, at most once per 50 ms.
- Default the model form to the model the picker lists first, not the first one the API returned. The two orders could disagree, leaving an old snapshot selected while the newest model topped the list.
- Let the initial setup form fill the pane up to `--initial-setup-max-width`. It had shrunk to the width of its title, so the fields stopped halfway across the pane.
- Draw the ONLYOFFICE logo in the context cloud row at its native 16px instead of stretching it to the 24px icon slot.

## 1.0.0

First stable release of `@onlyoffice/ai-chat` — a headless AI chat widget with built-in providers, MCP tool support and pluggable adapters.

### Providers

- Built-in providers: OpenAI, Anthropic, Google Gemini, Mistral, xAI, DeepSeek, Groq, Together AI, OpenRouter, Zhipu, Stability AI, Ollama, LM Studio, GPT4All, a generic OpenAI-compatible provider and the ONLYOFFICE gateway.
- `"external"` provider: the host owns transport via `PlatformAdapter.externalFetch`, response parsing is reused from a provider picked by `Profile.basedOn` (`openai`, `anthropic`, `mistral`, `openrouter`).
- Custom providers registered at runtime; import link and `onDownloadTemplate` for host-supplied provider templates.
- Lazy provider registry — each SDK loads on demand (`createProvider` / `providerFor` are async).
- OpenAI Responses API transport, chosen per profile by a live `useResponsesApi` probe.
- Live `canUseTool` probe; text-protocol tool-calling fallback (`<tool_call>` blocks) for models without native function calling.
- Per-profile `useProxy`, global `forceProxy`, custom `Profile.headers`, keyless local endpoints.
- Image generation (OpenAI, OpenRouter, OpenAI-compatible) and one-shot actions: summarization, translation, OCR, vision, text analysis, custom prompt.
- Prompt caching, `x-session-id` and `metadata` source attribution (`SourceMeta`, `resolveSource`) on the ONLYOFFICE route; OpenRouter routing hints.
- Typed, serializable chat errors (`toChatError`, `ChatErrorPayload`) with localized messages and a Retry button.

### Extended thinking

- Provider-neutral `ReasoningLevel` (`off` / `low` / `medium` / `high` / `max`) mapped to each provider's knob and clamped to what the model accepts.
- `ReasoningSupport` per model (`thinks`, `canDisable`, `depths`), read from the OpenRouter / ONLYOFFICE catalogue when available; the composer's **Effort** row adapts to it.
- Thinking blocks rendered in the message; reasoning level persisted via `PreferencesEngine`.

### Tools & MCP

- MCP servers over Streamable HTTP (stateful sessions) and stdio, with runtime `tools/list_changed` support and `initialize` instructions folded into the system prompt.
- Server-side "system" MCP tools (`SystemToolsSource`, `composeToolsAdapters`) — credentials never reach the browser.
- Host tools (`HostToolGroup`, `displayName`, `qualifyNames`, `requireApproval`) and a pluggable `ToolsAdapter`.
- Tool permission modes: `Ask every time`, `Auto approve`, `Allow without asking`; "always allow" per server; MCP `readOnlyHint` / `destructiveHint` honoured.
- Tool results can carry images; tool cards show the model's one-line intent (`aiChatIntent`), source and arguments.
- Built-in tools: `web_search` / `web_crawling` (Exa or ONLYOFFICE / cloud backend) and `generate_image`; `disableBuiltinImageTool` opt-out.
- `read_skill` tool for Agent Skills of a connected room.

### Chat

- Streaming replies with Stop, Regenerate, Copy, Save as docx and host-defined `assistantActions`.
- Markdown with GFM, code blocks (shiki), KaTeX math, per-block RTL/LTR direction.
- Attachments: files, images (picker, clipboard, hotkey, drag-and-drop, `onDropFiles`), attach-by-path (`attachFilesByPath`), recent files, pending upload chips, 5-item cap.
- Prompt history with ↑ / ↓, saved prompts and folders (import / export bundles), host-configured `suggestions` and welcome screen.
- Cursor (keyset) pagination for threads and messages (`enablePagination`), newest page first, server-side history search.
- Auto-generated thread titles; chat history grouped by date; thread export to host-declared formats (`getExportFormats`).
- DocSpace room as chat context: `getContextFolders` / `getRoomSkills` / `getRoomSkill`, room skills with switches, `contextRoomScopesRounds`.
- Scroll-to-bottom button, thread fade overlays, optimistic user messages, image-generation placeholder animation.

### Settings

- AI Models page with add / edit / delete profiles, model list per provider, capability probes.
- Model Assignment page: `Default`, `Chat`, `Code`, `Summarization`, `Translation`, `TextAnalysis`, `ImageGeneration`, `OCR`, `Vision`, `FormAnalysis` slots with per-action fallbacks and entity scoping.
- MCP Servers page: JSON config editor, per-server toggle, permissions list, crash logs.
- Web Search page with blur or button save mode (`webSearchSaveMode`), reset and custom headers.
- Initial-setup screen when no profile is configured.

### Integration

- Adapters injected via context: `StorageAdapter`, `SettingsAdapter`, `PlatformAdapter` (`fetchProxy`, `externalFetch`, `copyToClipboard`, `showToast`, `file`, `env`, `clouds`).
- Server-API mode (`createServerAPI`, `ApiProvider`, `DEFAULT_*_ROUTES`) — the core runs on a host over HTTP with NDJSON streaming.
- Engines usable headless: `AIEngine`, `ThreadsEngine`, `ProfilesEngine`, `AssignmentsEngine`, `ToolsEngine`, `PromptsEngine`, `AttachmentsEngine`, `PreferencesEngine`, `WebSearchEngine`, `ContextEngine`.
- Host callbacks (`ChatCallbacks`): `onReady`, `onThreadsUpdated`, `onProfilesUpdated`, `onModelAssignmentUpdated`, `onServersUpdated`, `onWebSearchUpdated`, `onStreamError`, `onError`, …
- Imperative ref (`AIChatWidgetRef`): `approveToolCall`, `denyToolCall`, `updateProfiles`, `updateThreads`, `updateMCPServer`, `exportThread`, …
- Host-owned dialogs: `onDeleteThread`, `onDeleteProfile`, `onCreatePrompt`, `onEditPrompt`, `onCreatePromptFolder`, `onRenamePromptFolder`, `onDeletePromptFolder`, `onDiscardMcpChanges`, `onToolCallApproveResult`, `formatChatError`.
- Middleware (`beforeSend`) with attachment refs resolved on demand.
- Composite UI building blocks exported for custom layouts (`Layout`, `ChatList`, `Composer`, `ModelCard`, `HelpButton`, `Toast`, …); primitives swappable via `ComponentsProvider`.

### Theming & layout

- Seven built-in themes, `customTheme`, and CSS tokens for every surface: composer, dropdowns, chat history, settings pages, buttons, inputs, combo-boxes, toggles, dialogs.
- Widget flags: `hideProfilePicker`, `profilePickerReadOnly`, `hideSettingsButton`, `hideContextClouds`, `composerDisabled`, `composerHeader`, `composerActions`, `dropdownNavigation` (`flyout` / `drilldown`), `iconFormat`, `isDialogFullscreen`, `logLevel`, …
- Icons compiled to inline SVG components (CSP-safe) with multi-scale PNG fallback; theme-aware provider logos; host overrides via `images`.
- Scoped Tailwind preflight (`.aui-root`) — the widget never emits global CSS.
- Slim install: only `lodash.clonedeep` is a hard dependency; provider SDKs and UI libraries are optional peers.

### i18n

- 41 locales; translation overrides via `initAIChatI18n`; own i18next instance; RTL support.
