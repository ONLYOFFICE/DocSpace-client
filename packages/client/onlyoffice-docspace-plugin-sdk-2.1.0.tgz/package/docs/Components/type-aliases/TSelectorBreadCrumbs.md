# Type Alias: TSelectorBreadCrumbs

> **TSelectorBreadCrumbs** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:318](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L318)

Defines properties for configuring breadcrumbs in a selector.

## Appearance

### withBreadCrumbs?

> `optional` **withBreadCrumbs**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:324](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L324)

If true, displays the breadcrumb navigation.

## Behavior

### onSelectBreadCrumb()?

> `optional` **onSelectBreadCrumb**: (`id`) => `TReturnMessage`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:342](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L342)

A callback function that is triggered when a breadcrumb item is selected.

#### Parameters

##### id

`string` | `number`

#### Returns

`TReturnMessage`

## Content

### breadCrumbs?

> `optional` **breadCrumbs**: [`TBreadCrumbItem`](TBreadCrumbItem.md)[]

Defined in: [interfaces/components/Selector/IBaseSelector.ts:336](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L336)

An array of breadcrumb items to display.

## State

### isBreadCrumbsLoading?

> `optional` **isBreadCrumbsLoading**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:330](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L330)

If true, shows a loading indicator for the breadcrumbs.
