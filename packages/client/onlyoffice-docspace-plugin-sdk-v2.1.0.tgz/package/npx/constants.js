/*
* (c) Copyright Ascensio System SIA 2026
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

const IPlugin = "IPlugin";

// const ISeparatorItem = "ISeparatorItem";

const PluginStatus = `PluginStatus`;
const status = `status: PluginStatus = PluginStatus.active;`;

const onLoadCallback = `
  onLoadCallback = async () => {};`;

const updateStatus = ` 
  updateStatus = (status: PluginStatus) => {
    this.status = status;
  };`;

const getStatus = `
  getStatus = () => {
    return this.status;
  };`;

const setOnLoadCallback = `
  setOnLoadCallback = (callback: () => Promise<void>) => {
    this.onLoadCallback = callback;
  };`;

export {
  IPlugin,
  PluginStatus,
  // ISeparatorItem,
  status,
  onLoadCallback,
  updateStatus,
  getStatus,
  setOnLoadCallback,
};
