# Enumeration: Security

Defined in: [enums/Security.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L22)

Defines the supported room/folder security parameters.

## Enumeration Members

### Copy

> **Copy**: `"Copy"`

Defined in: [enums/Security.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L24)

Permission to copy files and folders

***

### CopySharedLink

> **CopySharedLink**: `"CopySharedLink"`

Defined in: [enums/Security.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L27)

Permission to copy sharing links

***

### CopyTo

> **CopyTo**: `"CopyTo"`

Defined in: [enums/Security.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L30)

Permission to copy items to other locations

***

### Create

> **Create**: `"Create"`

Defined in: [enums/Security.ts:33](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L33)

Permission to create new files and folders

***

### Delete

> **Delete**: `"Delete"`

Defined in: [enums/Security.ts:36](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L36)

Permission to delete items

***

### Download

> **Download**: `"Download"`

Defined in: [enums/Security.ts:39](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L39)

Permission to download files

***

### Duplicate

> **Duplicate**: `"Duplicate"`

Defined in: [enums/Security.ts:42](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L42)

Permission to create duplicates of items

***

### EditAccess

> **EditAccess**: `"EditAccess"`

Defined in: [enums/Security.ts:45](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L45)

Permission to modify access rights

***

### EditRoom

> **EditRoom**: `"EditRoom"`

Defined in: [enums/Security.ts:48](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L48)

Permission to modify room settings

***

### Move

> **Move**: `"Move"`

Defined in: [enums/Security.ts:51](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L51)

Permission to move items

***

### MoveTo

> **MoveTo**: `"MoveTo"`

Defined in: [enums/Security.ts:54](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L54)

Permission to move items to other locations

***

### Mute

> **Mute**: `"Mute"`

Defined in: [enums/Security.ts:57](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L57)

Permission to mute notifications

***

### Pin

> **Pin**: `"Pin"`

Defined in: [enums/Security.ts:60](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L60)

Permission to pin items

***

### Read

> **Read**: `"Read"`

Defined in: [enums/Security.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L63)

Permission to view and read content

***

### Rename

> **Rename**: `"Rename"`

Defined in: [enums/Security.ts:66](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L66)

Permission to rename items

***

### CreateRoomFrom

> **CreateRoomFrom**: `"CreateRoomFrom"`

Defined in: [enums/Security.ts:69](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L69)

Permission to create rooms from existing content

***

### CopyLink

> **CopyLink**: `"CopyLink"`

Defined in: [enums/Security.ts:72](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L72)

Permission to copy links to files

***

### Embed

> **Embed**: `"Embed"`

Defined in: [enums/Security.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Security.ts#L75)

Permission to embed content
