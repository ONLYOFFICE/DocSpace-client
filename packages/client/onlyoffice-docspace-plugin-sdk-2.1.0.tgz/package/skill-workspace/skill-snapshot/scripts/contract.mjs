/*
 * The portal contract in one place: which scopes a shipped portal can host, what
 * its loader calls on each of them, which values it compares against, and which
 * payload every action needs.
 *
 * Deliberately *not* derived from the installed SDK. The SDK describes what
 * compiles; this describes what a released portal runs, and the two part company
 * whenever an SDK release lands ahead of a portal one - a scope the SDK exports
 * but the portal cannot host installs cleanly and then shows nothing.
 *
 * checkSdkDrift() compares the two anyway and reports where they disagree, so a
 * new SDK announces itself instead of waiting to be noticed.
 *
 * Keep in step with references/sdk-target.md when a new SDK *and* a portal
 * release land together.
 */

export const SDK_PACKAGE = "@onlyoffice/docspace-plugin-sdk";

/** The major version this contract was written against. */
export const SDK_MAJOR = 2;

export const SCOPES = [
  "API",
  "Settings",
  "ContextMenu",
  "InfoPanel",
  "MainButton",
  "ProfileMenu",
  "EventListener",
  "File",
  "PostMessage",
  "ArticleButton",
];

/**
 * Per scope: the interface to implement, the members the loader calls, the item
 * shape it reads, and the action that makes it re-read the map.
 *
 * `refresh` is null for ArticleButton because the SDK has no
 * updateArticleButtonItems - an item registered after installation never
 * arrives, which makes an empty map there terminal rather than merely odd.
 */
export const SCOPE_CONTRACT = {
  ContextMenu: {
    iface: "IContextMenuPlugin",
    item: "IContextMenuItem",
    field: "contextMenuItems",
    getter: "getContextMenuItems",
    adder: "addContextMenuItem",
    updater: "updateContextMenuItem",
    refresh: "updateContextMenuItems",
    key: "key",
    required: ["key", "label", "icon"],
    filter: "usersTypes",
  },
  InfoPanel: {
    iface: "IInfoPanelPlugin",
    item: "IInfoPanelItem",
    field: "infoPanelItems",
    getter: "getInfoPanelItems",
    adder: "addInfoPanelItem",
    updater: "updateInfoPanelItem",
    refresh: "updateInfoPanelItems",
    key: "key",
    required: ["key", "subMenu", "body"],
    filter: "usersTypes",
  },
  MainButton: {
    iface: "IMainButtonPlugin",
    item: "IMainButtonItem",
    field: "mainButtonItems",
    getter: "getMainButtonItems",
    adder: "addMainButtonItem",
    updater: "updateMainButtonItem",
    refresh: "updateMainButtonItems",
    key: "key",
    required: ["key", "label", "icon"],
    filter: "usersType",
  },
  ProfileMenu: {
    iface: "IProfileMenuPlugin",
    item: "IProfileMenuItem",
    field: "profileMenuItems",
    getter: "getProfileMenuItems",
    adder: "addProfileMenuItem",
    updater: "updateProfileMenuItem",
    refresh: "updateProfileMenuItems",
    key: "key",
    required: ["key", "label", "icon", "onClick"],
    filter: "usersType",
  },
  EventListener: {
    iface: "IEventListenerPlugin",
    item: "IEventListenerItem",
    field: "eventListenerItems",
    getter: "getEventListenerItems",
    adder: "addEventListenerItem",
    // The only scope with no updater in the SDK - re-adding overwrites by key.
    updater: null,
    refresh: "updateEventListenerItems",
    key: "key",
    required: ["key", "eventType", "eventHandler"],
    filter: "usersTypes",
  },
  File: {
    iface: "IFilePlugin",
    item: "IFileItem",
    field: "fileItems",
    getter: "getFileItems",
    adder: "addFileItem",
    updater: "updateFileItem",
    refresh: "updateFileItems",
    // Keyed by extension, so two plugins claiming ".md" evict one another.
    key: "extension",
    required: ["extension", "onClick"],
    filter: "usersType",
  },
  ArticleButton: {
    iface: "IArticleButtonPlugin",
    item: "IArticleButtonItem",
    field: "articleButtonItems",
    getter: "getArticleButtonItems",
    adder: "addArticleButtonItem",
    updater: "updateArticleButtonItem",
    refresh: null,
    key: "key",
    required: ["key", "body"],
    filter: "usersTypes",
  },
  API: { iface: "IApiPlugin", members: ["setAPI", "getAPI"] },
  Settings: {
    iface: "ISettingsPlugin",
    members: ["setAdminPluginSettingsValue", "getAdminPluginSettings"],
  },
  PostMessage: { iface: "IPostMessagePlugin", members: ["setPostMessageCallback"] },
};

/** UsersType values. The enum keys are camelCase; the host compares the values. */
export const USERS_TYPES = ["Owner", "DocSpaceAdmin", "RoomAdmin", "Collaborator", "User"];

export const DEVICES = ["mobile", "tablet", "desktop"];

export const EVENT_TYPES = [
  "create",
  "rename",
  "create_room",
  "edit_room",
  "change_column",
  "change_user_type",
  "create_plugin_file",
];

/** Actions that are a no-op unless their payload field is present in the message. */
export const ACTION_PAYLOAD = {
  "update-props": "newProps",
  "update-context": "contextProps",
  "show-toast": "toastProps",
  "show-modal": "modalDialogProps",
  "show-create-dialog-modal": "createDialogProps",
  "update-create-dialog-modal": "createDialogProps",
  "show-selector": "selectorProps",
  "update-selector": "selectorProps",
  "show-media-viewer": "mediaViewerProps",
  "update-media-viewer": "mediaViewerProps",
  "add-floating-operations-button": "floatingOperationsButtonProps",
  "update-floating-operations-button": "floatingOperationsButtonProps",
  "remove-floating-operations-button": "floatingOperationsButtonPropsId",
  "send-post-message": "postMessage",
  "save-settings": "settings",
  navigate: "navigatePath",
};

/** Actions the host performs with nothing else in the message. */
export const PAYLOAD_FREE_ACTIONS = [
  "update-status",
  "close-modal",
  "close-selector",
  "close-media-viewer",
  "open-info-panel",
  "update-context-menu-items",
  "update-info-panel-items",
  "update-main-button-items",
  "update-profile-menu-items",
  "update-file-items",
  "update-event-listener-items",
];

/**
 * Props each component cannot render without. Nothing wraps the plugin's tree in
 * an error boundary, so a missing one does not blank the element - it throws
 * during render and replaces the whole portal with an error screen.
 */
export const COMPONENT_PROPS = {
  box: [],
  button: ["label", "size", "onClick"],
  checkbox: ["isChecked", "onChange"],
  comboBox: ["options", "selectedOption"],
  iFrame: ["src"],
  iconButton: [],
  img: ["src", "alt"],
  input: ["value", "onChange"],
  label: ["text"],
  link: [],
  skeleton: ["width", "height"],
  text: ["text"],
  textArea: ["value", "onChange"],
  toggleButton: ["isChecked", "onChange"],
};

/** Every action string this contract knows about. */
export const KNOWN_ACTIONS = [...Object.keys(ACTION_PAYLOAD), ...PAYLOAD_FREE_ACTIONS];

/**
 * Compares the tables above against the SDK the project actually installed.
 *
 * A mismatch is not the plugin's fault, so everything here is a warning: it
 * means this tool's idea of the portal contract has aged, and someone should
 * check whether a portal release caught up. Returns {code, message} pairs.
 */
export const checkSdkDrift = (sdk, installedVersion) => {
  const drift = [];
  const note = (message) => drift.push({ code: "sdk-drift", message });

  // An older SDK is missing most of the list, and printing all of it buries the
  // one line that matters.
  const summarise = (values) =>
    values.length > 5 ? `${values.slice(0, 5).join(", ")} and ${values.length - 5} more` : values.join(", ");

  const compare = (label, ours, theirs, hint) => {
    if (!Array.isArray(theirs) || theirs.length === 0) return;

    const added = theirs.filter((v) => !ours.includes(v));
    const gone = ours.filter((v) => !theirs.includes(v));

    if (added.length)
      note(
        `the installed SDK has ${label} this tool does not know: ${summarise(added)}${hint ?? ""}`,
      );
    if (gone.length)
      note(`this tool expects ${label} the installed SDK does not have: ${summarise(gone)}`);
  };

  const major = Number(String(installedVersion ?? "").split(".")[0]);
  if (Number.isInteger(major) && major !== SDK_MAJOR)
    note(
      `the project installed ${SDK_PACKAGE} ${installedVersion}, but this tool encodes the portal contract for ${SDK_MAJOR}.x - a scope or action the SDK adds ahead of the portal compiles and then does nothing (see references/sdk-target.md)`,
    );

  const values = (enumObject) => (enumObject ? Object.values(enumObject) : []);

  compare("UsersType values", USERS_TYPES, values(sdk.UsersType));
  compare("Devices values", DEVICES, values(sdk.Devices));
  compare("Events values", EVENT_TYPES, values(sdk.Events));
  compare("components", Object.keys(COMPONENT_PROPS), values(sdk.Components));
  compare(
    "actions",
    KNOWN_ACTIONS,
    values(sdk.Actions),
    " - a returned message using one of those is not checked for its payload",
  );

  return drift;
};
