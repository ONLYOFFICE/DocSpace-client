# Interface: IComboBoxItem

Defined in: [interfaces/components/IComboBox.ts:47](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L47)

Custom combo box option.

## Example

Basic language option with icon

```typescript
const languageOption: IComboBoxItem = {
  key: "en-US",
  label: "English (US)",
  icon: "language-en.svg",
  disabled: false
}
```

## Content

Properties that define the option's display text and icon.

### label

> **label**: `string`

Defined in: [interfaces/components/IComboBox.ts:60](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L60)

Display text for the option

***

### icon?

> `optional` **icon**: `string`

Defined in: [interfaces/components/IComboBox.ts:67](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L67)

Optional icon for the option

## Options

### key

> **key**: `string`

Defined in: [interfaces/components/IComboBox.ts:53](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L53)

Unique identifier for the option

## State

Properties that control whether the option is disabled or selectable.

### disabled?

> `optional` **disabled**: `boolean`

Defined in: [interfaces/components/IComboBox.ts:74](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L74)

Specifies if the combo box option is disabled or not
