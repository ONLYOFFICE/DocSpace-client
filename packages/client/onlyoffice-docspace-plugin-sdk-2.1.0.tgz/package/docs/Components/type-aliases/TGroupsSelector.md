# Type Alias: TGroupsSelector

> **TGroupsSelector** = [`TSelectorHeader`](TSelectorHeader.md) & [`TSelectorBaseProps`](TSelectorBaseProps.md) & [`TSelectorLifecycleEvents`](TSelectorLifecycleEvents.md) & `object`

Defined in: [interfaces/components/Selector/IGroupsSelector.ts:86](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IGroupsSelector.ts#L86)

Defines the properties for a group selector component.

## Type Declaration

### onSubmit()

> **onSubmit**: (`params`) => `TReturnMessage`

A callback function that is triggered when the submit button is clicked.

#### Parameters

##### params

`TOnSubmitParams`

#### Returns

`TReturnMessage`

## Example

```typescript
// This example shows how to set up a group selector with a custom header and submit logic.

const groupsSelectorProps: TGroupsSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Select Groups",
  },

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (payload) => {
    // The `payload` object contains the `selectedIds` of the chosen groups.
    console.log("Selected groups:", payload.selectedIds);

    // After submission, close the selector and display a toast notification.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: "Groups selected successfully",
      }],
    };
  },
};
```
