# Events

Defined in: [enums/Events.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Events.ts#L22)

Defines the supported event types for the plugin system.

## Enumeration Members

### CREATE

```ts
CREATE: "create";
```

Defined in: [enums/Events.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Events.ts#L24)

Triggered when a new item is created

### RENAME

```ts
RENAME: "rename";
```

Defined in: [enums/Events.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Events.ts#L27)

Triggered when an item is renamed

### ROOM\_CREATE

```ts
ROOM_CREATE: "create_room";
```

Defined in: [enums/Events.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Events.ts#L30)

Triggered when a new room is created

### ROOM\_EDIT

```ts
ROOM_EDIT: "edit_room";
```

Defined in: [enums/Events.ts:33](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Events.ts#L33)

Triggered when a room is edited

### CHANGE\_COLUMN

```ts
CHANGE_COLUMN: "change_column";
```

Defined in: [enums/Events.ts:36](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Events.ts#L36)

Triggered when a column configuration is changed

### CHANGE\_USER\_TYPE

```ts
CHANGE_USER_TYPE: "change_user_type";
```

Defined in: [enums/Events.ts:39](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Events.ts#L39)

Triggered when a user's type or role is modified

### CREATE\_PLUGIN\_FILE

```ts
CREATE_PLUGIN_FILE: "create_plugin_file";
```

Defined in: [enums/Events.ts:42](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Events.ts#L42)

Triggered when a new file is created through a plugin
