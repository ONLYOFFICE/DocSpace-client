# Type Alias: TSelectorHeader

> **TSelectorHeader** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:388](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L388)

Defines properties for the selector's header.

## Appearance

### withHeader?

> `optional` **withHeader**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:394](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L394)

If true, displays the header.

## Content

### headerProps?

> `optional` **headerProps**: `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:400](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L400)

An object containing properties for the header.

#### Appearance

##### isCloseable?

> `optional` **isCloseable**: `boolean`

If true, displays a close button in the header.

##### withBackButton?

> `optional` **withBackButton**: `boolean`

If true, displays a back button in the header.

#### Behavior

##### onCloseClick()?

> `optional` **onCloseClick**: () => `TReturnMessage`

A callback function that is triggered when the close button is clicked.

###### Returns

`TReturnMessage`

##### onBackClick()?

> `optional` **onBackClick**: () => `TReturnMessage`

A callback function that is triggered when the back button is clicked.

###### Returns

`TReturnMessage`

#### Content

##### label

> **label**: `string`

The title text to display in the header.
