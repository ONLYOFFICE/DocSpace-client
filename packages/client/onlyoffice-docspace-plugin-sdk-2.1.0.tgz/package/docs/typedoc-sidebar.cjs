// @ts-check
/** @type {import("@docusaurus/plugin-content-docs").SidebarsConfig} */
const typedocSidebar = {
  items: [
    {
      type: "category",
      label: "Modules",
      items: [
        {
          type: "category",
          label: "Components",
          items: [
            {
              type: "category",
              label: "Box",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/BoxGroup",
                  label: "BoxGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IBorderProp",
                  label: "IBorderProp"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IBox",
                  label: "IBox"
                }
              ]
            },
            {
              type: "category",
              label: "Button",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/ButtonGroup",
                  label: "ButtonGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/enumerations/ButtonSize",
                  label: "ButtonSize"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IButton",
                  label: "IButton"
                }
              ]
            },
            {
              type: "category",
              label: "Checkbox",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/CheckboxGroup",
                  label: "CheckboxGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/ICheckbox",
                  label: "ICheckbox"
                }
              ]
            },
            {
              type: "category",
              label: "ComboBox",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/ComboBoxGroup",
                  label: "ComboBoxGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IComboBoxItem",
                  label: "IComboBoxItem"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IComboBox",
                  label: "IComboBox"
                }
              ]
            },
            {
              type: "category",
              label: "Component",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/Component",
                  label: "Component"
                }
              ]
            },
            {
              type: "category",
              label: "CreateDialog",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/ICreateDialog",
                  label: "ICreateDialog"
                }
              ]
            },
            {
              type: "category",
              label: "FloatingOperations",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IFloatingOperationsButton",
                  label: "IFloatingOperationsButton"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/enumerations/FloatingOperationType",
                  label: "FloatingOperationType"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IFloatingOperation",
                  label: "IFloatingOperation"
                }
              ]
            },
            {
              type: "category",
              label: "Frame",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/IFrameGroup",
                  label: "IFrameGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IFrame",
                  label: "IFrame"
                }
              ]
            },
            {
              type: "category",
              label: "Image",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/ImageGroup",
                  label: "ImageGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IImage",
                  label: "IImage"
                }
              ]
            },
            {
              type: "category",
              label: "Input",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/InputGroup",
                  label: "InputGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/enumerations/InputSize",
                  label: "InputSize"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/enumerations/InputAutocomplete",
                  label: "InputAutocomplete"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/enumerations/InputType",
                  label: "InputType"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IInput",
                  label: "IInput"
                }
              ]
            },
            {
              type: "category",
              label: "Label",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/LabelGroup",
                  label: "LabelGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/ILabel",
                  label: "ILabel"
                }
              ]
            },
            {
              type: "category",
              label: "ModalDialog",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/enumerations/ModalDisplayType",
                  label: "ModalDisplayType"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IModalDialog",
                  label: "IModalDialog"
                }
              ]
            },
            {
              type: "category",
              label: "Selector",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TBaseSelector",
                  label: "TBaseSelector"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorItem",
                  label: "TSelectorItem"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorItemFile",
                  label: "TSelectorItemFile"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorItemInput",
                  label: "TSelectorItemInput"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorItemNew",
                  label: "TSelectorItemNew"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TBreadCrumbItem",
                  label: "TBreadCrumbItem"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorBreadCrumbs",
                  label: "TSelectorBreadCrumbs"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorPagination",
                  label: "TSelectorPagination"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorHeader",
                  label: "TSelectorHeader"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorCheckbox",
                  label: "TSelectorCheckbox"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorCancelButton",
                  label: "TSelectorCancelButton"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorBaseProps",
                  label: "TSelectorBaseProps"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorLifecycleEvents",
                  label: "TSelectorLifecycleEvents"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorEmptyScreen",
                  label: "TSelectorEmptyScreen"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorSearchCreate",
                  label: "TSelectorSearchCreate"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelectorSubmitButton",
                  label: "TSelectorSubmitButton"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TFilesSelector",
                  label: "TFilesSelector"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TGroupsSelector",
                  label: "TGroupsSelector"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TPeopleSelector",
                  label: "TPeopleSelector"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TRoomSelector",
                  label: "TRoomSelector"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TSelector",
                  label: "TSelector"
                }
              ]
            },
            {
              type: "category",
              label: "Skeleton",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/SkeletonGroup",
                  label: "SkeletonGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/ISkeleton",
                  label: "ISkeleton"
                }
              ]
            },
            {
              type: "category",
              label: "Text",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TextGroup",
                  label: "TextGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IText",
                  label: "IText"
                }
              ]
            },
            {
              type: "category",
              label: "TextArea",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/TextAreaGroup",
                  label: "TextAreaGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/ITextArea",
                  label: "ITextArea"
                }
              ]
            },
            {
              type: "category",
              label: "Toast",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/enumerations/ToastType",
                  label: "ToastType"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IToast",
                  label: "IToast"
                }
              ]
            },
            {
              type: "category",
              label: "ToggleButton",
              items: [
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/type-aliases/ToggleButtonGroup",
                  label: "ToggleButtonGroup"
                },
                {
                  type: "doc",
                  id: "docspace/plugins-sdk/usage-sdk/Components/interfaces/IToggleButton",
                  label: "IToggleButton"
                }
              ]
            }
          ],
          link: {
            type: "doc",
            id: "docspace/plugins-sdk/usage-sdk/Components/index"
          }
        }
      ]
    },
    {
      type: "category",
      label: "Enumerations",
      items: [
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/Actions",
          label: "Actions"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/Components",
          label: "Components"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/Devices",
          label: "Devices"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/Events",
          label: "Events"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/FilesType",
          label: "FilesType"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/FilesExst",
          label: "FilesExst"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/FilesSecurity",
          label: "FilesSecurity"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/PluginStatus",
          label: "PluginStatus"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/PluginLocale",
          label: "PluginLocale"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/RoomSearchArea",
          label: "RoomSearchArea"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/RoomsType",
          label: "RoomsType"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/Security",
          label: "Security"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/SelectorType",
          label: "SelectorType"
        },
        {
          type: "doc",
          id: "docspace/plugins-sdk/usage-sdk/enumerations/UsersType",
          label: "UsersType"
        }
      ]
    }
  ]
};
module.exports = typedocSidebar.items;