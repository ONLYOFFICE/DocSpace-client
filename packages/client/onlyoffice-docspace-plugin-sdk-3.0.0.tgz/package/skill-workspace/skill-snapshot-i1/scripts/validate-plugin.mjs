#!/usr/bin/env node

/*
 * Validates a DocSpace plugin project against the portal loader contract:
 * package.json <-> config.json <-> bundle coherence, asset/limit rules, and a
 * runtime smoke test of the built bundle in a sandbox.
 *
 * Every table describing what the portal accepts lives in contract.mjs; this
 * file only applies them. The target SDK/portal pair is in
 * references/sdk-target.md.
 *
 * Usage:
 *   node scripts/validate-plugin.mjs <pluginDir> [options]
 *
 * Options:
 *   --no-runtime  skip loading dist/plugin.js in a sandbox
 *   --invoke      also call every item callback with a dummy id and validate
 *                 the returned IMessage (may hit the network - opt in)
 *   --json        machine-readable report on stdout
 *
 * Exit code 1 when there is at least one ERROR.
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as vm from "node:vm";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";

import {
  ACTION_PAYLOAD,
  checkSdkDrift,
  COMPONENT_PROPS,
  DEVICES,
  EVENT_TYPES,
  KNOWN_ACTIONS,
  RENDERED_BUTTON_SIZES,
  RENDERED_INPUT_SIZES,
  SCOPE_CONTRACT,
  SCOPES,
  SDK_PACKAGE,
  USERS_TYPES,
} from "./contract.mjs";

const MAX_FILE_BYTES = 5 * 1024 * 1024;
const MAX_ASSETS = 10;
const ASSET_EXT = [".svg", ".png", ".jpg", ".jpeg"];
const ONLOAD_TIMEOUT_MS = 10_000;

const findings = [];
const add = (level, code, message) => findings.push({ level, code, message });
const error = (code, message) => add("ERROR", code, message);
const warn = (code, message) => add("WARN", code, message);
const info = (code, message) => add("INFO", code, message);

const args = process.argv.slice(2);
const flags = new Set(args.filter((a) => a.startsWith("--")));
const dir = path.resolve(args.find((a) => !a.startsWith("--")) ?? ".");

const readJson = (file) => JSON.parse(fs.readFileSync(file, "utf8"));
const exists = (...p) => fs.existsSync(path.join(dir, ...p));

// --- package.json ------------------------------------------------------------

const pkgPath = path.join(dir, "package.json");

if (!fs.existsSync(pkgPath)) {
  console.error(`Not a plugin project: ${pkgPath} does not exist`);
  process.exit(1);
}

let pkg;
try {
  pkg = readJson(pkgPath);
} catch (e) {
  console.error(`package.json is not valid JSON: ${e.message}`);
  process.exit(1);
}

if (!pkg.name) error("pkg.name", "package.json has no name");
else if (/[A-Z]/.test(pkg.name))
  error(
    "pkg.name",
    `name "${pkg.name}" has upper case letters - the packer lower-cases it in config.json, so every name lookup against the portal has to use the lower case form`,
  );
else if (!/^[a-z_-]+$/.test(pkg.name))
  warn(
    "pkg.name",
    `name "${pkg.name}" contains characters the scaffold dialog rejects (it allows a-z, - and _); existing plugins such as draw.io do use dots`,
  );

if (!pkg.pluginName) error("pkg.pluginName", "package.json has no pluginName");
else if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(pkg.pluginName))
  error(
    "pkg.pluginName",
    `pluginName "${pkg.pluginName}" must be a valid JS identifier - it is used as window.Plugins.<pluginName>`,
  );

if (!/^\d+\.\d+\.\d+/.test(pkg.version ?? ""))
  warn("pkg.version", `version "${pkg.version}" is not semver-like`);

const scopes = Array.isArray(pkg.scopes) ? pkg.scopes : [];

if (!Array.isArray(pkg.scopes))
  error("pkg.scopes", "scopes must be an array in package.json");
else if (scopes.length === 0)
  error("pkg.scopes", "scopes is empty - the plugin cannot be activated");

// A scope outside this list is either a typo or one no shipped portal hosts;
// both install cleanly and render nothing, so both are errors rather than warnings.
for (const s of scopes)
  if (!SCOPES.includes(s))
    error("pkg.scopes", `unknown scope "${s}" (known: ${SCOPES.join(", ")})`);

if (pkg.cspDomains && !Array.isArray(pkg.cspDomains))
  error("pkg.cspDomains", "cspDomains must be an array of origins");

if (pkg.minDocSpaceVersion)
  warn(
    "pkg.minDocSpaceVersion",
    "minDocSpaceVersion in package.json is ignored - the packer reads it from the installed SDK",
  );

const buildScript = pkg.scripts?.build ?? "";
if (!buildScript.includes("build-docspace-plugin"))
  error(
    "pkg.scripts",
    `build script "${buildScript}" must end with "npx build-docspace-plugin" (SDK 1.1.1 createZip scripts are dead)`,
  );

if (pkg.runtime)
  warn(
    "pkg.runtime",
    `"runtime": "${pkg.runtime}" is not supported by the portal loader - the bundle will load and render nothing`,
  );

// --- assets ------------------------------------------------------------------

const assetsDir = path.join(dir, "assets");
let assetNames = [];

if (fs.existsSync(assetsDir)) {
  const entries = fs.readdirSync(assetsDir, { withFileTypes: true });

  for (const entry of entries) {
    if (entry.isDirectory()) {
      error("assets", `assets/${entry.name}/ - nested folders are not packed`);
      continue;
    }

    assetNames.push(entry.name);

    const ext = path.extname(entry.name).toLowerCase();
    if (!ASSET_EXT.includes(ext))
      error("assets", `assets/${entry.name} - only ${ASSET_EXT.join("/")} are accepted`);

    const size = fs.statSync(path.join(assetsDir, entry.name)).size;
    if (size > MAX_FILE_BYTES)
      error("assets", `assets/${entry.name} is ${(size / 1e6).toFixed(1)} MB, limit is 5 MB`);
  }

  if (assetNames.length > MAX_ASSETS)
    error("assets", `${assetNames.length} assets, the portal accepts at most ${MAX_ASSETS}`);
} else if (scopes.some((s) => s !== "API" && s !== "PostMessage")) {
  warn("assets", "no assets/ folder - the plugin card and every item icon will be broken");
}

if (!pkg.logo) warn("pkg.logo", "no logo - the plugin card shows a placeholder (48x48 expected)");
else if (!assetNames.includes(pkg.logo))
  error("pkg.logo", `logo "${pkg.logo}" is not in assets/`);

// --- sources ------------------------------------------------------------------

const srcDir = path.join(dir, "src");
let srcText = "";

if (!fs.existsSync(srcDir)) {
  error("src", "no src/ folder");
} else {
  const walk = (d) =>
    fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => {
      const p = path.join(d, e.name);
      return e.isDirectory() ? walk(p) : [p];
    });

  const srcFiles = walk(srcDir).filter((f) => /\.(ts|tsx|js|jsx)$/.test(f));

  if (srcFiles.length === 0) error("src", "src/ has no TypeScript/JavaScript files");

  // Comments are stripped so that commented-out items and icons are not treated
  // as live references (draw.io keeps a disabled main button item in comments).
  srcText = srcFiles
    .map((f) => fs.readFileSync(f, "utf8"))
    .join("\n")
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/(^|[^:])\/\/[^\n]*/g, "$1");

  const entry = ["index.ts", "index.tsx", "index.js"].find((f) => exists("src", f));
  if (!entry) error("src", "src/ has no index.ts entry point");

  if (pkg.pluginName) {
    // Three legitimate spellings: dotted, bracketed with a literal, and
    // bracketed with a constant. The last one is common enough that missing it
    // would reject working plugins, so resolve the constant before complaining.
    const direct = new RegExp(
      `window\\.Plugins\\.${pkg.pluginName}\\s*=|window\\.Plugins\\[["']${pkg.pluginName}["']\\]\\s*=`,
    );

    const viaConstant = () => {
      const identifier = srcText.match(/window\.Plugins\[\s*([A-Za-z_$][\w$]*)\s*\]\s*=/)?.[1];
      if (!identifier) return false;

      const bound = new RegExp(
        `\\b${identifier}\\s*(?::[^=]+)?=\\s*["\`']${pkg.pluginName}["\`']`,
      );

      return bound.test(srcText);
    };

    if (!direct.test(srcText) && !viaConstant())
      error(
        "registration",
        `no "window.Plugins.${pkg.pluginName} = ..." in src/ - the portal merges window.Plugins[pluginName] and silently gets an empty plugin when the names differ`,
      );
  }

  for (const scope of scopes) {
    const contract = SCOPE_CONTRACT[scope];
    if (!contract) continue;

    const members = contract.getter ? [contract.getter] : (contract.members ?? []);
    for (const member of members)
      if (!srcText.includes(member))
        error("scope", `scope "${scope}" is declared but src/ never defines ${member}`);
  }

  for (const [, icon] of srcText.matchAll(
    /(?:icon|fileRowIcon|fileTileIcon)\s*:\s*["']([^"']+)["']/g,
  ))
    if (!assetNames.includes(icon))
      error("icon", `icon "${icon}" referenced in src/ is not in assets/`);
}

// --- build output ------------------------------------------------------------

const bundlePath = path.join(dir, "dist", "plugin.js");
const zipPath = path.join(dir, "dist", "plugin.zip");
const isBuilt = fs.existsSync(bundlePath);

if (!isBuilt) {
  warn("dist", "dist/plugin.js is missing - run the build before validating the archive");
} else {
  const size = fs.statSync(bundlePath).size;
  if (size > MAX_FILE_BYTES)
    error("dist", `dist/plugin.js is ${(size / 1e6).toFixed(1)} MB, limit is 5 MB`);
}

/** Resolves a dependency from the audited project rather than from this tool. */
const loadFromProject = async (name) => {
  for (const from of [pkgPath, path.join(dir, "node_modules")]) {
    try {
      const resolved = createRequire(from).resolve(name);
      return await import(pathToFileURL(resolved).href);
    } catch {
      /* try the next resolution root */
    }
  }
  return null;
};

const loadJsZip = async () => (await loadFromProject("jszip"))?.default ?? null;

// --- SDK drift ----------------------------------------------------------------
//
// The tables in contract.mjs describe what a shipped portal runs, which is not
// the same thing as what the installed SDK exports. When they part company it is
// this tool that has aged, not the plugin - so these are warnings, and they are
// the signal that references/sdk-target.md needs revisiting.

const sdk = await loadFromProject(SDK_PACKAGE);
const sdkActions = sdk ? Object.values(sdk.Actions ?? {}) : [];

if (sdk) {
  const installed = (() => {
    try {
      return readJson(
        createRequire(pkgPath).resolve(`${SDK_PACKAGE}/package.json`),
      ).version;
    } catch {
      return pkg.dependencies?.[SDK_PACKAGE];
    }
  })();

  for (const { code, message } of checkSdkDrift(sdk, installed)) warn(code, message);
} else if (fs.existsSync(path.join(dir, "node_modules"))) {
  warn(
    "sdk-drift",
    `${SDK_PACKAGE} is not resolvable from the project - the contract tables could not be checked against the SDK it builds with`,
  );
}

if (fs.existsSync(zipPath)) {
  const zipSize = fs.statSync(zipPath).size;
  if (zipSize > MAX_FILE_BYTES)
    error("zip", `dist/plugin.zip is ${(zipSize / 1e6).toFixed(1)} MB, limit is 5 MB`);

  const JSZip = await loadJsZip();

  if (!JSZip) {
    warn("zip", "jszip not resolvable from the project - archive contents not inspected");
  } else {
    const zip = await JSZip.loadAsync(fs.readFileSync(zipPath));
    const names = Object.keys(zip.files).filter((n) => !zip.files[n].dir);

    if (!names.includes("plugin.js")) error("zip", "plugin.js is missing from the archive");
    if (!names.includes("config.json")) error("zip", "config.json is missing from the archive");

    const zipAssets = names.filter((n) => n.startsWith("assets/"));
    if (zipAssets.length > MAX_ASSETS)
      error("zip", `${zipAssets.length} assets in the archive, limit is ${MAX_ASSETS}`);

    if (names.includes("config.json")) {
      const config = JSON.parse(await zip.file("config.json").async("string"));

      const expect = (field, actual, wanted) => {
        if (actual !== wanted)
          error(
            "config",
            `config.json ${field} is "${actual}", expected "${wanted}" - rebuild after editing package.json`,
          );
      };

      expect("name", config.name, String(pkg.name ?? "").toLowerCase());
      expect("pluginName", config.pluginName, pkg.pluginName ?? "");
      expect("version", config.version, pkg.version ?? "");
      expect("scopes", config.scopes, scopes.join(","));
      expect("image", config.image, pkg.logo ?? "");

      if (!config.minDocSpaceVersion)
        error("config", "config.json has no minDocSpaceVersion - the SDK package could not be read");
      else info("config", `minDocSpaceVersion from the SDK: ${config.minDocSpaceVersion}`);
    }
  }
} else if (isBuilt) {
  warn("zip", "dist/plugin.zip is missing - webpack ran but the packer did not");
}

// --- runtime smoke test -------------------------------------------------------

const runtimeReport = { loaded: false, items: {} };

const makeSandbox = () => {
  const noop = () => {};
  const element = () => ({
    style: {},
    dataset: {},
    setAttribute: noop,
    appendChild: noop,
    addEventListener: noop,
    remove: noop,
  });

  const sandbox = {
    console: { log: noop, warn: noop, error: noop, info: noop, debug: noop },
    setTimeout,
    clearTimeout,
    setInterval: () => 0,
    clearInterval: noop,
    queueMicrotask,
    Promise,
    URL,
    URLSearchParams,
    TextEncoder,
    TextDecoder,
    fetch: async () => {
      throw new Error("network access is not available in the validator sandbox");
    },
    navigator: { userAgent: "docspace-plugin-validator", language: "en-US" },
    location: { href: "https://localhost/", origin: "https://localhost", pathname: "/" },
    localStorage: { getItem: () => null, setItem: noop, removeItem: noop },
    document: {
      createElement: element,
      createElementNS: element,
      head: element(),
      body: element(),
      getElementById: () => null,
      querySelector: () => null,
      addEventListener: noop,
      cookie: "",
    },
    addEventListener: noop,
    Plugins: {},
  };

  sandbox.window = sandbox;
  sandbox.self = sandbox;
  sandbox.globalThis = sandbox;
  sandbox.top = sandbox;
  sandbox.parent = sandbox;

  return sandbox;
};

const withTimeout = (promise, ms, label) =>
  Promise.race([
    Promise.resolve(promise),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`${label} did not settle in ${ms} ms`)), ms).unref?.(),
    ),
  ]);

/**
 * Walks a declarative UI tree and checks that every node can actually render.
 * `node` is either an IBox (children at the top level) or a {component, props}
 * pair; both forms nest through `children`.
 */
const checkComponentTree = (where, node, depth = 0) => {
  if (!node || typeof node !== "object" || depth > 20) return;

  if (Array.isArray(node)) {
    for (const child of node) checkComponentTree(where, child, depth + 1);
    return;
  }

  // A bare IBox carries its children directly; only a component node has props.
  if (node.component === undefined) {
    checkBoxProps(where, node);
    checkComponentTree(where, node.children, depth + 1);
    return;
  }

  const required = COMPONENT_PROPS[node.component];

  if (required === undefined) {
    error(
      "component",
      `${where} uses component "${node.component}", which the host cannot render (known: ${Object.keys(COMPONENT_PROPS).join(", ")})`,
    );
    return;
  }

  for (const prop of required)
    if (node.props?.[prop] === undefined)
      error(
        "component",
        `${where} has a ${node.component} without ${prop} - nothing wraps the plugin tree in an error boundary, so this throws during render and replaces the whole portal with an error screen`,
      );

  checkComponentVisuals(where, node);

  checkComponentTree(where, node.props?.children, depth + 1);
};

/**
 * Values that compile against the SDK and then render wrong on the portal.
 * These do not crash (mostly), which is what makes them worth warning about:
 * the plugin ships and the control is collapsed, blank or mismatched.
 */
const checkComponentVisuals = (where, node) => {
  const props = node.props ?? {};

  if (
    node.component === "button" &&
    typeof props.size === "string" &&
    !RENDERED_BUTTON_SIZES.includes(props.size)
  )
    warn(
      "component",
      `${where} button size "${props.size}" has no styles on the portal, so the button renders collapsed - sizes that render: ${RENDERED_BUTTON_SIZES.join(", ")} (ButtonSize.extraSmall is the usual culprit: the SDK emits "extra-small", the host only knows "extraSmall")`,
    );

  if (
    node.component === "input" &&
    typeof props.size === "string" &&
    !RENDERED_INPUT_SIZES.includes(props.size)
  )
    warn(
      "component",
      `${where} input size "${props.size}" has no styles on the portal, so the field renders collapsed - sizes that render: ${RENDERED_INPUT_SIZES.join(", ")} (InputSize.big and InputSize.huge compile and are dead)`,
    );

  if (node.component === "comboBox") {
    const { options, selectedOption } = props;

    if (options !== undefined && !Array.isArray(options))
      error(
        "component",
        `${where} comboBox options must be an array (even when empty) - the host reads options.length during render, and anything else throws and takes the portal down`,
      );

    if (Array.isArray(options)) {
      options.forEach((option, index) => {
        if (!option || typeof option !== "object" || option.key === undefined)
          error(
            "component",
            `${where} comboBox option ${index} has no key - the host derives ids from it during render and throws without one`,
          );
        else if (option.label === undefined)
          warn(
            "component",
            `${where} comboBox option "${String(option.key)}" has no label - the row renders empty`,
          );
      });

      const labels = options.map((o) => o?.label).filter((l) => l !== undefined);
      if (new Set(labels).size !== labels.length)
        warn(
          "component",
          `${where} comboBox has duplicate option labels - the portal matches the selected option by label, so duplicates grey out and block each other`,
        );
    }

    if (
      selectedOption &&
      typeof selectedOption === "object" &&
      (selectedOption.key === undefined || selectedOption.label === undefined)
    )
      warn(
        "component",
        `${where} comboBox selectedOption is missing key or label - the closed control renders blank`,
      );
  }

  if (node.component === "box") checkBoxProps(where, props);
};

/** Box props appear both on {component:"box"}.props and directly on bare IBox roots. */
const checkBoxProps = (where, boxProps) => {
  if (typeof boxProps?.borderProp === "string")
    warn(
      "component",
      `${where} box borderProp is a CSS string, which the host silently ignores - use the object form { width, style, color, radius }`,
    );
};

/** IModalDialog has two mandatory callbacks that are easy to leave out. */
const checkModal = (where, modal) => {
  if (!modal || typeof modal !== "object") return;

  if (typeof modal.onLoad !== "function")
    error(
      "message",
      `${where} opens a modal whose onLoad is not a function - IModalDialog.onLoad is required even when there is nothing async to do; return the body you already built`,
    );

  if (typeof modal.onClose !== "function")
    error("message", `${where} opens a modal without onClose - the close button does nothing`);

  if (modal.dialogBody === undefined)
    error("message", `${where} opens a modal without dialogBody`);

  checkComponentTree(`${where} modal body`, modal.dialogBody);
  checkComponentTree(`${where} modal footer`, modal.dialogFooter);
};

const checkFilterValues = (where, field, value) => {
  if (value === undefined) return;

  if (!Array.isArray(value)) {
    error("item", `${where} ${field} must be an array`);
    return;
  }

  const allowed = field === "devices" ? DEVICES : USERS_TYPES;

  for (const entry of value)
    if (!allowed.includes(entry))
      error(
        "item",
        `${where} ${field} contains "${entry}", which is not a valid value (${allowed.join(", ")}) - the host compares these exactly, so the item is filtered out for everyone`,
      );
};

const checkItem = (scope, contract, key, item) => {
  const where = `${scope} item "${key}"`;

  for (const field of contract.required)
    if (item[field] === undefined) error("item", `${where} has no ${field}`);

  const wrongFilter = contract.filter === "usersTypes" ? "usersType" : "usersTypes";
  if (item[wrongFilter] !== undefined)
    error(
      "item",
      `${where} uses ${wrongFilter} but the host reads ${contract.filter} for ${scope} - the filter is silently ignored`,
    );

  checkFilterValues(where, contract.filter, item[contract.filter]);
  checkFilterValues(where, "devices", item.devices);

  // The tab body and the article button body are rendered as-is at load time.
  checkComponentTree(`${where} body`, item.body);

  if (typeof item.icon === "string" && !assetNames.includes(item.icon))
    error("item", `${where} icon "${item.icon}" is not in assets/`);

  if (scope === "EventListener" && !EVENT_TYPES.includes(item.eventType))
    error("item", `${where} eventType "${item.eventType}" is not a known Events value`);

  if (scope === "ContextMenu" && !item.onItemClick && !item.onClick && !item.items)
    error("item", `${where} has neither onItemClick/onClick nor nested items`);

  if (scope === "ContextMenu" && item.items?.some((child) => child.items?.length))
    warn("item", `${where} nests deeper than 2 levels - the host caps nesting at maxDepth 2`);

  if (pkg.name && typeof key === "string" && !key.toLowerCase().includes(pkg.name.toLowerCase()))
    warn(
      "item",
      `${where} key is not namespaced with the plugin name - item keys share one host-wide map per scope`,
    );
};

const validateMessage = (where, message) => {
  if (message === undefined || message === null) return;

  if (!Array.isArray(message.actions)) {
    warn("message", `${where} returned a message without an actions array`);
    return;
  }

  // Prefer the SDK the project installed: it is the authority on which action
  // strings exist, and it may know ones this tool does not.
  const validActions = sdkActions.length ? sdkActions : KNOWN_ACTIONS;

  for (const action of message.actions) {
    if (!validActions.includes(action)) {
      error(
        "message",
        `${where} returns action "${action}", which is not an Actions value${
          validActions.includes(`${action}`.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`))
            ? ` - that looks like the enum key; the value is "${`${action}`.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)}"`
            : ""
        }. The host matches on the string, so it does nothing`,
      );
      continue;
    }

    const field = ACTION_PAYLOAD[action];
    if (field && message[field] === undefined)
      error(
        "message",
        `${where} returns action "${action}" without ${field} - the host silently skips it`,
      );
  }

  if (message.modalDialogProps !== undefined) checkModal(where, message.modalDialogProps);
};

/**
 * A file as the host passes it to IFileItem.onClick. Handing every callback a
 * bare id instead would make a correct File plugin look like it throws.
 */
const FILE_STUB = {
  id: 1,
  title: "example.txt",
  fileExst: ".txt",
  folderId: 2,
  rootFolderId: 2,
  rootFolderType: 0,
  viewUrl: "https://localhost/view/1",
  webUrl: "https://localhost/doceditor/1",
  security: {},
  fileSecurity: {},
};

const GROUP_STUB = [{ id: 1, itemType: "file" }];

const isFn = (value) => typeof value === "function";

/**
 * Which callbacks a scope's item exposes, and what the host calls each of them
 * with. `kind` says how to read the result: an IMessage, or the {body} that the
 * async loaders resolve to.
 */
const invocations = (scope, item) => {
  const calls = [];
  const message = (name, run) => calls.push({ name, run, kind: "message" });
  const body = (name, run) => calls.push({ name, run, kind: "body" });

  if (scope === "File") {
    if (isFn(item.onClick)) message("onClick", () => item.onClick(FILE_STUB));
    return calls;
  }

  if (scope === "ProfileMenu") {
    if (isFn(item.onClick)) message("onClick", () => item.onClick());
    return calls;
  }

  if (scope === "EventListener") {
    if (isFn(item.eventHandler)) message("eventHandler", () => item.eventHandler());
    return calls;
  }

  if (scope === "InfoPanel") {
    if (isFn(item.subMenu?.onClick))
      message("subMenu.onClick", () => item.subMenu.onClick(1));
    if (isFn(item.onLoad)) body("onLoad", () => item.onLoad());
    return calls;
  }

  if (scope === "ArticleButton") {
    if (isFn(item.onLoad)) body("onLoad", () => item.onLoad());
    return calls;
  }

  // ContextMenu and MainButton: onItemClick supersedes onClick, and a group
  // action is a separate entry point the host calls with the selection.
  if (isFn(item.onItemClick)) message("onItemClick", () => item.onItemClick(1));
  else if (isFn(item.onClick)) message("onClick", () => item.onClick(1));

  if (isFn(item.onGroupClick)) message("onGroupClick", () => item.onGroupClick(GROUP_STUB));

  return calls;
};

/**
 * A global the sandbox does not stub is our gap, not the plugin's - the portal
 * has the real thing. Anything else that throws would throw on the portal too,
 * so it must not be softened into a warning.
 */
const isMissingHostApi = (e) =>
  e?.name === "ReferenceError" && /is not defined/.test(e?.message ?? "");

if (isBuilt && !flags.has("--no-runtime")) {
  const sandbox = makeSandbox();
  let loaded = false;

  try {
    vm.createContext(sandbox);
    new vm.Script(fs.readFileSync(bundlePath, "utf8"), { filename: "plugin.js" }).runInContext(
      sandbox,
      { timeout: ONLOAD_TIMEOUT_MS },
    );
    loaded = true;
  } catch (e) {
    if (isMissingHostApi(e))
      warn(
        "runtime",
        `the bundle needs a browser API the validator does not stub (${e.message}) - the runtime checks were skipped, so verify this one on a portal`,
      );
    else
      error(
        "runtime",
        `the bundle threw while loading: ${e.message}. Top-level code runs as soon as the portal injects the script, so nothing after that point is ever registered`,
      );
  }

  const plugin = loaded ? sandbox.Plugins?.[pkg.pluginName] : null;

  if (loaded && !plugin) {
    const registered = Object.keys(sandbox.Plugins ?? {});
    error(
      "runtime",
      `the bundle did not register window.Plugins.${pkg.pluginName}${
        registered.length ? ` (it registered: ${registered.join(", ")})` : ""
      }`,
    );
  }

  if (plugin) {
    runtimeReport.loaded = true;

    for (const member of [
      "status",
      "getStatus",
      "updateStatus",
      "onLoadCallback",
      "setOnLoadCallback",
    ])
      if (plugin[member] === undefined)
        error("runtime", `IPlugin member ${member} is missing on the registered plugin`);

    let onLoadFailed = false;

    try {
      await withTimeout(plugin.onLoadCallback?.(), ONLOAD_TIMEOUT_MS, "onLoadCallback");
    } catch (e) {
      onLoadFailed = true;

      if (isMissingHostApi(e))
        warn(
          "runtime",
          `onLoadCallback needs a browser API the validator does not stub (${e.message}) - verify this one on a portal`,
        );
      else
        error(
          "runtime",
          `onLoadCallback threw: ${e.message}. The portal awaits it during installation, so a throw there aborts the plugin with no CSS, no items and nothing in the console`,
        );
    }

    const status = plugin.getStatus?.();
    if (status === "hide")
      warn(
        "runtime",
        "getStatus() is hide after onLoadCallback - the host stops here and renders nothing. Intentional only if the plugin hides itself until it is configured",
      );
    else if (status !== "active")
      error("runtime", `getStatus() returned "${status}", expected "active" or "hide"`);

    for (const scope of scopes) {
      const contract = SCOPE_CONTRACT[scope];
      if (!contract) continue;

      if (contract.members) {
        for (const member of contract.members)
          if (typeof plugin[member] !== "function")
            error("runtime", `scope "${scope}" requires ${member}() on the plugin instance`);
        continue;
      }

      let items;
      try {
        items = plugin[contract.getter]?.();
      } catch (e) {
        error("runtime", `${contract.getter}() threw: ${e.message}`);
        continue;
      }

      if (!(items instanceof Map) && !(items && typeof items.forEach === "function")) {
        error("runtime", `${contract.getter}() did not return a Map`);
        continue;
      }

      const entries = [...items];
      runtimeReport.items[scope] = entries.length;

      // With a failed onLoadCallback an empty map is a consequence, not a
      // separate defect - reporting it again would bury the real cause.
      if (entries.length === 0 && !onLoadFailed) {
        // A map that is empty at load time is only legitimate when the plugin
        // registers items later and tells the host to re-read them.
        const registersSomewhere = new RegExp(`\\b${contract.adder}\\s*\\(`).test(srcText);
        const { refresh } = contract;

        if (registersSomewhere && refresh)
          warn(
            "runtime",
            `${contract.getter}() is empty after onLoadCallback - fine only if the plugin registers items later and then sends Actions.${refresh}`,
          );
        else if (registersSomewhere)
          error(
            "runtime",
            `${contract.getter}() is empty after onLoadCallback and the SDK has no update${scope}Items action to refresh it - an item registered later never reaches the portal`,
          );
        else
          error(
            "runtime",
            `scope "${scope}" is declared but ${contract.adder}() is never called - the scope is dead weight in config.json`,
          );
      }

      for (const [key, item] of entries) {
        checkItem(scope, contract, key, item);

        if (!flags.has("--invoke")) continue;

        for (const call of invocations(scope, item)) {
          const where = `${scope} item "${key}" ${call.name}`;

          try {
            const result = await withTimeout(call.run(), ONLOAD_TIMEOUT_MS, where);

            if (call.kind === "body") checkComponentTree(`${where} body`, result?.body);
            else validateMessage(`${scope} item "${key}"`, result);
          } catch (e) {
            warn("message", `${where} threw: ${e.message}`);
          }
        }
      }
    }
  }
}

// --- report -------------------------------------------------------------------

const errors = findings.filter((f) => f.level === "ERROR");
const warnings = findings.filter((f) => f.level === "WARN");

if (flags.has("--json")) {
  console.log(
    JSON.stringify(
      {
        plugin: { dir, name: pkg.name, pluginName: pkg.pluginName, version: pkg.version, scopes },
        built: isBuilt,
        runtime: runtimeReport,
        findings,
        ok: errors.length === 0,
      },
      null,
      2,
    ),
  );
} else {
  console.log(`${pkg.name} (${pkg.pluginName}) ${pkg.version} - scopes: ${scopes.join(", ") || "none"}`);
  console.log(`${dir}\n`);

  for (const f of findings) console.log(`${f.level.padEnd(5)} [${f.code}] ${f.message}`);

  console.log(
    `\n${errors.length} error(s), ${warnings.length} warning(s)${
      runtimeReport.loaded
        ? ` - runtime: ${
            Object.entries(runtimeReport.items)
              .map(([s, n]) => `${s}:${n}`)
              .join(" ") || "no item scopes"
          }`
        : ""
    }`,
  );
}

process.exit(errors.length > 0 ? 1 : 0);
