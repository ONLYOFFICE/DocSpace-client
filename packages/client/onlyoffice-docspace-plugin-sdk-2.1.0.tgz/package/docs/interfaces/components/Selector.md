# TSelector

```ts
type TSelector = 
  | {
  type: Base;
  props: TBaseSelector;
}
  | {
  type: Files;
  props: TFilesSelector;
}
  | {
  type: Groups;
  props: TGroupsSelector;
}
  | {
  type: People;
  props: TPeopleSelector;
}
  | {
  type: Room;
  props: TRoomSelector;
};
```

Defined in: [interfaces/components/Selector/index.ts:58](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/index.ts#L58)

Provides selector components for choosing files, rooms, users, and groups within DocSpace.

Set `type` to the desired [SelectorType](../../enums/Selector.md) value and `props` to the matching
selector props interface ([TBaseSelector](#tbaseselector), [TFilesSelector](#tfilesselector),
[TGroupsSelector](#tgroupsselector), [TPeopleSelector](#tpeopleselector), or [TRoomSelector](#troomselector)).

To display a selector, return an [`IMessage`](../utils.md#imessage) with
[`Actions.showSelector`](../../enums/Actions.md#showselector) in `actions`
and pass the configuration in `selectorProps`.
Use [`Actions.updateSelector`](../../enums/Actions.md#updateselector) and
[`Actions.closeSelector`](../../enums/Actions.md#closeselector) to update or close it.

![selector](/assets/images/docspace/selector.png#gh-light-mode-only)![selector](/assets/images/docspace/selector.dark.png#gh-dark-mode-only)

## Example

```typescript
import { TSelector, TBaseSelector, SelectorType, Actions, ToastType } from "@onlyoffice/docspace-plugin-sdk";

const selector: TSelector = {
  type: SelectorType.Base,
  props: {
    submitButtonLabel: "Select",
    items: [{ id: "item-1", label: "First Item" }],
    onSubmit: ({ selectedIds }) => ({
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{ type: ToastType.success, title: `Selected ${selectedIds.length} items` }],
    }),
  },
};
```

## TBaseSelector

```ts
type TBaseSelector = TSelectorBreadCrumbs & TSelectorPagination & TSelectorHeader & TSelectorCancelButton & TSelectorSubmitButton & TSelectorCheckbox & TSelectorBaseProps & TSelectorLifecycleEvents & TSelectorEmptyScreen & {
  isLoading?: boolean;
  isMultiSelect?: boolean;
  maxSelectedItems?: number;
  selectedItems?: TSelectorItem[];
  descriptionText?: string;
  searchEmptyScreenHeader?: string;
  searchEmptyScreenDescription?: string;
  onSelect?: (params: {
     selectedId?: string | number;
     isDoubleClick: boolean;
  }) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L98)

Defines the base properties for all selector components.

### Type Declaration

#### isLoading?

```ts
optional isLoading: boolean;
```

If true, shows a loading indicator for the entire selector.

#### isMultiSelect?

```ts
optional isMultiSelect: boolean;
```

If true, allows multiple items to be selected.

#### maxSelectedItems?

```ts
optional maxSelectedItems: number;
```

The maximum number of items that can be selected.

#### selectedItems?

```ts
optional selectedItems: TSelectorItem[];
```

An array of initially selected items.

#### descriptionText?

```ts
optional descriptionText: string;
```

A descriptive text displayed within the selector.

#### searchEmptyScreenHeader?

```ts
optional searchEmptyScreenHeader: string;
```

The header text to display when a search yields no results.

#### searchEmptyScreenDescription?

```ts
optional searchEmptyScreenDescription: string;
```

The description text to display when a search yields no results.

#### onSelect()?

```ts
optional onSelect: (params: {
  selectedId?: string | number;
  isDoubleClick: boolean;
}) => TReturnMessage;
```

A callback function that is triggered when an item is selected.

##### Parameters

###### params

###### selectedId?

`string` \| `number`

The ID of the selected item.

###### isDoubleClick

`boolean`

If true, the item was selected with a double-click.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

### See

 - [TSelectorBreadCrumbs](#tselectorbreadcrumbs) - Breadcrumb navigation properties
 - [TSelectorPagination](#tselectorpagination) - Pagination and item loading properties
 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorCancelButton](#tselectorcancelbutton) - Cancel button properties
 - [TSelectorSubmitButton](#tselectorsubmitbutton) - Submit button properties
 - [TSelectorCheckbox](#tselectorcheckbox) - Footer checkbox properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)
 - [TSelectorEmptyScreen](#tselectoremptyscreen) - Empty state messages

### Example

```typescript
// This example demonstrates how to create a basic selector with a list of items,
// a header, and a submit button. It also includes an item that, when clicked,
// dynamically adds a new input item to the list.

const selectorProps: TBaseSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Plugin Base Selector",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Submit",

  // An array of items to display in the selector.
  items: [
    {
      id: "create-new",
      label: "Create new item",
      isCreateNewItem: true, // Renders this item as a button for creating new entries.
      onCreateClick: () => {
        // When clicked, this function returns a message to the host application
        // with an `updateSelector` action. This action provides new props to
        // re-render the selector, in this case, adding a new item to the list.
        const updatedItems = [...selectorProps.items, { id: "new-item", label: "Newly Added Item" }];

        return {
          actions: [Actions.updateSelector], // Specifies the action to perform.
          selectorProps: { // Provides the new properties for the selector.
             type: SelectorType.Base,
             props: { ...selectorProps, items: updatedItems }
          }
        };

      },
    },
    {
      id: "item-1",
      label: "First Item",
      icon: "your-icon-url.svg", // Specify an icon for the item.
    },
  ],

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: ({ selectedIds }) => {
    // The `selectedIds` parameter contains an array of the IDs of the selected items.
    console.log("Items submitted:", selectedIds);

    // After submission, you can perform actions like closing the selector
    // and showing a success message.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `Selected ${selectedIds.length} items`,
      }],
    };
  },
};
```

***

## TSelectorItem

```ts
type TSelectorItem = {
  label: string;
  id?: string | number;
} & Partial<TSelectorItemFile> & Partial<TSelectorItemInput> & Partial<TSelectorItemNew>;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:149](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L149)

Represents a single item within a selector component.

### Type Declaration

#### label

```ts
label: string;
```

The display text for the item.

#### id?

```ts
optional id: string | number;
```

A unique identifier for the item.

### See

 - [TSelectorItemFile](#tselectoritemfile) - File item properties
 - [TSelectorItemInput](#tselectoriteminput) - Input item properties
 - [TSelectorItemNew](#tselectoritemnew) - New item properties

***

## TSelectorItemFile

```ts
type TSelectorItemFile = {
  icon: string;
  fileExst: FilesExst | string;
  fileType: FilesType;
  security: FilesSecurity;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:165](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L165)

Defines properties for an item that represents a file.

### Properties

#### icon

```ts
icon: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:169](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L169)

The URL or identifier for the item's icon.

#### fileExst

```ts
fileExst: FilesExst | string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:173](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L173)

The file extension (e.g., 'docx', 'pdf').

#### fileType

```ts
fileType: FilesType;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:177](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L177)

The general type of the file (e.g., 'text', 'spreadsheet').

#### security

```ts
security: FilesSecurity;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:181](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L181)

The security or access level of the file.

***

## TSelectorItemInput

```ts
type TSelectorItemInput = {
  isInputItem: boolean;
  defaultInputValue: string;
  onAcceptInput: (value: string) => TReturnMessage;
  onCancelInput: () => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L187)

Defines properties for an item that functions as an input field.

### Properties

#### isInputItem

```ts
isInputItem: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:191](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L191)

If true, this item will be rendered as an input field.

#### defaultInputValue

```ts
defaultInputValue: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L195)

The default value to display in the input field.

#### onAcceptInput()

```ts
onAcceptInput: (value: string) => TReturnMessage;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L199)

A callback function that is triggered when the user accepts the input value.

##### Parameters

###### value

`string`

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

#### onCancelInput()

```ts
onCancelInput: () => TReturnMessage;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:203](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L203)

A callback function that is triggered when the user cancels the input.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

***

## TSelectorItemNew

```ts
type TSelectorItemNew = {
  isCreateNewItem: boolean;
  onCreateClick: () => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:209](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L209)

Defines properties for an item that allows creating a new entity.

### Properties

#### isCreateNewItem

```ts
isCreateNewItem: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:213](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L213)

If true, this item will be rendered as a 'create new' button.

#### onCreateClick()

```ts
onCreateClick: () => TReturnMessage;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:217](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L217)

A callback function that is triggered when the user clicks the 'create new' button.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

***

## TBreadCrumbItem

```ts
type TBreadCrumbItem = {
  label: string;
  id: string | number;
  isRoom?: boolean;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:223](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L223)

Represents a single item in a breadcrumb trail.

### Properties

#### label

```ts
label: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L227)

The display text for the breadcrumb item.

#### id

```ts
id: string | number;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:231](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L231)

A unique identifier for the breadcrumb item.

#### isRoom?

```ts
optional isRoom: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:235](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L235)

If true, indicates that the breadcrumb item represents a room.

***

## TSelectorBreadCrumbs

```ts
type TSelectorBreadCrumbs = {
  withBreadCrumbs?: boolean;
  isBreadCrumbsLoading?: boolean;
  breadCrumbs?: TBreadCrumbItem[];
  onSelectBreadCrumb?: (id: string | number) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:252](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L252)

Defines properties for configuring breadcrumbs in a selector.

### Properties

#### withBreadCrumbs?

```ts
optional withBreadCrumbs: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:256](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L256)

If true, displays the breadcrumb navigation.

#### isBreadCrumbsLoading?

```ts
optional isBreadCrumbsLoading: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:260](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L260)

If true, shows a loading indicator for the breadcrumbs.

#### breadCrumbs?

```ts
optional breadCrumbs: TBreadCrumbItem[];
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:264](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L264)

An array of breadcrumb items to display.

#### onSelectBreadCrumb()?

```ts
optional onSelectBreadCrumb: (id: string | number) => TReturnMessage;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:268](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L268)

A callback function that is triggered when a breadcrumb item is selected.

##### Parameters

###### id

`string` | `number`

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

***

## TSelectorPagination

```ts
type TSelectorPagination = {
  items: TSelectorItem[];
  hasNextPage?: boolean;
  isNextPageLoading?: boolean;
  onLoadNextPage?: () => TReturnMessage;
  totalItems?: number;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:274](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L274)

Defines properties for pagination within a selector.

### Properties

#### items

```ts
items: TSelectorItem[];
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:278](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L278)

The list of items to display on the current page.

#### hasNextPage?

```ts
optional hasNextPage: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:282](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L282)

If true, indicates that more items are available on subsequent pages.

#### isNextPageLoading?

```ts
optional isNextPageLoading: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:286](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L286)

If true, shows a loading indicator while the next page is being loaded.

#### onLoadNextPage()?

```ts
optional onLoadNextPage: () => TReturnMessage;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:290](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L290)

A callback function that is triggered to load the next page of items.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

#### totalItems?

```ts
optional totalItems: number;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:294](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L294)

The total number of items available.

***

## TSelectorHeader

```ts
type TSelectorHeader = {
  withHeader?: boolean;
  headerProps?: {
     label: string;
     isCloseable?: boolean;
     onCloseClick?: () => TReturnMessage;
     withBackButton?: boolean;
     onBackClick?: () => TReturnMessage;
  };
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:300](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L300)

Defines properties for the selector's header.

### Properties

#### withHeader?

```ts
optional withHeader: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:304](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L304)

If true, displays the header.

#### headerProps?

```ts
optional headerProps: {
  label: string;
  isCloseable?: boolean;
  onCloseClick?: () => TReturnMessage;
  withBackButton?: boolean;
  onBackClick?: () => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:308](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L308)

An object containing properties for the header.

##### label

```ts
label: string;
```

The title text to display in the header.

##### isCloseable?

```ts
optional isCloseable: boolean;
```

If true, displays a close button in the header.

##### onCloseClick()?

```ts
optional onCloseClick: () => TReturnMessage;
```

A callback function that is triggered when the close button is clicked.

###### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

##### withBackButton?

```ts
optional withBackButton: boolean;
```

If true, displays a back button in the header.

##### onBackClick()?

```ts
optional onBackClick: () => TReturnMessage;
```

A callback function that is triggered when the back button is clicked.

###### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

***

## TSelectorCheckbox

```ts
type TSelectorCheckbox = {
  withCheckbox?: boolean;
  footerCheckboxLabel?: string;
  isChecked?: boolean;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:335](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L335)

Defines properties for a checkbox in the selector's footer.

### Properties

#### withCheckbox?

```ts
optional withCheckbox: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:339](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L339)

If true, displays a checkbox in the footer.

#### footerCheckboxLabel?

```ts
optional footerCheckboxLabel: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:343](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L343)

The label for the footer checkbox.

#### isChecked?

```ts
optional isChecked: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:347](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L347)

The initial checked state of the footer checkbox.

***

## TSelectorCancelButton

```ts
type TSelectorCancelButton = {
  withCancelButton?: boolean;
  cancelButtonLabel?: string;
  onCancel?: () => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:353](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L353)

Defines properties for the cancel button in the selector.

### Properties

#### withCancelButton?

```ts
optional withCancelButton: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:357](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L357)

If true, displays the cancel button.

#### cancelButtonLabel?

```ts
optional cancelButtonLabel: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:361](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L361)

The text label for the cancel button.

#### onCancel()?

```ts
optional onCancel: () => TReturnMessage;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:365](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L365)

A callback function that is triggered when the cancel button is clicked.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

***

## TSelectorBaseProps

```ts
type TSelectorBaseProps = {
  id?: string;
  className?: string;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:371](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L371)

Common base properties shared across all selector types.

### Properties

#### id?

```ts
optional id: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:375](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L375)

A unique identifier for the selector component.

#### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:379](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L379)

A CSS class name to apply to the selector component.

***

## TSelectorLifecycleEvents

```ts
type TSelectorLifecycleEvents = {
  onLoad?: () => TReturnMessage;
  onClose?: () => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:385](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L385)

Lifecycle callback properties for selectors.

### Properties

#### onLoad()?

```ts
optional onLoad: () => TReturnMessage;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:389](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L389)

A callback function that is triggered when the selector is loaded.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

#### onClose()?

```ts
optional onClose: () => TReturnMessage;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:393](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L393)

A callback function that is triggered when the selector is closed.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

***

## TSelectorEmptyScreen

```ts
type TSelectorEmptyScreen = {
  emptyScreenHeader?: string;
  emptyScreenDescription?: string;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:399](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L399)

Empty screen message properties for selectors.

### Properties

#### emptyScreenHeader?

```ts
optional emptyScreenHeader: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:403](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L403)

The header text to display when there are no items to show.

#### emptyScreenDescription?

```ts
optional emptyScreenDescription: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:407](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L407)

The description text to display when there are no items to show.

***

## TSelectorSearchCreate

```ts
type TSelectorSearchCreate = {
  withSearch?: boolean;
  withCreate?: boolean;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:413](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L413)

Search and create functionality properties for selectors.

### Properties

#### withSearch?

```ts
optional withSearch: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:417](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L417)

If true, displays a search input field.

#### withCreate?

```ts
optional withCreate: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:421](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L421)

If true, allows users to create new items.

***

## TSelectorSubmitButton

```ts
type TSelectorSubmitButton = {
  submitButtonLabel: string;
  disabledSubmitButton?: boolean;
  onSubmit: (params: {
     selectedIds: (string | number)[];
     fileName: string;
     isFooterCheckboxChecked: boolean;
  }) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:440](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L440)

Defines properties for the submit button in the selector.

### Properties

#### submitButtonLabel

```ts
submitButtonLabel: string;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:444](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L444)

The text label for the submit button.

#### disabledSubmitButton?

```ts
optional disabledSubmitButton: boolean;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:448](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L448)

If true, the submit button will be disabled.

#### onSubmit()

```ts
onSubmit: (params: {
  selectedIds: (string | number)[];
  fileName: string;
  isFooterCheckboxChecked: boolean;
}) => TReturnMessage;
```

Defined in: [interfaces/components/Selector/IBaseSelector.ts:452](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L452)

A callback function that is triggered when the submit button is clicked.

##### Parameters

###### params

###### selectedIds

(`string` \| `number`)[]

An array of IDs of the selected items.

###### fileName

`string`

The name of the file, if applicable.

###### isFooterCheckboxChecked

`boolean`

The checked state of the footer checkbox.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

***

## TFilesSelector

```ts
type TFilesSelector = TSelectorHeader & TSelectorBaseProps & TSelectorLifecycleEvents & TSelectorSearchCreate & TSelectorCancelButton & Pick<TSelectorSubmitButton, "submitButtonLabel"> & {
  isMultiSelect?: boolean;
  withBreadCrumbs?: boolean;
  currentFolderId?: string | number;
  isRoomsOnly?: boolean;
  openRoot?: boolean;
  descriptionText?: string;
  withFooterInput?: boolean;
  footerInputHeader?: string;
  currentFooterInputValue?: string;
  withFooterCheckbox?: boolean;
  footerCheckboxLabel?: string;
  filterParam?: FilterType;
  getIsDisabled: (params: {
     selectedItemId: string | number | undefined;
     selectedItemType?: "rooms" | "files";
     selectedItemSecurity?:   | FilesSecurity
        | Security;
     selectedFileInfo:   | {
        id: string | number;
        title: string;
        fileExst?: FilesExst | string;
      }
        | null;
     isFirstLoad: boolean;
     isDisabledFolder?: boolean;
     isRoot: boolean;
  }) => boolean;
  onSubmit?: (params: {
     selectedItemId: string | number | undefined;
     folderTitle: string;
     fileName: string;
     isChecked: boolean;
     selectedFileInfo:   | {
        id: string | number;
        title: string;
        fileExst?: FilesExst | string;
      }
        | null;
     breadCrumbs?: TBreadCrumbItem[];
  }) => TReturnMessage;
  onSelect?: (id: string | number | undefined) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IFilesSelector.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L96)

Defines the properties for a file and folder selector component.

### Type Declaration

#### isMultiSelect?

```ts
optional isMultiSelect: boolean;
```

If true, allows multiple items to be selected.

#### withBreadCrumbs?

```ts
optional withBreadCrumbs: boolean;
```

If true, displays breadcrumb navigation.

#### currentFolderId?

```ts
optional currentFolderId: string | number;
```

The ID of the folder to open by default.

#### isRoomsOnly?

```ts
optional isRoomsOnly: boolean;
```

If true, displays only rooms at the root level.

#### openRoot?

```ts
optional openRoot: boolean;
```

If true, opens the root directory by default.

#### descriptionText?

```ts
optional descriptionText: string;
```

A descriptive text displayed within the selector.

#### withFooterInput?

```ts
optional withFooterInput: boolean;
```

If true, displays an input field in the footer.

#### footerInputHeader?

```ts
optional footerInputHeader: string;
```

The header text for the footer input.

#### currentFooterInputValue?

```ts
optional currentFooterInputValue: string;
```

The initial value for the footer input.

#### withFooterCheckbox?

```ts
optional withFooterCheckbox: boolean;
```

If true, displays a checkbox in the footer.

#### footerCheckboxLabel?

```ts
optional footerCheckboxLabel: string;
```

The label for the footer checkbox.

#### filterParam?

```ts
optional filterParam: FilterType;
```

File type filter.

#### getIsDisabled()

```ts
getIsDisabled: (params: {
  selectedItemId: string | number | undefined;
  selectedItemType?: "rooms" | "files";
  selectedItemSecurity?:   | FilesSecurity
     | Security;
  selectedFileInfo:   | {
     id: string | number;
     title: string;
     fileExst?: FilesExst | string;
   }
     | null;
  isFirstLoad: boolean;
  isDisabledFolder?: boolean;
  isRoot: boolean;
}) => boolean;
```

A callback function to determine if the submit button should be disabled.

##### Parameters

###### params

###### selectedItemId

`string` \| `number` \| `undefined`

The ID of the currently selected item.

###### selectedItemType?

`"rooms"` \| `"files"`

The type of the selected item ('rooms' or 'files').

###### selectedItemSecurity?

  [`FilesSecurity`](../../enums/Files.md#filessecurity)
  \| [`Security`](../../enums/Security.md)

The security level of the selected item.

###### selectedFileInfo

  \{
  `id`: `string` \| `number`;
  `title`: `string`;
  `fileExst?`: [`FilesExst`](../../enums/Files.md#filesexst) \| `string`;
\}
  `null`

Detailed information about the selected file.

###### isFirstLoad

`boolean`

If true, this is the initial load of the selector.

###### isDisabledFolder?

`boolean`

If true, the selected item is a folder that should be disabled.

###### isRoot

`boolean`

If true, the selector is currently at the root level.

##### Returns

`boolean`

#### onSubmit()?

```ts
optional onSubmit: (params: {
  selectedItemId: string | number | undefined;
  folderTitle: string;
  fileName: string;
  isChecked: boolean;
  selectedFileInfo:   | {
     id: string | number;
     title: string;
     fileExst?: FilesExst | string;
   }
     | null;
  breadCrumbs?: TBreadCrumbItem[];
}) => TReturnMessage;
```

A callback function that is triggered when the submit button is clicked.

##### Parameters

###### params

###### selectedItemId

`string` \| `number` \| `undefined`

The ID of the selected item (file or folder).

###### folderTitle

`string`

The title of the folder where the submission occurred.

###### fileName

`string`

The name of the file entered in the footer input.

###### isChecked

`boolean`

The checked state of the footer checkbox.

###### selectedFileInfo

  \{
  `id`: `string` \| `number`;
  `title`: `string`;
  `fileExst?`: [`FilesExst`](../../enums/Files.md#filesexst) \| `string`;
\}
  `null`

Detailed information about the selected file, if any.

###### breadCrumbs?

[`TBreadCrumbItem`](#tbreadcrumbitem)[]

The current breadcrumb trail at the time of submission.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

#### onSelect()?

```ts
optional onSelect: (id: string | number | undefined) => TReturnMessage;
```

A callback function that is triggered when an item is selected.

##### Parameters

###### id

`string` | `number` | `undefined`

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

### See

 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)
 - [TSelectorSearchCreate](#tselectorsearchcreate) - Search and create functionality
 - [TSelectorCancelButton](#tselectorcancelbutton) - Cancel button properties
 - [TSelectorSubmitButton](#tselectorsubmitbutton) - Submit button properties (partial)

### Example

```typescript
// This example demonstrates a file selector for choosing a location to save a file.
// It includes a footer input for the filename, breadcrumbs for navigation, and
// custom logic to disable the submit button in the root directory.

const filesSelectorProps: TFilesSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Save File As",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Save",
  // Enables and sets the text for the cancel button.
  withCancelButton: true,
  cancelButtonLabel: "Cancel",

  // Enables breadcrumbs for easy navigation through folders.
  withBreadCrumbs: true,
  // Enables the search functionality.
  withSearch: true,
  // Allows users to create new folders within the selector.
  withCreate: true,

  // Adds an input field in the footer, typically for a filename.
  withFooterInput: true,
  footerInputHeader: "File name",
  currentFooterInputValue: "Untitled Document",

  // A callback function to determine if the submit button should be disabled.
  getIsDisabled: ({ isRoot }) => {
    // In this case, disable the submit button if the user is in the root directory.
    return isRoot;
  },

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (payload) => {
    // The `payload` object contains information about the selected location and filename.
    console.log("File save details:", payload);

    // After submission, close the selector and show a confirmation message.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `File saved as ${payload.fileName}`,
      }],
    };
  },
};
```

***

## TGroupsSelector

```ts
type TGroupsSelector = TSelectorHeader & TSelectorBaseProps & TSelectorLifecycleEvents & {
  onSubmit: (params: {
     selectedIds: (string | number)[];
     fileName?: string;
     isFooterCheckboxChecked?: boolean;
  }) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IGroupsSelector.ts:57](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IGroupsSelector.ts#L57)

Defines the properties for a group selector component.

### Type Declaration

#### onSubmit()

```ts
onSubmit: (params: {
  selectedIds: (string | number)[];
  fileName?: string;
  isFooterCheckboxChecked?: boolean;
}) => TReturnMessage;
```

A callback function that is triggered when the submit button is clicked.

##### Parameters

###### params

###### selectedIds

(`string` \| `number`)[]

An array of IDs of the selected groups.

###### fileName?

`string`

The name of the file, if applicable.

###### isFooterCheckboxChecked?

`boolean`

The checked state of the footer checkbox.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

### See

 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)

### Example

```typescript
// This example shows how to set up a group selector with a custom header and submit logic.

const groupsSelectorProps: TGroupsSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Select Groups",
  },

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (payload) => {
    // The `payload` object contains the `selectedIds` of the chosen groups.
    console.log("Selected groups:", payload.selectedIds);

    // After submission, close the selector and display a toast notification.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: "Groups selected successfully",
      }],
    };
  },
};
```

***

## TPeopleSelector

```ts
type TPeopleSelector = TSelectorHeader & TSelectorCancelButton & TSelectorSubmitButton & TSelectorBaseProps & TSelectorLifecycleEvents & TSelectorEmptyScreen & {
  targetEntityType?: "file" | "folder" | "room";
  withGroups?: boolean;
  isGroupsOnly?: boolean;
  withGuests?: boolean;
  isGuestsOnly?: boolean;
  isMultiSelect?: boolean;
  currentUserId?: string;
  excludeItems?: string[];
  disableInvitedUsers?: string[];
  disableDisabledUsers?: boolean;
  roomId?: string | number;
  alwaysShowFooter?: boolean;
  onlyRoomMembers?: boolean;
};
```

Defined in: [interfaces/components/Selector/IPeopleSelector.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L84)

Defines the properties for a user and group selector component.

### Type Declaration

#### targetEntityType?

```ts
optional targetEntityType: "file" | "folder" | "room";
```

The type of entity for which the user is being selected (e.g., for sharing a file).

##### Example

```ts
"file" | "folder" | "room"
```

#### withGroups?

```ts
optional withGroups: boolean;
```

If true, allows the selection of groups.

##### Default

```ts
false
```

#### isGroupsOnly?

```ts
optional isGroupsOnly: boolean;
```

If true, displays only groups in the selector.

##### Default

```ts
false
```

#### withGuests?

```ts
optional withGuests: boolean;
```

If true, includes guest users in the selector.

##### Default

```ts
false
```

#### isGuestsOnly?

```ts
optional isGuestsOnly: boolean;
```

If true, displays only guest users in the selector.

##### Default

```ts
false
```

#### isMultiSelect?

```ts
optional isMultiSelect: boolean;
```

If true, allows multiple users and/or groups to be selected.

##### Default

```ts
false
```

#### currentUserId?

```ts
optional currentUserId: string;
```

The ID of the current user, to be excluded from the list.

##### Example

```ts
"user-1234"
```

#### excludeItems?

```ts
optional excludeItems: string[];
```

An array of user or group IDs to exclude from the list.

##### Example

```ts
["user-1234", "group-5678"]
```

#### disableInvitedUsers?

```ts
optional disableInvitedUsers: string[];
```

An array of user IDs that are already invited and should be disabled.

##### Example

```ts
["user-1234", "user-5678"]
```

#### disableDisabledUsers?

```ts
optional disableDisabledUsers: boolean;
```

If true, users with a 'disabled' status will not be displayed.

##### Default

```ts
false
```

#### roomId?

```ts
optional roomId: string | number;
```

The ID of the room to which the selector is related.

##### Example

```ts
"room-1234"
```

#### alwaysShowFooter?

```ts
optional alwaysShowFooter: boolean;
```

If true, the footer will always be visible, even if no users are selected.

##### Default

```ts
false
```

#### onlyRoomMembers?

```ts
optional onlyRoomMembers: boolean;
```

If true, displays only the members of the current room.

##### Default

```ts
false
```

### See

 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorCancelButton](#tselectorcancelbutton) - Cancel button properties
 - [TSelectorSubmitButton](#tselectorsubmitbutton) - Submit button properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)
 - [TSelectorEmptyScreen](#tselectoremptyscreen) - Empty state messages

### Example

```typescript
// This example demonstrates how to configure a selector for choosing users and groups.
// It allows multi-selection, includes groups, and provides clear labels and descriptions.

const peopleSelectorProps: TPeopleSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Share Document",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Share",
  // The text for the cancel button.
  cancelButtonLabel: "Cancel",

  // If true, the footer with action buttons is always visible.
  alwaysShowFooter: true,

  // Custom text to display when no users or groups are found.
  emptyScreenHeader: "No users found",
  emptyScreenDescription: "There are no users or groups matching your search.",

  // Allows the selection of multiple users and groups.
  isMultiSelect: true,
  // Includes groups in the selection list.
  withGroups: true,

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (payload) => {
    // The `payload` object contains the `selectedIds` of the chosen users and groups.
    console.log("Selected users and groups:", payload.selectedIds);

    // After submission, close the selector and show a confirmation toast.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: "Document shared successfully",
      }],
    };
  },
};
```

***

## TRoomSelector

```ts
type TRoomSelector = TSelectorHeader & TSelectorCancelButton & TSelectorBaseProps & TSelectorLifecycleEvents & TSelectorEmptyScreen & TSelectorSearchCreate & Pick<TSelectorSubmitButton, "submitButtonLabel"> & {
  isMultiSelect?: boolean;
  roomType?:   | RoomsType
     | RoomsType[];
  searchArea?: RoomSearchArea;
  excludeItems?: (number | string | undefined)[];
  createDefineRoomLabel?: string;
  createDefineRoomType?: RoomsType;
  onSubmit?: (selectedIds: (string | number)[]) => TReturnMessage;
};
```

Defined in: [interfaces/components/Selector/IRoomSelector.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L96)

Defines the properties for a room selector component.

### Type Declaration

#### isMultiSelect?

```ts
optional isMultiSelect: boolean;
```

If true, allows multiple rooms to be selected.

#### roomType?

```ts
optional roomType: 
  | RoomsType
  | RoomsType[];
```

The type of rooms to display (e.g., 'collaboration', 'custom'). Can be a single type or an array of types.

#### searchArea?

```ts
optional searchArea: RoomSearchArea;
```

The area to search for rooms within (e.g., 'myRooms', 'allRooms').

#### excludeItems?

```ts
optional excludeItems: (number | string | undefined)[];
```

An array of room IDs to exclude from the list.

#### createDefineRoomLabel?

```ts
optional createDefineRoomLabel: string;
```

The label for the 'create new room' option.

#### createDefineRoomType?

```ts
optional createDefineRoomType: RoomsType;
```

The default type for newly created rooms.

#### onSubmit()?

```ts
optional onSubmit: (selectedIds: (string | number)[]) => TReturnMessage;
```

A callback function that is triggered when the submit button is clicked.

##### Parameters

###### selectedIds

(`string` \| `number`)[]

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

### See

 - [TSelectorHeader](#tselectorheader) - Header configuration properties
 - [TSelectorCancelButton](#tselectorcancelbutton) - Cancel button properties
 - [TSelectorBaseProps](#tselectorbaseprops) - Common base properties (id, className)
 - [TSelectorLifecycleEvents](#tselectorlifecycleevents) - Lifecycle callbacks (onLoad, onClose)
 - [TSelectorEmptyScreen](#tselectoremptyscreen) - Empty state messages
 - [TSelectorSearchCreate](#tselectorsearchcreate) - Search and create functionality
 - [TSelectorSubmitButton](#tselectorsubmitbutton) - Submit button properties (partial)

### Example

```typescript
// This example demonstrates how to create a room selector that allows users to
// select multiple public or custom rooms. It includes search and create functionalities.

const roomSelectorProps: TRoomSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Select a Room",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Open Rooms",
  // Enables and sets the text for the cancel button.
  withCancelButton: true,
  cancelButtonLabel: "Close",

  // Custom text to display when no rooms are found.
  emptyScreenHeader: "No Rooms Available",
  emptyScreenDescription: "You can create a new room or try a different search.",

  // Allows the selection of multiple rooms.
  isMultiSelect: true,
  // Filters the list to show only public and custom rooms.
  roomType: [RoomsType.PublicRoom, RoomsType.CustomRoom],
  // Sets the search scope to active rooms.
  searchArea: RoomSearchArea.Active,

  // Enables the search bar and the create room button.
  withCreate: true,
  withSearch: true,
  // Label for the create room button.
  createDefineRoomLabel: "Create a new collaboration room",
  // Default type for a newly created room.
  createDefineRoomType: RoomsType.EditingRoom,

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (selectedIds) => {
    // The `selectedIds` parameter is an array of the selected room IDs.
    console.log("Selected rooms:", selectedIds);

    // After submission, close the selector and show a success message.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `${selectedIds.length} rooms selected`,
      }],
    };
  },
};
```

