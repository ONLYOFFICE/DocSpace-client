# send-to-archive (old_skill)

- pluginName: `SendToArchive`  version: `1.0.0`  scopes: `["MainButton"]`
- zip built: yes

## src/index.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  ButtonSize,
  Components,
  IBox,
  IComboBoxItem,
  IMainButtonItem,
  IMainButtonPlugin,
  IMessage,
  IModalDialog,
  InputSize,
  IPlugin,
  ModalDisplayType,
  PluginLocale,
  PluginStatus,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

import { currentLocale, setLocale, t } from "./locales";

// ---------------------------------------------------------------------------
// Dialog state. Module-level draft state, reset every time the dialog opens.
// ---------------------------------------------------------------------------

type ArchiveFormat = "zip" | "tar.gz";

let urlDraft = "";
let formatDraft: ArchiveFormat = "zip";

/**
 * The requested rule, verbatim: the URL is invalid when it is empty or does
 * not start with "https". Everything else is accepted.
 */
const isUrlValid = (value: string): boolean => {
  const trimmed = value.trim();
  return trimmed.length > 0 && trimmed.startsWith("https");
};

// Context names are namespaced with the plugin name: updateContext addresses
// elements by these names, and the maps are shared portal-wide.
const URL_ERROR_CONTEXT = "send-to-archive-url-error";
const URL_INPUT_CONTEXT = "send-to-archive-url-input";

const errorTextProps = (visible: boolean) => ({
  text: visible ? t("dialog.invalidUrl") : "",
  // The portal's own error colour so the message stays red in every theme.
  color: "var(--error-color, var(--input-error-color, #f24724))",
  fontSize: "12px",
  lineHeight: "16px",
});

// ---------------------------------------------------------------------------
// Dialog UI
// ---------------------------------------------------------------------------

const formatOptions: IComboBoxItem[] = [
  { key: "zip", label: "zip" },
  { key: "tar.gz", label: "tar.gz" },
];

const selectedFormatOption = (): IComboBoxItem =>
  formatOptions.find((option) => option.key === formatDraft) ?? formatOptions[0];

/**
 * Live validation: the self-update keeps the field editable and marks it red;
 * the sibling update shows or clears the message under the field the moment
 * the value changes. Both only work because this callback runs inside the
 * rendered modal tree. Named so it can hand itself back through newProps —
 * updateProps replaces the element's props wholesale.
 */
const onUrlChange = (value: string): IMessage => {
  urlDraft = value;
  const nowInvalid = !isUrlValid(value);

  return {
    actions: [Actions.updateProps, Actions.updateContext],
    newProps: { value, hasError: nowInvalid, onChange: onUrlChange },
    contextProps: [{ name: URL_ERROR_CONTEXT, props: errorTextProps(nowInvalid) }],
  };
};

const onFormatSelect = (item: IComboBoxItem): IMessage => {
  formatDraft = item.key as ArchiveFormat;

  return {
    actions: [Actions.updateProps],
    newProps: {
      options: formatOptions,
      selectedOption: item,
      onSelect: onFormatSelect,
      scaled: true,
      dropDownMaxHeight: 200,
    },
  };
};

const dialogBody = (): IBox => {
  const invalid = !isUrlValid(urlDraft);

  return {
    displayProp: "flex",
    flexDirection: "column",
    children: [
      {
        component: Components.text,
        props: { text: t("dialog.urlLabel"), fontSize: "13px", isBold: true },
      },
      {
        component: Components.box,
        props: {
          marginProp: "4px 0 0 0",
          children: [
            {
              component: Components.input,
              contextName: URL_INPUT_CONTEXT,
              props: {
                value: urlDraft,
                placeholder: t("dialog.urlPlaceholder"),
                scale: true,
                size: InputSize.base,
                isAutoFocused: true,
                hasError: invalid,
                onChange: onUrlChange,
              },
            },
          ],
        },
      },
      {
        component: Components.box,
        props: {
          marginProp: "4px 0 0 0",
          children: [
            {
              component: Components.text,
              contextName: URL_ERROR_CONTEXT,
              // The URL is empty when the dialog opens, so the message is
              // visible immediately — the rule asks for exactly that.
              props: errorTextProps(invalid),
            },
          ],
        },
      },
      {
        component: Components.box,
        props: {
          marginProp: "16px 0 0 0",
          children: [
            {
              component: Components.text,
              props: { text: t("dialog.formatLabel"), fontSize: "13px", isBold: true },
            },
          ],
        },
      },
      {
        component: Components.box,
        props: {
          marginProp: "4px 0 0 0",
          children: [
            {
              component: Components.comboBox,
              props: {
                options: formatOptions,
                selectedOption: selectedFormatOption(),
                scaled: true,
                dropDownMaxHeight: 200,
                onSelect: onFormatSelect,
              },
            },
          ],
        },
      },
    ],
  };
};

const dialogFooter = (): IBox => ({
  displayProp: "flex",
  flexDirection: "row",
  children: [
    {
      component: Components.button,
      props: {
        label: t("dialog.send"),
        size: ButtonSize.normal,
        primary: true,
        scale: true,
        onClick: (): IMessage => {
          // Re-check on click: an invalid URL only refreshes the red message
          // under the field — nothing is sent and the dialog stays open.
          if (!isUrlValid(urlDraft)) {
            return {
              actions: [Actions.updateContext],
              contextProps: [{ name: URL_ERROR_CONTEXT, props: errorTextProps(true) }],
            };
          }

          // No delivery endpoint was specified, so a valid submission is
          // acknowledged with a toast. Replace this branch with the real
          // request when the destination is known.
          return {
            actions: [Actions.closeModal, Actions.showToast],
            toastProps: [
              {
                type: ToastType.success,
                title: `${t("toast.sent")}: ${urlDraft.trim()} (${formatDraft})`,
              },
            ],
          };
        },
      },
    },
  ],
});

const archiveDialog = (): IModalDialog => ({
  displayType: ModalDisplayType.modal,
  dialogHeader: t("dialog.header"),
  dialogBody: dialogBody(),
  dialogFooter: dialogFooter(),
  autoMaxHeight: true,
  withFooterBorder: true,
  onClose: (): IMessage => ({ actions: [Actions.closeModal] }),
  // Mandatory on IModalDialog even when there is nothing async to do.
  onLoad: async () => ({ newDialogBody: dialogBody(), newDialogFooter: dialogFooter() }),
});

// ---------------------------------------------------------------------------
// Main button item
// ---------------------------------------------------------------------------

const sendToArchiveMainButtonItem = (): IMainButtonItem => ({
  key: "send-to-archive-main-button",
  label: t("mainButton.label"),
  icon: "icon-16.svg",
  // A menu item cannot update anything itself — it opens the modal, and all
  // updates happen from elements inside the modal's own tree.
  onItemClick: async (): Promise<IMessage> => {
    urlDraft = "";
    formatDraft = "zip";

    return { actions: [Actions.showModal], modalDialogProps: archiveDialog() };
  },
});

class SendToArchive implements IPlugin, IMainButtonPlugin {
  status: PluginStatus = PluginStatus.active;

  mainButtonItems: Map<string, IMainButtonItem> = new Map();

  // Register items here rather than at module scope. Both are read in time, but
  // setLanguage and setAPI only run after the bundle executes - so a factory that
  // translates a label or calls getAPI() at module scope would capture empty values.
  onLoadCallback = async (): Promise<void> => {
    this.addMainButtonItem(sendToArchiveMainButtonItem());
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  // The portal calls this when the interface language changes. Labels were
  // captured when the items were built, so the items have to be rebuilt.
  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
    this.updateMainButtonItem(sendToArchiveMainButtonItem());
  };

  getLanguage = (): PluginLocale => currentLocale();

  addMainButtonItem = (item: IMainButtonItem): void => {
    this.mainButtonItems.set(item.key, item);
  };

  getMainButtonItems = (): Map<string, IMainButtonItem> => this.mainButtonItems;

  updateMainButtonItem = (item: IMainButtonItem): void => {
    this.mainButtonItems.set(item.key, item);
  };
}

const plugin = new SendToArchive();

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.SendToArchive = plugin || {};

export default plugin;
```

## src/locales.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 *
 * Russian is the primary locale — the requested labels are Russian — with an
 * English translation for portals running in other languages.
 */
export type TStrings = {
  "mainButton.label": string;
  "dialog.header": string;
  "dialog.urlLabel": string;
  "dialog.urlPlaceholder": string;
  "dialog.invalidUrl": string;
  "dialog.formatLabel": string;
  "dialog.send": string;
  "toast.sent": string;
};

const ru: TStrings = {
  "mainButton.label": "Отправить в архив",
  "dialog.header": "Отправить в архив",
  "dialog.urlLabel": "URL архива",
  "dialog.urlPlaceholder": "https://example.com/archive.zip",
  "dialog.invalidUrl": "Укажите URL архива, начинающийся с https",
  "dialog.formatLabel": "Формат архива",
  "dialog.send": "Отправить",
  "toast.sent": "Архив отправлен",
};

const en: TStrings = {
  "mainButton.label": "Send to archive",
  "dialog.header": "Send to archive",
  "dialog.urlLabel": "Archive URL",
  "dialog.urlPlaceholder": "https://example.com/archive.zip",
  "dialog.invalidUrl": "Enter an archive URL that starts with https",
  "dialog.formatLabel": "Archive format",
  "dialog.send": "Send",
  "toast.sent": "Archive sent",
};

const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.RU]: ru,
  [PluginLocale.EN_US]: en,
};

let locale: PluginLocale = PluginLocale.RU;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.RU;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings): string => (translations[locale] ?? ru)[key];
```
