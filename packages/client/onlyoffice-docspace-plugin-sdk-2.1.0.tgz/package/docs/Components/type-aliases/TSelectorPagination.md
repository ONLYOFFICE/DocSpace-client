# Type Alias: TSelectorPagination

> **TSelectorPagination** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:350](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L350)

Defines properties for pagination within a selector.

## Behavior

### onLoadNextPage()?

> `optional` **onLoadNextPage**: () => `TReturnMessage`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:374](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L374)

A callback function that is triggered to load the next page of items.

#### Returns

`TReturnMessage`

## Content

### items

> **items**: [`TSelectorItem`](TSelectorItem.md)[]

Defined in: [interfaces/components/Selector/IBaseSelector.ts:356](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L356)

The list of items to display on the current page.

***

### totalItems?

> `optional` **totalItems**: `number`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:380](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L380)

The total number of items available.

## State

### hasNextPage?

> `optional` **hasNextPage**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:362](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L362)

If true, indicates that more items are available on subsequent pages.

***

### isNextPageLoading?

> `optional` **isNextPageLoading**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:368](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L368)

If true, shows a loading indicator while the next page is being loaded.
