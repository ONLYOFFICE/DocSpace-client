# Interface: IButton

Defined in: [interfaces/components/IButton.ts:97](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L97)

## Appearance

### label

> **label**: `string`

Defined in: [interfaces/components/IButton.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L103)

Defines the button text

***

### size

> **size**: [`ButtonSize`](../enumerations/ButtonSize.md)

Defined in: [interfaces/components/IButton.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L111)

Defines the button size. The normal size is equal to 36x40 px on the Desktop and Touchscreen devices.
Can be: "extraSmall", "small", "normal", "medium". The default value is "extraSmall"

***

### primary?

> `optional` **primary**: `boolean`

Defined in: [interfaces/components/IButton.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L125)

Specifies if the button is primary or not. If the button is primary, it is colored blue

***

### scale?

> `optional` **scale**: `boolean`

Defined in: [interfaces/components/IButton.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L132)

Specifies if the button width will be scaled to 100% or not

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/IButton.ts:169](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L169)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Behavior

### onClick()

> **onClick**: () => `void` \| `IMessage` \| `Promise`\<`IMessage`\>

Defined in: [interfaces/components/IButton.ts:118](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L118)

Sets a function which specifies an action initiated upon clicking the button

#### Returns

`void` \| `IMessage` \| `Promise`\<`IMessage`\>

## State Management

### isLoading?

> `optional` **isLoading**: `boolean`

Defined in: [interfaces/components/IButton.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L139)

Specifies if the button will be displayed as a loader icon or not

***

### isDisabled?

> `optional` **isDisabled**: `boolean`

Defined in: [interfaces/components/IButton.ts:146](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L146)

Specifies if the button is disabled or not. The disabled button is blurred

***

### withLoadingAfterClick?

> `optional` **withLoadingAfterClick**: `boolean`

Defined in: [interfaces/components/IButton.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L153)

Specifies whether to set the "isLoading" state to the button after it is clicked until the action is completed

***

### disableWhileRequestRunning?

> `optional` **disableWhileRequestRunning**: `boolean`

Defined in: [interfaces/components/IButton.ts:161](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L161)

Specifies whether to set the "isDisabled" state for the button when the "withLoadingAfterClick" parameter is set to true,
and it is clicked either on the page or in the dialog box
