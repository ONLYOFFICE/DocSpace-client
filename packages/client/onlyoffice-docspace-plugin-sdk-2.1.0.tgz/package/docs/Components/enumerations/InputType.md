# Enumeration: InputType

Defined in: [interfaces/components/IInput.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L70)

The supported input types.

## Enumeration Members

### text

> **text**: `"text"`

Defined in: [interfaces/components/IInput.ts:74](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L74)

Text input type.

***

### password

> **password**: `"password"`

Defined in: [interfaces/components/IInput.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L78)

Password input type.
