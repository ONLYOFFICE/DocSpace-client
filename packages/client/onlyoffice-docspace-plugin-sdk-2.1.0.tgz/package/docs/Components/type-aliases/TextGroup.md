# Type Alias: TextGroup

> **TextGroup** = `object`

Defined in: [interfaces/components/Component.ts:405](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L405)

Defines the text component.

## Example

```typescript
import { IText, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const text: IText = {
  text: "Welcome to DocSpace Plugin",
  fontSize: "18px",
  fontWeight: 500,
  lineHeight: "24px",
  color: "#333333",
  isBold: false,
  textAlign: "left",
  truncate: true,
  title: "Welcome to DocSpace Plugin"
};

const textGroup: Component = {
  component: Components.text,
  props: text,
  contextName: "welcomeText"
};
```

## Properties

### component

> **component**: [`text`](../../enumerations/Components.md#text)

Defined in: [interfaces/components/Component.ts:407](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L407)

Defines the "text" component type

***

### props

> **props**: [`IText`](../interfaces/IText.md)

Defined in: [interfaces/components/Component.ts:409](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L409)

Defines the text component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:411](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L411)

Defines the text component context name that updates the component via React context
