# Type Alias: ToggleButtonGroup

> **ToggleButtonGroup** = `object`

Defined in: [interfaces/components/Component.ts:478](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L478)

Defines the toggle button component.

## Example

```typescript
import { IToggleButton, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const toggleButton: IToggleButton = {
  label: "Auto-sync",
  isChecked: true,
  onChange: () => {},
  style: {
    backgroundColor: "#f8f9f9",
    padding: "8px 12px",
    borderRadius: "4px"
  }
};

const toggleButtonGroup: Component = {
  component: Components.toggleButton,
  props: toggleButton,
  contextName: "syncToggle"
};
```

## Properties

### component

> **component**: [`toggleButton`](../../enumerations/Components.md#togglebutton)

Defined in: [interfaces/components/Component.ts:480](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L480)

Defines the "toggleButton" component type

***

### props

> **props**: [`IToggleButton`](../interfaces/IToggleButton.md)

Defined in: [interfaces/components/Component.ts:482](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L482)

Defines the toggle button component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:484](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L484)

Defines the toggle button component context name that updates the component via React context
