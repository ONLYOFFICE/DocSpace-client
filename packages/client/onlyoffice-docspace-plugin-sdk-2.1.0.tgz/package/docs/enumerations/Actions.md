# Enumeration: Actions

Defined in: [enums/Actions.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L22)

A collection of events that will be processed on the portal side.

## Enumeration Members

### updateProps

> **updateProps**: `"update-props"`

Defined in: [enums/Actions.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L27)

Calls a function to update the state of the item which action was passed.
It does not work if the "newProps" parameter is not passed to the message.

***

### updateContext

> **updateContext**: `"update-context"`

Defined in: [enums/Actions.ts:33](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L33)

Calls a function to update the state of the parent or child items which were passed.
It does not work if the "contextProps" parameter is not passed to the message.

***

### updateStatus

> **updateStatus**: `"update-status"`

Defined in: [enums/Actions.ts:38](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L38)

Calls a function to update the plugin status.

***

### updateContextMenuItems

> **updateContextMenuItems**: `"update-context-menu-items"`

Defined in: [enums/Actions.ts:43](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L43)

Calls a function to update all the context menu items.

***

### updateInfoPanelItems

> **updateInfoPanelItems**: `"update-info-panel-items"`

Defined in: [enums/Actions.ts:48](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L48)

Calls a function to update all the info panel items.

***

### updateMainButtonItems

> **updateMainButtonItems**: `"update-main-button-items"`

Defined in: [enums/Actions.ts:53](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L53)

Calls a function to update all the main button menu items.

***

### updateProfileMenuItems

> **updateProfileMenuItems**: `"update-profile-menu-items"`

Defined in: [enums/Actions.ts:58](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L58)

Calls a function to update all the profile menu items.

***

### updateFileItems

> **updateFileItems**: `"update-file-items"`

Defined in: [enums/Actions.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L63)

Calls a function to update all the file items.

***

### updateEventListenerItems

> **updateEventListenerItems**: `"update-event-listener-items"`

Defined in: [enums/Actions.ts:68](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L68)

Calls a function to update all the event listener items.

***

### showToast

> **showToast**: `"show-toast"`

Defined in: [enums/Actions.ts:74](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L74)

Calls a function to display a toast notification after the user actions.
It does not work if the "toastProps" parameter is not passed to the message.

***

### showCreateDialogModal

> **showCreateDialogModal**: `"show-create-dialog-modal"`

Defined in: [enums/Actions.ts:80](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L80)

Calls a function to open a modal window for creating certain item (file, folder, etc.).
It does not work if the "createDialogProps" parameter is not passed to the message.

***

### updateCreateDialogModal

> **updateCreateDialogModal**: `"update-create-dialog-modal"`

Defined in: [enums/Actions.ts:86](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L86)

Calls a function to update a modal window for creating certain item (file, folder, etc.).
It does not work if the "createDialogProps" parameter is not passed to the message.

***

### showModal

> **showModal**: `"show-modal"`

Defined in: [enums/Actions.ts:92](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L92)

Calls a function to open a modal window.
It does not work if the "modalDialogProps" parameter is not passed to the message.

***

### closeModal

> **closeModal**: `"close-modal"`

Defined in: [enums/Actions.ts:97](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L97)

Calls a function to close a modal window.

***

### sendPostMessage

> **sendPostMessage**: `"send-post-message"`

Defined in: [enums/Actions.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L103)

Calls a function to send a message to a frame.
It does not work if the "postMessage" parameter is not passed to the message or the specified frame is not found.

***

### saveSettings

> **saveSettings**: `"save-settings"`

Defined in: [enums/Actions.ts:110](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L110)

Calls a function to save the data that was transferred in the "settings" parameter
and returns it in the "setAdminPluginSettingsValue" method each time the plugin is requested.
It functions only when the "Save" button is clicked in the "Settings" block.

***

### showSelector

> **showSelector**: `"show-selector"`

Defined in: [enums/Actions.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L116)

Calls a function to display a selector.
It does not work if the "selectorProps" parameter is not passed to the message.

***

### updateSelector

> **updateSelector**: `"update-selector"`

Defined in: [enums/Actions.ts:122](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L122)

Calls a function to update a selector.
It does not work if the "selectorProps" parameter is not passed to the message.

***

### closeSelector

> **closeSelector**: `"close-selector"`

Defined in: [enums/Actions.ts:127](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L127)

Calls a function to close a selector.

***

### addFloatingOperationsButton

> **addFloatingOperationsButton**: `"add-floating-operations-button"`

Defined in: [enums/Actions.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L137)

Calls a function to add operations in floating button.
Multiple plugins can show operations simultaneously - they will be aggregated.
It does not work if the "floatingOperationsButtonProps" parameter is not passed to the message.

**Note:** Each floating operations is identified by its id. Calling this action again
will not replace the previous operations.

***

### updateFloatingOperationsButton

> **updateFloatingOperationsButton**: `"update-floating-operations-button"`

Defined in: [enums/Actions.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L143)

Calls a function to update operations in floating button.
It does not work if the "floatingOperationsButtonProps" parameter is not passed to the message.

***

### removeFloatingOperationsButton

> **removeFloatingOperationsButton**: `"remove-floating-operations-button"`

Defined in: [enums/Actions.ts:149](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Actions.ts#L149)

Calls a function to remove the floating operations.
It does not work if the "floatingOperationsButtonPropsId" parameter is not passed to the message.
