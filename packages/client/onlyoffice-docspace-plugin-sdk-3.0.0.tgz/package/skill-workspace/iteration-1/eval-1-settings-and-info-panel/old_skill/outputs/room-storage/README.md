# room-storage

Shows how much space a room occupies and who owns it in an Info Panel tab. Admins can set a size threshold in GB above which the size is highlighted in red.

## Usage

Select a room (or open one) and open the Info Panel — the plugin adds a
**Storage** tab (Хранилище in Russian) showing the room's size and owner.

The threshold is set in Settings → Integration → Plugins → room-storage →
Settings: enter a number of gigabytes (decimal comma or dot both work) and
save. Rooms larger than the threshold show their size in red together with an
"Exceeds the N GB threshold" note. Leave the field empty to disable
highlighting.

The room size comes from the portal's storage statistics (`usedSpace` in the
room info). It is only reported when quota statistics are enabled on the
portal and the viewer can manage or add content to the room; otherwise the tab
says the size is unavailable and still shows the owner.

## Build

```sh
npm install
npm run build
```

The uploadable archive is `dist/plugin.zip`.

## Install

Upload `dist/plugin.zip` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump `version` in `package.json` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

## Scopes

- `InfoPanel`
- `Settings`
- `API`
