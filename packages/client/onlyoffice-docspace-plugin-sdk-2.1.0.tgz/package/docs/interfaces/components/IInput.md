# IInput

Defined in: [interfaces/components/IInput.ts:90](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L90)

Input field for single-line strings.

![input](/assets/images/docspace/input.png#gh-light-mode-only)![input](/assets/images/docspace/input.dark.png#gh-dark-mode-only)

## Properties

### value

```ts
value: string;
```

Defined in: [interfaces/components/IInput.ts:94](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L94)

Defines the input value.

### onChange()

```ts
onChange: (value: string) => void | IMessage;
```

Defined in: [interfaces/components/IInput.ts:101](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L101)

Sets a function which is triggered whenever the input value is changed.
It is required when the input is not read-only.
The changed input value is passed to the function, which passes it back in the "value" parameter.

#### Parameters

##### value

`string`

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### name?

```ts
optional name: string;
```

Defined in: [interfaces/components/IInput.ts:106](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L106)

Defines the input HTML "name" property.

### placeholder?

```ts
optional placeholder: string;
```

Defined in: [interfaces/components/IInput.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L111)

Defines the input placeholder text.

### maxLength?

```ts
optional maxLength: string;
```

Defined in: [interfaces/components/IInput.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L116)

Defines the default maximum length of the input value.

### size?

```ts
optional size: InputSize;
```

Defined in: [interfaces/components/IInput.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L121)

Defines the input size.

### isAutoFocused?

```ts
optional isAutoFocused: boolean;
```

Defined in: [interfaces/components/IInput.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L126)

Specifies whether to focus the input field when initially rendered.

### isReadOnly?

```ts
optional isReadOnly: boolean;
```

Defined in: [interfaces/components/IInput.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L131)

Specifies whether the input field displays the read-only content.

### hasError?

```ts
optional hasError: boolean;
```

Defined in: [interfaces/components/IInput.ts:136](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L136)

Specifies whether to indicate that there is an error in the input field.

### hasWarning?

```ts
optional hasWarning: boolean;
```

Defined in: [interfaces/components/IInput.ts:141](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L141)

Specifies whether to indicate that there is a warning in the input field.

### scale?

```ts
optional scale: boolean;
```

Defined in: [interfaces/components/IInput.ts:146](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L146)

Specifies if the input field is scaled or not.

### autoComplete?

```ts
optional autoComplete: InputAutocomplete;
```

Defined in: [interfaces/components/IInput.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L151)

Defines the input HTML "autocomplete" property.

### tabIndex?

```ts
optional tabIndex: number;
```

Defined in: [interfaces/components/IInput.ts:156](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L156)

Defines the input HTML "tabindex" property.

### mask?

```ts
optional mask: [];
```

Defined in: [interfaces/components/IInput.ts:161](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L161)

Defines the input text mask.

### isDisabled?

```ts
optional isDisabled: boolean;
```

Defined in: [interfaces/components/IInput.ts:166](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L166)

Specifies that the field cannot be used (e.g the user is not authorized, or the changes are not saved).

### type?

```ts
optional type: InputType;
```

Defined in: [interfaces/components/IInput.ts:171](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L171)

The input field type.

### keepCharPositions?

```ts
optional keepCharPositions: boolean;
```

Defined in: [interfaces/components/IInput.ts:176](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L176)

Specifies whether the characters are allowed to be added or deleted without changing the positions of the existing characters.

### onBlur()?

```ts
optional onBlur: (value: string) => void | IMessage;
```

Defined in: [interfaces/components/IInput.ts:181](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L181)

Sets a function which is triggered whenever the input field is blurred.

#### Parameters

##### value

`string`

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### onFocus()?

```ts
optional onFocus: (value: string) => void | IMessage;
```

Defined in: [interfaces/components/IInput.ts:186](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L186)

Sets a function which is triggered whenever the input field is focused.

#### Parameters

##### value

`string`

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### children?

```ts
optional children: Node | Node[];
```

Defined in: [interfaces/components/IInput.ts:191](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L191)

Defines the input field components.

### iconSize?

```ts
optional iconSize: number;
```

Defined in: [interfaces/components/IInput.ts:196](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L196)

Defines the input icon size.

### iconName?

```ts
optional iconName: string;
```

Defined in: [interfaces/components/IInput.ts:201](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L201)

Defines the path to the input icon.

### isIconFill?

```ts
optional isIconFill: boolean;
```

Defined in: [interfaces/components/IInput.ts:206](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L206)

Specifies if the icon fill is needed or not.

### iconColor?

```ts
optional iconColor: string;
```

Defined in: [interfaces/components/IInput.ts:211](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L211)

Defines the input icon color.

### hoverColor?

```ts
optional hoverColor: string;
```

Defined in: [interfaces/components/IInput.ts:216](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L216)

Defines the icon color on hover action.

### iconButtonClassName?

```ts
optional iconButtonClassName: string;
```

Defined in: [interfaces/components/IInput.ts:221](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L221)

Defines the class name of the icon button.

### onIconClick()?

```ts
optional onIconClick: () => void;
```

Defined in: [interfaces/components/IInput.ts:226](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L226)

Sets a function which is triggered whenever the input icon is clicked.

#### Returns

`void`

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IInput.ts:232](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L232)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Examples

Search input with icon and hover effects

```typescript
const searchInput: IInput = {
  value: "",
  onChange: (value) => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        value
      }
    };
  },
  placeholder: "Search documents...",
  size: InputSize.middle,
  iconName: "search",
  iconSize: 16,
  iconColor: "#666666",
  hoverColor: "#333333",
  isIconFill: true,
}
```

Password input with validation and error handling

```typescript
const passwordInput: IInput = {
  value: "",
  type: InputType.password,
  onChange: (value) => {
    const hasError = value.length < 8;
    return {
      actions: [Actions.updateProps],
      newProps: {
        value,
        hasError
      }
    };
  },
  onBlur: (value) => {
    if (value.length < 8) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Password must be at least 8 characters long",
          type: ToastType.error
        }]
      };
    }
  },
  placeholder: "Enter password",
  name: "password",
  autoComplete: InputAutocomplete.off,
  size: InputSize.big,
  isAutoFocused: true,
  hasError: false,
  maxLength: "32"
}
```

## InputSize

Defined in: [interfaces/components/IInput.ts:238](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L238)

The supported input sizes.

### Enumeration Members

#### base

```ts
base: "base";
```

Defined in: [interfaces/components/IInput.ts:242](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L242)

Base size of the input field.

#### middle

```ts
middle: "middle";
```

Defined in: [interfaces/components/IInput.ts:246](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L246)

Middle size of the input field.

#### big

```ts
big: "big";
```

Defined in: [interfaces/components/IInput.ts:250](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L250)

Big size of the input field.

#### huge

```ts
huge: "huge";
```

Defined in: [interfaces/components/IInput.ts:254](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L254)

Huge size of the input field.

#### large

```ts
large: "large";
```

Defined in: [interfaces/components/IInput.ts:258](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L258)

Large size of the input field.

***

## InputAutocomplete

Defined in: [interfaces/components/IInput.ts:264](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L264)

The input autocomplete feature.

### Enumeration Members

#### on

```ts
on: "on";
```

Defined in: [interfaces/components/IInput.ts:268](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L268)

Autocomplete is enabled.

#### off

```ts
off: "off";
```

Defined in: [interfaces/components/IInput.ts:272](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L272)

Autocomplete is disabled.

***

## InputType

Defined in: [interfaces/components/IInput.ts:278](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L278)

The supported input types.

### Enumeration Members

#### text

```ts
text: "text";
```

Defined in: [interfaces/components/IInput.ts:282](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L282)

Text input type.

#### password

```ts
password: "password";
```

Defined in: [interfaces/components/IInput.ts:286](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L286)

Password input type.

