const path = require("path");
const fs = require("fs");

/**
 * Copies src/plugin.css into dist/ after every build. build-docspace-plugin
 * packs dist/plugin.css into the archive when present, and the portal
 * installs it alongside the bundle.
 */
class EmitPluginCss {
  apply(compiler) {
    compiler.hooks.afterEmit.tap("EmitPluginCss", () => {
      fs.copyFileSync(
        path.resolve(__dirname, "src", "plugin.css"),
        path.resolve(__dirname, "dist", "plugin.css")
      );
    });
  }
}

module.exports = {
  entry: "./src/index.ts",
  mode: "production",
  module: {
    rules: [
      {
        test: /\.ts?$/,
        use: "ts-loader",
        exclude: /node_modules/,
      },
    ],
  },
  resolve: {
    extensions: [".tsx", ".ts", ".js"],
  },
  output: {
    filename: "plugin.js",
    path: path.resolve(__dirname, "dist"),
  },
  plugins: [new EmitPluginCss()],
};
