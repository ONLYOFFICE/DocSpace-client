# IButton

Defined in: [interfaces/components/IButton.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L63)

A component that is used for an action on a page.

![button](/assets/images/docspace/button.png#gh-light-mode-only)![button](/assets/images/docspace/button.dark.png#gh-dark-mode-only)

## Properties

### label

```ts
label: string;
```

Defined in: [interfaces/components/IButton.ts:67](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L67)

Defines the button text

### size

```ts
size: ButtonSize;
```

Defined in: [interfaces/components/IButton.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L73)

Defines the button size. The normal size is equal to 36x40 px on the Desktop and Touchscreen devices.
Can be: "extraSmall", "small", "normal", "medium". The default value is "extraSmall"

### onClick()

```ts
onClick: () => 
  | void
  | IMessage
| Promise<IMessage>;
```

Defined in: [interfaces/components/IButton.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L78)

Sets a function which specifies an action initiated upon clicking the button

#### Returns

  `void`
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

### primary?

```ts
optional primary: boolean;
```

Defined in: [interfaces/components/IButton.ts:83](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L83)

Specifies if the button is primary or not. If the button is primary, it is colored blue

### scale?

```ts
optional scale: boolean;
```

Defined in: [interfaces/components/IButton.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L88)

Specifies if the button width will be scaled to 100% or not

### isLoading?

```ts
optional isLoading: boolean;
```

Defined in: [interfaces/components/IButton.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L93)

Specifies if the button will be displayed as a loader icon or not

### isDisabled?

```ts
optional isDisabled: boolean;
```

Defined in: [interfaces/components/IButton.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L98)

Specifies if the button is disabled or not. The disabled button is blurred

### withLoadingAfterClick?

```ts
optional withLoadingAfterClick: boolean;
```

Defined in: [interfaces/components/IButton.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L103)

Specifies whether to set the "isLoading" state to the button after it is clicked until the action is completed

### disableWhileRequestRunning?

```ts
optional disableWhileRequestRunning: boolean;
```

Defined in: [interfaces/components/IButton.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L109)

Specifies whether to set the "isDisabled" state for the button when the "withLoadingAfterClick" parameter is set to true,
and it is clicked either on the page or in the dialog box

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IButton.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L115)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Example

Primary save button with loading state and error handling

```typescript
const saveButton: IButton = {
  label: "Save Changes",
  size: ButtonSize.normal,
  onClick: async () => {
    try {
      await saveChanges();
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Changes saved successfully",
          type: ToastType.success
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Failed to save changes",
          type: ToastType.error
        }]
      };
    }
  },
  primary: true,
  scale: false,
  isLoading: false,
  isDisabled: false,
  withLoadingAfterClick: true,
  disableWhileRequestRunning: true
}
```

## ButtonSize

Defined in: [interfaces/components/IButton.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L121)

Defines button size options

### Enumeration Members

#### extraSmall

```ts
extraSmall: "extra-small";
```

Defined in: [interfaces/components/IButton.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L123)

Extra small button size

#### small

```ts
small: "small";
```

Defined in: [interfaces/components/IButton.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L125)

Small button size

#### normal

```ts
normal: "normal";
```

Defined in: [interfaces/components/IButton.ts:127](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L127)

Normal button size

#### medium

```ts
medium: "medium";
```

Defined in: [interfaces/components/IButton.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IButton.ts#L129)

Medium button size

