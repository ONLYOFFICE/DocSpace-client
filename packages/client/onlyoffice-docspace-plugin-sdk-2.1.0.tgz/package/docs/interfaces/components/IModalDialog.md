# IModalDialog

Defined in: [interfaces/components/IModalDialog.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L184)

Modal dialog.

To display the dialog, return an [`IMessage`](../utils.md#imessage) with
[`Actions.showModal`](../../enums/Actions.md#showmodal) in `actions`
and pass the dialog configuration in `modalDialogProps`.
Use [`Actions.closeModal`](../../enums/Actions.md#closemodal) to close it.

![modal-dialog](/assets/images/docspace/modal-dialog.png#gh-light-mode-only)![modal-dialog](/assets/images/docspace/modal-dialog.dark.png#gh-dark-mode-only)

:::info
`dialogBody` and `dialogFooter` are rendered in separate contexts.
Components in `dialogFooter` cannot update components in `dialogBody` using
`Actions.updateContext`, and vice versa.
:::

## Properties

### displayType

```ts
displayType: ModalDisplayType;
```

Defined in: [interfaces/components/IModalDialog.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L187)

Defines the modal dialog display type

### dialogHeader?

```ts
optional dialogHeader: string;
```

Defined in: [interfaces/components/IModalDialog.ts:191](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L191)

Defines the modal dialog header

### dialogBody

```ts
dialogBody: IBox;
```

Defined in: [interfaces/components/IModalDialog.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L195)

Defines the modal dialog body

### dialogFooter?

```ts
optional dialogFooter: IBox;
```

Defined in: [interfaces/components/IModalDialog.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L199)

Defines the modal dialog footer

### autoMaxWidth?

```ts
optional autoMaxWidth: boolean;
```

Defined in: [interfaces/components/IModalDialog.ts:203](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L203)

Specifies whether the "max-width: auto" property is set

### autoMaxHeight?

```ts
optional autoMaxHeight: boolean;
```

Defined in: [interfaces/components/IModalDialog.ts:207](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L207)

Specifies whether the "max-height: auto" property is set

### withoutBodyPadding?

```ts
optional withoutBodyPadding: boolean;
```

Defined in: [interfaces/components/IModalDialog.ts:211](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L211)

Specifies whether the modal dialog body has no paddings

### withoutHeaderMargin?

```ts
optional withoutHeaderMargin: boolean;
```

Defined in: [interfaces/components/IModalDialog.ts:215](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L215)

Specifies whether the modal dialog header has no bottom margins

### withFooterBorder?

```ts
optional withFooterBorder: boolean;
```

Defined in: [interfaces/components/IModalDialog.ts:219](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L219)

Specifies whether the border betweeen the body and footer is displayed

### fullScreen?

```ts
optional fullScreen: boolean;
```

Defined in: [interfaces/components/IModalDialog.ts:223](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L223)

Specifies whether to display the modal dialog body in the full screen mode without paddings

### eventListeners?

```ts
optional eventListeners: {
  name: string;
  onAction: () => 
     | void
     | Promise<void>
     | IMessage
    | Promise<IMessage>;
}[];
```

Defined in: [interfaces/components/IModalDialog.ts:228](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L228)

Defines the event listeners.

#### name

```ts
name: string;
```

Defines the event listener name.

#### onAction()

```ts
onAction: () => 
  | void
  | Promise<void>
  | IMessage
| Promise<IMessage>;
```

Sets a function which is triggered whenever the event listener is processed.

##### Returns

  `void`
  \| `Promise`\<`void`\>
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

### onClose()

```ts
onClose: () => 
  | void
  | Promise<void>
  | IMessage
| Promise<IMessage>;
```

Defined in: [interfaces/components/IModalDialog.ts:241](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L241)

Sets a function which is triggered whenever the "Close" button in the modal dialog is clicked

#### Returns

  `void`
  \| `Promise`\<`void`\>
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

### onLoad()

```ts
onLoad: () => Promise<{
  newDialogHeader?: string;
  newDialogBody: IBox;
  newDialogFooter?: IBox;
}>;
```

Defined in: [interfaces/components/IModalDialog.ts:246](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L246)

Sets a function which is triggered whenever the modal dialog is loaded.

#### Returns

`Promise`\<\{
  `newDialogHeader?`: `string`;
  `newDialogBody`: [`IBox`](IBox.md);
  `newDialogFooter?`: [`IBox`](IBox.md);
\}\>

## Examples

Interactive document preview modal with dynamic content loading

```typescript
import {
  IModalDialog,
  ModalDisplayType,
  Components,
  ButtonSize,
  Actions,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

const filePreviewModal: IModalDialog = {
  displayType: ModalDisplayType.modal,
  dialogHeader: "Document Preview",
  dialogBody: {
    children: [
      {
        component: Components.iFrame,
        props: {
          src: "https://example.com/preview/doc.pdf",
          width: "100%",
          height: "600px"
        }
      }
    ]
  },
  dialogFooter: {
    children: [
      {
        component: Components.button,
        props: {
          label: "Close",
          size: ButtonSize.normal,
          onClick: () => {
            return {
              actions: [Actions.closeModal]
            };
          }
        }
      }
    ]
  },
  autoMaxWidth: true,
  autoMaxHeight: true,
  withFooterBorder: true,
  fullScreen: false,
  eventListeners: [
    {
      name: "documentLoaded",
      onAction: async () => {
        return {
          actions: [Actions.showToast],
          toastProps: [{
            type: ToastType.success,
            title: "Document loaded successfully"
          }]
        };
      }
    }
  ],
  onClose: () => {
    return {
      actions: [Actions.closeModal]
    };
  },
  onLoad: async () => {
    const documentDetails = await fetchDocumentDetails();
    return {
      newDialogHeader: `Preview: ${documentDetails.name}`,
      newDialogBody: {
        children: [
          {
            component: Components.iFrame,
            props: {
              src: documentDetails.previewUrl,
              width: "100%",
              height: "600px"
            }
          }
        ]
      }
    };
  }
}
```

Side panel settings dialog with API key configuration

```typescript
const apiKeyInput: IInput = {
  value: "",
  type: InputType.password,
  placeholder: "Enter your API key",
  onChange: (value) => ({
    actions: [Actions.updateProps],
    newProps: { ...apiKeyInput, value }
  })
};

const settingsPanel: IModalDialog = {
  displayType: ModalDisplayType.aside,
  dialogHeader: "Plugin Settings",
  dialogBody: {
    children: [
      {
        component: Components.label,
        props: { text: "API Key" }
      },
      {
        component: Components.input,
        props: apiKeyInput
      }
    ]
  },
  autoMaxWidth: false,
  autoMaxHeight: true,
  withFooterBorder: true,
  fullScreen: false,
  onClose: () => ({
    actions: [Actions.closeModal]
  }),
  onLoad: async () => {
    const settings = await loadSettings();
    return {
      newDialogBody: {
        children: [
          {
            component: Components.label,
            props: { text: "API Key" }
          },
          {
            component: Components.input,
            props: { ...apiKeyInput, value: settings.apiKey }
          }
        ]
      }
    };
  }
}
```

## ModalDisplayType

Defined in: [interfaces/components/IModalDialog.ts:265](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L265)

The supported modal dialog types.

### Enumeration Members

#### modal

```ts
modal: "modal";
```

Defined in: [interfaces/components/IModalDialog.ts:267](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L267)

Modal dialog displayed in the center of the screen

#### aside

```ts
aside: "aside";
```

Defined in: [interfaces/components/IModalDialog.ts:269](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IModalDialog.ts#L269)

Modal dialog displayed as a side panel

