# archive-sender

Send the current folder to an archive URL.

Adds a **Send to archive** entry to the main button (the portal puts plugin
entries under its **More** sub-entry, and under the section "+" menu). It opens a
modal with an archive URL field and a format combo box (`zip` / `tar.gz`).

The URL is validated as you type and again when **Send** is pressed: an empty
value or one that does not start with `https://` paints the field red and shows
the message under it, and **Send** does nothing else — the dialog stays open and
nothing is submitted.

## Not wired to a destination

`sendToArchive()` in `src/dialog.ts` is a stub — no upload endpoint was
specified. Replace it with the real call and make it reject on failure so the
dialog can show its error message. Note that the portal's CSP blocks requests to
any origin not listed in `cspDomains` in `package.json`, and the origin here is
only known at runtime, so a browser-side POST to an arbitrary user-supplied host
will not work without a fixed backend.

`assets/icon-16.svg` and `assets/logo.svg` are the scaffold placeholders.

## Build

```sh
npm install
npm run build
```

The uploadable archive is `dist/plugin.zip`.

## Install

Upload `dist/plugin.zip` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump `version` in `package.json` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

## Scopes

- `MainButton`
