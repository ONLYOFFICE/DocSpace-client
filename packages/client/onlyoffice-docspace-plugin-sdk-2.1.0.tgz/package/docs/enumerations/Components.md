# Enumeration: Components

Defined in: [enums/Components.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L22)

Defines the available UI component.

## Enumeration Members

### box

> **box**: `"box"`

Defined in: [enums/Components.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L24)

Container component for grouping other elements

***

### button

> **button**: `"button"`

Defined in: [enums/Components.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L27)

Interactive button element

***

### checkbox

> **checkbox**: `"checkbox"`

Defined in: [enums/Components.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L30)

Selectable checkbox input

***

### input

> **input**: `"input"`

Defined in: [enums/Components.ts:33](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L33)

Text input field

***

### label

> **label**: `"label"`

Defined in: [enums/Components.ts:36](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L36)

Text label for form elements

***

### text

> **text**: `"text"`

Defined in: [enums/Components.ts:39](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L39)

Static text display

***

### textArea

> **textArea**: `"textArea"`

Defined in: [enums/Components.ts:42](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L42)

Multi-line text input

***

### toggleButton

> **toggleButton**: `"toggleButton"`

Defined in: [enums/Components.ts:45](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L45)

Switch-like button with two states

***

### img

> **img**: `"img"`

Defined in: [enums/Components.ts:48](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L48)

Image display component

***

### iFrame

> **iFrame**: `"iFrame"`

Defined in: [enums/Components.ts:51](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L51)

Embedded frame component

***

### comboBox

> **comboBox**: `"comboBox"`

Defined in: [enums/Components.ts:54](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L54)

Dropdown selection input

***

### skeleton

> **skeleton**: `"skeleton"`

Defined in: [enums/Components.ts:57](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L57)

Loading placeholder component
