# Interface: ITextArea

Defined in: [interfaces/components/ITextArea.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L116)

Custom textarea.

## Examples

JSON configuration editor with syntax validation

```typescript
const configEditor: ITextArea = {
  value: JSON.stringify({
    apiKey: "your-api-key",
    endpoint: "https://api.example.com",
    timeout: 5000
  }, null, 2),
  onChange: (value) => {
    try {
      JSON.parse(value);
      return {
        actions: [Actions.updateProps],
        newProps: {
          value,
          hasError: false
        }
      };
    } catch (error) {
      return {
        actions: [Actions.updateProps, Actions.showToast],
        newProps: {
          value,
          hasError: true
        },
        toastProps: [{
          title: "Invalid JSON",
          type: "error",
          message: "Please check your JSON syntax"
        }]
      };
    }
  },
  placeholder: "Enter JSON configuration...",
  isJSONField: true,
  enableCopy: true,
  hasNumeration: true,
  heightTextArea: 300,
  fontSize: 14,
  copyInfoText: true
}
```

Character-limited comment box with dynamic validation

```typescript
const commentBox: ITextArea = {
  value: "",
  onChange: (value) => {
    const hasError = value.length > 500;
    return {
      actions: [Actions.updateProps],
      newProps: {
        value,
        hasError
      }
    };
  },
  placeholder: "Add your comment (max 500 characters)",
  maxLength: 500,
  heightTextArea: "120px",
  isFullHeight: true,
  heightScale: true,
  fontSize: 16,
  name: "comment",
  tabIndex: 1
}
```

## Appearance

Properties that control the visual styling, dimensions, JSON formatting, and copy functionality.

### fontSize?

> `optional` **fontSize**: `number`

Defined in: [interfaces/components/ITextArea.ts:185](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L185)

Defines the textarea font size.

***

### heightTextArea?

> `optional` **heightTextArea**: `string` \| `number`

Defined in: [interfaces/components/ITextArea.ts:192](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L192)

Defines the textarea height.

***

### isJSONField?

> `optional` **isJSONField**: `boolean`

Defined in: [interfaces/components/ITextArea.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L199)

Specifies whether the textarea is prettified for JSON and the line numeration is added.

***

### enableCopy?

> `optional` **enableCopy**: `boolean`

Defined in: [interfaces/components/ITextArea.ts:206](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L206)

Specifies whether the "Copy" icon is displayed in the textarea.

***

### hasNumeration?

> `optional` **hasNumeration**: `boolean`

Defined in: [interfaces/components/ITextArea.ts:213](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L213)

Specifies whether the numeration is inserted into the textarea.

***

### isFullHeight?

> `optional` **isFullHeight**: `boolean`

Defined in: [interfaces/components/ITextArea.ts:220](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L220)

Specifies whether the height of the textarea content is calculated depending on the number of lines.

***

### heightScale?

> `optional` **heightScale**: `boolean`

Defined in: [interfaces/components/ITextArea.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L227)

Specifies whether the textarea has a height scale.

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/ITextArea.ts:242](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L242)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Behavior

Callback functions for handling value changes and user interactions with the textarea.

### onChange()

> **onChange**: (`value`) => `void` \| `IMessage`

Defined in: [interfaces/components/ITextArea.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L129)

Sets a function which is triggered whenever the textarea is changed.

#### Parameters

##### value

`string`

#### Returns

`void` \| `IMessage`

***

### maxLength?

> `optional` **maxLength**: `number`

Defined in: [interfaces/components/ITextArea.ts:164](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L164)

Defines the maximum value length in the textarea.

***

### tabIndex?

> `optional` **tabIndex**: `number`

Defined in: [interfaces/components/ITextArea.ts:178](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L178)

Defines the textarea HTML "tabindex" property.

***

### copyInfoText?

> `optional` **copyInfoText**: `boolean`

Defined in: [interfaces/components/ITextArea.ts:234](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L234)

Specifies whether the toast / information text will be displayed when copying.

## Content

Properties that define the textarea's value, placeholder, name, and displayed content.

### value

> **value**: `string`

Defined in: [interfaces/components/ITextArea.ts:122](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L122)

Defines the textarea value.

***

### placeholder?

> `optional` **placeholder**: `string`

Defined in: [interfaces/components/ITextArea.ts:136](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L136)

Defines the textarea placeholder.

***

### name?

> `optional` **name**: `string`

Defined in: [interfaces/components/ITextArea.ts:171](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L171)

Defines the textarea HTML "name" property.

## State

Properties that control the textarea's disabled, read-only, and error states.

### isDisabled?

> `optional` **isDisabled**: `boolean`

Defined in: [interfaces/components/ITextArea.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L143)

Specifies whether the textarea is disabled.

***

### isReadOnly?

> `optional` **isReadOnly**: `boolean`

Defined in: [interfaces/components/ITextArea.ts:150](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L150)

Specifies whether the textarea displays the read-only content.

***

### hasError?

> `optional` **hasError**: `boolean`

Defined in: [interfaces/components/ITextArea.ts:157](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L157)

Specifies whether to indicate that there is an error in the textarea.
