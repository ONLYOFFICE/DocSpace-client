# Interface: IImage

Defined in: [interfaces/components/IImage.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L70)

A component that is used to embed an image not from the assets folder into a modal window or the settings page.

## Examples

Plugin logo with fixed dimensions and spacing

```typescript
const pluginLogo: IImage = {
  src: "https://example.com/plugin-logo.png",
  alt: "Plugin Logo",
  width: "120px",
  height: "40px",
  name: "plugin-logo",
  id: "settings-logo",
  style: {
    objectFit: "contain",
    marginBottom: "16px"
  }
}
```

Responsive document preview with modern styling

```typescript
const documentPreview: IImage = {
  src: "https://example.com/document-preview.jpg",
  alt: "Document Preview",
  width: "100%",
  height: "auto",
  name: "doc-preview",
  style: {
    borderRadius: "4px",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
    maxWidth: "800px"
  }
}
```

## Appearance

Properties that control the visual dimensions, styling, and layout of the image.

### width?

> `optional` **width**: `string`

Defined in: [interfaces/components/IImage.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L87)

Defines the image width

***

### height?

> `optional` **height**: `string`

Defined in: [interfaces/components/IImage.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L93)

Defines the image height

***

### style?

> `optional` **style**: `object`

Defined in: [interfaces/components/IImage.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L111)

Defines the image style

#### Index Signature

\[`key`: `string`\]: `string`

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/IImage.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L119)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Content

Properties that define the image source, alt text, name, and identifiers.

### src

> **src**: `string`

Defined in: [interfaces/components/IImage.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L75)

Defines the full path to the image

***

### alt

> **alt**: `string`

Defined in: [interfaces/components/IImage.ts:81](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L81)

Defines the image alt attribute

***

### name?

> `optional` **name**: `string`

Defined in: [interfaces/components/IImage.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L99)

Defines the image name

***

### id?

> `optional` **id**: `string`

Defined in: [interfaces/components/IImage.ts:105](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IImage.ts#L105)

Defines the image ID
