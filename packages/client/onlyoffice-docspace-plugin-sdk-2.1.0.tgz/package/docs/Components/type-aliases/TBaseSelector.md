# Type Alias: TBaseSelector

> **TBaseSelector** = [`TSelectorBreadCrumbs`](TSelectorBreadCrumbs.md) & [`TSelectorPagination`](TSelectorPagination.md) & [`TSelectorHeader`](TSelectorHeader.md) & [`TSelectorCancelButton`](TSelectorCancelButton.md) & [`TSelectorSubmitButton`](TSelectorSubmitButton.md) & [`TSelectorCheckbox`](TSelectorCheckbox.md) & [`TSelectorBaseProps`](TSelectorBaseProps.md) & [`TSelectorLifecycleEvents`](TSelectorLifecycleEvents.md) & [`TSelectorEmptyScreen`](TSelectorEmptyScreen.md) & `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:106](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L106)

Defines the base properties for all selector components.

## Type Declaration

### isLoading?

> `optional` **isLoading**: `boolean`

If true, shows a loading indicator for the entire selector.

### isMultiSelect?

> `optional` **isMultiSelect**: `boolean`

If true, allows multiple items to be selected.

### maxSelectedItems?

> `optional` **maxSelectedItems**: `number`

The maximum number of items that can be selected.

### selectedItems?

> `optional` **selectedItems**: [`TSelectorItem`](TSelectorItem.md)[]

An array of initially selected items.

### descriptionText?

> `optional` **descriptionText**: `string`

A descriptive text displayed within the selector.

### searchEmptyScreenHeader?

> `optional` **searchEmptyScreenHeader**: `string`

The header text to display when a search yields no results.

### searchEmptyScreenDescription?

> `optional` **searchEmptyScreenDescription**: `string`

The description text to display when a search yields no results.

### onSelect()?

> `optional` **onSelect**: (`params`) => `TReturnMessage`

A callback function that is triggered when an item is selected.

#### Parameters

##### params

`TOnSelectParams`

#### Returns

`TReturnMessage`

## Example

```typescript
// This example demonstrates how to create a basic selector with a list of items,
// a header, and a submit button. It also includes an item that, when clicked,
// dynamically adds a new input item to the list.

const selectorProps: TBaseSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Plugin Base Selector",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Submit",

  // An array of items to display in the selector.
  items: [
    {
      id: "create-new",
      label: "Create new item",
      isCreateNewItem: true, // Renders this item as a button for creating new entries.
      onCreateClick: () => {
        // When clicked, this function returns a message to the host application
        // with an `updateSelector` action. This action provides new props to
        // re-render the selector, in this case, adding a new item to the list.
        const updatedItems = [...selectorProps.items, { id: "new-item", label: "Newly Added Item" }];

        return {
          actions: [Actions.updateSelector], // Specifies the action to perform.
          selectorProps: { // Provides the new properties for the selector.
             type: SelectorType.Base,
             props: { ...selectorProps, items: updatedItems }
          }
        };

      },
    },
    {
      id: "item-1",
      label: "First Item",
      icon: "your-icon-url.svg", // Specify an icon for the item.
    },
  ],

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: ({ selectedIds }) => {
    // The `selectedIds` parameter contains an array of the IDs of the selected items.
    console.log("Items submitted:", selectedIds);

    // After submission, you can perform actions like closing the selector
    // and showing a success message.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `Selected ${selectedIds.length} items`,
      }],
    };
  },
};
```
