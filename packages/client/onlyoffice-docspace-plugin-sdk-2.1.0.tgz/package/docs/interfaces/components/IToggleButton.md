# IToggleButton

Defined in: [interfaces/components/IToggleButton.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L98)

Custom toggle button input for binary state controls.

![toggle-button](/assets/images/docspace/toggle-button.png#gh-light-mode-only)![toggle-button](/assets/images/docspace/toggle-button.dark.png#gh-dark-mode-only)

## Properties

### label?

```ts
optional label: string;
```

Defined in: [interfaces/components/IToggleButton.ts:101](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L101)

Defines the toggle button label

### isChecked

```ts
isChecked: boolean;
```

Defined in: [interfaces/components/IToggleButton.ts:105](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L105)

Specifies whether the toggle button is enabled

### onChange()

```ts
onChange: () => void | IMessage;
```

Defined in: [interfaces/components/IToggleButton.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L109)

Sets a function which is triggered whenever the toggle button is clicked

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### isDisabled?

```ts
optional isDisabled: boolean;
```

Defined in: [interfaces/components/IToggleButton.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L113)

Specifies whether the toggle button is disabled

### style?

```ts
optional style: any;
```

Defined in: [interfaces/components/IToggleButton.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L117)

Defines the toggle button CSS style

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IToggleButton.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L123)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Examples

Theme switcher with custom margin

```typescript
const darkModeToggle: IToggleButton = {
  label: "Dark Mode",
  isChecked: false,
  onChange: () => {
    return {
      actions: [Actions.updateProps, Actions.updateTheme],
      newProps: {
        isChecked: true
      },
      theme: "dark"
    };
  },
  style: {
    marginLeft: "16px"
  }
}
```

Permission-aware notification settings

```typescript
const notificationsToggle: IToggleButton = {
  label: "Enable Notifications",
  isChecked: true,
  isDisabled: !hasNotificationPermission,
  onChange: () => {
    return {
      actions: [Actions.updateProps, Actions.showToast],
      newProps: {
        isChecked: false
      },
      toastProps: [{
        type: ToastType.info,
        title: "Notifications disabled",
        timeout: 3000
      }]
    };
  }
}
```

Styled auto-save control with custom background

```typescript
const autoSaveToggle: IToggleButton = {
  label: "Auto-save",
  isChecked: true,
  onChange: () => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        isChecked: false
      }
    };
  },
  style: {
    backgroundColor: "#f5f5f5",
    padding: "8px",
    borderRadius: "4px"
  }
}
```

