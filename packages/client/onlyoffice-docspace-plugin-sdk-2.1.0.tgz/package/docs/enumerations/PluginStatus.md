# Enumeration: PluginStatus

Defined in: [enums/Plugins.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L22)

Defines the supported plugin statuses.

## Enumeration Members

### active

> **active**: `"active"`

Defined in: [enums/Plugins.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L24)

Plugin is enabled and visible to users

***

### hide

> **hide**: `"hide"`

Defined in: [enums/Plugins.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L27)

Plugin is disabled and hidden from the user interface
