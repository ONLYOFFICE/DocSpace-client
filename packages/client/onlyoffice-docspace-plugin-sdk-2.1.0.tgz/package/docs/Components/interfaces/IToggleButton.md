# Interface: IToggleButton

Defined in: [interfaces/components/IToggleButton.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L114)

Custom toggle button input for binary state controls.

## Examples

Theme switcher with custom margin

```typescript
const darkModeToggle: IToggleButton = {
  label: "Dark Mode",
  isChecked: false,
  onChange: () => {
    return {
      actions: [Actions.updateProps, Actions.updateTheme],
      newProps: {
        isChecked: true
      },
      theme: "dark"
    };
  },
  style: {
    marginLeft: "16px"
  }
}
```

Permission-aware notification settings

```typescript
const notificationsToggle: IToggleButton = {
  label: "Enable Notifications",
  isChecked: true,
  isDisabled: !hasNotificationPermission,
  onChange: () => {
    return {
      actions: [Actions.updateProps, Actions.showToast],
      newProps: {
        isChecked: false
      },
      toastProps: [{
        type: "info",
        title: "Notifications disabled",
        timeout: 3000
      }]
    };
  }
}
```

Styled auto-save control with custom background

```typescript
const autoSaveToggle: IToggleButton = {
  label: "Auto-save",
  isChecked: true,
  onChange: () => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        isChecked: false
      }
    };
  },
  style: {
    backgroundColor: "#f5f5f5",
    padding: "8px",
    borderRadius: "4px"
  }
}
```

## Appearance

Properties that control the visual styling and CSS customization of the toggle button.

### style?

> `optional` **style**: `any`

Defined in: [interfaces/components/IToggleButton.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L143)

Defines the toggle button CSS style

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/IToggleButton.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L151)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Behavior

Callback functions for handling toggle state changes and user interactions.

### onChange()

> **onChange**: () => `void` \| `IMessage`

Defined in: [interfaces/components/IToggleButton.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L131)

Sets a function which is triggered whenever the toggle button is clicked

#### Returns

`void` \| `IMessage`

## Content

Properties that define the toggle button's label text.

### label?

> `optional` **label**: `string`

Defined in: [interfaces/components/IToggleButton.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L119)

Defines the toggle button label

## State

Properties that control the toggle button's checked and disabled states.

### isChecked

> **isChecked**: `boolean`

Defined in: [interfaces/components/IToggleButton.ts:125](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L125)

Specifies whether the toggle button is enabled

***

### isDisabled?

> `optional` **isDisabled**: `boolean`

Defined in: [interfaces/components/IToggleButton.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToggleButton.ts#L137)

Specifies whether the toggle button is disabled
