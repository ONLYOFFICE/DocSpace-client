# Recipes

Working patterns for the things plugins actually do. Each one is shaped by a host constraint explained in [host-behavior.md](host-behavior.md) — the comments say which.

## A modal with live validation

The most common shape, and the one that exercises the trickiest rule: a menu item cannot update anything itself, so it opens a modal, and updates happen from inside the modal's own elements.

```ts
let draft = "";

const errorText = (text: string) => ({
  actions: [Actions.updateContext],
  contextProps: [{ name: "url-error", props: { text } }],
});

const dialogBody = (): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [
    {
      component: Components.input,
      contextName: "url-input",
      props: {
        value: draft,
        placeholder: "https://",
        scale: true,
        // Self-update keeps the field editable; the sibling update shows the error.
        // Both only work because this callback lives inside the rendered tree.
        onChange: (value: string) => {
          draft = value;
          const invalid = value.length > 0 && !/^https?:\/\//.test(value);

          return {
            actions: [Actions.updateProps, Actions.updateContext],
            newProps: { value, hasError: invalid },
            contextProps: [
              { name: "url-error", props: { text: invalid ? t("dialog.invalidUrl") : "" } },
            ],
          };
        },
      },
    },
    {
      component: Components.text,
      contextName: "url-error",
      props: { text: "", color: "var(--error-color)", fontSize: "12px" },
    },
  ],
});

const dialogFooter = (): IBox => ({
  children: [
    {
      component: Components.button,
      props: {
        label: t("dialog.save"),
        size: ButtonSize.normal,
        primary: true,
        onClick: async () => {
          if (!/^https?:\/\//.test(draft)) return errorText(t("dialog.invalidUrl"));

          try {
            await saveSomewhere(draft);
            return {
              actions: [Actions.closeModal, Actions.showToast],
              toastProps: [{ type: ToastType.success, title: t("toast.saved") }],
            };
          } catch {
            // Nothing catches this for us - an uncaught rejection is a dead button.
            return errorText(t("dialog.saveFailed"));
          }
        },
      },
    },
  ],
});

export const urlDialog = (): IModalDialog => ({
  displayType: ModalDisplayType.modal,
  dialogHeader: t("dialog.header"),
  dialogBody: dialogBody(),
  dialogFooter: dialogFooter(),
  onClose: () => ({ actions: [Actions.closeModal] }),
  onLoad: async () => ({ newDialogBody: dialogBody() }),   // mandatory, even when trivial
});
```

Opening it from a context menu:

```ts
onItemClick: async (id) => {
  currentId = id;
  return { actions: [Actions.showModal], modalDialogProps: urlDialog() };
},
```

## Admin settings that persist

Settings travel as one opaque string. The plugin owns the format; the portal only stores it.

```ts
type TSettings = { apiKey: string; enabled: boolean };

let settings: TSettings = { apiKey: "", enabled: true };

const settingsBody = (): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [
    {
      component: Components.input,
      props: {
        value: settings.apiKey,
        scale: true,
        onChange: (value: string) => {
          settings = { ...settings, apiKey: value };
          return { actions: [Actions.updateProps], newProps: { value } };
        },
      },
    },
  ],
});

export const pluginSettings = (): ISettings => ({
  settings: settingsBody(),
  saveButton: {
    component: Components.button,
    props: {
      label: t("settings.save"),
      size: ButtonSize.normal,
      primary: true,
      // saveSettings is honoured only from this button - nowhere else.
      onClick: async () => ({
        actions: [Actions.saveSettings, Actions.showToast],
        settings: JSON.stringify(settings),
        toastProps: [{ type: ToastType.success, title: t("settings.saved") }],
      }),
    },
  },
  onLoad: async () => ({ settings: settingsBody() }),
});
```

Reading them back — this arrives **after** installation, never during `onLoadCallback`:

```ts
setAdminPluginSettingsValue = (value: string | null): void => {
  if (!value) return;

  try {
    settings = { ...settings, ...(JSON.parse(value) as TSettings) };
  } catch {
    // Keep the defaults rather than breaking installation on a bad stored value.
  }
};
```

## Acting on a file, with permissions respected

```ts
const onFileAction = async (id: number) => {
  try {
    const res = await fetch(`${buildApiUrl()}/files/file/${id}`, { credentials: "include" });
    const file = (await res.json()).response;      // note the wrapper

    if (!file.security?.Download)
      return {
        actions: [Actions.showToast],
        toastProps: [{ type: ToastType.error, title: t("toast.noPermission") }],
      };

    const content = await (await fetch(file.viewUrl)).text();   // bytes come from viewUrl

    return {
      actions: [Actions.showModal],
      modalDialogProps: previewDialog(file.title, content),
    };
  } catch {
    return {
      actions: [Actions.showToast],
      toastProps: [{ type: ToastType.error, title: t("toast.readFailed") }],
    };
  }
};
```

## A panel that loads asynchronously

Fetching in `onLoadCallback` delays the whole plugin's installation, and an exception there aborts it silently. Put the work in the item's `onLoad` instead and show a skeleton meanwhile.

```ts
const loadingBody = (): IBox => ({
  children: [{ component: Components.skeleton, props: { width: "100%", height: "80px" } }],
});

const loadedBody = (rows: string[]): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: rows.map((text) => ({ component: Components.text, props: { text } })),
});

export const reportItem = (): IInfoPanelItem => ({
  key: "myplugin-report",
  subMenu: { name: t("infoPanel.tab") },
  body: loadingBody(),
  onLoad: async () => {
    try {
      return { body: loadedBody(await fetchRows()) };
    } catch {
      return { body: loadedBody([t("infoPanel.failed")]) };
    }
  },
});
```

## Reacting to a portal event

```ts
export const createListener = (): IEventListenerItem => ({
  key: "myplugin-on-create",
  eventType: Events.CREATE,
  // No arguments are passed, and after the event only item updates and toasts
  // are honoured - so this cannot, for example, open a modal.
  eventHandler: async () => ({
    actions: [Actions.showToast],
    toastProps: [{ type: ToastType.info, title: t("toast.created") }],
  }),
});
```

## Embedding a third-party page

For an external editor or viewer. The plugin runs in a hidden iframe, so the listener goes on `window.parent`, and the origin must be in `cspDomains`.

```ts
const embedBody = (): IBox => ({
  children: [
    {
      component: Components.iFrame,
      props: { id: "myplugin-frame", src: "https://example.com/editor", width: "100%", height: "600px" },
    },
  ],
});

// Set this up once, in onLoadCallback.
const listenToFrame = () => {
  window.parent.addEventListener("message", (event: MessageEvent) => {
    if (event.origin !== "https://example.com") return;   // always check the origin

    const data = JSON.parse(event.data);

    // The portal gave us this callback; calling it asks the portal to act.
    plugin.postMessageCallback({
      actions: [Actions.showToast],
      toastProps: [{ type: ToastType.success, title: data.title }],
    });
  });
};
```

Sending a message the other way uses the portal, addressing the frame by DOM id:

```ts
{ actions: [Actions.sendPostMessage], postMessage: { frameId: "myplugin-frame", message: { command: "save" } } }
```
