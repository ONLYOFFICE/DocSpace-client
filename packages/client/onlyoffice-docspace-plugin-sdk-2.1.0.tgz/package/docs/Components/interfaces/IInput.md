# Interface: IInput

Defined in: [interfaces/components/IInput.ts:167](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L167)

Input field for single-line strings.

## Examples

Search input with icon and hover effects

```typescript
const searchInput: IInput = {
  value: "",
  onChange: (value) => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        value
      }
    };
  },
  placeholder: "Search documents...",
  size: InputSize.middle,
  iconName: "search",
  iconSize: 16,
  iconColor: "#666666",
  hoverColor: "#333333",
  isIconFill: true,
}
```

Password input with validation and error handling

```typescript
const passwordInput: IInput = {
  value: "",
  type: InputType.password,
  onChange: (value) => {
    const hasError = value.length < 8;
    return {
      actions: [Actions.updateProps],
      newProps: {
        value,
        hasError
      }
    };
  },
  onBlur: (value) => {
    if (value.length < 8) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Validation Error",
          type: "error",
          message: "Password must be at least 8 characters long"
        }]
      };
    }
  },
  placeholder: "Enter password",
  name: "password",
  autoComplete: InputAutocomplete.off,
  size: InputSize.big,
  isAutoFocused: true,
  hasError: false,
  maxLength: "32"
}
```

## Appearance

Properties that control the visual styling, size, icons, and layout of the input field.

### maxLength?

> `optional` **maxLength**: `string`

Defined in: [interfaces/components/IInput.ts:203](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L203)

Defines the default maximum length of the input value.

***

### size?

> `optional` **size**: [`InputSize`](../enumerations/InputSize.md)

Defined in: [interfaces/components/IInput.ts:210](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L210)

Defines the input size.

***

### scale?

> `optional` **scale**: `boolean`

Defined in: [interfaces/components/IInput.ts:245](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L245)

Specifies if the input field is scaled or not.

***

### autoComplete?

> `optional` **autoComplete**: [`InputAutocomplete`](../enumerations/InputAutocomplete.md)

Defined in: [interfaces/components/IInput.ts:252](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L252)

Defines the input HTML "autocomplete" property.

***

### tabIndex?

> `optional` **tabIndex**: `number`

Defined in: [interfaces/components/IInput.ts:259](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L259)

Defines the input HTML "tabindex" property.

***

### type?

> `optional` **type**: [`InputType`](../enumerations/InputType.md)

Defined in: [interfaces/components/IInput.ts:280](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L280)

The input field type.

***

### iconSize?

> `optional` **iconSize**: `number`

Defined in: [interfaces/components/IInput.ts:315](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L315)

Defines the input icon size.

***

### iconName?

> `optional` **iconName**: `string`

Defined in: [interfaces/components/IInput.ts:322](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L322)

Defines the path to the input icon.

***

### isIconFill?

> `optional` **isIconFill**: `boolean`

Defined in: [interfaces/components/IInput.ts:329](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L329)

Specifies if the icon fill is needed or not.

***

### iconColor?

> `optional` **iconColor**: `string`

Defined in: [interfaces/components/IInput.ts:336](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L336)

Defines the input icon color.

***

### hoverColor?

> `optional` **hoverColor**: `string`

Defined in: [interfaces/components/IInput.ts:343](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L343)

Defines the icon color on hover action.

***

### iconButtonClassName?

> `optional` **iconButtonClassName**: `string`

Defined in: [interfaces/components/IInput.ts:350](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L350)

Defines the class name of the icon button.

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/IInput.ts:365](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L365)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Behavior

Callback functions for handling user interactions like change, blur, focus, and icon clicks.

### onChange()

> **onChange**: (`value`) => `void` \| `IMessage`

Defined in: [interfaces/components/IInput.ts:182](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L182)

Sets a function which is triggered whenever the input value is changed.
It is required when the input is not read-only.
The changed input value is passed to the function, which passes it back in the "value" parameter.

#### Parameters

##### value

`string`

#### Returns

`void` \| `IMessage`

***

### keepCharPositions?

> `optional` **keepCharPositions**: `boolean`

Defined in: [interfaces/components/IInput.ts:287](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L287)

Specifies whether the characters are allowed to be added or deleted without changing the positions of the existing characters.

***

### onBlur()?

> `optional` **onBlur**: (`value`) => `void` \| `IMessage`

Defined in: [interfaces/components/IInput.ts:294](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L294)

Sets a function which is triggered whenever the input field is blurred.

#### Parameters

##### value

`string`

#### Returns

`void` \| `IMessage`

***

### onFocus()?

> `optional` **onFocus**: (`value`) => `void` \| `IMessage`

Defined in: [interfaces/components/IInput.ts:301](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L301)

Sets a function which is triggered whenever the input field is focused.

#### Parameters

##### value

`string`

#### Returns

`void` \| `IMessage`

***

### onIconClick()?

> `optional` **onIconClick**: () => `void`

Defined in: [interfaces/components/IInput.ts:357](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L357)

Sets a function which is triggered whenever the input icon is clicked.

#### Returns

`void`

## Content

Properties that define the input's value, placeholder, name, and mask.

### value

> **value**: `string`

Defined in: [interfaces/components/IInput.ts:173](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L173)

Defines the input value.

***

### name?

> `optional` **name**: `string`

Defined in: [interfaces/components/IInput.ts:189](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L189)

Defines the input HTML "name" property.

***

### placeholder?

> `optional` **placeholder**: `string`

Defined in: [interfaces/components/IInput.ts:196](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L196)

Defines the input placeholder text.

***

### mask?

> `optional` **mask**: \[\]

Defined in: [interfaces/components/IInput.ts:266](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L266)

Defines the input text mask.

***

### children?

> `optional` **children**: `Node` \| `Node`[]

Defined in: [interfaces/components/IInput.ts:308](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L308)

Defines the input field components.

## State

Properties that control the input's focus, validation, disabled, and read-only states.

### isAutoFocused?

> `optional` **isAutoFocused**: `boolean`

Defined in: [interfaces/components/IInput.ts:217](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L217)

Specifies whether to focus the input field when initially rendered.

***

### isReadOnly?

> `optional` **isReadOnly**: `boolean`

Defined in: [interfaces/components/IInput.ts:224](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L224)

Specifies whether the input field displays the read-only content.

***

### hasError?

> `optional` **hasError**: `boolean`

Defined in: [interfaces/components/IInput.ts:231](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L231)

Specifies whether to indicate that there is an error in the input field.

***

### hasWarning?

> `optional` **hasWarning**: `boolean`

Defined in: [interfaces/components/IInput.ts:238](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L238)

Specifies whether to indicate that there is a warning in the input field.

***

### isDisabled?

> `optional` **isDisabled**: `boolean`

Defined in: [interfaces/components/IInput.ts:273](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IInput.ts#L273)

Specifies that the field cannot be used (e.g the user is not authorized, or the changes are not saved).
