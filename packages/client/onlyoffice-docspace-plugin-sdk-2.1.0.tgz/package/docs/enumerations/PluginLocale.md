# Enumeration: PluginLocale

Defined in: [enums/Plugins.ts:33](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L33)

Defines the supported plugin languages.

## Enumeration Members

### AZ

> **AZ**: `"az"`

Defined in: [enums/Plugins.ts:34](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L34)

***

### CS

> **CS**: `"cs"`

Defined in: [enums/Plugins.ts:35](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L35)

***

### DE

> **DE**: `"de"`

Defined in: [enums/Plugins.ts:36](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L36)

***

### EN\_GB

> **EN\_GB**: `"en-GB"`

Defined in: [enums/Plugins.ts:37](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L37)

***

### EN\_US

> **EN\_US**: `"en-US"`

Defined in: [enums/Plugins.ts:38](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L38)

***

### ES

> **ES**: `"es"`

Defined in: [enums/Plugins.ts:39](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L39)

***

### FR

> **FR**: `"fr"`

Defined in: [enums/Plugins.ts:40](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L40)

***

### IT

> **IT**: `"it"`

Defined in: [enums/Plugins.ts:41](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L41)

***

### LV

> **LV**: `"lv"`

Defined in: [enums/Plugins.ts:42](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L42)

***

### NL

> **NL**: `"nl"`

Defined in: [enums/Plugins.ts:43](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L43)

***

### PL

> **PL**: `"pl"`

Defined in: [enums/Plugins.ts:44](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L44)

***

### PT\_BR

> **PT\_BR**: `"pt-BR"`

Defined in: [enums/Plugins.ts:45](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L45)

***

### PT

> **PT**: `"pt"`

Defined in: [enums/Plugins.ts:46](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L46)

***

### RO

> **RO**: `"ro"`

Defined in: [enums/Plugins.ts:47](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L47)

***

### SK

> **SK**: `"sk"`

Defined in: [enums/Plugins.ts:48](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L48)

***

### SL

> **SL**: `"sl"`

Defined in: [enums/Plugins.ts:49](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L49)

***

### SQ\_AL

> **SQ\_AL**: `"sq-AL"`

Defined in: [enums/Plugins.ts:50](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L50)

***

### FI

> **FI**: `"fi"`

Defined in: [enums/Plugins.ts:51](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L51)

***

### VI

> **VI**: `"vi"`

Defined in: [enums/Plugins.ts:52](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L52)

***

### TR

> **TR**: `"tr"`

Defined in: [enums/Plugins.ts:53](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L53)

***

### EL\_GR

> **EL\_GR**: `"el-GR"`

Defined in: [enums/Plugins.ts:54](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L54)

***

### BG

> **BG**: `"bg"`

Defined in: [enums/Plugins.ts:55](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L55)

***

### RU

> **RU**: `"ru"`

Defined in: [enums/Plugins.ts:56](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L56)

***

### SR\_CYRL\_RS

> **SR\_CYRL\_RS**: `"sr-Cyrl-RS"`

Defined in: [enums/Plugins.ts:57](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L57)

***

### SR\_LATN\_RS

> **SR\_LATN\_RS**: `"sr-Latn-RS"`

Defined in: [enums/Plugins.ts:58](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L58)

***

### UK\_UA

> **UK\_UA**: `"uk-UA"`

Defined in: [enums/Plugins.ts:59](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L59)

***

### HY\_AM

> **HY\_AM**: `"hy-AM"`

Defined in: [enums/Plugins.ts:60](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L60)

***

### AR\_SA

> **AR\_SA**: `"ar-SA"`

Defined in: [enums/Plugins.ts:61](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L61)

***

### SI

> **SI**: `"si"`

Defined in: [enums/Plugins.ts:62](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L62)

***

### LO\_LA

> **LO\_LA**: `"lo-LA"`

Defined in: [enums/Plugins.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L63)

***

### ZH\_CN

> **ZH\_CN**: `"zh-CN"`

Defined in: [enums/Plugins.ts:64](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L64)

***

### JA\_JP

> **JA\_JP**: `"ja-JP"`

Defined in: [enums/Plugins.ts:65](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L65)

***

### KO\_KR

> **KO\_KR**: `"ko-KR"`

Defined in: [enums/Plugins.ts:66](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L66)
