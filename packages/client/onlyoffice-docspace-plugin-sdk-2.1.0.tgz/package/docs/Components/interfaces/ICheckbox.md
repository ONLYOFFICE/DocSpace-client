# Interface: ICheckbox

Defined in: [interfaces/components/ICheckbox.ts:71](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L71)

Custom checkbox.

## Example

Privacy policy checkbox with submit button state control

```typescript
const privacyCheckbox: ICheckbox = {
  isChecked: false,
  label: "I agree to the Privacy Policy",
  onChange: () => {
    return {
      actions: [Actions.updateProps, Actions.updateContext],
      newProps: {
        isChecked: !privacyCheckbox.isChecked
      },
      contextProps: [{
        name: "submitButton",
        props: {
          isDisabled: !privacyCheckbox.isChecked
        }
      }]
    };
  },
  truncate: false,
  tabIndex: 1,
  hasError: false,
  name: "privacy-policy",
  value: "accepted",
  isIndeterminate: false,
  isDisabled: false,
  title: "Privacy Policy Agreement"
}
```

## Appearance

Properties that control the visual styling, truncation, and tab order of the checkbox.

### truncate?

> `optional` **truncate**: `boolean`

Defined in: [interfaces/components/ICheckbox.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L98)

Specifies if the word wrapping is disabled or not

***

### tabIndex?

> `optional` **tabIndex**: `number`

Defined in: [interfaces/components/ICheckbox.ts:105](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L105)

Defines the checkbox tab index

***

### title?

> `optional` **title**: `string`

Defined in: [interfaces/components/ICheckbox.ts:147](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L147)

Defines the checkbox input title

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/ICheckbox.ts:155](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L155)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Behavior

Callback functions for handling checkbox state changes and user interactions.

### onChange()

> **onChange**: () => `void` \| `IMessage`

Defined in: [interfaces/components/ICheckbox.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L91)

Sets a function which is triggered whenever the checkbox input is clicked

#### Returns

`void` \| `IMessage`

## Content

### label?

> `optional` **label**: `string`

Defined in: [interfaces/components/ICheckbox.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L84)

Defines the checkbox label

***

### name?

> `optional` **name**: `string`

Defined in: [interfaces/components/ICheckbox.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L119)

Defines the HTML "name" property

## State

Properties that control the checkbox's checked, error, indeterminate, and disabled states.

### isChecked

> **isChecked**: `boolean`

Defined in: [interfaces/components/ICheckbox.ts:77](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L77)

Sets the checked state of the checkbox

***

### hasError?

> `optional` **hasError**: `boolean`

Defined in: [interfaces/components/ICheckbox.ts:112](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L112)

Specifies whether a notification will be sent if an error occurs

***

### value?

> `optional` **value**: `string`

Defined in: [interfaces/components/ICheckbox.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L126)

Defines the checkbox input value

***

### isIndeterminate?

> `optional` **isIndeterminate**: `boolean`

Defined in: [interfaces/components/ICheckbox.ts:133](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L133)

Specifies whether the checkbox state will be displayed as a black rectangle in the checkbox when it is set to true

***

### isDisabled?

> `optional` **isDisabled**: `boolean`

Defined in: [interfaces/components/ICheckbox.ts:140](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L140)

Specifies if the checkbox input is disabled
