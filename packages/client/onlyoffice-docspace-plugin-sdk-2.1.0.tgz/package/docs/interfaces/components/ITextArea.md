# ITextArea

Defined in: [interfaces/components/ITextArea.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L99)

Custom textarea.

![textarea](/assets/images/docspace/textarea.png#gh-light-mode-only)![textarea](/assets/images/docspace/textarea.dark.png#gh-dark-mode-only)

## Properties

### value

```ts
value: string;
```

Defined in: [interfaces/components/ITextArea.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L103)

Defines the textarea value.

### onChange()

```ts
onChange: (value: string) => void | IMessage;
```

Defined in: [interfaces/components/ITextArea.ts:108](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L108)

Sets a function which is triggered whenever the textarea is changed.

#### Parameters

##### value

`string`

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### placeholder?

```ts
optional placeholder: string;
```

Defined in: [interfaces/components/ITextArea.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L113)

Defines the textarea placeholder.

### isDisabled?

```ts
optional isDisabled: boolean;
```

Defined in: [interfaces/components/ITextArea.ts:118](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L118)

Specifies whether the textarea is disabled.

### isReadOnly?

```ts
optional isReadOnly: boolean;
```

Defined in: [interfaces/components/ITextArea.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L123)

Specifies whether the textarea displays the read-only content.

### hasError?

```ts
optional hasError: boolean;
```

Defined in: [interfaces/components/ITextArea.ts:128](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L128)

Specifies whether to indicate that there is an error in the textarea.

### maxLength?

```ts
optional maxLength: number;
```

Defined in: [interfaces/components/ITextArea.ts:133](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L133)

Defines the maximum value length in the textarea.

### name?

```ts
optional name: string;
```

Defined in: [interfaces/components/ITextArea.ts:138](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L138)

Defines the textarea HTML "name" property.

### tabIndex?

```ts
optional tabIndex: number;
```

Defined in: [interfaces/components/ITextArea.ts:143](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L143)

Defines the textarea HTML "tabindex" property.

### fontSize?

```ts
optional fontSize: number;
```

Defined in: [interfaces/components/ITextArea.ts:148](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L148)

Defines the textarea font size.

### heightTextArea?

```ts
optional heightTextArea: string | number;
```

Defined in: [interfaces/components/ITextArea.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L153)

Defines the textarea height.

### isJSONField?

```ts
optional isJSONField: boolean;
```

Defined in: [interfaces/components/ITextArea.ts:158](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L158)

Specifies whether the textarea is prettified for JSON and the line numeration is added.

### enableCopy?

```ts
optional enableCopy: boolean;
```

Defined in: [interfaces/components/ITextArea.ts:163](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L163)

Specifies whether the "Copy" icon is displayed in the textarea.

### hasNumeration?

```ts
optional hasNumeration: boolean;
```

Defined in: [interfaces/components/ITextArea.ts:168](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L168)

Specifies whether the numeration is inserted into the textarea.

### isFullHeight?

```ts
optional isFullHeight: boolean;
```

Defined in: [interfaces/components/ITextArea.ts:173](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L173)

Specifies whether the height of the textarea content is calculated depending on the number of lines.

### heightScale?

```ts
optional heightScale: boolean;
```

Defined in: [interfaces/components/ITextArea.ts:178](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L178)

Specifies whether the textarea has a height scale.

### copyInfoText?

```ts
optional copyInfoText: boolean;
```

Defined in: [interfaces/components/ITextArea.ts:183](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L183)

Specifies whether the toast / information text will be displayed when copying.

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/ITextArea.ts:189](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ITextArea.ts#L189)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Examples

JSON configuration editor with syntax validation

```typescript
const configEditor: ITextArea = {
  value: JSON.stringify({
    apiKey: "your-api-key",
    endpoint: "https://api.example.com",
    timeout: 5000
  }, null, 2),
  onChange: (value) => {
    try {
      JSON.parse(value);
      return {
        actions: [Actions.updateProps],
        newProps: {
          value,
          hasError: false
        }
      };
    } catch (error) {
      return {
        actions: [Actions.updateProps, Actions.showToast],
        newProps: {
          value,
          hasError: true
        },
        toastProps: [{
          title: "Please check your JSON syntax",
          type: ToastType.error
        }]
      };
    }
  },
  placeholder: "Enter JSON configuration...",
  isJSONField: true,
  enableCopy: true,
  hasNumeration: true,
  heightTextArea: 300,
  fontSize: 14,
  copyInfoText: true
}
```

Character-limited comment box with dynamic validation

```typescript
const commentBox: ITextArea = {
  value: "",
  onChange: (value) => {
    const hasError = value.length > 500;
    return {
      actions: [Actions.updateProps],
      newProps: {
        value,
        hasError
      }
    };
  },
  placeholder: "Add your comment (max 500 characters)",
  maxLength: 500,
  heightTextArea: "120px",
  isFullHeight: true,
  heightScale: true,
  fontSize: 16,
  name: "comment",
  tabIndex: 1
}
```

