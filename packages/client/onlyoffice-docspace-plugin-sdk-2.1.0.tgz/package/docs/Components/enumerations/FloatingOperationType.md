# Enumeration: FloatingOperationType

Defined in: [interfaces/components/IFloatingOperationsButton.ts:252](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L252)

Determines the icon and visual representation of the operation.

## Enumeration Members

### Download

> **Download**: `"download"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:254](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L254)

File download operation

***

### Convert

> **Convert**: `"convert"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:256](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L256)

File conversion operation

***

### Copy

> **Copy**: `"copy"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:258](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L258)

File copy operation

***

### Duplicate

> **Duplicate**: `"duplicate"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:260](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L260)

File duplication operation

***

### MarkAsRead

> **MarkAsRead**: `"markAsRead"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:262](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L262)

Mark as read operation

***

### DeletePermanently

> **DeletePermanently**: `"deletePermanently"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:264](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L264)

Permanent deletion operation

***

### ExportIndex

> **ExportIndex**: `"exportIndex"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:266](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L266)

Export index operation

***

### Move

> **Move**: `"move"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:268](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L268)

File move operation

***

### Trash

> **Trash**: `"trash"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:270](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L270)

Move to trash operation

***

### Other

> **Other**: `"other"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:272](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L272)

Other custom operation

***

### Upload

> **Upload**: `"upload"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:274](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L274)

File upload operation

***

### DeleteVersionFile

> **DeleteVersionFile**: `"deleteVersionFile"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:276](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L276)

Delete file version operation

***

### Backup

> **Backup**: `"backup"`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:278](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L278)

Backup operation
