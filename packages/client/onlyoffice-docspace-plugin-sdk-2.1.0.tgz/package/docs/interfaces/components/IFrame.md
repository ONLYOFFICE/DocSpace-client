# IFrame

Defined in: [interfaces/components/IFrame.ts:64](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L64)

A component that is used to embed a third-party website into a modal window or the settings page.

![iframe](/assets/images/docspace/iframe.png#gh-light-mode-only)![iframe](/assets/images/docspace/iframe.dark.png#gh-dark-mode-only)

## Properties

### src

```ts
src: string;
```

Defined in: [interfaces/components/IFrame.ts:67](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L67)

Defines the base URL to a modal window or the settings page. It is used to generate links

### width?

```ts
optional width: string;
```

Defined in: [interfaces/components/IFrame.ts:71](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L71)

Defines the frame width measured in percent

### height?

```ts
optional height: string;
```

Defined in: [interfaces/components/IFrame.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L75)

Defines the frame height measured in percent

### name?

```ts
optional name: string;
```

Defined in: [interfaces/components/IFrame.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L79)

Defines the name of the object inserted into the page

### sandbox?

```ts
optional sandbox: string;
```

Defined in: [interfaces/components/IFrame.ts:83](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L83)

Defines the frame sandbox

### id?

```ts
optional id: string;
```

Defined in: [interfaces/components/IFrame.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L87)

Defines the element ID

### style?

```ts
optional style: {
[key: string]: string;
};
```

Defined in: [interfaces/components/IFrame.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L91)

Defines the frame style

#### Index Signature

```ts
[key: string]: string
```

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IFrame.ts:97](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFrame.ts#L97)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Examples

Embedding a PDF viewer in a modal window

```typescript
const pdfViewer: IFrame = {
  src: "https://example.com/pdf-viewer",
  width: "100%",
  height: "80%",
  name: "pdf-viewer-frame",
  sandbox: "allow-scripts allow-same-origin allow-forms",
  id: "pdf-viewer-iframe",
  style: {
    border: "none",
    borderRadius: "8px",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)"
  }
}
```

Embedding a settings configuration page

```typescript
const settingsConfig: IFrame = {
  src: "https://example.com/plugin-settings",
  width: "100%",
  height: "100%",
  name: "plugin-settings",
  sandbox: "allow-scripts allow-same-origin allow-forms allow-popups",
  id: "settings-iframe",
  style: {
    border: "1px solid #eceef1",
    backgroundColor: "#ffffff",
    padding: "16px"
  }
}
```

