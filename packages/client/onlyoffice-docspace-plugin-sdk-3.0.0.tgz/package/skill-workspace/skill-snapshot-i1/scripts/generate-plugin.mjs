#!/usr/bin/env node

/*
 * Scaffolds a DocSpace plugin project that builds and passes validate-plugin.mjs
 * as-is, so that real work starts from something running rather than from a
 * blank file.
 *
 * This exists instead of `npx create-docspace-plugin` because that one is built
 * on inquirer: it blocks waiting for keyboard input, which hangs a tool call.
 *
 * What the loader calls on each scope comes from contract.mjs; the templates
 * below only say what code to emit for it.
 *
 * Usage:
 *   node scripts/generate-plugin.mjs --name my-plugin --plugin-name MyPlugin \
 *     --scopes ContextMenu,MainButton --dir ./my-plugin
 *
 * Options:
 *   --name          portal identifier, lower case, [a-z_-]        (required)
 *   --plugin-name   JS class name == window.Plugins.<pluginName>  (required)
 *   --scopes        comma separated, see the table below          (required)
 *   --dir           target directory (default: ./<name>)
 *   --description   one line description for the manifest
 *   --author        manifest author
 *   --locales       comma separated extra locales, e.g. ru,de     (en is always present)
 *   --force         write into a non-empty directory
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

import { SCOPE_CONTRACT, SCOPES, SDK_PACKAGE } from "./contract.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const templates = path.join(here, "..", "templates");

const SDK = SDK_PACKAGE;
const SDK_RANGE = "^2.1.0";

/**
 * What each scope contributes to the generated class. Member names, item
 * interfaces and map keys are not repeated here - they come from
 * SCOPE_CONTRACT. `types` lists only the *extra* SDK imports the emitted code
 * needs, and `starter` is a single working item so the plugin does something
 * visible on first upload and the validator's runtime pass has a non-empty map
 * to look at.
 */
const SCOPE_SPECS = {
  API: {
    types: [],
    members: () => `  origin = "";

  proxy = "";

  prefix = "";

  setOrigin = (origin: string): void => {
    this.origin = origin;
  };

  getOrigin = (): string => this.origin;

  setProxy = (proxy: string): void => {
    this.proxy = proxy;
  };

  getProxy = (): string => this.proxy;

  setPrefix = (prefix: string): void => {
    this.prefix = prefix;
  };

  getPrefix = (): string => this.prefix;

  setAPI = (origin: string, proxy: string, prefix: string): void => {
    this.origin = origin;
    this.proxy = proxy;
    this.prefix = prefix;
  };

  getAPI = (): { origin: string; proxy: string; prefix: string } => ({
    origin: this.origin,
    proxy: this.proxy,
    prefix: this.prefix,
  });
`,
  },

  Settings: {
    types: ["ISettings"],
    members: () => `  adminPluginSettings: ISettings | null = null;

  setAdminPluginSettings = (settings: ISettings | null): void => {
    this.adminPluginSettings = settings;
  };

  // The portal hands settings back as the raw string the plugin saved earlier,
  // and it arrives *after* installation - so parse defensively.
  setAdminPluginSettingsValue = (settings: string | null): void => {
    if (!settings) return;

    try {
      JSON.parse(settings);
    } catch {
      // Ignore malformed stored settings rather than breaking installation.
    }
  };

  getAdminPluginSettings = (): ISettings | null => this.adminPluginSettings;
`,
  },

  PostMessage: {
    types: ["IPostMessageCallbackMessage"],
    members: () => `  postMessageCallback: (message: IPostMessageCallbackMessage) => void = () => {};

  setPostMessageCallback = (callback: (message: IPostMessageCallbackMessage) => void): void => {
    this.postMessageCallback = callback;
  };

  getPostMessageCallback = (): ((message: IPostMessageCallbackMessage) => void) =>
    this.postMessageCallback;
`,
  },

  ContextMenu: {
    types: ["FilesType"],
    extraMethods: (n) => `  getContextMenuItemsKeys = (): string[] => Array.from(this.${n.map}.keys());
`,
    starter: (n) => `const ${n.fn}ContextMenuItem = (): IContextMenuItem => ({
  key: "${n.name}-context-menu",
  label: t("contextMenu.label"),
  icon: "icon-16.svg",
  fileType: [FilesType.file],
  // The host reads usersTypes (plural) for this scope.
  onItemClick: async (id: string | number) => ({
    actions: [Actions.showToast],
    toastProps: [{ type: ToastType.info, title: \`\${t("contextMenu.label")}: \${id}\` }],
  }),
});
`,
    icons: ["icon-16.svg"],
  },

  MainButton: {
    types: [],
    starter: (n) => `const ${n.fn}MainButtonItem = (): IMainButtonItem => ({
  key: "${n.name}-main-button",
  label: t("mainButton.label"),
  icon: "icon-16.svg",
  // The host reads usersType (singular) for this scope.
  onItemClick: async (id: number | string) => ({
    actions: [Actions.showToast],
    toastProps: [{ type: ToastType.info, title: \`\${t("mainButton.label")}: \${id}\` }],
  }),
});
`,
    icons: ["icon-16.svg"],
  },

  ProfileMenu: {
    types: [],
    starter: (n) => `const ${n.fn}ProfileMenuItem = (): IProfileMenuItem => ({
  key: "${n.name}-profile-menu",
  label: t("profileMenu.label"),
  icon: "icon-16.svg",
  // onClick is mandatory here and takes no arguments.
  onClick: async () => ({
    actions: [Actions.showToast],
    toastProps: [{ type: ToastType.info, title: t("profileMenu.label") }],
  }),
});
`,
    icons: ["icon-16.svg"],
  },

  InfoPanel: {
    types: ["IBox", "Components"],
    starter: (n) => `const ${n.fn}InfoPanelBody = (): IBox => ({
  children: [
    {
      component: Components.text,
      props: { text: t("infoPanel.body") },
    },
  ],
});

const ${n.fn}InfoPanelItem = (): IInfoPanelItem => ({
  key: "${n.name}-info-panel",
  subMenu: { name: t("infoPanel.tab") },
  body: ${n.fn}InfoPanelBody(),
});
`,
  },

  EventListener: {
    types: ["Events"],
    starter: (n) => `const ${n.fn}EventListenerItem = (): IEventListenerItem => ({
  key: "${n.name}-event-listener",
  eventType: Events.CREATE,
  // The handler receives no arguments, and once an event has fired the host
  // only honours item updates and toasts - other actions are ignored.
  eventHandler: async () => ({
    actions: [Actions.showToast],
    toastProps: [{ type: ToastType.info, title: t("eventListener.fired") }],
  }),
});
`,
  },

  File: {
    types: ["File"],
    starter: (n) => `const ${n.fn}FileItem = (): IFileItem => ({
  // Claiming an extension another plugin also claims means the last one loaded wins.
  extension: ".${n.name}",
  fileTypeName: t("file.typeName"),
  fileRowIcon: "icon-32.svg",
  fileTileIcon: "icon-96.svg",
  onClick: async (file: File) => ({
    actions: [Actions.showToast],
    toastProps: [{ type: ToastType.info, title: file.title }],
  }),
});
`,
    icons: ["icon-32.svg", "icon-96.svg"],
  },

  ArticleButton: {
    types: ["IBox", "Components", "ButtonSize"],
    starter: (n) => `const ${n.fn}ArticleButtonBody = (): IBox => ({
  children: [
    {
      component: Components.button,
      props: {
        label: t("articleButton.label"),
        size: ButtonSize.normal,
        scale: true,
        onClick: async () => ({
          actions: [Actions.showToast],
          toastProps: [{ type: ToastType.info, title: t("articleButton.label") }],
        }),
      },
    },
  ],
});

// The whole portal shows at most five article buttons across all plugins.
const ${n.fn}ArticleButtonItem = (): IArticleButtonItem => ({
  key: "${n.name}-article-button",
  body: ${n.fn}ArticleButtonBody(),
});
`,
  },
};

// --- arguments ---------------------------------------------------------------

const argv = process.argv.slice(2);
const flag = (name) => {
  const i = argv.indexOf(`--${name}`);
  return i === -1 ? undefined : argv[i + 1];
};
const has = (name) => argv.includes(`--${name}`);

const fail = (message) => {
  console.error(`error: ${message}`);
  process.exit(1);
};

const name = flag("name");
const pluginName = flag("plugin-name");
const scopesArg = flag("scopes");

if (!name) fail("--name is required");
if (!pluginName) fail("--plugin-name is required");
if (!scopesArg) fail("--scopes is required");

if (!/^[a-z][a-z_-]*$/.test(name))
  fail(`--name "${name}" must be lower case letters, - and _ only (the packer lower-cases it anyway)`);

if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(pluginName))
  fail(`--plugin-name "${pluginName}" must be a valid JS identifier - it becomes window.Plugins.${pluginName}`);

const scopes = scopesArg.split(",").map((s) => s.trim()).filter(Boolean);

for (const s of scopes) {
  if (!SCOPES.includes(s) || !SCOPE_SPECS[s])
    fail(`unknown scope "${s}" (known: ${SCOPES.join(", ")})`);
}

const dir = path.resolve(flag("dir") ?? `./${name}`);
const description = flag("description") ?? `DocSpace plugin ${name}`;
const author = flag("author") ?? "";
const extraLocales = (flag("locales") ?? "").split(",").map((s) => s.trim()).filter(Boolean);

if (fs.existsSync(dir) && fs.readdirSync(dir).length > 0 && !has("force"))
  fail(`${dir} is not empty - pass --force to write into it anyway`);

// --- helpers -----------------------------------------------------------------

const names = {
  name,
  pluginName,
  // Lower-camel prefix for the generated item factories.
  fn: pluginName.charAt(0).toLowerCase() + pluginName.slice(1),
};

const write = (relative, contents) => {
  const target = path.join(dir, relative);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, contents);
};

const copyTemplate = (from, to) =>
  write(to, fs.readFileSync(path.join(templates, from), "utf8"));

const LICENSE_HEADER = `/*
 * (c) Copyright Ascensio System SIA ${new Date().getFullYear()}
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
`;

const selected = scopes.map((s) => ({
  scope: s,
  spec: SCOPE_SPECS[s],
  contract: SCOPE_CONTRACT[s],
}));

// Scopes the loader reads through a map, as opposed to plain members.
const mapped = selected.filter(({ contract }) => contract.field);

/** The item factory the starter template defines for a scope. */
const factory = (scope) => `${names.fn}${scope}Item`;

// --- src/index.ts ------------------------------------------------------------

const sdkTypes = new Set(["IPlugin", "PluginStatus", "PluginLocale"]);
for (const { spec, contract } of selected) {
  sdkTypes.add(contract.iface);
  if (contract.item) sdkTypes.add(contract.item);
  for (const t of spec.types) sdkTypes.add(t);
}
if (mapped.length > 0) {
  sdkTypes.add("Actions");
  sdkTypes.add("ToastType");
}

const mapFields = mapped
  .map(({ contract }) => `  ${contract.field}: Map<string, ${contract.item}> = new Map();\n`)
  .join("\n");

const mapMethods = mapped
  .map(({ scope, spec, contract }) => {
    const { field, item, key, adder, getter, updater } = contract;

    const extra = spec.extraMethods ? `\n${spec.extraMethods({ map: field })}` : "";

    // EventListener is the one scope with no updater in the SDK.
    const update = updater
      ? `\n  ${updater} = (item: ${item}): void => {
    this.${field}.set(item.${key}, item);
  };\n`
      : "";

    return `  ${adder} = (item: ${item}): void => {
    this.${field}.set(item.${key}, item);
  };

  ${getter} = (): Map<string, ${item}> => this.${field};
${extra}${update}`;
  })
  .join("\n");

const scopeMembers = selected
  .filter(({ spec }) => spec.members)
  .map(({ spec }) => spec.members(names))
  .join("\n");

const starters = mapped.map(({ spec }) => spec.starter(names)).join("\n");

const registrations = mapped
  .map(({ scope, contract }) => `    this.${contract.adder}(${factory(scope)}());`)
  .join("\n");

const interfaces = ["IPlugin", ...selected.map(({ contract }) => contract.iface)];

const indexTs = `${LICENSE_HEADER}
import {
${[...sdkTypes].sort().map((t) => `  ${t},`).join("\n")}
} from "${SDK}";

import { currentLocale, setLocale, t } from "./locales";

${starters}
class ${pluginName}
  implements
${interfaces.map((i) => `    ${i}`).join(",\n")}
{
  status: PluginStatus = PluginStatus.active;

${mapFields}${scopeMembers ? `\n${scopeMembers}` : ""}
  // Register items here rather than at module scope. Both are read in time, but
  // setLanguage and setAPI only run after the bundle executes - so a factory that
  // translates a label or calls getAPI() at module scope would capture empty values.
  onLoadCallback = async (): Promise<void> => {
${registrations || "    // no items for the declared scopes"}
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  // The portal calls this when the interface language changes. Labels were
  // captured when the items were built, so the items have to be rebuilt.
  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
${
  mapped
    .map(
      ({ scope, contract }) =>
        // EventListener has no updater - re-adding overwrites by key just the same.
        `    this.${contract.updater ?? contract.adder}(${factory(scope)}());`,
    )
    .join("\n") || "    // nothing to rebuild"
}
  };

  getLanguage = (): PluginLocale => currentLocale();

${mapMethods}}

const plugin = new ${pluginName}();

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.${pluginName} = plugin || {};

export default plugin;
`;

// --- src/locales.ts ----------------------------------------------------------

const stringKeys = [];
for (const { scope } of selected) {
  if (scope === "ContextMenu") stringKeys.push(["contextMenu.label", "Do the thing"]);
  if (scope === "MainButton") stringKeys.push(["mainButton.label", "New thing"]);
  if (scope === "ProfileMenu") stringKeys.push(["profileMenu.label", "My thing"]);
  if (scope === "InfoPanel")
    stringKeys.push(["infoPanel.tab", "Thing"], ["infoPanel.body", "Nothing here yet."]);
  if (scope === "EventListener") stringKeys.push(["eventListener.fired", "Something happened"]);
  if (scope === "File") stringKeys.push(["file.typeName", "Thing file"]);
  if (scope === "ArticleButton") stringKeys.push(["articleButton.label", "Open thing"]);
}

const localeTable = (values) =>
  `{\n${stringKeys.map(([k, v]) => `  "${k}": ${JSON.stringify(values ? `${v}` : v)},`).join("\n")}\n}`;

const localesTs = `${LICENSE_HEADER}
import { PluginLocale } from "${SDK}";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 */
export type TStrings = {
${stringKeys.map(([k]) => `  "${k}": string;`).join("\n")}
};

const en: TStrings = ${localeTable(false)};

${extraLocales
  .map(
    (l) =>
      `// TODO: translate\nconst ${l.replace(/[^a-z0-9]/gi, "_")}: TStrings = ${localeTable(false)};\n`,
  )
  .join("\n")}
const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.EN_US]: en,
${extraLocales.map((l) => `  "${l}": ${l.replace(/[^a-z0-9]/gi, "_")},`).join("\n")}
};

let locale: PluginLocale = PluginLocale.EN_US;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.EN_US;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings): string => (translations[locale] ?? en)[key];
`;

// --- package.json ------------------------------------------------------------

const pkg = {
  name,
  version: "1.0.0",
  description,
  author,
  license: "Apache-2.0",
  homepage: "",
  main: "index.ts",
  private: true,
  pluginName,
  logo: "logo.svg",
  nameLocale: {},
  descriptionLocale: {},
  scopes,
  scripts: {
    build: "webpack && npx build-docspace-plugin",
    format: "npx prettier --write .",
  },
  dependencies: {
    [SDK]: SDK_RANGE,
  },
  devDependencies: {
    prettier: "2.8.6",
    "ts-loader": "^9.6.2",
    typescript: "^6.0.3",
    webpack: "^5.108.3",
    "webpack-cli": "^7.1.0",
  },
};

// --- assets ------------------------------------------------------------------

const placeholderIcon = (size, label) =>
  `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <rect width="${size}" height="${size}" rx="${Math.max(2, Math.round(size / 8))}" fill="#4781D1"/>
  <text x="50%" y="50%" text-anchor="middle" dominant-baseline="central" fill="#fff"
        font-family="Arial, sans-serif" font-size="${Math.round(size * 0.5)}">${label}</text>
</svg>
`;

const iconSizes = new Map([["logo.svg", 48]]);
for (const { spec } of selected)
  for (const icon of spec.icons ?? [])
    iconSizes.set(icon, Number(icon.match(/(\d+)/)?.[1] ?? 16));

// --- write it out ------------------------------------------------------------

// Templates are stored under inert names so that editors and linters do not
// treat this repository's copies as live project config.
write("package.json", `${JSON.stringify(pkg, null, 2)}\n`);
copyTemplate("tsconfig", "tsconfig.json");
copyTemplate("webpack.config", "webpack.config.js");
copyTemplate("prettierrc.json", ".prettierrc.json");
copyTemplate("gitignore", ".gitignore");

write("src/index.ts", indexTs);
write("src/locales.ts", localesTs);

for (const [file, size] of iconSizes)
  write(`assets/${file}`, placeholderIcon(size, pluginName.charAt(0).toUpperCase()));

write(
  "README.md",
  `# ${name}

${description}

## Build

\`\`\`sh
npm install
npm run build
\`\`\`

The uploadable archive is \`dist/plugin.zip\`.

## Install

Upload \`dist/plugin.zip\` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump \`version\` in \`package.json\` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

## Scopes

${scopes.map((s) => `- \`${s}\``).join("\n")}
`,
);

write(
  "CHANGELOG.md",
  `# Change Log

## 1.0.0

### Added

- Initial version.
`,
);

const iconList = [...iconSizes.keys()].map((i) => `assets/${i}`).join(", ");

console.log(`Scaffolded ${pluginName} (${name}) in ${dir}`);
console.log(`  scopes:      ${scopes.join(", ")}`);
console.log(`  registered:  window.Plugins.${pluginName}`);
console.log(`  placeholders: ${iconList} - replace these with real icons`);
console.log(`\nNext: cd ${dir} && npm install && npm run build`);
