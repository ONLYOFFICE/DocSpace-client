# `usersType` или `usersTypes` — правильны оба, но каждый в своём scope

Короткий ответ: это **не опечатка и не два варианта одного и того же поля**. Портал читает **разное имя поля в разных scope**, и SDK просто повторяет эту непоследовательность в типах. Поэтому вы и видели оба — и оба были правильными в своих местах.

## Таблица: какое имя в каком scope

| Поле | Scopes |
|---|---|
| `usersTypes` (множественное) | `ContextMenu`, `InfoPanel`, `EventListener`, `ArticleButton` |
| `usersType` (единственное) | `MainButton`, `ProfileMenu`, `File` |

Мнемоники нет — это историческая случайность в коде хоста, а не какое-то правило («у пунктов меню так, у панелей эдак»). Запоминать бесполезно, проще каждый раз свериться с таблицей.

Отдельно: в `IMediaViewer` (в том числе в `playlistFilter`) поле тоже называется `usersTypes`, во множественном.

## Как это выглядит в коде

```ts
// ContextMenu — множественное
this.contextMenuItems.set("myplugin-convert", {
  key: "myplugin-convert",
  label: "Convert",
  icon: "icon-16.svg",
  usersTypes: [UsersType.owner, UsersType.docSpaceAdmin, UsersType.roomAdmin],
  onItemClick: async (id) => ({ actions: [Actions.showToast], toastProps: [...] }),
});

// MainButton — единственное
this.mainButtonItems.set("myplugin-create", {
  key: "myplugin-create",
  label: "Create report",
  icon: "icon-16.svg",
  usersType: [UsersType.docSpaceAdmin],
  onItemClick: async (folderId) => ({ actions: [Actions.showModal], modalDialogProps: {...} }),
});
```

Обратите внимание: **в обоих случаях значение — массив**. Единственное число в `usersType` относится только к имени поля, а не к количеству ролей.

## Почему оба компилируются, хотя одно из них в конкретном месте неверно

Три причины складываются:

1. **Это разные интерфейсы.** `IContextMenuItem` объявляет `usersTypes?`, `IMainButtonItem` — `usersType?`. Каждый по-своему валиден, компилятору не с чем сравнивать.
2. **Поле необязательное.** Пропуск фильтра — легальный случай (пункт виден всем), так что отсутствие «правильного» поля ошибкой не является.
3. **Проверка лишних свойств (excess property check) в TypeScript срабатывает только на литерале объекта, записанном прямо в месте присваивания.** А объекты пунктов почти всегда собирают через промежуточную переменную или фабрику:

```ts
const item = {                      // тип выводится сам, никакой сверки с IContextMenuItem
  key: "room-stats",
  usersType: [UsersType.roomAdmin], // неверное имя для ContextMenu
  // ...
};

this.contextMenuItems.set(item.key, item); // переменная, а не литерал → проверка не срабатывает
```

Здесь `usersType` просто становится частью выведенного типа и проходит структурную проверку — лишнее поле никого не смущает. Если написать тот же литерал прямо в `.set({...})`, TS ругнётся, но так почти никто не пишет.

## Что происходит на портале при неверном имени

Ничего заметного — и это самое неприятное. Хост читает своё имя поля, не находит его, и **фильтр просто пропускается**: пункт показывается **всем пользователям**. Ни ошибки в консоли, ни предупреждения при установке. Симптом, с которым к этому обычно приходят, звучит как «плагин показывается не тем пользователям» — и это ровно тот случай.

## Значения: берите из enum, а не строками

`UsersType` — ключи в camelCase, значения в PascalCase:

| Ключ | Значение на проводе |
|---|---|
| `UsersType.owner` | `"Owner"` |
| `UsersType.docSpaceAdmin` | `"DocSpaceAdmin"` |
| `UsersType.roomAdmin` | `"RoomAdmin"` |
| `UsersType.collaborator` | `"Collaborator"` |
| `UsersType.user` | `"User"` |

Пишите `UsersType.roomAdmin`, а не `"roomAdmin"`: строка с ключом enum скомпилируется (тип-то `string[]` после расширения), но хост сравнивает с `"RoomAdmin"` и не совпадёт — снова тихо, снова пункт для всех.

## Пара полезных деталей

- **Фильтры вычисляются при открытии меню, а не при регистрации.** Смена роли пользователя применяется сразу, перезагрузка плагина не нужна.
- **`devices` работает во всех scope, кроме `File`** — там проверка устройства происходит уже внутри `onClick`.
- `usersTypes`/`usersType` — фильтр отображения, а не безопасность. Для ограничений по правам используйте `security` (права на родительской папке/комнате) и `itemSecurity` / `fileSecurity` (права на самом элементе).

## Как больше не попадаться

Не полагайтесь на компилятор — он это не ловит. Прогоняйте валидатор, он проверяет имя поля по scope и значения по enum:

```sh
node "$SKILL/scripts/validate-plugin.mjs" <папка-плагина> --invoke
```

На неверном имени он выдаёт ошибку класса `item` с явным текстом вида «host reads usersTypes for ContextMenu», а на значении вне enum — `usersTypes contains "admin"`.

---

Проверено по клиенту DocSpace `v3.7.2-server` и по интерфейсам SDK (`src/interfaces/items/*.ts`, `src/enums/UsersType.ts`).
