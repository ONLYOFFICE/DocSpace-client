# ILabel

Defined in: [interfaces/components/ILabel.ts:55](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L55)

Field name in the form.

![label](/assets/images/docspace/label.png#gh-light-mode-only)![label](/assets/images/docspace/label.dark.png#gh-dark-mode-only)

## Properties

### text

```ts
text: string;
```

Defined in: [interfaces/components/ILabel.ts:58](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L58)

Defines the element text

### isRequired?

```ts
optional isRequired: boolean;
```

Defined in: [interfaces/components/ILabel.ts:62](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L62)

Specifies whether the field to which the label is attached is required

### error?

```ts
optional error: boolean;
```

Defined in: [interfaces/components/ILabel.ts:66](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L66)

Specifies whether the field to which the label is attached is incorrect

### title?

```ts
optional title: string;
```

Defined in: [interfaces/components/ILabel.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L70)

Defines the label title

### truncate?

```ts
optional truncate: boolean;
```

Defined in: [interfaces/components/ILabel.ts:74](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L74)

Specifies whether the word wrapping is disabled

### htmlFor?

```ts
optional htmlFor: string;
```

Defined in: [interfaces/components/ILabel.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L78)

Defines the field ID to which the label is attached

### display?

```ts
optional display: string;
```

Defined in: [interfaces/components/ILabel.ts:82](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L82)

Specifies whether the "display" property is set

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/ILabel.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILabel.ts#L88)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Examples

Required field label with inline display

```typescript
const emailLabel: ILabel = {
  text: "Email Address",
  isRequired: true,
  error: false,
  title: "Enter your email address",
  htmlFor: "email-input",
  display: "flex"
}
```

Error state label with truncation and block display

```typescript
const longFieldLabel: ILabel = {
  text: "Document Processing Configuration Settings",
  isRequired: false,
  error: true,
  truncate: true,
  title: "Configure document processing settings",
  htmlFor: "doc-settings",
  display: "block"
}
```

