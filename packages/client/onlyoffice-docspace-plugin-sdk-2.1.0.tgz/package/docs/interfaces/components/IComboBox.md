# IComboBox

Defined in: [interfaces/components/IComboBox.ts:82](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L82)

Custom combo box input.

![combobox](/assets/images/docspace/combobox.png#gh-light-mode-only)![combobox](/assets/images/docspace/combobox.dark.png#gh-dark-mode-only)

## Properties

### options

```ts
options: IComboBoxItem[];
```

Defined in: [interfaces/components/IComboBox.ts:86](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L86)

Defines the combo box options

### selectedOption

```ts
selectedOption: IComboBoxItem;
```

Defined in: [interfaces/components/IComboBox.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L91)

Defines the combo box selected option

### onSelect()?

```ts
optional onSelect: (item: IComboBoxItem) => void | IMessage;
```

Defined in: [interfaces/components/IComboBox.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L96)

Sets a function which is triggered whenever the combo box is selected

#### Parameters

##### item

[`IComboBoxItem`](#icomboboxitem)

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### scaled?

```ts
optional scaled: boolean;
```

Defined in: [interfaces/components/IComboBox.ts:101](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L101)

Specifies that the combo box is scaled by its parent

### directionX?

```ts
optional directionX: "left" | "right";
```

Defined in: [interfaces/components/IComboBox.ts:106](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L106)

Defines the position of the combo box in the X direction

### directionY?

```ts
optional directionY: "both" | "top" | "bottom";
```

Defined in: [interfaces/components/IComboBox.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L111)

Defines the position of the combo box in the Y direction

### displayType?

```ts
optional displayType: "default" | "toggle";
```

Defined in: [interfaces/components/IComboBox.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L116)

Defines the combo box display type

### modernView?

```ts
optional modernView: boolean;
```

Defined in: [interfaces/components/IComboBox.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L121)

Specifies whether to display the combo box in the modern view

### isDisabled?

```ts
optional isDisabled: boolean;
```

Defined in: [interfaces/components/IComboBox.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L126)

Specifies if the combo box is disabled or not

### showDisabledItems?

```ts
optional showDisabledItems: boolean;
```

Defined in: [interfaces/components/IComboBox.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L131)

Whether to show disabled combo box options

### opened?

```ts
optional opened: boolean;
```

Defined in: [interfaces/components/IComboBox.ts:136](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L136)

Specifies whether to open the combo box

### scaledOptions?

```ts
optional scaledOptions: boolean;
```

Defined in: [interfaces/components/IComboBox.ts:141](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L141)

Specifies whether the combo box options are scaled by the combo box button

### onToggle()?

```ts
optional onToggle: () => void | IMessage;
```

Defined in: [interfaces/components/IComboBox.ts:146](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L146)

Sets a function which is triggered whenever the combo box is clicked when "displayType == toggle"

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### noBorder?

```ts
optional noBorder: boolean;
```

Defined in: [interfaces/components/IComboBox.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L151)

Specifies whether to display the combo box without borders

### withBackdrop?

```ts
optional withBackdrop: boolean;
```

Defined in: [interfaces/components/IComboBox.ts:156](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L156)

Specifies whether the combo box contains a backdrop

### dropDownMaxHeight?

```ts
optional dropDownMaxHeight: number;
```

Defined in: [interfaces/components/IComboBox.ts:161](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L161)

Defines the maximum height of the dropdown list

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IComboBox.ts:167](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L167)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

***

## Example

Multi-language selector with toast notifications

```typescript
const languageSelector: IComboBox = {
  options: [
    {
      key: "en-US",
      label: "English (US)",
      icon: "language-en.svg"
    },
    {
      key: "es-ES",
      label: "Español",
      icon: "language-es.svg"
    },
    {
      key: "fr-FR",
      label: "Français",
      icon: "language-fr.svg",
      disabled: true
    }
  ],
  selectedOption: {
    key: "en-US",
    label: "English (US)",
    icon: "language-en.svg"
  },
  onSelect: (item) => {
    return {
      actions: [Actions.updateProps, Actions.showToast],
      newProps: {
        selectedOption: item
      },
      toastProps: [{
        title: `Interface language changed to ${item.label}`,
        type: ToastType.success
      }]
    };
  },
  scaled: true,
  directionX: "right",
  directionY: "bottom",
  displayType: "default",
  dropDownMaxHeight: 300,
  showDisabledItems: true,
  withBackdrop: true,
  isDisabled: false,
  noBorder: false,
  opened: false,
  scaledOptions: true,
  modernView: true
}
```

## IComboBoxItem

Defined in: [interfaces/components/IComboBox.ts:186](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L186)

Custom combo box option.

### Properties

#### key

```ts
key: string;
```

Defined in: [interfaces/components/IComboBox.ts:190](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L190)

Unique identifier for the option

#### label

```ts
label: string;
```

Defined in: [interfaces/components/IComboBox.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L195)

Display text for the option

#### icon?

```ts
optional icon: string;
```

Defined in: [interfaces/components/IComboBox.ts:201](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L201)

The option display icon. The icon image must be uploaded to the assets folder.
Only the image name with the extension must be specified in this field.

#### disabled?

```ts
optional disabled: boolean;
```

Defined in: [interfaces/components/IComboBox.ts:206](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L206)

Specifies if the combo box option is disabled or not

### Example

Basic language option with icon

```typescript
const languageOption: IComboBoxItem = {
  key: "en-US",
  label: "English (US)",
  icon: "language-en.svg",
  disabled: false
}
```

