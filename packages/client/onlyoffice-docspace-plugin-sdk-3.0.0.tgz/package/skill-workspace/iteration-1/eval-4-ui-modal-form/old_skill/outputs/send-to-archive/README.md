# send-to-archive

Adds a 'Send to archive' entry to the main button: a dialog with archive URL, format selection (zip / tar.gz) and validated submit

## Build

```sh
npm install
npm run build
```

The uploadable archive is `dist/plugin.zip`.

## Install

Upload `dist/plugin.zip` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump `version` in `package.json` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

## Scopes

- `MainButton`
