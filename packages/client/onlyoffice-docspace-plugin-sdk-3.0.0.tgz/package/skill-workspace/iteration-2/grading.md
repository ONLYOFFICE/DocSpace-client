# Grading - iteration-2

```
Generated projects - universal checks

run                                            [0] [1] [2] [3] [4] [5] [6] [7] [8] [9]  score
eval-0-context-menu-file-action/without_skill   ✓   ·   ✓   ·   ·   ✓   ✓   ✓   ✓   ·   6/10
eval-0-context-menu-file-action/with_skill      ✓   ✓   ✓   ✓   ✓   ✓   ✓   ✓   ✓   ✓   10/10
eval-1-settings-and-info-panel/without_skill    ✓   ✓   ✓   ✓   ·   ✓   ✓   ✓   ✓   ✓   9/10
eval-1-settings-and-info-panel/with_skill       ✓   ✓   ✓   ✓   ✓   ✓   ✓   ✓   ✓   ✓   10/10
eval-3-extend-existing-plugin/without_skill     ✓   ✓   ✓   ✓   ✓   ✓   –   ✓   ✓   ✓   9/9
eval-3-extend-existing-plugin/with_skill        ✓   ✓   ✓   ✓   ✓   ✓   –   ✓   ✓   ✓   9/9
eval-4-ui-modal-form/without_skill              ✓   ✓   ✓   ✓   ·   ·   ✓   ✓   ✓   ✓   8/10
eval-4-ui-modal-form/with_skill                 ✓   ✓   ✓   ✓   ✓   ✓   ✓   ✓   ✓   ✓   10/10
eval-6-native-looking-settings/without_skill    ✓   ·   ✓   ·   –   –   ✓   ✓   ✓   ✓   6/8
eval-6-native-looking-settings/with_skill       ✓   ✓   ✓   ✓   –   –   ✓   ✓   ✓   ✓   8/8

  [0] zip built
  [1] validator clean
  [2] sdk 2.1.x
  [3] name registered correctly
  [4] registers in onLoadCallback
  [5] keys namespaced
  [6] errors handled
  [7] no fetch in onLoadCallback
  [8] no dead visual values
  [9] colors via theme vars

Generated projects - context-menu-file-action

run                                            [0] [1] [2] [3]  score
eval-0-context-menu-file-action/without_skill   ✓   ✓   ✓   ✓   4/4
eval-0-context-menu-file-action/with_skill      ✓   ✓   ✓   ✓   4/4

  [0] filtered to .md
  [1] fileType includes file
  [2] showModal carries modalDialogProps
  [3] modal defines onLoad

Generated projects - settings-and-info-panel

run                                           [0] [1] [2] [3]  score
eval-1-settings-and-info-panel/without_skill   ·   ·   ·   ·   0/4
eval-1-settings-and-info-panel/with_skill      ✓   ✓   ✓   ✓   4/4

  [0] saveSettings from a click
  [1] settings parsed defensively
  [2] panel content fetched in an onLoad
  [3] InfoPanel declared and implemented

Generated projects - extend-existing-plugin

run                                          [0] [1] [2] [3] [4] [5] [6]  score
eval-3-extend-existing-plugin/without_skill   ✓   ✓   ✓   ✓   ✓   ✓   ✓   7/7
eval-3-extend-existing-plugin/with_skill      ✓   ✓   ✓   ✓   ✓   ✓   ✓   7/7

  [0] identity preserved
  [1] version bumped
  [2] InfoPanel declared and implemented
  [3] rebuilt with the new scope
  [4] existing item kept
  [5] edited in place
  [6] labels go through locales

Generated projects - ui-modal-form

run                                 [0] [1] [2] [3] [4] [5]  score
eval-4-ui-modal-form/without_skill   ✓   ✓   ✓   ·   ·   ✓   4/6
eval-4-ui-modal-form/with_skill      ✓   ✓   ✓   ✓   ✓   ✓   6/6

  [0] tree uses the Components enum
  [1] modalDialogProps complete
  [2] modal onLoad returns every section
  [3] comboBox kept in sync
  [4] error via --input-error-color
  [5] error label updated by contextName

Generated projects - native-looking-settings

run                                           [0] [1] [2] [3] [4]  score
eval-6-native-looking-settings/without_skill   ·   ✓   ·   ·   ·   1/5
eval-6-native-looking-settings/with_skill      ✓   ✓   ✓   ✓   ✓   5/5

  [0] saveSettings from a click
  [1] settings parsed defensively
  [2] comboBox kept in sync
  [3] toggle onChange takes no arguments
  [4] toggle given explicit dimensions

Reports - audit-broken-plugin

run                                       [0] [1] [2] [3] [4] [5]  score
eval-2-audit-broken-plugin/without_skill   ✓   ✓   ✓   ·   ✓   ✓   5/6
eval-2-audit-broken-plugin/with_skill      ✓   ✓   ✓   ·   ✓   ✓   5/6

  [0] registration mismatch
  [1] wrong filter field
  [2] dead showModal
  [3] module-scope registration
  [4] cites file and line
  [5] left the plugin unmodified

Reports - explain-filter-fields

run                                         [0] [1] [2] [3] [4] [5]  score
eval-5-explain-filter-fields/without_skill   ✓   ✓   ✓   ·   ·   ✓   4/6
eval-5-explain-filter-fields/with_skill      ✓   ✓   ✓   ·   ·   ✓   4/6

  [0] names the plural form
  [1] contrasts it with the singular
  [2] names scopes on both sides
  [3] calls it a quirk, not a rule
  [4] says the wrong spelling fails silently
  [5] did not build a project

Summary

eval                        with_skill  baseline  delta  verdict
0-context-menu-file-action  14/14       10/14     +4     skill ahead, 1 sample
1-settings-and-info-panel   14/14       9/14      +5     skill ahead, 1 sample
2-audit-broken-plugin       5/6         5/6       0      tie - the skill's text earned nothing here, 1 sample
3-extend-existing-plugin    16/16       16/16     0      tie - the skill's text earned nothing here, 1 sample
4-ui-modal-form             16/16       12/16     +4     skill ahead, 1 sample
5-explain-filter-fields     4/6         4/6       0      tie - the skill's text earned nothing here, 1 sample
6-native-looking-settings   13/13       7/13      +6     skill ahead, 1 sample

Note: one run per configuration. A single changed check is as likely to be the model
varying as a real change - add a second run directory (with_skill-2) to see the spread.

Marks: ✓ passed   · failed   ? unknown, the check applies but could not decide
       – not applicable, excluded from the score
```
