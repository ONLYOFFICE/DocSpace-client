# Enumeration: SelectorType

Defined in: [enums/Selector.ts:4](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Selector.ts#L4)

Defines the types of selector components that can be rendered.

## Enumeration Members

### Base

> **Base**: `"base"`

Defined in: [enums/Selector.ts:6](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Selector.ts#L6)

A generic selector with a customizable list of items.

***

### Files

> **Files**: `"files"`

Defined in: [enums/Selector.ts:8](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Selector.ts#L8)

A selector for browsing and selecting files and folders.

***

### Groups

> **Groups**: `"groups"`

Defined in: [enums/Selector.ts:10](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Selector.ts#L10)

A selector for choosing user groups.

***

### People

> **People**: `"people"`

Defined in: [enums/Selector.ts:12](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Selector.ts#L12)

A selector for choosing users and guests.

***

### Room

> **Room**: `"room"`

Defined in: [enums/Selector.ts:14](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Selector.ts#L14)

A selector for browsing and selecting rooms.
