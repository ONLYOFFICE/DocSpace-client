# Type Alias: TSelector

> **TSelector** = \{ `type`: [`Base`](../../enumerations/SelectorType.md#base); `props`: [`TBaseSelector`](TBaseSelector.md); \} \| \{ `type`: [`Files`](../../enumerations/SelectorType.md#files); `props`: [`TFilesSelector`](TFilesSelector.md); \} \| \{ `type`: [`Groups`](../../enumerations/SelectorType.md#groups); `props`: [`TGroupsSelector`](TGroupsSelector.md); \} \| \{ `type`: [`People`](../../enumerations/SelectorType.md#people); `props`: [`TPeopleSelector`](TPeopleSelector.md); \} \| \{ `type`: [`Room`](../../enumerations/SelectorType.md#room); `props`: [`TRoomSelector`](TRoomSelector.md); \}

Defined in: [interfaces/components/Selector/index.ts:53](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/index.ts#L53)
