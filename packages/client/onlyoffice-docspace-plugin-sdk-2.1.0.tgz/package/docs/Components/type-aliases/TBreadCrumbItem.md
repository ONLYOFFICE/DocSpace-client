# Type Alias: TBreadCrumbItem

> **TBreadCrumbItem** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:282](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L282)

Represents a single item in a breadcrumb trail.

## Content

### label

> **label**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:288](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L288)

The display text for the breadcrumb item.

***

### id

> **id**: `string` \| `number`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:294](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L294)

A unique identifier for the breadcrumb item.

## State

### isRoom?

> `optional` **isRoom**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:300](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L300)

If true, indicates that the breadcrumb item represents a room.
