# Type Alias: SkeletonGroup

> **SkeletonGroup** = `object`

Defined in: [interfaces/components/Component.ts:368](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L368)

Defines the skeleton component.

## Example

```typescript
import { ISkeleton, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const skeleton: ISkeleton = {
  width: "100%",
  height: "200px",
  borderRadius: "8px"
};

const skeletonGroup: Component = {
  component: Components.skeleton,
  props: skeleton,
  contextName: "loadingState"
};
```

## Properties

### component

> **component**: [`skeleton`](../../enumerations/Components.md#skeleton)

Defined in: [interfaces/components/Component.ts:370](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L370)

Defines the "skeleton" component type

***

### props

> **props**: [`ISkeleton`](../interfaces/ISkeleton.md)

Defined in: [interfaces/components/Component.ts:372](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L372)

Defines the skeleton component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:374](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L374)

Defines the skeleton component context name that updates the component via React context
