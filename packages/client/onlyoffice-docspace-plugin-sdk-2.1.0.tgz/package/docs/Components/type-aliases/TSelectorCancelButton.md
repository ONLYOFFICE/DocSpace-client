# Type Alias: TSelectorCancelButton

> **TSelectorCancelButton** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:465](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L465)

Defines properties for the cancel button in the selector.

## Appearance

### withCancelButton?

> `optional` **withCancelButton**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:471](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L471)

If true, displays the cancel button.

## Behavior

### onCancel()?

> `optional` **onCancel**: () => `TReturnMessage`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:483](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L483)

A callback function that is triggered when the cancel button is clicked.

#### Returns

`TReturnMessage`

## Content

### cancelButtonLabel?

> `optional` **cancelButtonLabel**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:477](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L477)

The text label for the cancel button.
