# IMediaViewer

Defined in: [interfaces/components/IMediaViewer.ts:116](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L116)

Properties for the Media Viewer component that allows plugins to display custom content.

To open the viewer, return an [`IMessage`](../utils.md#imessage) with
[`Actions.showMediaViewer`](../../enums/Actions.md#showmediaviewer) in `actions`
and pass the configuration in `mediaViewerProps`.
Use [`Actions.updateMediaViewer`](../../enums/Actions.md#updatemediaviewer) and
[`Actions.closeMediaViewer`](../../enums/Actions.md#closemediaviewer) to update or close it.

![mediaviewer](/assets/images/docspace/mediaviewer.png#gh-light-mode-only)![mediaviewer](/assets/images/docspace/mediaviewer.dark.png#gh-dark-mode-only)

## Properties

### fileId?

```ts
optional fileId: string | number;
```

Defined in: [interfaces/components/IMediaViewer.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L121)

The ID of the file to display in the media viewer.
If not specified, the first file in the playlist will be displayed.

### content

```ts
content: IBox;
```

Defined in: [interfaces/components/IMediaViewer.ts:126](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L126)

The custom content to render inside the media viewer.
This should be a Box component that contains your custom UI elements.

### title?

```ts
optional title: string;
```

Defined in: [interfaces/components/IMediaViewer.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L132)

Optional title to display in the media viewer header.
If not provided, the default file name will be used.

### onClose()?

```ts
optional onClose: () => TReturnMessage;
```

Defined in: [interfaces/components/IMediaViewer.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L139)

Callback function that is called when the media viewer should be closed.
This is triggered when the user clicks the close button, background, or presses ESC.
Can return a TReturnMessage with Actions.closeMediaViewer to close the viewer.

#### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

### playlistFilter?

```ts
optional playlistFilter: IMediaViewerPlaylistFilter;
```

Defined in: [interfaces/components/IMediaViewer.ts:146](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L146)

Filter that determines which files are included in the media viewer playlist
used for navigation.
If not specified, the playlist is not filtered.

### navigation?

```ts
optional navigation: IMediaViewerNavigation;
```

Defined in: [interfaces/components/IMediaViewer.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L153)

Navigation callbacks invoked when the user moves between files in the media
viewer playlist.
If not specified, no navigation callbacks are triggered.

### onLoad()?

```ts
optional onLoad: (data: {
  fileId: string | number;
}) => TReturnMessage;
```

Defined in: [interfaces/components/IMediaViewer.ts:160](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L160)

A function that is executed when the plugin viewer is mounted.
It is called once when the viewer is first displayed.

#### Parameters

##### data

Object containing fileId of the current file

##### fileId

`string` \| `number`

#### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

***

## Examples

Display custom video player in Media Viewer

```typescript
const mediaViewerProps: IMediaViewer = {
  title: "Custom Video Player",
  content: {
    widthProp: "100%",
    heightProp: "100%",
    displayProp: "flex",
    children: [
      {
        component: Components.iFrame,
        props: {
          id: "video-player-frame",
          src: "https://player.example.com/video/12345",
          width: "100%",
          height: "100%",
          sandbox: "allow-scripts allow-same-origin",
          style: { border: "none" }
        }
      }
    ]
  },
  onClose: () => {
    return {
      actions: [Actions.closeMediaViewer]
    };
  },
  onLoad: (data) => {
    console.log("Media viewer loaded with fileId:", data.fileId);
    return { actions: [] };
  }
};
```

Display custom image viewer with playlist navigation

```typescript
const mediaViewerProps: IMediaViewer = {
  title: "Image with Annotations",
  content: {
    widthProp: "100%",
    heightProp: "100%",
    children: [
      {
        component: Components.iFrame,
        props: {
          id: "annotation-viewer",
          src: "https://annotator.example.com/image/67890",
          width: "100%",
          height: "100%"
        }
      }
    ]
  },
  playlistFilter: {
    filesExsts: [".jpg", ".png", FilesExst.svg],
    filesSecurity: [FilesSecurity.Read],
    usersTypes: [UsersType.user, UsersType.collaborator],
    devices: [Devices.desktop, Devices.tablet]
  },
  navigation: {
    onNext: () => {
      console.log("Next file");
      return { actions: [] };
    },
    onPrevious: () => {
      console.log("Previous file");
      return { actions: [] };
    },
    onFileChange: (data) => {
      console.log("File changed to:", data.fileId);
      return { actions: [] };
    }
  }
};
```

## IMediaViewerPlaylistFilter

Defined in: [interfaces/components/IMediaViewer.ts:167](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L167)

Filter configuration for media viewer playlist.
Defines which files should be included in the playlist.

### Properties

#### filesExsts?

```ts
optional filesExsts: string[];
```

Defined in: [interfaces/components/IMediaViewer.ts:172](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L172)

Allowed file extensions (e.g., [FilesExst.doc, ".drawio", ".md"]).
If not specified, all extensions are allowed.

#### filesSecurity?

```ts
optional filesSecurity: FilesSecurity[];
```

Defined in: [interfaces/components/IMediaViewer.ts:178](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L178)

Required security permissions for files.
If not specified, all security permissions are allowed.

#### usersTypes?

```ts
optional usersTypes: UsersType[];
```

Defined in: [interfaces/components/IMediaViewer.ts:185](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L185)

The types of users who will see the media viewer.
Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user.
If this parameter is not specified, then the media viewer will be displayed for all user types.

#### devices?

```ts
optional devices: Devices[];
```

Defined in: [interfaces/components/IMediaViewer.ts:192](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L192)

The types of devices where the media viewer will be displayed.
At the moment the following device types are available: mobile, tablet, desktop.
If this parameter is not specified, then the media viewer will be displayed in any device types.

***

## IMediaViewerNavigation

Defined in: [interfaces/components/IMediaViewer.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L199)

Navigation callbacks for media viewer.
Called when user navigates through the playlist.

### Properties

#### onNext()?

```ts
optional onNext: () => TReturnMessage;
```

Defined in: [interfaces/components/IMediaViewer.ts:203](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L203)

Called when navigating to next file.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

#### onPrevious()?

```ts
optional onPrevious: () => TReturnMessage;
```

Defined in: [interfaces/components/IMediaViewer.ts:208](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L208)

Called when navigating to previous file.

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

#### onFileChange()?

```ts
optional onFileChange: (data: {
  fileId: string | number;
}) => TReturnMessage;
```

Defined in: [interfaces/components/IMediaViewer.ts:214](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IMediaViewer.ts#L214)

Called when file changes.

##### Parameters

###### data

Object containing fileId of the new file

###### fileId

`string` \| `number`

##### Returns

[`TReturnMessage`](../utils.md#treturnmessage)
