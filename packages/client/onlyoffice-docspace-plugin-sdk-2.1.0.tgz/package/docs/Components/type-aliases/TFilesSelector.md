# Type Alias: TFilesSelector

> **TFilesSelector** = [`TSelectorHeader`](TSelectorHeader.md) & [`TSelectorBaseProps`](TSelectorBaseProps.md) & [`TSelectorLifecycleEvents`](TSelectorLifecycleEvents.md) & [`TSelectorSearchCreate`](TSelectorSearchCreate.md) & [`TSelectorCancelButton`](TSelectorCancelButton.md) & `Pick`\<[`TSelectorSubmitButton`](TSelectorSubmitButton.md), `"submitButtonLabel"`\> & `object`

Defined in: [interfaces/components/Selector/IFilesSelector.ts:141](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IFilesSelector.ts#L141)

Defines the properties for a file and folder selector component.

## Type Declaration

### isMultiSelect?

> `optional` **isMultiSelect**: `boolean`

If true, allows multiple items to be selected.

### withBreadCrumbs?

> `optional` **withBreadCrumbs**: `boolean`

If true, displays breadcrumb navigation.

### currentFolderId?

> `optional` **currentFolderId**: `string` \| `number`

The ID of the folder to open by default.

### isRoomsOnly?

> `optional` **isRoomsOnly**: `boolean`

If true, displays only rooms at the root level.

### openRoot?

> `optional` **openRoot**: `boolean`

If true, opens the root directory by default.

### descriptionText?

> `optional` **descriptionText**: `string`

A descriptive text displayed within the selector.

### withFooterInput?

> `optional` **withFooterInput**: `boolean`

If true, displays an input field in the footer.

### footerInputHeader?

> `optional` **footerInputHeader**: `string`

The header text for the footer input.

### currentFooterInputValue?

> `optional` **currentFooterInputValue**: `string`

The initial value for the footer input.

### withFooterCheckbox?

> `optional` **withFooterCheckbox**: `boolean`

If true, displays a checkbox in the footer.

### footerCheckboxLabel?

> `optional` **footerCheckboxLabel**: `string`

The label for the footer checkbox.

### getIsDisabled()

> **getIsDisabled**: (`params`) => `boolean`

A callback function to determine if the submit button should be disabled.

#### Parameters

##### params

`TGetIsDisabledParams`

#### Returns

`boolean`

### onSubmit()?

> `optional` **onSubmit**: (`params`) => `TReturnMessage`

A callback function that is triggered when the submit button is clicked.

#### Parameters

##### params

`TOnSubmitParams`

#### Returns

`TReturnMessage`

### onSelect()?

> `optional` **onSelect**: (`id`) => `TReturnMessage`

A callback function that is triggered when an item is selected.

#### Parameters

##### id

`string` | `number` | `undefined`

#### Returns

`TReturnMessage`

## Example

```typescript
// This example demonstrates a file selector for choosing a location to save a file.
// It includes a footer input for the filename, breadcrumbs for navigation, and
// custom logic to disable the submit button in the root directory.

const filesSelectorProps: TFilesSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Save File As",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Save",
  // Enables and sets the text for the cancel button.
  withCancelButton: true,
  cancelButtonLabel: "Cancel",

  // Enables breadcrumbs for easy navigation through folders.
  withBreadCrumbs: true,
  // Enables the search functionality.
  withSearch: true,
  // Allows users to create new folders within the selector.
  withCreate: true,

  // Adds an input field in the footer, typically for a filename.
  withFooterInput: true,
  footerInputHeader: "File name",
  currentFooterInputValue: "Untitled Document",

  // A callback function to determine if the submit button should be disabled.
  getIsDisabled: ({ isRoot }) => {
    // In this case, disable the submit button if the user is in the root directory.
    return isRoot;
  },

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (payload) => {
    // The `payload` object contains information about the selected location and filename.
    console.log("File save details:", payload);

    // After submission, close the selector and show a confirmation message.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `File saved as ${payload.fileName}`,
      }],
    };
  },
};
```
