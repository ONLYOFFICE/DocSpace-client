# Enumeration: FilesType

Defined in: [enums/Files.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L22)

Defines the supported file types.

## Enumeration Members

### room

> **room**: `"room"`

Defined in: [enums/Files.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L24)

DocSpace room or workspace

***

### file

> **file**: `"file"`

Defined in: [enums/Files.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L27)

Generic file type

***

### folder

> **folder**: `"folder"`

Defined in: [enums/Files.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L30)

Directory or folder

***

### image

> **image**: `"image"`

Defined in: [enums/Files.ts:33](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L33)

Image file (various formats)

***

### video

> **video**: `"video"`

Defined in: [enums/Files.ts:36](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L36)

Video file (various formats)
