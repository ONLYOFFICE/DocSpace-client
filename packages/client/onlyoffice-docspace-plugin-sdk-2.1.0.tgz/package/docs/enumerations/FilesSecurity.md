# Enumeration: FilesSecurity

Defined in: [enums/Files.ts:149](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L149)

Defines the supported file security parameters.

## Enumeration Members

### Convert

> **Convert**: `"Convert"`

Defined in: [enums/Files.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L151)

Permission to convert files to other formats

***

### Copy

> **Copy**: `"Copy"`

Defined in: [enums/Files.ts:154](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L154)

Permission to copy files and folders

***

### CustomFilter

> **CustomFilter**: `"CustomFilter"`

Defined in: [enums/Files.ts:157](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L157)

Permission to apply custom filters

***

### Delete

> **Delete**: `"Delete"`

Defined in: [enums/Files.ts:160](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L160)

Permission to delete items

***

### Download

> **Download**: `"Download"`

Defined in: [enums/Files.ts:163](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L163)

Permission to download files

***

### Duplicate

> **Duplicate**: `"Duplicate"`

Defined in: [enums/Files.ts:166](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L166)

Permission to create duplicates of items

***

### Edit

> **Edit**: `"Edit"`

Defined in: [enums/Files.ts:169](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L169)

Permission to edit files

***

### EditHistory

> **EditHistory**: `"EditHistory"`

Defined in: [enums/Files.ts:172](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L172)

Permission to view and edit file history

***

### FillForms

> **FillForms**: `"FillForms"`

Defined in: [enums/Files.ts:175](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L175)

Permission to fill forms

***

### Lock

> **Lock**: `"Lock"`

Defined in: [enums/Files.ts:178](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L178)

Permission to lock/unlock files

***

### Move

> **Move**: `"Move"`

Defined in: [enums/Files.ts:181](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L181)

Permission to move items

***

### Read

> **Read**: `"Read"`

Defined in: [enums/Files.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L184)

Permission to view and read content

***

### ReadHistory

> **ReadHistory**: `"ReadHistory"`

Defined in: [enums/Files.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L187)

Permission to read file history

***

### Rename

> **Rename**: `"Rename"`

Defined in: [enums/Files.ts:190](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L190)

Permission to rename items

***

### Review

> **Review**: `"Review"`

Defined in: [enums/Files.ts:193](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L193)

Permission to review documents

***

### SubmitToFormGallery

> **SubmitToFormGallery**: `"SubmitToFormGallery"`

Defined in: [enums/Files.ts:196](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L196)

Permission to submit forms to gallery

***

### StopFilling

> **StopFilling**: `"StopFilling"`

Defined in: [enums/Files.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L199)

Permission to stop form filling process

***

### ResetFilling

> **ResetFilling**: `"ResetFilling"`

Defined in: [enums/Files.ts:202](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L202)

Permission to reset form filling

***

### EditForm

> **EditForm**: `"EditForm"`

Defined in: [enums/Files.ts:205](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L205)

Permission to edit forms

***

### Comment

> **Comment**: `"Comment"`

Defined in: [enums/Files.ts:208](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L208)

Permission to comment on files

***

### CreateRoomFrom

> **CreateRoomFrom**: `"CreateRoomFrom"`

Defined in: [enums/Files.ts:211](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L211)

Permission to create rooms from existing content

***

### CopyLink

> **CopyLink**: `"CopyLink"`

Defined in: [enums/Files.ts:214](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L214)

Permission to copy links to files

***

### Embed

> **Embed**: `"Embed"`

Defined in: [enums/Files.ts:217](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Files.ts#L217)

Permission to embed content
