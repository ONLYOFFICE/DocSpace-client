# Interface: IFloatingOperation

Defined in: [interfaces/components/IFloatingOperationsButton.ts:299](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L299)

Represents a single operation in the floating operations button.
Each operation displays as a row with icon, label, and progress indicator.

## Appearance

Properties that customize the visual representation of the operation.

### icon?

> `optional` **icon**: `string`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:353](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L353)

Custom icon for the operation (overrides default operation icon).
The icon image must be uploaded to the "assets" folder.
Only specify the filename here, e.g., "upload.svg" or "custom-icon.png".

## Content

Properties that define the operation's display content and identification.

### label

> **label**: `string`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:311](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L311)

Text label displayed to the user describing the operation.
Example: "Uploading document.pdf" or "Converting 5 files"

***

### operation

> **operation**: [`FloatingOperationType`](../enumerations/FloatingOperationType.md)

Defined in: [interfaces/components/IFloatingOperationsButton.ts:319](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L319)

Type of operation - determines the default icon and visual representation.
Use predefined types (Upload, Convert, etc.).

## State

Properties that control the operation's current state and progress.

### completed

> **completed**: `boolean`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:336](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L336)

Completion flag - if true, the operation is marked as completed.
Shows checkmark icon and allows user to dismiss the operation.

***

### percent?

> `optional` **percent**: `number`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:344](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L344)

Progress percentage of the operation (0-100).
If undefined, displays an infinite loader animation instead of percentage.

## State
Shows red icon.

### alert

> **alert**: `boolean`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:328](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L328)

Error flag - if true, the operation is displayed with a warning/error state.
Shows red icon and allows user to see what went wrong.

## Other

### id

> **id**: `string`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:303](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L303)

Unique identifier for the operation.
