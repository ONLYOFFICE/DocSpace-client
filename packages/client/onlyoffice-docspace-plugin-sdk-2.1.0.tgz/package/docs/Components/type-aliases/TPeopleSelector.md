# Type Alias: TPeopleSelector

> **TPeopleSelector** = [`TSelectorHeader`](TSelectorHeader.md) & [`TSelectorCancelButton`](TSelectorCancelButton.md) & [`TSelectorSubmitButton`](TSelectorSubmitButton.md) & [`TSelectorBaseProps`](TSelectorBaseProps.md) & [`TSelectorLifecycleEvents`](TSelectorLifecycleEvents.md) & [`TSelectorEmptyScreen`](TSelectorEmptyScreen.md) & `object`

Defined in: [interfaces/components/Selector/IPeopleSelector.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IPeopleSelector.ts#L93)

Defines the properties for a user and group selector component.

## Type Declaration

### targetEntityType?

> `optional` **targetEntityType**: `"file"` \| `"folder"` \| `"room"`

The type of entity for which the user is being selected (e.g., for sharing a file).

#### Example

```ts
"file" | "folder" | "room"
```

### withGroups?

> `optional` **withGroups**: `boolean`

If true, allows the selection of groups.

#### Default

```ts
false
```

### isGroupsOnly?

> `optional` **isGroupsOnly**: `boolean`

If true, displays only groups in the selector.

#### Default

```ts
false
```

### withGuests?

> `optional` **withGuests**: `boolean`

If true, includes guest users in the selector.

#### Default

```ts
false
```

### isGuestsOnly?

> `optional` **isGuestsOnly**: `boolean`

If true, displays only guest users in the selector.

#### Default

```ts
false
```

### isMultiSelect?

> `optional` **isMultiSelect**: `boolean`

If true, allows multiple users and/or groups to be selected.

#### Default

```ts
false
```

### currentUserId?

> `optional` **currentUserId**: `string`

The ID of the current user, to be excluded from the list.

#### Example

```ts
"user-1234"
```

### excludeItems?

> `optional` **excludeItems**: `string`[]

An array of user or group IDs to exclude from the list.

#### Example

```ts
["user-1234", "group-5678"]
```

### disableInvitedUsers?

> `optional` **disableInvitedUsers**: `string`[]

An array of user IDs that are already invited and should be disabled.

#### Example

```ts
["user-1234", "user-5678"]
```

### disableDisabledUsers?

> `optional` **disableDisabledUsers**: `boolean`

If true, users with a 'disabled' status will not be displayed.

#### Default

```ts
false
```

### roomId?

> `optional` **roomId**: `string` \| `number`

The ID of the room to which the selector is related.

#### Example

```ts
"room-1234"
```

### alwaysShowFooter?

> `optional` **alwaysShowFooter**: `boolean`

If true, the footer will always be visible, even if no users are selected.

#### Default

```ts
false
```

### onlyRoomMembers?

> `optional` **onlyRoomMembers**: `boolean`

If true, displays only the members of the current room.

#### Default

```ts
false
```

## Example

```typescript
// This example demonstrates how to configure a selector for choosing users and groups.
// It allows multi-selection, includes groups, and provides clear labels and descriptions.

const peopleSelectorProps: TPeopleSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Share Document",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Share",
  // The text for the cancel button.
  cancelButtonLabel: "Cancel",

  // If true, the footer with action buttons is always visible.
  alwaysShowFooter: true,

  // Custom text to display when no users or groups are found.
  emptyScreenHeader: "No users found",
  emptyScreenDescription: "There are no users or groups matching your search.",

  // Allows the selection of multiple users and groups.
  isMultiSelect: true,
  // Includes groups in the selection list.
  withGroups: true,

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (payload) => {
    // The `payload` object contains the `selectedIds` of the chosen users and groups.
    console.log("Selected users and groups:", payload.selectedIds);

    // After submission, close the selector and show a confirmation toast.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: "Document shared successfully",
      }],
    };
  },
};
```
