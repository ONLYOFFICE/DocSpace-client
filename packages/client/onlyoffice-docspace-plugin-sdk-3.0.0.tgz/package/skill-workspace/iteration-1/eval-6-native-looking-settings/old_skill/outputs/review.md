# webhook-settings (old_skill)

- pluginName: `WebhookSettings`  version: `1.0.0`  scopes: `["Settings"]`
- zip built: yes

## src/index.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  IPlugin,
  ISettings,
  ISettingsPlugin,
  PluginLocale,
  PluginStatus,
} from "@onlyoffice/docspace-plugin-sdk";

import { currentLocale, setLocale } from "./locales";
import { applyStoredSettings, pluginSettings } from "./settings";

class WebhookSettings
  implements
    IPlugin,
    ISettingsPlugin
{
  status: PluginStatus = PluginStatus.active;


  adminPluginSettings: ISettings | null = null;

  setAdminPluginSettings = (settings: ISettings | null): void => {
    this.adminPluginSettings = settings;
  };

  // The portal hands settings back as the raw string the plugin saved earlier,
  // and it arrives *after* installation - so parse defensively.
  setAdminPluginSettingsValue = (settings: string | null): void => {
    if (!settings) return;

    applyStoredSettings(settings);

    // Rebuild the block so the stored values are what the settings page shows.
    this.setAdminPluginSettings(pluginSettings());
  };

  getAdminPluginSettings = (): ISettings | null => this.adminPluginSettings;

  // Register the settings block here rather than at module scope. Both are read
  // in time, but setLanguage only runs after the bundle executes - so building
  // the block at module scope would capture untranslated labels.
  onLoadCallback = async (): Promise<void> => {
    this.setAdminPluginSettings(pluginSettings());
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  // The portal calls this when the interface language changes. Labels were
  // captured when the items were built, so the items have to be rebuilt.
  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
    this.setAdminPluginSettings(pluginSettings());
  };

  getLanguage = (): PluginLocale => currentLocale();

}

const plugin = new WebhookSettings();

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.WebhookSettings = plugin || {};

export default plugin;
```

## src/locales.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 */
export type TStrings = {
  "settings.webhookUrl.label": string;
  "settings.webhookUrl.placeholder": string;
  "settings.webhookUrl.invalid": string;
  "settings.environment.label": string;
  "settings.environment.production": string;
  "settings.environment.staging": string;
  "settings.notifications.label": string;
  "settings.save": string;
  "settings.saved": string;
};

const en: TStrings = {
  "settings.webhookUrl.label": "Webhook URL",
  "settings.webhookUrl.placeholder": "https://example.com/webhook",
  "settings.webhookUrl.invalid":
    "Enter a valid URL starting with http:// or https://",
  "settings.environment.label": "Environment",
  "settings.environment.production": "Production",
  "settings.environment.staging": "Staging",
  "settings.notifications.label": "Send notifications",
  "settings.save": "Save",
  "settings.saved": "Settings saved",
};

const ru: TStrings = {
  "settings.webhookUrl.label": "Webhook URL",
  "settings.webhookUrl.placeholder": "https://example.com/webhook",
  "settings.webhookUrl.invalid":
    "Введите корректный URL, начинающийся с http:// или https://",
  "settings.environment.label": "Окружение",
  "settings.environment.production": "Production",
  "settings.environment.staging": "Staging",
  "settings.notifications.label": "Отправлять уведомления",
  "settings.save": "Сохранить",
  "settings.saved": "Настройки сохранены",
};

const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.EN_US]: en,
  [PluginLocale.RU]: ru,
};

let locale: PluginLocale = PluginLocale.EN_US;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.EN_US;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings): string => (translations[locale] ?? en)[key];
```

## src/settings.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  ButtonGroup,
  ButtonSize,
  Components,
  IBox,
  IComboBoxItem,
  IMessage,
  ISettings,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

import { t } from "./locales";

export type TEnvironment = "production" | "staging";

export type TWebhookSettings = {
  webhookUrl: string;
  environment: TEnvironment;
  sendNotifications: boolean;
};

/**
 * The settings travel to the portal as one opaque JSON string; this object is
 * the plugin's own working copy of it.
 */
const state: TWebhookSettings = {
  webhookUrl: "",
  environment: "production",
  sendNotifications: true,
};

/**
 * Merges a stored settings string back into the working copy. Called from
 * setAdminPluginSettingsValue, which the portal invokes *after* installation -
 * a malformed value must never throw, or it would break the plugin silently.
 */
export const applyStoredSettings = (value: string): void => {
  try {
    const parsed = JSON.parse(value) as Partial<TWebhookSettings>;

    if (typeof parsed.webhookUrl === "string") state.webhookUrl = parsed.webhookUrl;
    if (parsed.environment === "production" || parsed.environment === "staging")
      state.environment = parsed.environment;
    if (typeof parsed.sendNotifications === "boolean")
      state.sendNotifications = parsed.sendNotifications;
  } catch {
    // Keep the defaults rather than breaking installation on a bad stored value.
  }
};

// contextName is how one element addresses another inside the rendered tree;
// prefixed with the plugin name to stay collision-proof.
const URL_INPUT = "webhook-settings-url-input";
const URL_ERROR = "webhook-settings-url-error";

// An empty URL is a legitimate "not configured yet" value; only a non-empty
// value that is not an http(s) URL is rejected.
const isWebhookUrlValid = (value: string): boolean =>
  value === "" || /^https?:\/\/\S+$/.test(value);

const environmentOptions = (): IComboBoxItem[] => [
  { key: "production", label: t("settings.environment.production") },
  { key: "staging", label: t("settings.environment.staging") },
];

const selectedEnvironment = (): IComboBoxItem =>
  environmentOptions().find((option) => option.key === state.environment) ??
  environmentOptions()[0];

// Named handlers: IMessage.newProps must satisfy the full component interface
// (onChange included), so the handlers reference themselves by name.
const onWebhookUrlChange = (value: string): IMessage => {
  state.webhookUrl = value;
  const invalid = !isWebhookUrlValid(value);

  // Self-update keeps the field editable; the sibling update shows or clears
  // the error line. Both work here because this callback lives inside the
  // rendered settings tree.
  return {
    actions: [Actions.updateProps, Actions.updateContext],
    newProps: { value, hasError: invalid, onChange: onWebhookUrlChange },
    contextProps: [
      {
        name: URL_ERROR,
        props: { text: invalid ? t("settings.webhookUrl.invalid") : "" },
      },
    ],
  };
};

const onNotificationsToggle = (): IMessage => {
  state.sendNotifications = !state.sendNotifications;

  return {
    actions: [Actions.updateProps],
    newProps: {
      isChecked: state.sendNotifications,
      onChange: onNotificationsToggle,
    },
  };
};

/**
 * The settings block is declarative: the portal renders every node with its own
 * React components, which is what makes the result look native and follow the
 * active theme (dark included) without any CSS from the plugin. The only colour
 * set anywhere is the error text, and it uses the portal's own theme variable.
 */
const settingsBody = (): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [
    // --- Webhook URL ---------------------------------------------------------
    {
      component: Components.box,
      props: {
        marginProp: "0 0 4px",
        children: [
          {
            component: Components.label,
            props: { text: t("settings.webhookUrl.label") },
          },
        ],
      },
    },
    {
      component: Components.input,
      contextName: URL_INPUT,
      props: {
        value: state.webhookUrl,
        placeholder: t("settings.webhookUrl.placeholder"),
        scale: true,
        hasError: !isWebhookUrlValid(state.webhookUrl),
        onChange: onWebhookUrlChange,
      },
    },
    {
      component: Components.box,
      props: {
        marginProp: "4px 0 0",
        children: [
          {
            component: Components.text,
            contextName: URL_ERROR,
            props: {
              text: "",
              fontSize: "12px",
              lineHeight: "16px",
              color: "var(--error-color, var(--input-error-color))",
            },
          },
        ],
      },
    },

    // --- Environment ---------------------------------------------------------
    {
      component: Components.box,
      props: {
        marginProp: "16px 0 4px",
        children: [
          {
            component: Components.label,
            props: { text: t("settings.environment.label") },
          },
        ],
      },
    },
    {
      component: Components.comboBox,
      props: {
        options: environmentOptions(),
        selectedOption: selectedEnvironment(),
        scaled: false,
        scaledOptions: true,
        directionY: "bottom",
        dropDownMaxHeight: 200,
        onSelect: (option: IComboBoxItem): IMessage => {
          state.environment = option.key === "staging" ? "staging" : "production";

          return {
            actions: [Actions.updateProps],
            newProps: { options: environmentOptions(), selectedOption: option },
          };
        },
      },
    },

    // --- Notifications -------------------------------------------------------
    {
      component: Components.box,
      props: {
        marginProp: "20px 0 0",
        children: [
          {
            component: Components.toggleButton,
            props: {
              label: t("settings.notifications.label"),
              isChecked: state.sendNotifications,
              onChange: onNotificationsToggle,
            },
          },
        ],
      },
    },
  ],
});

const saveButton = (): ButtonGroup => ({
  component: Components.button,
  props: {
    label: t("settings.save"),
    size: ButtonSize.normal,
    primary: true,
    scale: false,
    onClick: (): IMessage => {
      if (!isWebhookUrlValid(state.webhookUrl)) {
        // The save button can address the input and the error line via
        // updateContext because it, too, is inside the rendered settings tree.
        return {
          actions: [Actions.updateContext],
          contextProps: [
            {
              name: URL_INPUT,
              props: {
                value: state.webhookUrl,
                hasError: true,
                onChange: onWebhookUrlChange,
              },
            },
            { name: URL_ERROR, props: { text: t("settings.webhookUrl.invalid") } },
          ],
        };
      }

      // saveSettings is honoured only from this button - nowhere else.
      return {
        actions: [Actions.saveSettings, Actions.showToast],
        settings: JSON.stringify(state),
        toastProps: [{ type: ToastType.success, title: t("settings.saved") }],
      };
    },
  },
});

export const pluginSettings = (): ISettings => ({
  settings: settingsBody(),
  saveButton: saveButton(),
  // Called when the admin opens the settings page - by then the stored value
  // has already arrived through setAdminPluginSettingsValue, so rebuilding
  // here shows the saved values rather than the defaults.
  onLoad: async () => ({ settings: settingsBody(), saveButton: saveButton() }),
});
```
