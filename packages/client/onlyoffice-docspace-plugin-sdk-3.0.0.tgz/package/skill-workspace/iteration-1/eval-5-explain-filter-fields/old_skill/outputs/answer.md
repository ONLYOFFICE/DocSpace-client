# `usersType` и `usersTypes`: правильны оба — но каждый только в своём скоупе

**Короткий ответ:** это не «одно правильное, другое опечатка». Хост DocSpace читает **разное имя поля в разных скоупах**, а интерфейсы SDK это честно зеркалируют — поэтому оба варианта компилируются, каждый на своём месте:

| Поле | Скоупы |
|---|---|
| `usersTypes` (множественное) | `ContextMenu`, `InfoPanel`, `EventListener`, `ArticleButton` |
| `usersType` (единственное) | `MainButton`, `ProfileMenu`, `File` |

При этом **оба поля принимают массив** `UsersType[]` — единственное число в `usersType` ни на что не влияет, это просто имя.

## Почему оба компилируются

У каждого скоупа свой интерфейс item'а, и вариант поля прописан в каждом отдельно (по исходникам SDK):

- `IContextMenuItem.usersTypes?: UsersType[]`
- `IInfoPanelItem.usersTypes?: UsersType[]`
- `IEventListenerItem.usersTypes?: UsersType[]`
- `IArticleButtonItem.usersTypes?: UsersType[]`
- `IMainButtonItem.usersType?: UsersType[]`
- `IProfileMenuItem.usersType?: UsersType[]`
- `IFileItem.usersType?: UsersType[]`

Так что если вы видели `usersTypes` в пункте контекстного меню, а `usersType` — в main button или профильном меню, то оба места написаны правильно: TypeScript не «прощает ошибку», он проверяет каждый интерфейс по его собственному объявлению.

## Чем это опасно

При фильтрации хост читает ровно то имя, которое ожидает для данного скоупа. Чужое имя он **молча игнорирует** — ни ошибки компиляции (если item собран не прямым литералом), ни ошибки в консоли. Симптом ровно один: фильтр «не работает», и пункт видят **все** пользователи, включая тех, от кого вы его прятали.

Промахнуться проще, чем кажется: прямой объектный литерал TypeScript проверит на лишние поля, но стоит собрать item через промежуточную переменную, spread или общую «фабрику пунктов» — и неправильное имя спокойно проезжает мимо компилятора. Отсюда и ощущение, что «оба варианта работают»: компилируются оба, а вот фильтрует хост только правильный для скоупа.

## Как правильно ограничить пункт по роли

Перечислите типы пользователей, которым пункт **виден**; если поле не задано, пункт видят все. Значения — из enum `UsersType`: `owner` («Owner»), `docSpaceAdmin` («DocSpaceAdmin»), `roomAdmin` («RoomAdmin»), `collaborator` («Collaborator»), `user` («User»).

```ts
import {
  IContextMenuItem,
  IMainButtonItem,
  UsersType,
} from "@onlyoffice/docspace-plugin-sdk";

// ContextMenu — МНОЖЕСТВЕННОЕ число: usersTypes
const contextMenuItem: IContextMenuItem = {
  key: "myplugin-convert",
  label: "Convert",
  icon: "convert.svg",
  onItemClick: (id) => ({ actions: [] }),
  usersTypes: [UsersType.owner, UsersType.docSpaceAdmin, UsersType.roomAdmin],
};

// MainButton — ЕДИНСТВЕННОЕ число: usersType (но значение всё равно массив!)
const mainButtonItem: IMainButtonItem = {
  key: "myplugin-create",
  label: "Create report",
  icon: "create.svg",
  onItemClick: (id) => ({ actions: [] }),
  usersType: [UsersType.docSpaceAdmin],
};
```

Практический приём: всегда типизируйте item конкретным интерфейсом (`IContextMenuItem`, `IMainButtonItem`, …) и задавайте поля прямым литералом — тогда компилятор сам поймает неправильный вариант. И не копируйте блок фильтра между скоупами не глядя: при переносе пункта из контекстного меню в main button поле надо переименовать.

## Почему так вышло

Это не продуманное правило, а **причуда портала**: лоадер DocSpace (поведение проверено на клиенте v3.7.2-server) в каждом скоупе читает своё захардкоженное имя поля, а SDK описал типы «как есть» — по фактическому поведению хоста, а не унифицировав имя. Логики, по которой можно угадать вариант для нового скоупа, нет: это надо либо помнить по таблице выше, либо каждый раз смотреть в интерфейс нужного скоупа.

К слову, у соседнего фильтра `devices` имя везде одинаковое, но своя странность есть и у него: хост учитывает его во всех скоупах, кроме `File` — там проверка устройства происходит уже внутри `onClick` самого плагина.
