# Type Alias: InputGroup

> **InputGroup** = `object`

Defined in: [interfaces/components/Component.ts:301](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L301)

Defines the input component.

## Example

```typescript
import { IInput, Components, Component, Actions, InputSize } from "@onlyoffice/docspace-plugin-sdk";

const input: IInput = {
  value: "",
  onChange: (value) => {},
  placeholder: "Enter text...",
  size: InputSize.middle,
  name: "search-input",
  isAutoFocused: true,
  iconName: "search",
  iconSize: 16,
  scale: true,
  onIconClick: () => {
    console.log("Search icon clicked");
  }
};

const inputGroup: Component = {
  component: Components.input,
  props: input,
  contextName: "searchInput"
};
```

## Properties

### component

> **component**: [`input`](../../enumerations/Components.md#input)

Defined in: [interfaces/components/Component.ts:303](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L303)

Defines the "input" component type

***

### props

> **props**: [`IInput`](../interfaces/IInput.md)

Defined in: [interfaces/components/Component.ts:305](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L305)

Defines the input component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:307](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L307)

Defines the input component context name that updates the component via React context
