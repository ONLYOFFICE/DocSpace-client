# IInfoPanelItem

Defined in: [interfaces/items/IInfoPanelItem.ts:133](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L133)

The info panel item that is displayed in the info panel.

![infopanelitem](/assets/images/docspace/infopanelitem.png#gh-light-mode-only)![infopanelitem](/assets/images/docspace/infopanelitem.dark.png#gh-dark-mode-only)

## Properties

### key

```ts
key: string;
```

Defined in: [interfaces/items/IInfoPanelItem.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L137)

The unique item identifier used by the service to recognize the item

### subMenu

```ts
subMenu: IInfoPanelSubMenu;
```

Defined in: [interfaces/items/IInfoPanelItem.ts:142](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L142)

The item submenu

### body

```ts
body: IBox;
```

Defined in: [interfaces/items/IInfoPanelItem.ts:147](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L147)

The tab UI of the info panel

### isHeaderVisible?

```ts
optional isHeaderVisible: boolean;
```

Defined in: [interfaces/items/IInfoPanelItem.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L153)

The property that controls whether the header is visible in the info panel.
By default, the header is visible.

### onLoad()?

```ts
optional onLoad: () => Promise<{
  body: IBox;
}>;
```

Defined in: [interfaces/items/IInfoPanelItem.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L159)

A function that is executed after opening a tab.
It returns a new body. If this functionality is not needed, the old body value is returned.

#### Returns

`Promise`\<\{
  `body`: [`IBox`](../components/IBox.md);
\}\>

### filesType?

```ts
optional filesType: FilesType[];
```

Defined in: [interfaces/items/IInfoPanelItem.ts:166](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L166)

The types of files where the current item will be displayed in the info panel.
Presently the following file types are available: room, file, folder, image, video.
If this parameter is not specified, then the current info panel item will be displayed in any file type.

### filesExsts?

```ts
optional filesExsts: string[];
```

Defined in: [interfaces/items/IInfoPanelItem.ts:173](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L173)

The extensions of files where the current item will be displayed in the info panel.
It only works if the FilesType.file is specified in the filesType parameter.
If this parameter is not specified, then the current info panel item will be displayed in any file extension.

### usersTypes?

```ts
optional usersTypes: UsersType[];
```

Defined in: [interfaces/items/IInfoPanelItem.ts:180](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L180)

The types of users who will see the current item in the info panel.
Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user.
If this parameter is not specified, then the current info panel item will be displayed for all user types.

### devices?

```ts
optional devices: Devices[];
```

Defined in: [interfaces/items/IInfoPanelItem.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L187)

The types of devices where the current item will be displayed in the info panel.
At the moment the following device types are available: mobile, tablet, desktop.
If this parameter is not specified, then the current info panel item will be displayed in any device types.

## Examples

AI-powered document analysis with error handling

```typescript
import {
  IInfoPanelItem,
  Components,
  Actions,
  ToastType,
  FilesType,
} from "@onlyoffice/docspace-plugin-sdk";

const documentAnalysis: IInfoPanelItem = {
  key: "ai-analysis",
  subMenu: {
    name: "AI Analysis",
    onClick: async (id) => {
      try {
        const analysis = await analyzeDocument(id);
        await exportAnalysis(id, analysis);

        return {
          actions: [Actions.showToast],
          toastProps: [{
            type: ToastType.success,
            title: "Document analysis complete"
          }]
        };
      } catch (error) {
        return {
          actions: [Actions.showToast],
          toastProps: [{
            type: ToastType.error,
            title: "Unable to analyze the document"
          }]
        };
      }
    }
  },
  body: {
    children: [
      {
        component: Components.text,
        props: { text: "Open the tab to generate an AI summary of the document" }
      }
    ]
  },
  filesType: [FilesType.file]
}
```

Image metadata viewer with file type restrictions

```typescript
const imageMetadata: IInfoPanelItem = {
  key: "image-metadata",
  subMenu: {
    name: "Image Info"
  },
  body: {
    children: [
      {
        component: Components.text,
        props: { text: "Loading image metadata..." }
      }
    ]
  },
  onLoad: async () => {
    const metadata = await getImageMetadata();
    return {
      body: {
        children: [
          {
            component: Components.text,
            props: { text: metadata.summary }
          }
        ]
      }
    };
  },
  isHeaderVisible: true,
  filesType: [FilesType.image],
  filesExsts: [".jpeg", ".jpg", ".png", ".gif", ".bmp"],
  devices: [Devices.desktop, Devices.tablet]
}
```

## IInfoPanelSubMenu

Defined in: [interfaces/items/IInfoPanelItem.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L27)

Describes the item submenu.

### Properties

#### name

```ts
name: string;
```

Defined in: [interfaces/items/IInfoPanelItem.ts:29](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L29)

The tab display name

#### onClick()?

```ts
optional onClick: (id: number) => 
  | void
  | IMessage
| Promise<IMessage>;
```

Defined in: [interfaces/items/IInfoPanelItem.ts:35](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IInfoPanelItem.ts#L35)

A function that takes the file/folder/room id as an argument.
This function can be asynchronous. It will be executed when clicking on the tab.

##### Parameters

###### id

`number`

##### Returns

  `void`
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

