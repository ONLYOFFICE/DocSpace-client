#!/usr/bin/env node

/**
 * Script to copy generated TypeDoc documentation to the plugin-sdk-doc project
 * and integrate the sidebar configuration
 * 
 * Usage: node tools/copy-docs.mjs [target-path]
 * 
 * If target-path is not provided, it will use the default path relative to SDK:
 * ../plugin-sdk-doc/docs/docspace/plugins-sdk/usage-sdk
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Source directory (SDK docs output)
const SOURCE_DIR = path.resolve(__dirname, '../docs');

// Source sidebar file
const SOURCE_SIDEBAR = path.resolve(__dirname, '../docs/typedoc-sidebar.cjs');

// Default target directory (plugin-sdk-doc project)
const DEFAULT_TARGET_DIR = path.resolve(__dirname, '../../plugin-sdk-doc/docs/docspace/plugins-sdk/usage-sdk');

// Target sidebar file
const DEFAULT_TARGET_SIDEBAR = path.resolve(__dirname, '../../plugin-sdk-doc/sidebars.js');

// Get target directory from command line args or use default
const targetDir = process.argv[2] || DEFAULT_TARGET_DIR;
const targetSidebar = process.argv[3] || DEFAULT_TARGET_SIDEBAR;

/**
 * Recursively copy directory contents, excluding typedoc-sidebar.cjs
 */
function copyDirectory(source, target) {
  // Create target directory if it doesn't exist
  if (!fs.existsSync(target)) {
    fs.mkdirSync(target, { recursive: true });
  }

  // Read source directory
  const entries = fs.readdirSync(source, { withFileTypes: true });

  for (const entry of entries) {
    const sourcePath = path.join(source, entry.name);
    const targetPath = path.join(target, entry.name);

    // Skip typedoc-sidebar.cjs - it will be integrated separately
    if (entry.name === 'typedoc-sidebar.cjs') {
      continue;
    }

    if (entry.isDirectory()) {
      // Recursively copy subdirectories
      copyDirectory(sourcePath, targetPath);
    } else {
      // Copy file
      fs.copyFileSync(sourcePath, targetPath);
    }
  }
}

/**
 * Integrate sidebar content from typedoc-sidebar.cjs into sidebars.js
 */
function integrateSidebar(sourceSidebar, targetSidebar) {
  console.log('🔗 Integrating sidebar configuration...');

  // Read source sidebar
  let sourceContent = fs.readFileSync(sourceSidebar, 'utf8');

  // Replace the export statement to match the expected format
  // From: module.exports = typedocSidebar.items;
  // To: module.exports = { docs: typedocSidebar.items };
  sourceContent = sourceContent.replace(
    /module\.exports\s*=\s*typedocSidebar\.items;/,
    'module.exports = {\n  docs: typedocSidebar.items\n};'
  );

  // Write to target sidebar
  fs.writeFileSync(targetSidebar, sourceContent, 'utf8');

  console.log(`   Updated: ${targetSidebar}`);
}

/**
 * Clean target directory (remove old files)
 */
function cleanDirectory(dir) {
  if (fs.existsSync(dir)) {
    console.log(`🧹 Cleaning target directory: ${dir}`);
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

/**
 * Main execution
 */
function main() {
  console.log('📚 DocSpace Plugin SDK - Documentation Copy Tool\n');

  // Validate source directory exists
  if (!fs.existsSync(SOURCE_DIR)) {
    console.error(`❌ Error: Source directory not found: ${SOURCE_DIR}`);
    console.error('Please run "npm run docs" first to generate documentation.');
    process.exit(1);
  }

  // Validate target directory parent exists
  const targetParent = path.dirname(targetDir);
  if (!fs.existsSync(targetParent)) {
    console.error(`❌ Error: Target parent directory not found: ${targetParent}`);
    console.error('Please ensure the plugin-sdk-doc project is cloned in the correct location.');
    process.exit(1);
  }

  // Validate sidebar files exist
  if (!fs.existsSync(SOURCE_SIDEBAR)) {
    console.error(`❌ Error: Source sidebar not found: ${SOURCE_SIDEBAR}`);
    process.exit(1);
  }

  console.log(`📂 Source docs: ${SOURCE_DIR}`);
  console.log(`📂 Target docs: ${targetDir}`);
  console.log(`📄 Source sidebar: ${SOURCE_SIDEBAR}`);
  console.log(`📄 Target sidebar: ${targetSidebar}\n`);

  try {
    // Clean target directory
    cleanDirectory(targetDir);

    // Copy documentation files (excluding sidebar)
    console.log('📋 Copying documentation files...');
    copyDirectory(SOURCE_DIR, targetDir);

    // Integrate sidebar
    integrateSidebar(SOURCE_SIDEBAR, targetSidebar);

    console.log('\n✅ Documentation copied and sidebar integrated successfully!');
    console.log(`\n📍 Documentation is now available at:\n   ${targetDir}`);
    console.log(`📍 Sidebar configuration updated at:\n   ${targetSidebar}`);
  } catch (error) {
    console.error('\n❌ Error:', error.message);
    process.exit(1);
  }
}

main();
