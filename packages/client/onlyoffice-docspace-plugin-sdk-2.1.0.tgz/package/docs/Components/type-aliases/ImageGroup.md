# Type Alias: ImageGroup

> **ImageGroup** = `object`

Defined in: [interfaces/components/Component.ts:261](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L261)

Defines the image component.

## Example

```typescript
import { IImage, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const image: IImage = {
  src: "https://example.com/plugin-banner.png",
  alt: "Plugin Banner",
  width: "100%",
  height: "auto",
  name: "plugin-banner",
  id: "banner-image",
  style: {
    borderRadius: "8px",
    boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
    maxWidth: "600px"
  }
};

const imageGroup: Component = {
  component: Components.img,
  props: image,
  contextName: "bannerImage"
};
```

## Properties

### component

> **component**: [`img`](../../enumerations/Components.md#img)

Defined in: [interfaces/components/Component.ts:263](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L263)

Defines the "img" component type

***

### props

> **props**: [`IImage`](../interfaces/IImage.md)

Defined in: [interfaces/components/Component.ts:265](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L265)

Defines the image component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:267](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L267)

Defines the image component context name that updates the component via React context
