# UsersType

Defined in: [enums/UsersType.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/UsersType.ts#L22)

Defines the supported user types.

## Enumeration Members

### owner

```ts
owner: "Owner";
```

Defined in: [enums/UsersType.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/UsersType.ts#L24)

System owner with full administrative rights and control over the entire DocSpace instance

### docSpaceAdmin

```ts
docSpaceAdmin: "DocSpaceAdmin";
```

Defined in: [enums/UsersType.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/UsersType.ts#L27)

Administrator with system-wide management capabilities but limited compared to owner

### roomAdmin

```ts
roomAdmin: "RoomAdmin";
```

Defined in: [enums/UsersType.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/UsersType.ts#L30)

User with administrative rights within specific rooms or workspaces

### collaborator

```ts
collaborator: "Collaborator";
```

Defined in: [enums/UsersType.ts:33](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/UsersType.ts#L33)

User with enhanced permissions for content creation and modification

### user

```ts
user: "User";
```

Defined in: [enums/UsersType.ts:36](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/UsersType.ts#L36)

Regular user with basic access rights for viewing and interacting with content
