#!/usr/bin/env node

/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Kept for plugins whose build script still calls the pre-3.0 name. The warning
// has to print before the command runs, so the hand-over is a dynamic import.
console.warn(
  `⚠️  'build-docspace-plugin' is deprecated. Use 'build-onlyoffice-plugin' instead.`
);

await import("./buildPlugin.js");
