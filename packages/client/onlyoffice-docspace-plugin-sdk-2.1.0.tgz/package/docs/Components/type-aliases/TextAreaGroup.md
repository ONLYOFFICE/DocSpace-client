# Type Alias: TextAreaGroup

> **TextAreaGroup** = `object`

Defined in: [interfaces/components/Component.ts:442](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L442)

Defines the textarea component.

## Example

```typescript
import { ITextArea, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const textarea: ITextArea = {
  value: "",
  onChange: (value) => {},
  placeholder: "Enter description...",
  heightTextArea: 150,
  fontSize: 14,
  isFullHeight: true,
  heightScale: true,
  maxLength: 1000,
  hasNumeration: false
};

const textAreaGroup: Component = {
  component: Components.textArea,
  props: textarea,
  contextName: "descriptionEditor"
};
```

## Properties

### component

> **component**: [`textArea`](../../enumerations/Components.md#textarea)

Defined in: [interfaces/components/Component.ts:444](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L444)

Defines the "textArea" component type

***

### props

> **props**: [`ITextArea`](../interfaces/ITextArea.md)

Defined in: [interfaces/components/Component.ts:446](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L446)

Defines the textarea component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:448](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L448)

Defines the textarea component context name that updates the component via React context
