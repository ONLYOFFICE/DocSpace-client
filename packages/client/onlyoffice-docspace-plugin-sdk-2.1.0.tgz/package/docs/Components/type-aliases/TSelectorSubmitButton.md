# Type Alias: TSelectorSubmitButton

> **TSelectorSubmitButton** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:583](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L583)

Defines properties for the submit button in the selector.

## Behavior

### onSubmit()

> **onSubmit**: (`params`) => `TReturnMessage`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:601](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L601)

A callback function that is triggered when the submit button is clicked.

#### Parameters

##### params

`TOnSubmitParams`

#### Returns

`TReturnMessage`

## Content

### submitButtonLabel

> **submitButtonLabel**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:589](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L589)

The text label for the submit button.

## State

### disabledSubmitButton?

> `optional` **disabledSubmitButton**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:595](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L595)

If true, the submit button will be disabled.
