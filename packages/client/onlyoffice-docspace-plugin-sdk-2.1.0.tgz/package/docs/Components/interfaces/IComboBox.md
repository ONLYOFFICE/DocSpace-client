# Interface: IComboBox

Defined in: [interfaces/components/IComboBox.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L151)

Custom combo box input.

## Example

Multi-language selector with toast notifications

```typescript
const languageSelector: IComboBox = {
  options: [
    {
      key: "en-US",
      label: "English (US)",
      icon: "language-en.svg"
    },
    {
      key: "es-ES",
      label: "Español",
      icon: "language-es.svg"
    },
    {
      key: "fr-FR",
      label: "Français",
      icon: "language-fr.svg",
      disabled: true
    }
  ],
  selectedOption: {
    key: "en-US",
    label: "English (US)",
    icon: "language-en.svg"
  },
  onSelect: (item) => {
    return {
      actions: [Actions.updateProps, Actions.showToast],
      newProps: {
        selectedOption: item
      },
      toastProps: [{
        title: "Language Changed",
        type: "success",
        message: `Interface language changed to ${item.label}`
      }]
    };
  },
  scaled: true,
  directionX: "right",
  directionY: "bottom",
  displayType: "default",
  dropDownMaxHeight: 300,
  showDisabledItems: true,
  withBackdrop: true,
  isDisabled: false,
  noBorder: false,
  opened: false,
  scaledOptions: true,
  modernView: true
}
```

## Appearance

### scaled?

> `optional` **scaled**: `boolean`

Defined in: [interfaces/components/IComboBox.ts:178](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L178)

Specifies that the combo box is scaled by its parent

***

### directionX?

> `optional` **directionX**: `"left"` \| `"right"`

Defined in: [interfaces/components/IComboBox.ts:185](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L185)

Defines the position of the combo box in the X direction

***

### directionY?

> `optional` **directionY**: `"both"` \| `"top"` \| `"bottom"`

Defined in: [interfaces/components/IComboBox.ts:192](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L192)

Defines the position of the combo box in the Y direction

***

### displayType?

> `optional` **displayType**: `"default"` \| `"toggle"`

Defined in: [interfaces/components/IComboBox.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L199)

Defines the combo box display type

***

### modernView?

> `optional` **modernView**: `boolean`

Defined in: [interfaces/components/IComboBox.ts:206](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L206)

Specifies whether to display the combo box in the modern view

***

### scaledOptions?

> `optional` **scaledOptions**: `boolean`

Defined in: [interfaces/components/IComboBox.ts:234](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L234)

Specifies whether the combo box options are scaled by the combo box button

***

### noBorder?

> `optional` **noBorder**: `boolean`

Defined in: [interfaces/components/IComboBox.ts:248](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L248)

Specifies whether to display the combo box without borders

***

### withBackdrop?

> `optional` **withBackdrop**: `boolean`

Defined in: [interfaces/components/IComboBox.ts:255](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L255)

Specifies whether the combo box contains a backdrop

***

### dropDownMaxHeight?

> `optional` **dropDownMaxHeight**: `number`

Defined in: [interfaces/components/IComboBox.ts:262](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L262)

Defines the maximum height of the dropdown list

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/IComboBox.ts:270](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L270)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Behavior

Callback functions for handling option selection and toggle interactions.

### onSelect()?

> `optional` **onSelect**: (`item`) => `void` \| `IMessage`

Defined in: [interfaces/components/IComboBox.ts:171](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L171)

Sets a function which is triggered whenever the combo box is selected

#### Parameters

##### item

[`IComboBoxItem`](IComboBoxItem.md)

#### Returns

`void` \| `IMessage`

***

### onToggle()?

> `optional` **onToggle**: () => `void` \| `IMessage`

Defined in: [interfaces/components/IComboBox.ts:241](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L241)

Sets a function which is triggered whenever the combo box is clicked when "displayType == toggle"

#### Returns

`void` \| `IMessage`

## Options

Properties that define the available options and currently selected option in the combo box.

### options

> **options**: [`IComboBoxItem`](IComboBoxItem.md)[]

Defined in: [interfaces/components/IComboBox.ts:157](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L157)

Defines the combo box options

## State

Properties that control the combo box's disabled, opened, and visibility states.

### selectedOption

> **selectedOption**: [`IComboBoxItem`](IComboBoxItem.md)

Defined in: [interfaces/components/IComboBox.ts:164](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L164)

Defines the combo box selected option

***

### isDisabled?

> `optional` **isDisabled**: `boolean`

Defined in: [interfaces/components/IComboBox.ts:213](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L213)

Specifies if the combo box is disabled or not

***

### showDisabledItems?

> `optional` **showDisabledItems**: `boolean`

Defined in: [interfaces/components/IComboBox.ts:220](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L220)

Whether to show disabled combo box options

***

### opened?

> `optional` **opened**: `boolean`

Defined in: [interfaces/components/IComboBox.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IComboBox.ts#L227)

Specifies whether to open the combo box
