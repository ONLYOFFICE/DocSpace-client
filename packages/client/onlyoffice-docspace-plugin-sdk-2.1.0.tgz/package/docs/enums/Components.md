# Components

Defined in: [enums/Components.ts:22](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L22)

Defines the available UI component.

## Enumeration Members

### box

```ts
box: "box";
```

Defined in: [enums/Components.ts:24](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L24)

Container component for grouping other elements

### button

```ts
button: "button";
```

Defined in: [enums/Components.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L27)

Interactive button element

### checkbox

```ts
checkbox: "checkbox";
```

Defined in: [enums/Components.ts:30](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L30)

Selectable checkbox input

### input

```ts
input: "input";
```

Defined in: [enums/Components.ts:33](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L33)

Text input field

### label

```ts
label: "label";
```

Defined in: [enums/Components.ts:36](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L36)

Text label for form elements

### text

```ts
text: "text";
```

Defined in: [enums/Components.ts:39](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L39)

Static text display

### textArea

```ts
textArea: "textArea";
```

Defined in: [enums/Components.ts:42](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L42)

Multi-line text input

### toggleButton

```ts
toggleButton: "toggleButton";
```

Defined in: [enums/Components.ts:45](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L45)

Switch-like button with two states

### img

```ts
img: "img";
```

Defined in: [enums/Components.ts:48](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L48)

Image display component

### iFrame

```ts
iFrame: "iFrame";
```

Defined in: [enums/Components.ts:51](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L51)

Embedded frame component

### comboBox

```ts
comboBox: "comboBox";
```

Defined in: [enums/Components.ts:54](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L54)

Dropdown selection input

### skeleton

```ts
skeleton: "skeleton";
```

Defined in: [enums/Components.ts:57](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L57)

Loading placeholder component

### iconButton

```ts
iconButton: "iconButton";
```

Defined in: [enums/Components.ts:60](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L60)

Icon button component with hover and click states

### link

```ts
link: "link";
```

Defined in: [enums/Components.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Components.ts#L63)

Hyperlink component
