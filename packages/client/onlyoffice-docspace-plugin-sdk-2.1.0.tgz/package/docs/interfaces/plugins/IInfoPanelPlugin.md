# IInfoPanelPlugin

Defined in: [interfaces/plugins/IInfoPanelPlugin.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L88)

The plugin that is embedded as a separate tab in the file info panel.

## Methods

### addInfoPanelItem()

```ts
addInfoPanelItem(item: IInfoPanelItem): void;
```

Defined in: [interfaces/plugins/IInfoPanelPlugin.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L96)

Add a new info panel item

#### Parameters

##### item

[`IInfoPanelItem`](../items/IInfoPanelItem.md)

#### Returns

`void`

### getInfoPanelItems()

```ts
getInfoPanelItems(): Map<string, IInfoPanelItem>;
```

Defined in: [interfaces/plugins/IInfoPanelPlugin.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L99)

Get all the info panel items

#### Returns

`Map`\<`string`, [`IInfoPanelItem`](../items/IInfoPanelItem.md)\>

### updateInfoPanelItem()

```ts
updateInfoPanelItem(item: IInfoPanelItem): void;
```

Defined in: [interfaces/plugins/IInfoPanelPlugin.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L102)

Update the info panel item

#### Parameters

##### item

[`IInfoPanelItem`](../items/IInfoPanelItem.md)

#### Returns

`void`

## Properties

### infoPanelItems

```ts
infoPanelItems: Map<string, IInfoPanelItem>;
```

Defined in: [interfaces/plugins/IInfoPanelPlugin.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IInfoPanelPlugin.ts#L93)

Stores a collection of elements where the keys are the key parameters from the InfoPanelItem objects.
A list for embedding into the info panel is generated based on this collection.

## Example

The plugin class implements `IInfoPanelPlugin` and registers a "Document Info" tab
in the constructor. DocSpace calls `getInfoPanelItems` to embed the tabs into the
file info panel; the tab UI is described by the item's `body` box.

```typescript
import {
  type IInfoPanelItem,
  type IInfoPanelPlugin,
  Components,
  Actions,
  ToastType,
  FilesType,
} from "@onlyoffice/docspace-plugin-sdk";

class Plugin implements IInfoPanelPlugin {
  infoPanelItems: Map<string, IInfoPanelItem> = new Map();

  constructor() {
    this.addInfoPanelItem({
      key: "doc-info",
      subMenu: {
        name: "Document Info",
        onClick: async (id) => {
          try {
            await getDocumentInfo(id);
          } catch (error) {
            return {
              actions: [Actions.showToast],
              toastProps: [{
                type: ToastType.error,
                title: "Unable to load the document info"
              }]
            };
          }
        }
      },
      body: {
        children: [
          {
            component: Components.text,
            props: { text: "Document details will be displayed here" }
          }
        ]
      },
      filesType: [FilesType.file]
    });
  }

  addInfoPanelItem = (item: IInfoPanelItem): void => {
    this.infoPanelItems.set(item.key, item);
  };

  getInfoPanelItems = (): Map<string, IInfoPanelItem> => {
    return this.infoPanelItems;
  };

  updateInfoPanelItem = (item: IInfoPanelItem): void => {
    this.infoPanelItems.set(item.key, item);
  };
}
```

