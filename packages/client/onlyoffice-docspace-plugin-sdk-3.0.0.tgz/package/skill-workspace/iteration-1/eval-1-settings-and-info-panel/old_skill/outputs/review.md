# room-storage (old_skill)

- pluginName: `RoomStorage`  version: `1.0.0`  scopes: `["InfoPanel","Settings","API"]`
- zip built: yes

## src/api.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

type TApiParts = { origin: string; proxy: string; prefix: string };

let getApiParts: (() => TApiParts) | null = null;

/** Wired once from index.ts; the URL itself is built lazily on first use. */
export const setApiSource = (source: () => TApiParts): void => {
  getApiParts = source;
};

/**
 * The three parts come from the portal via setAPI and may be empty or carry
 * stray slashes, so join them carefully. Built lazily - setAPI is guaranteed
 * to have run only before onLoadCallback, never before module scope.
 */
const buildApiUrl = (): string => {
  if (!getApiParts) return "";

  const { origin, proxy, prefix } = getApiParts();

  let url = origin.replace(/\/+$/, "");

  for (const part of [proxy, prefix]) {
    if (!part) continue;
    const clean = part.trim().replace(/^\/+/, "");
    if (!clean) continue;
    url += url.endsWith("/") ? clean : `/${clean}`;
  }

  return url; // e.g. https://portal.example.com/api/2.0
};

/** The fields of the room DTO this plugin reads; everything else is ignored. */
export type TRoomInfo = {
  title?: string;
  /** Bytes. Absent when storage statistics are off or the user lacks rights. */
  usedSpace?: number;
  createdBy?: { displayName?: string };
};

/**
 * Room metadata. Requests ride the signed-in user's session - no token exists.
 * Every DocSpace endpoint wraps its payload in a `response` field.
 */
export const fetchRoomInfo = async (roomId: number | string): Promise<TRoomInfo> => {
  const res = await fetch(`${buildApiUrl()}/files/rooms/${roomId}`, {
    credentials: "include",
  });

  if (!res.ok) throw new Error(`GET /files/rooms/${roomId} -> ${res.status}`);

  return ((await res.json()) as { response: TRoomInfo }).response ?? {};
};
```

## src/index.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  IApiPlugin,
  IInfoPanelItem,
  IInfoPanelPlugin,
  IPlugin,
  ISettings,
  ISettingsPlugin,
  PluginLocale,
  PluginStatus,
} from "@onlyoffice/docspace-plugin-sdk";

import { setApiSource } from "./api";
import { roomStorageInfoPanelItem } from "./infoPanel";
import { currentLocale, setLocale } from "./locales";
import { applyStoredSettings, roomStorageSettings } from "./settings";

class RoomStorage
  implements IPlugin, IInfoPanelPlugin, ISettingsPlugin, IApiPlugin
{
  status: PluginStatus = PluginStatus.active;

  infoPanelItems: Map<string, IInfoPanelItem> = new Map();

  adminPluginSettings: ISettings | null = null;

  setAdminPluginSettings = (settings: ISettings | null): void => {
    this.adminPluginSettings = settings;
  };

  // The portal hands settings back as the raw string the plugin saved earlier,
  // and it arrives *after* installation - so parse defensively.
  setAdminPluginSettingsValue = (settings: string | null): void => {
    applyStoredSettings(settings);
    this.adminPluginSettings = roomStorageSettings();
  };

  getAdminPluginSettings = (): ISettings | null => this.adminPluginSettings;

  origin = "";

  proxy = "";

  prefix = "";

  setOrigin = (origin: string): void => {
    this.origin = origin;
  };

  getOrigin = (): string => this.origin;

  setProxy = (proxy: string): void => {
    this.proxy = proxy;
  };

  getProxy = (): string => this.proxy;

  setPrefix = (prefix: string): void => {
    this.prefix = prefix;
  };

  getPrefix = (): string => this.prefix;

  setAPI = (origin: string, proxy: string, prefix: string): void => {
    this.origin = origin;
    this.proxy = proxy;
    this.prefix = prefix;
  };

  getAPI = (): { origin: string; proxy: string; prefix: string } => ({
    origin: this.origin,
    proxy: this.proxy,
    prefix: this.prefix,
  });

  // Register items here rather than at module scope. Both are read in time, but
  // setLanguage and setAPI only run after the bundle executes - so a factory that
  // translates a label or calls getAPI() at module scope would capture empty values.
  onLoadCallback = async (): Promise<void> => {
    this.addInfoPanelItem(roomStorageInfoPanelItem());
    this.adminPluginSettings = roomStorageSettings();
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  // The portal calls this when the interface language changes. Labels were
  // captured when the items were built, so the items have to be rebuilt.
  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
    this.updateInfoPanelItem(roomStorageInfoPanelItem());
    if (this.adminPluginSettings) this.adminPluginSettings = roomStorageSettings();
  };

  getLanguage = (): PluginLocale => currentLocale();

  addInfoPanelItem = (item: IInfoPanelItem): void => {
    this.infoPanelItems.set(item.key, item);
  };

  getInfoPanelItems = (): Map<string, IInfoPanelItem> => this.infoPanelItems;

  updateInfoPanelItem = (item: IInfoPanelItem): void => {
    this.infoPanelItems.set(item.key, item);
  };
}

const plugin = new RoomStorage();

// The URL builder reads the API parts lazily, on first fetch - by then setAPI
// has run (it always precedes onLoadCallback).
setApiSource(plugin.getAPI);

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.RoomStorage = plugin || {};

export default plugin;
```

## src/infoPanel.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Component,
  Components,
  FilesType,
  IBox,
  IInfoPanelItem,
  IText,
} from "@onlyoffice/docspace-plugin-sdk";

import { fetchRoomInfo, TRoomInfo } from "./api";
import { t } from "./locales";
import { formatGb, getThresholdGb } from "./settings";

const ERROR_COLOR = "var(--error-color, var(--input-error-color, #f24724))";

const BYTES_IN_GB = 1024 * 1024 * 1024;

/**
 * The id of the room the tab was last opened for. The host passes it to
 * subMenu.onClick when the tab is clicked, then calls onLoad for the body.
 */
let currentRoomId: number | string | null = null;

const formatBytes = (bytes: number): string => {
  const units = [t("units.b"), t("units.kb"), t("units.mb"), t("units.gb"), t("units.tb")];

  let value = Math.max(bytes, 0);
  let unit = 0;

  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }

  const digits = unit === 0 ? 0 : value >= 100 ? 0 : value >= 10 ? 1 : 2;

  return `${parseFloat(value.toFixed(digits))} ${units[unit]}`;
};

const text = (props: IText): Component => ({
  component: Components.text,
  props,
});

const panel = (children: Component[]): IBox => ({
  widthProp: "100%",
  paddingProp: "12px 16px",
  displayProp: "flex",
  flexDirection: "column",
  children,
});

const row = (label: string, value: string, valueColor?: string): Component => ({
  component: Components.box,
  props: {
    displayProp: "flex",
    flexDirection: "column",
    paddingProp: "0 0 12px 0",
    children: [
      text({ text: label, fontSize: "12px" }),
      text({ text: value, isBold: true, fontSize: "13px", color: valueColor }),
    ],
  },
});

const loadingBody = (): IBox =>
  panel([
    { component: Components.skeleton, props: { width: "100%", height: "32px" } },
    { component: Components.box, props: { heightProp: "12px" } },
    { component: Components.skeleton, props: { width: "100%", height: "32px" } },
  ]);

const messageBody = (title: string, hint: string): IBox =>
  panel([
    text({ text: title, isBold: true, fontSize: "13px" }),
    { component: Components.box, props: { heightProp: "8px" } },
    text({ text: hint, fontSize: "12px" }),
  ]);

const roomBody = (room: TRoomInfo): IBox => {
  const thresholdGb = getThresholdGb();
  const hasSize = typeof room.usedSpace === "number" && isFinite(room.usedSpace);
  const overThreshold =
    hasSize && thresholdGb !== null && (room.usedSpace as number) > thresholdGb * BYTES_IN_GB;

  const children: Component[] = [
    row(
      t("infoPanel.size"),
      hasSize ? formatBytes(room.usedSpace as number) : t("infoPanel.sizeUnavailable"),
      overThreshold ? ERROR_COLOR : undefined,
    ),
  ];

  if (overThreshold && thresholdGb !== null) {
    children.push(
      text({
        text: t("infoPanel.overThreshold", { gb: formatGb(thresholdGb) }),
        fontSize: "12px",
        color: ERROR_COLOR,
      }),
      { component: Components.box, props: { heightProp: "12px" } },
    );
  }

  if (!hasSize) {
    children.push(
      text({ text: t("infoPanel.sizeUnavailableHint"), fontSize: "12px" }),
      { component: Components.box, props: { heightProp: "12px" } },
    );
  }

  children.push(
    row(t("infoPanel.owner"), room.createdBy?.displayName || t("infoPanel.ownerUnknown")),
  );

  return panel(children);
};

export const roomStorageInfoPanelItem = (): IInfoPanelItem => ({
  key: "room-storage-info-panel",
  subMenu: {
    name: t("infoPanel.tab"),
    // The host passes the current room id here when the tab is clicked;
    // onLoad below (which takes no arguments) then fetches for that room.
    onClick: (id: number): void => {
      currentRoomId = id;
    },
  },
  body: loadingBody(),
  onLoad: async () => {
    if (currentRoomId === null) {
      return { body: messageBody(t("infoPanel.loadFailed"), t("infoPanel.retryHint")) };
    }

    try {
      return { body: roomBody(await fetchRoomInfo(currentRoomId)) };
    } catch {
      // Nothing wraps plugin callbacks - an uncaught rejection here would be
      // a permanently blank tab.
      return { body: messageBody(t("infoPanel.loadFailed"), t("infoPanel.retryHint")) };
    }
  },
  filesType: [FilesType.room],
});
```

## src/locales.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 */
export type TStrings = {
  "infoPanel.tab": string;
  "infoPanel.size": string;
  "infoPanel.owner": string;
  "infoPanel.ownerUnknown": string;
  "infoPanel.sizeUnavailable": string;
  "infoPanel.sizeUnavailableHint": string;
  "infoPanel.overThreshold": string;
  "infoPanel.loadFailed": string;
  "infoPanel.retryHint": string;
  "settings.thresholdLabel": string;
  "settings.thresholdHint": string;
  "settings.invalidNumber": string;
  "settings.save": string;
  "settings.saved": string;
  "settings.saveFailed": string;
  "units.b": string;
  "units.kb": string;
  "units.mb": string;
  "units.gb": string;
  "units.tb": string;
};

const en: TStrings = {
  "infoPanel.tab": "Storage",
  "infoPanel.size": "Size",
  "infoPanel.owner": "Owner",
  "infoPanel.ownerUnknown": "Unknown",
  "infoPanel.sizeUnavailable": "Unavailable",
  "infoPanel.sizeUnavailableHint":
    "Storage statistics are disabled on this portal, or you do not have permission to see them.",
  "infoPanel.overThreshold": "Exceeds the {gb} GB threshold",
  "infoPanel.loadFailed": "Could not load room information.",
  "infoPanel.retryHint": "Switch to another tab and back to try again.",
  "settings.thresholdLabel": "Size threshold (GB)",
  "settings.thresholdHint":
    "Rooms larger than this are highlighted in red in the Storage tab. Leave empty to disable highlighting.",
  "settings.invalidNumber": "Enter a non-negative number, e.g. 10 or 2.5",
  "settings.save": "Save",
  "settings.saved": "Settings saved",
  "settings.saveFailed": "Check the threshold value",
  "units.b": "B",
  "units.kb": "KB",
  "units.mb": "MB",
  "units.gb": "GB",
  "units.tb": "TB",
};

const ru: TStrings = {
  "infoPanel.tab": "Хранилище",
  "infoPanel.size": "Размер",
  "infoPanel.owner": "Владелец",
  "infoPanel.ownerUnknown": "Неизвестно",
  "infoPanel.sizeUnavailable": "Недоступно",
  "infoPanel.sizeUnavailableHint":
    "На портале отключена статистика хранилища, или у вас недостаточно прав для её просмотра.",
  "infoPanel.overThreshold": "Превышен порог {gb} ГБ",
  "infoPanel.loadFailed": "Не удалось загрузить сведения о комнате.",
  "infoPanel.retryHint": "Переключитесь на другую вкладку и обратно, чтобы повторить.",
  "settings.thresholdLabel": "Порог размера (ГБ)",
  "settings.thresholdHint":
    "Комнаты крупнее этого значения подсвечиваются красным во вкладке «Хранилище». Оставьте поле пустым, чтобы отключить подсветку.",
  "settings.invalidNumber": "Введите неотрицательное число, например 10 или 2,5",
  "settings.save": "Сохранить",
  "settings.saved": "Настройки сохранены",
  "settings.saveFailed": "Проверьте значение порога",
  "units.b": "Б",
  "units.kb": "КБ",
  "units.mb": "МБ",
  "units.gb": "ГБ",
  "units.tb": "ТБ",
};

const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.EN_US]: en,
  [PluginLocale.EN_GB]: en,
  [PluginLocale.RU]: ru,
};

let locale: PluginLocale = PluginLocale.EN_US;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.EN_US;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings, params?: Record<string, string>): string => {
  let text = (translations[locale] ?? en)[key];

  if (params) {
    for (const name of Object.keys(params)) {
      text = text.split(`{${name}}`).join(params[name]);
    }
  }

  return text;
};
```

## src/settings.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  ButtonSize,
  Components,
  IBox,
  IInput,
  IMessage,
  InputSize,
  ISettings,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

import { t } from "./locales";

/** The opaque string stored by the portal is this, JSON-encoded. */
type TStoredSettings = { thresholdGb: number | null };

const ERROR_CONTEXT = "room-storage-settings-error";

/** null = no threshold configured, highlighting disabled. */
let thresholdGb: number | null = null;

/** What the admin is currently typing in the settings input. */
let draft = "";

export const getThresholdGb = (): number | null => thresholdGb;

/** Trims a formatted number: 2.50 -> "2.5", 10.00 -> "10". */
export const formatGb = (value: number): string =>
  String(parseFloat(value.toFixed(2)));

/**
 * Empty input means "no threshold". Accepts both decimal separators because
 * the portal ships in locales that type "2,5".
 */
const parseDraft = (
  text: string,
): { ok: true; value: number | null } | { ok: false } => {
  const trimmed = text.trim();

  if (!trimmed) return { ok: true, value: null };

  const value = Number(trimmed.replace(",", "."));

  if (!isFinite(value) || value < 0) return { ok: false };

  return { ok: true, value };
};

/**
 * Stored settings arrive via setAdminPluginSettingsValue *after* installation,
 * never during onLoadCallback - and a malformed value must not throw, or it
 * breaks installation.
 */
export const applyStoredSettings = (raw: string | null): void => {
  if (!raw) return;

  try {
    const parsed = JSON.parse(raw) as Partial<TStoredSettings>;
    const value =
      typeof parsed.thresholdGb === "string"
        ? Number(parsed.thresholdGb)
        : parsed.thresholdGb;

    if (typeof value === "number" && isFinite(value) && value >= 0) {
      thresholdGb = value;
      draft = formatGb(value);
    } else if (value === null) {
      thresholdGb = null;
      draft = "";
    }
  } catch {
    // Keep the defaults rather than breaking installation on a bad stored value.
  }
};

const errorMessage = (text: string): IMessage => ({
  actions: [Actions.updateContext],
  contextProps: [{ name: ERROR_CONTEXT, props: { text } }],
});

const onDraftChange = (value: string): IMessage => {
  draft = value;

  const invalid = !parseDraft(value).ok;

  return {
    actions: [Actions.updateProps, Actions.updateContext],
    newProps: { ...thresholdInput(), value, hasError: invalid },
    contextProps: [
      {
        name: ERROR_CONTEXT,
        props: { text: invalid ? t("settings.invalidNumber") : "" },
      },
    ],
  };
};

const thresholdInput = (): IInput => ({
  value: draft,
  placeholder: "10",
  size: InputSize.base,
  scale: true,
  onChange: onDraftChange,
});

const settingsBody = (): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [
    {
      component: Components.text,
      props: { text: t("settings.thresholdLabel"), isBold: true, fontSize: "13px" },
    },
    { component: Components.box, props: { heightProp: "8px" } },
    {
      component: Components.input,
      props: thresholdInput(),
    },
    {
      component: Components.text,
      contextName: ERROR_CONTEXT,
      props: {
        text: "",
        fontSize: "12px",
        color: "var(--error-color, var(--input-error-color, #f24724))",
      },
    },
    { component: Components.box, props: { heightProp: "8px" } },
    {
      component: Components.text,
      props: { text: t("settings.thresholdHint"), fontSize: "12px" },
    },
  ],
});

export const roomStorageSettings = (): ISettings => ({
  settings: settingsBody(),
  saveButton: {
    component: Components.button,
    props: {
      label: t("settings.save"),
      size: ButtonSize.normal,
      primary: true,
      onClick: async (): Promise<IMessage> => {
        const parsed = parseDraft(draft);

        if (!parsed.ok) {
          return {
            ...errorMessage(t("settings.invalidNumber")),
            actions: [Actions.updateContext, Actions.showToast],
            toastProps: [{ type: ToastType.error, title: t("settings.saveFailed") }],
          };
        }

        thresholdGb = parsed.value;
        draft = parsed.value === null ? "" : formatGb(parsed.value);

        // saveSettings is honoured only from this button - nowhere else.
        return {
          actions: [Actions.saveSettings, Actions.updateContext, Actions.showToast],
          settings: JSON.stringify({ thresholdGb } as TStoredSettings),
          contextProps: [{ name: ERROR_CONTEXT, props: { text: "" } }],
          toastProps: [{ type: ToastType.success, title: t("settings.saved") }],
        };
      },
    },
  },
  // Rebuild on every open so the input reflects the currently stored value.
  onLoad: async () => ({ settings: settingsBody() }),
});
```
