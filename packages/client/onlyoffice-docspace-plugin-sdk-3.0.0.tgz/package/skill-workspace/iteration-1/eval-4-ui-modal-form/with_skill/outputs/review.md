# send-to-archive (with_skill)

- pluginName: `SendToArchive`  version: `1.0.0`  scopes: `["MainButton"]`
- zip built: yes

## src/archiveDialog.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  ButtonSize,
  Components,
  IBox,
  IComboBox,
  IComboBoxItem,
  IInput,
  IMessage,
  IModalDialog,
  IText,
  ModalDisplayType,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

import { t } from "./locales";

/**
 * The "Send to archive" dialog: a URL field with live validation, a format
 * combo box (zip / tar.gz) and a single "Send" button.
 *
 * Everything visible is rebuilt from this module-level state. `updateProps`
 * REPLACES an element's props rather than merging, so every factory below
 * returns the complete prop set for its element.
 */

const URL_INPUT_CONTEXT = "send-to-archive-url-input";
const URL_ERROR_CONTEXT = "send-to-archive-url-error";

type TArchiveFormatKey = "zip" | "tar.gz";

let url = "";
let urlError = "";
let formatKey: TArchiveFormatKey = "zip";

const zipOption: IComboBoxItem = { key: "zip", label: "zip" };
const tarGzOption: IComboBoxItem = { key: "tar.gz", label: "tar.gz" };

const formatOptions = (): IComboBoxItem[] => [zipOption, tarGzOption];

const selectedFormatOption = (): IComboBoxItem =>
  formatKey === "tar.gz" ? tarGzOption : zipOption;

// The validation rule as requested: an empty URL, or one that does not
// start with https, is invalid.
const validationError = (value: string): string => {
  const trimmed = value.trim();
  if (!trimmed) return t("dialog.errorEmpty");
  if (!trimmed.startsWith("https")) return t("dialog.errorNotHttps");
  return "";
};

const urlErrorTextProps = (): IText => ({
  text: urlError,
  // --input-error-color is the portal's real error token; --error-color does not exist.
  color: "var(--input-error-color)",
  fontSize: "12px",
  lineHeight: "16px",
});

const urlInputProps = (): IInput => ({
  value: url,
  placeholder: "https://example.com/archive.zip",
  scale: true,
  isAutoFocused: true,
  tabIndex: 0,
  maxLength: "2048", // the host default is 255 - too short for URLs
  hasError: urlError !== "",
  // Live validation: the moment the value becomes empty or stops starting
  // with https, the red text under the field appears (updateContext) and the
  // border turns red (updateProps). Both actions work here only because this
  // callback runs inside the rendered modal tree.
  onChange: (value: string): IMessage => {
    url = value;
    urlError = validationError(value);
    return {
      actions: [Actions.updateProps, Actions.updateContext],
      newProps: urlInputProps(),
      contextProps: [{ name: URL_ERROR_CONTEXT, props: urlErrorTextProps() }],
    };
  },
});

const formatComboBoxProps = (): IComboBox => ({
  options: formatOptions(),
  selectedOption: selectedFormatOption(),
  scaled: true,
  scaledOptions: true, // otherwise the dropdown panel is a fixed 200px
  directionY: "both",
  // Selecting an option does not repaint the control by itself - return the
  // complete new prop set with the new selectedOption.
  onSelect: (option: IComboBoxItem): IMessage => {
    formatKey = option.key === "tar.gz" ? "tar.gz" : "zip";
    return {
      actions: [Actions.updateProps],
      newProps: formatComboBoxProps(),
    };
  },
});

const dialogBody = (): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [
    {
      component: Components.box,
      props: {
        marginProp: "0 0 4px 0",
        children: [
          {
            component: Components.label,
            props: { text: t("dialog.urlLabel"), isRequired: true },
          },
        ],
      },
    },
    {
      component: Components.input,
      contextName: URL_INPUT_CONTEXT,
      props: urlInputProps(),
    },
    {
      // A fixed-height row, so the error appearing does not shift the form.
      component: Components.box,
      props: {
        heightProp: "16px",
        marginProp: "4px 0 12px 0",
        children: [
          {
            component: Components.text,
            contextName: URL_ERROR_CONTEXT,
            props: urlErrorTextProps(),
          },
        ],
      },
    },
    {
      component: Components.box,
      props: {
        marginProp: "0 0 4px 0",
        children: [
          {
            component: Components.label,
            props: { text: t("dialog.formatLabel") },
          },
        ],
      },
    },
    {
      component: Components.comboBox,
      props: formatComboBoxProps(),
    },
  ],
});

const onSendClick = (): IMessage => {
  urlError = validationError(url);

  // Invalid: show the red text and the red border, and send nothing at all.
  // This is a sibling update from the button, so it goes through updateContext.
  if (urlError) {
    return {
      actions: [Actions.updateContext],
      contextProps: [
        { name: URL_ERROR_CONTEXT, props: urlErrorTextProps() },
        { name: URL_INPUT_CONTEXT, props: urlInputProps() },
      ],
    };
  }

  // Valid. The request names no backend, so the send is acknowledged with a
  // success toast; wire a real request here once an endpoint exists.
  const sentUrl = url.trim();
  const sentFormat = formatKey;

  return {
    actions: [Actions.closeModal, Actions.showToast],
    toastProps: [
      {
        type: ToastType.success,
        title: `${t("toast.sent")}: ${sentUrl} (${sentFormat})`,
      },
    ],
  };
};

const dialogFooter = (): IBox => ({
  displayProp: "flex",
  children: [
    {
      component: Components.button,
      props: {
        label: t("dialog.send"),
        size: ButtonSize.normal,
        primary: true,
        scale: true,
        onClick: onSendClick,
      },
    },
  ],
});

export const archiveDialog = (): IModalDialog => {
  // A fresh form on every open.
  url = "";
  urlError = "";
  formatKey = "zip";

  return {
    displayType: ModalDisplayType.modal,
    dialogHeader: t("dialog.header"),
    dialogBody: dialogBody(),
    dialogFooter: dialogFooter(),
    autoMaxHeight: true, // a bare modal caps at 280px and does not scroll
    onClose: () => ({ actions: [Actions.closeModal] }),
    // onLoad is mandatory and REPLACES header, body and footer together -
    // return every section the dialog has, or the omitted ones vanish.
    onLoad: async () => ({
      newDialogHeader: t("dialog.header"),
      newDialogBody: dialogBody(),
      newDialogFooter: dialogFooter(),
    }),
  };
};
```

## src/index.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  IMainButtonItem,
  IMainButtonPlugin,
  IMessage,
  IPlugin,
  PluginLocale,
  PluginStatus,
} from "@onlyoffice/docspace-plugin-sdk";

import { archiveDialog } from "./archiveDialog";
import { currentLocale, setLocale, t } from "./locales";

const sendToArchiveMainButtonItem = (): IMainButtonItem => ({
  key: "send-to-archive-main-button",
  label: t("mainButton.label"),
  icon: "icon-16.svg",
  // The host reads usersType (singular) for this scope; no filter -> everyone.
  // A menu item cannot update anything itself - it opens the modal, and all
  // updates (validation text, red border) happen from inside the modal tree.
  onItemClick: (): IMessage => ({
    actions: [Actions.showModal],
    modalDialogProps: archiveDialog(),
  }),
});

class SendToArchive
  implements
    IPlugin,
    IMainButtonPlugin
{
  status: PluginStatus = PluginStatus.active;

  mainButtonItems: Map<string, IMainButtonItem> = new Map();

  // Register items here rather than at module scope. Both are read in time, but
  // setLanguage and setAPI only run after the bundle executes - so a factory that
  // translates a label or calls getAPI() at module scope would capture empty values.
  onLoadCallback = async (): Promise<void> => {
    this.addMainButtonItem(sendToArchiveMainButtonItem());
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  // The portal calls this when the interface language changes. Labels were
  // captured when the items were built, so the items have to be rebuilt.
  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
    this.updateMainButtonItem(sendToArchiveMainButtonItem());
  };

  getLanguage = (): PluginLocale => currentLocale();

  addMainButtonItem = (item: IMainButtonItem): void => {
    this.mainButtonItems.set(item.key, item);
  };

  getMainButtonItems = (): Map<string, IMainButtonItem> => this.mainButtonItems;

  updateMainButtonItem = (item: IMainButtonItem): void => {
    this.mainButtonItems.set(item.key, item);
  };
}

const plugin = new SendToArchive();

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.SendToArchive = plugin || {};

export default plugin;
```

## src/locales.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 *
 * Russian is the plugin's base language (the feature was specified in Russian);
 * English is served on English portals, and any other locale falls back to English.
 */
export type TStrings = {
  "mainButton.label": string;
  "dialog.header": string;
  "dialog.urlLabel": string;
  "dialog.formatLabel": string;
  "dialog.errorEmpty": string;
  "dialog.errorNotHttps": string;
  "dialog.send": string;
  "toast.sent": string;
};

const ru: TStrings = {
  "mainButton.label": "Отправить в архив",
  "dialog.header": "Отправить в архив",
  "dialog.urlLabel": "URL архива",
  "dialog.formatLabel": "Формат",
  "dialog.errorEmpty": "Укажите URL архива",
  "dialog.errorNotHttps": "URL должен начинаться с https",
  "dialog.send": "Отправить",
  "toast.sent": "Архив отправлен",
};

const en: TStrings = {
  "mainButton.label": "Send to archive",
  "dialog.header": "Send to archive",
  "dialog.urlLabel": "Archive URL",
  "dialog.formatLabel": "Format",
  "dialog.errorEmpty": "Enter the archive URL",
  "dialog.errorNotHttps": "The URL must start with https",
  "dialog.send": "Send",
  "toast.sent": "Archive sent",
};

const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.RU]: ru,
  [PluginLocale.EN_US]: en,
};

let locale: PluginLocale = PluginLocale.RU;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.EN_US;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings): string => (translations[locale] ?? ru)[key];
```
