# IIconButton

Defined in: [interfaces/components/IIconButton.ts:61](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L61)

A component that displays an interactive icon button with hover and click states.

![iconbutton](/assets/images/docspace/iconbutton.png#gh-light-mode-only)![iconbutton](/assets/images/docspace/iconbutton.dark.png#gh-dark-mode-only)

## Properties

### iconName?

```ts
optional iconName: string;
```

Defined in: [interfaces/components/IIconButton.ts:67](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L67)

The button display icon. The icon image must be uploaded to the assets folder.
Only the image name with the extension must be specified in this field.
The icon is rendered at the size set in the `size` field.

### iconHoverName?

```ts
optional iconHoverName: string;
```

Defined in: [interfaces/components/IIconButton.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L73)

The icon displayed while the cursor is over the button. The icon image must be uploaded
to the assets folder. Only the image name with the extension must be specified in this field.

### iconClickName?

```ts
optional iconClickName: string;
```

Defined in: [interfaces/components/IIconButton.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L79)

The icon displayed while the button is being clicked. The icon image must be uploaded
to the assets folder. Only the image name with the extension must be specified in this field.

### color?

```ts
optional color: string;
```

Defined in: [interfaces/components/IIconButton.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L84)

Icon color. Can be "accent" or any CSS color value

### hoverColor?

```ts
optional hoverColor: string;
```

Defined in: [interfaces/components/IIconButton.ts:89](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L89)

Icon color on hover action

### clickColor?

```ts
optional clickColor: string;
```

Defined in: [interfaces/components/IIconButton.ts:94](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L94)

Icon color on click action

### size?

```ts
optional size: number;
```

Defined in: [interfaces/components/IIconButton.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L99)

Button height and width value. Can be a number (pixels)

### isFill?

```ts
optional isFill: boolean;
```

Defined in: [interfaces/components/IIconButton.ts:104](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L104)

Determines if icon fill is needed

### isStroke?

```ts
optional isStroke: boolean;
```

Defined in: [interfaces/components/IIconButton.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L109)

Determines if icon stroke is needed

### isDisabled?

```ts
optional isDisabled: boolean;
```

Defined in: [interfaces/components/IIconButton.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L114)

Sets the button to present a disabled state

### isClickable?

```ts
optional isClickable: boolean;
```

Defined in: [interfaces/components/IIconButton.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L119)

Sets cursor value to indicate clickability

### onClick()?

```ts
optional onClick: () => TReturnMessage;
```

Defined in: [interfaces/components/IIconButton.ts:124](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L124)

Sets a button callback function triggered when the button is clicked

#### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

### id?

```ts
optional id: string;
```

Defined in: [interfaces/components/IIconButton.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L129)

Sets component id

### title?

```ts
optional title: string;
```

Defined in: [interfaces/components/IIconButton.ts:134](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L134)

Data when user hover on icon (tooltip text)

### tooltipId?

```ts
optional tooltipId: string;
```

Defined in: [interfaces/components/IIconButton.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L139)

Tooltip id for advanced tooltip configuration

### tooltipContent?

```ts
optional tooltipContent: string;
```

Defined in: [interfaces/components/IIconButton.ts:144](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L144)

Tooltip content text

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IIconButton.ts:150](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IIconButton.ts#L150)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Example

Simple icon button with click handler

```typescript
const deleteButton: IIconButton = {
  iconName: "delete.svg",
  size: 20,
  color: "#333333",
  hoverColor: "#FF0000",
  onClick: async () => {
    try {
      await deleteItem();
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Item deleted successfully",
          type: ToastType.success
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Failed to delete item",
          type: ToastType.error
        }]
      };
    }
  },
  isDisabled: false,
  title: "Delete item"
}
```

