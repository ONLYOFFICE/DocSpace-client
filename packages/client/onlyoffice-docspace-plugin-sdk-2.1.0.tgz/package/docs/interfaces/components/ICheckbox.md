# ICheckbox

Defined in: [interfaces/components/ICheckbox.ts:59](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L59)

Custom checkbox.

![checkbox](/assets/images/docspace/checkbox.png#gh-light-mode-only)![checkbox](/assets/images/docspace/checkbox.dark.png#gh-dark-mode-only)

## Properties

### isChecked

```ts
isChecked: boolean;
```

Defined in: [interfaces/components/ICheckbox.ts:63](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L63)

Sets the checked state of the checkbox

### label?

```ts
optional label: string;
```

Defined in: [interfaces/components/ICheckbox.ts:68](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L68)

Defines the checkbox label

### onChange()

```ts
onChange: () => void | IMessage;
```

Defined in: [interfaces/components/ICheckbox.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L73)

Sets a function which is triggered whenever the checkbox input is clicked

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### truncate?

```ts
optional truncate: boolean;
```

Defined in: [interfaces/components/ICheckbox.ts:78](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L78)

Specifies if the word wrapping is disabled or not

### tabIndex?

```ts
optional tabIndex: number;
```

Defined in: [interfaces/components/ICheckbox.ts:83](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L83)

Defines the checkbox tab index

### hasError?

```ts
optional hasError: boolean;
```

Defined in: [interfaces/components/ICheckbox.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L88)

Specifies whether a notification will be sent if an error occurs

### name?

```ts
optional name: string;
```

Defined in: [interfaces/components/ICheckbox.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L93)

Defines the HTML "name" property

### value?

```ts
optional value: string;
```

Defined in: [interfaces/components/ICheckbox.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L98)

Defines the checkbox input value

### isIndeterminate?

```ts
optional isIndeterminate: boolean;
```

Defined in: [interfaces/components/ICheckbox.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L103)

Specifies whether the checkbox state will be displayed as a black rectangle in the checkbox when it is set to true

### isDisabled?

```ts
optional isDisabled: boolean;
```

Defined in: [interfaces/components/ICheckbox.ts:108](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L108)

Specifies if the checkbox input is disabled

### title?

```ts
optional title: string;
```

Defined in: [interfaces/components/ICheckbox.ts:113](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L113)

Defines the checkbox input title

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/ICheckbox.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICheckbox.ts#L119)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

## Example

Privacy policy checkbox with submit button state control

```typescript
const privacyCheckbox: ICheckbox = {
  isChecked: false,
  label: "I agree to the Privacy Policy",
  onChange: () => {
    return {
      actions: [Actions.updateProps, Actions.updateContext],
      newProps: {
        isChecked: !privacyCheckbox.isChecked
      },
      contextProps: [{
        name: "submitButton",
        props: {
          isDisabled: !privacyCheckbox.isChecked
        }
      }]
    };
  },
  truncate: false,
  tabIndex: 1,
  hasError: false,
  name: "privacy-policy",
  value: "accepted",
  isIndeterminate: false,
  isDisabled: false,
  title: "Privacy Policy Agreement"
}
```

