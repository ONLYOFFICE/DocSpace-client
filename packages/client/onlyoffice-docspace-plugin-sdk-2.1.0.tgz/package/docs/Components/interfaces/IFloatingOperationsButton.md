# Interface: IFloatingOperationsButton

Defined in: [interfaces/components/IFloatingOperationsButton.ts:179](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L179)

Configuration for the floating operations button.
Used to display progress of long-running operations (upload, conversion, backup, etc.)
The button appears as a floating action button in the bottom-right corner of DocSpace.

## Example

Demonstrates a floating operations in button with simulated upload progress, 
allowing users to cancel the process or remove individual operations while 
preventing a new upload until the current one finishes.

```typescript
import {
  IFloatingOperationsButton,
  FloatingOperationType,
  Actions,
  IContextMenuItem,
  FilesType,
} from "@onlyoffice/docspace-plugin-sdk";

const operations = [
  {
      id: "upload-document",
      label: "Uploading document.pdf",
      operation: FloatingOperationType.Upload,
      alert: false,
      completed: false,
      percent: 0,
      // custom icon from assets
      icon: "upload.svg",
  },
  {
      id: "convert-image",
      label: "Converting image.jpg",
      operation: FloatingOperationType.Convert,
      alert: false,
      completed: false,
      percent: 0,
  }
]

// flag to check if upload is in progress
let isUpload = false;
let intervalId: NodeJS.Timeout | null = null;

export const uploadButton: IFloatingOperationsButton = {
  id: "upload-button",
  operationsCompleted: false,
  operationsAlert: false,
  // show cancel button when there is only one operation left
  showCancelButton: true,

  cancelOperation: () => {
      // reset interval and flags
      intervalId && clearInterval(intervalId);
      isUpload = false;
      intervalId = null;
      // send message to remove floating operations from button
      return {
          actions: [Actions.removeFloatingOperationsButton],
          floatingOperationsButtonPropsId: uploadButton.id,
      };
  },

  onCancelOperationFromList: (id) => {
      // remove operation from list
      const filteredOps = uploadButton.operations?.filter(
          (op) => op.id !== id
      ) ?? [];

      // update operations
      uploadButton.operations = filteredOps;

      // send message to update floating operations button
      return {
          actions: [Actions.updateFloatingOperationsButton],
          floatingOperationsButtonProps: uploadButton,
      };
  },

  // event on add floating operations in button
  onLoad: (dispatchMessage) => {
      let progress = 0;
      isUpload = true;

      // update progress every 400ms
      intervalId = setInterval(() => {
          progress += 5;

          // update progress for each operation
          const operations = uploadButton.operations?.map((op) => ({
              ...op,
              percent: progress,
              completed: progress >= 100,
          })) ?? [];

          uploadButton.operations = operations;

          // update operations completed
          uploadButton.operationsCompleted = progress >= 100;

          // send message to update floating operations button
          dispatchMessage({
              actions: [Actions.updateFloatingOperationsButton],
              floatingOperationsButtonProps: uploadButton,
          });

          // stop interval if progress is 100
          if (progress >= 100) {
              // reset interval and flags
              intervalId && clearInterval(intervalId);
              isUpload = false;
              intervalId = null;
          }
      }, 400);
  },
};

export const uploadMenuItem: IContextMenuItem = {
  key: "upload-files",
  label: "Upload with progress",
  icon: "upload.svg",
  fileType: [FilesType.file],
  onClick: () => {
      // if upload is in progress, do not allow to start new upload
      if (isUpload) {
          return;
      }

      // Reset operations from previous upload
      uploadButton.operations = structuredClone(operations);
      uploadButton.operationsCompleted = false;
      uploadButton.operationsAlert = false;

      // send message to add floating operations in button
      return {
          actions: [Actions.addFloatingOperationsButton],
          floatingOperationsButtonProps: uploadButton,
      };
  },
};
```

## Behavior

Callback functions and lifecycle events for handling user interactions and button lifecycle.

### cancelOperation()?

> `optional` **cancelOperation**: () => `TReturnMessage`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:225](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L225)

Callback executed when user clicks the cancel button in the floating button.

#### Returns

`TReturnMessage`

***

### onCancelOperationFromList()?

> `optional` **onCancelOperationFromList**: (`operation`) => `TReturnMessage`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:233](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L233)

Callback executed when user closes a specific operation from the operations list.
Receives the operation ID.

#### Parameters

##### operation

`string`

#### Returns

`TReturnMessage`

***

### onLoad()?

> `optional` **onLoad**: (`dispatchMessage`) => `TReturnMessage`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:243](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L243)

Lifecycle callback executed once when floating operations button with given id is displayed for the first time.
Receives a dispatchMessage function to send updates back to DocSpace.
Use this to initialize progress tracking or update.

#### Parameters

##### dispatchMessage

(`message`) => `void`

Function to send progress updates to DocSpace

#### Returns

`TReturnMessage`

## Operations

Properties related to managing and displaying operation items in the floating button.

### operations?

> `optional` **operations**: [`IFloatingOperation`](IFloatingOperation.md)[]

Defined in: [interfaces/components/IFloatingOperationsButton.ts:193](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L193)

Array of operations to display in the floating button.
Each operation shows as a row with icon, label, and progress indicator. 
Operations from other plugins are aggregated and displayed together.

## State

Properties that control the current state and appearance of the floating operations button.

### operationsCompleted?

> `optional` **operationsCompleted**: `boolean`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:202](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L202)

Flag indicating all operations are completed.
When true, the button shows a green checkmark and "completed" status.
User can then dismiss the button or review completed operations.

***

### operationsAlert?

> `optional` **operationsAlert**: `boolean`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:210](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L210)

Flag indicating at least one operation has an error.
When true, the button shows a red warning indicator.

***

### showCancelButton?

> `optional` **showCancelButton**: `boolean`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:218](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L218)

Controls the visibility of the cancel button. 
Cancel button is displayed only if the floating button contains only one operation

## Other

### id

> **id**: `string`

Defined in: [interfaces/components/IFloatingOperationsButton.ts:186](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IFloatingOperationsButton.ts#L186)

Unique identifier for floating operations.
Used to update props of floating operations button. 
When Actions.addFloatingOperationsButton is called again with the same identifier, 
operations in the button will not be replaced as long as there are operations in the button.
