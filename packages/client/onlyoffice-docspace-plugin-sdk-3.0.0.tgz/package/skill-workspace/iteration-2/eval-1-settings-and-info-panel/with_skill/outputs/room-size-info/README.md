# room-size-info

Shows room size and owner in the info panel, highlighting sizes above an admin-defined threshold

## What it does

Selecting a room and opening the info panel adds a **Room size** tab (Russian:
«Размер комнаты») after the portal's own tabs. It shows:

- how much storage the room occupies, read from the room's `usedSpace`;
- the room owner's display name.

An administrator sets a threshold in gigabytes under Settings → Integration →
Plugins → this plugin. A room larger than the threshold has its size shown in
red and bold, with a line naming the limit. An empty field turns the
highlighting off.

Both the size and the owner degrade to a placeholder rather than a wrong value
when the portal does not report them, and a failed request shows an error line
instead of a stuck skeleton.

## Build

```sh
npm install
npm run build
```

The uploadable archive is `dist/plugin.zip`.

## Install

Upload `dist/plugin.zip` in the portal under Settings → Integration → Plugins,
then reload the page fully. Bump `version` in `package.json` before every
re-upload, otherwise the portal keeps serving the cached bundle and icons.

## Scopes

- `InfoPanel`
- `Settings`
- `API`
