# Plugins

Enumerations for plugin status and supported locales.

## PluginStatus

Defined in: [enums/Plugins.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L27)

Defines the supported plugin statuses.

### Enumeration Members

#### active

```ts
active: "active";
```

Defined in: [enums/Plugins.ts:29](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L29)

Plugin is enabled and visible to users

#### hide

```ts
hide: "hide";
```

Defined in: [enums/Plugins.ts:32](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L32)

Plugin is disabled and hidden from the user interface

***

## PluginLocale

Defined in: [enums/Plugins.ts:38](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L38)

Defines the supported plugin locales.

### Enumeration Members

#### AZ

```ts
AZ: "az";
```

Defined in: [enums/Plugins.ts:40](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L40)

Azerbaijani

#### CS

```ts
CS: "cs";
```

Defined in: [enums/Plugins.ts:43](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L43)

Czech

#### DE

```ts
DE: "de";
```

Defined in: [enums/Plugins.ts:46](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L46)

German

#### EN\_GB

```ts
EN_GB: "en-GB";
```

Defined in: [enums/Plugins.ts:49](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L49)

English (United Kingdom)

#### EN\_US

```ts
EN_US: "en-US";
```

Defined in: [enums/Plugins.ts:52](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L52)

English (United States)

#### ES

```ts
ES: "es";
```

Defined in: [enums/Plugins.ts:55](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L55)

Spanish

#### FR

```ts
FR: "fr";
```

Defined in: [enums/Plugins.ts:58](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L58)

French

#### IT

```ts
IT: "it";
```

Defined in: [enums/Plugins.ts:61](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L61)

Italian

#### LV

```ts
LV: "lv";
```

Defined in: [enums/Plugins.ts:64](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L64)

Latvian

#### NL

```ts
NL: "nl";
```

Defined in: [enums/Plugins.ts:67](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L67)

Dutch

#### PL

```ts
PL: "pl";
```

Defined in: [enums/Plugins.ts:70](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L70)

Polish

#### PT\_BR

```ts
PT_BR: "pt-BR";
```

Defined in: [enums/Plugins.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L73)

Portuguese (Brazil)

#### PT

```ts
PT: "pt";
```

Defined in: [enums/Plugins.ts:76](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L76)

Portuguese

#### RO

```ts
RO: "ro";
```

Defined in: [enums/Plugins.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L79)

Romanian

#### SK

```ts
SK: "sk";
```

Defined in: [enums/Plugins.ts:82](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L82)

Slovak

#### SL

```ts
SL: "sl";
```

Defined in: [enums/Plugins.ts:85](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L85)

Slovenian

#### SQ\_AL

```ts
SQ_AL: "sq-AL";
```

Defined in: [enums/Plugins.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L88)

Albanian (Albania)

#### FI

```ts
FI: "fi";
```

Defined in: [enums/Plugins.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L91)

Finnish

#### VI

```ts
VI: "vi";
```

Defined in: [enums/Plugins.ts:94](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L94)

Vietnamese

#### TR

```ts
TR: "tr";
```

Defined in: [enums/Plugins.ts:97](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L97)

Turkish

#### EL\_GR

```ts
EL_GR: "el-GR";
```

Defined in: [enums/Plugins.ts:100](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L100)

Greek (Greece)

#### BG

```ts
BG: "bg";
```

Defined in: [enums/Plugins.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L103)

Bulgarian

#### RU

```ts
RU: "ru";
```

Defined in: [enums/Plugins.ts:106](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L106)

Russian

#### SR\_CYRL\_RS

```ts
SR_CYRL_RS: "sr-Cyrl-RS";
```

Defined in: [enums/Plugins.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L109)

Serbian (Cyrillic, Serbia)

#### SR\_LATN\_RS

```ts
SR_LATN_RS: "sr-Latn-RS";
```

Defined in: [enums/Plugins.ts:112](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L112)

Serbian (Latin, Serbia)

#### UK\_UA

```ts
UK_UA: "uk-UA";
```

Defined in: [enums/Plugins.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L115)

Ukrainian (Ukraine)

#### HY\_AM

```ts
HY_AM: "hy-AM";
```

Defined in: [enums/Plugins.ts:118](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L118)

Armenian (Armenia)

#### AR\_SA

```ts
AR_SA: "ar-SA";
```

Defined in: [enums/Plugins.ts:121](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L121)

Arabic (Saudi Arabia)

#### SI

```ts
SI: "si";
```

Defined in: [enums/Plugins.ts:124](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L124)

Sinhala

#### LO\_LA

```ts
LO_LA: "lo-LA";
```

Defined in: [enums/Plugins.ts:127](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L127)

Lao (Laos)

#### ZH\_CN

```ts
ZH_CN: "zh-CN";
```

Defined in: [enums/Plugins.ts:130](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L130)

Chinese (Simplified, China)

#### JA\_JP

```ts
JA_JP: "ja-JP";
```

Defined in: [enums/Plugins.ts:133](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L133)

Japanese (Japan)

#### KO\_KR

```ts
KO_KR: "ko-KR";
```

Defined in: [enums/Plugins.ts:136](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Plugins.ts#L136)

Korean (Korea)
