# Enumeration: RoomSearchArea

Defined in: [enums/Rooms.ts:4](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L4)

Defines the available search scopes for rooms within a room selector.

## Enumeration Members

### Any

> **Any**: `"Any"`

Defined in: [enums/Rooms.ts:6](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L6)

Search across all available rooms.

***

### Active

> **Active**: `"Active"`

Defined in: [enums/Rooms.ts:8](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L8)

Search only within active rooms.

***

### Archive

> **Archive**: `"Archive"`

Defined in: [enums/Rooms.ts:10](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L10)

Search only within archived rooms.

***

### Templates

> **Templates**: `"Templates"`

Defined in: [enums/Rooms.ts:12](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L12)

Search only within room templates.
