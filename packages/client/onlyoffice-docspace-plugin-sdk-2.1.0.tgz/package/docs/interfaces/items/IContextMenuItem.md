# IContextMenuItem

Defined in: [interfaces/items/IContextMenuItem.ts:164](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L164)

Describes an item that will be embedded in the context menu.

Items are registered by a plugin implementing
[`IContextMenuPlugin`](../plugins/IContextMenuPlugin.md).

![context-menu-plugin](/assets/images/docspace/context-menu-plugin.png#gh-light-mode-only)![context-menu-plugin](/assets/images/docspace/context-menu-plugin.dark.png#gh-dark-mode-only)

## Properties

### key

```ts
key: string;
```

Defined in: [interfaces/items/IContextMenuItem.ts:168](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L168)

The unique item identifier used by the service to recognize the item

### label

```ts
label: string;
```

Defined in: [interfaces/items/IContextMenuItem.ts:173](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L173)

The item display name

### icon

```ts
icon: string;
```

Defined in: [interfaces/items/IContextMenuItem.ts:180](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L180)

The item display icon. The icon image must be uploaded to the assets folder.
Only the image name with the extension must be specified in this field. The required icon size is 16x16 px.
Otherwise, it will be compressed to this size.

### ~~onClick()?~~

```ts
optional onClick: (id: number) => 
  | void
  | Promise<void>
  | IMessage
| Promise<IMessage>;
```

Defined in: [interfaces/items/IContextMenuItem.ts:195](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L195)

Callback invoked when the action is triggered for a single selected
file, folder, or room.

#### Parameters

##### id

`number`

The identifier of the selected item (number only for backward compatibility).

#### Returns

  `void`
  \| `Promise`\<`void`\>
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

#### Remarks:

This callback is executed only for single selection.
If `isGroupAction` is set to `true`, this callback will not be triggered.

#### Deprecated:

Use `onItemClick` instead to support both string and number IDs.
This method will be removed in a future major version.

### onItemClick()?

```ts
optional onItemClick: (id: string | number) => 
  | void
  | Promise<void>
  | IMessage
| Promise<IMessage>;
```

Defined in: [interfaces/items/IContextMenuItem.ts:208](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L208)

Callback invoked when the action is triggered for a single selected
file, folder, or room. Supports both string and number identifiers.

#### Parameters

##### id

The identifier of the selected item (string or number).

`string` | `number`

#### Returns

  `void`
  \| `Promise`\<`void`\>
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

#### Remarks:

This callback is executed only for single selection.
If `isGroupAction` is set to `true`, this callback will not be triggered.
This is the preferred method over the deprecated `onClick`.

### onGroupClick()?

```ts
optional onGroupClick: (items: GroupItem[]) => 
  | void
  | Promise<void>
  | IMessage
| Promise<IMessage>;
```

Defined in: [interfaces/items/IContextMenuItem.ts:226](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L226)

Callback invoked when the action is triggered for multiple selected
files, folders, or rooms.

#### Parameters

##### items

`GroupItem`[]

The selected entities passed as an array of `GroupItem`.

#### Returns

  `void`
  \| `Promise`\<`void`\>
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

#### Remarks:

Each `GroupItem` in `items` exposes the entity `id` (`number` or `string`)
and its `itemType` (`"file"`, `"folder"`, or `"room"`), so files, folders,
and rooms can be distinguished within the selection.

To make the action appear in the group actions menu, set `isGroupAction` to `true`.
When `isGroupAction` is `true`, the action will not be shown for single selected items.

### isGroupAction?

```ts
optional isGroupAction: boolean;
```

Defined in: [interfaces/items/IContextMenuItem.ts:234](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L234)

Indicates whether this item should be displayed in the group actions
context menu when multiple files, folders, or rooms are selected.

### withActiveItem?

```ts
optional withActiveItem: boolean;
```

Defined in: [interfaces/items/IContextMenuItem.ts:240](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L240)

Whether to add the action state to the item in the file list when the
`onItemClick` (or the deprecated `onClick`) event is triggered.

### fileExt?

```ts
optional fileExt: string[];
```

Defined in: [interfaces/items/IContextMenuItem.ts:247](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L247)

The extensions of files where the current item will be displayed in the context menu.
It only works if FilesType.file is specified in the fileType parameter.
If this parameter is not specified, then the current context menu item will be displayed in any file extension.

### fileType?

```ts
optional fileType: FilesType[];
```

Defined in: [interfaces/items/IContextMenuItem.ts:254](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L254)

The types of files where the current item will be displayed in the context menu.
Presently the following file types are available: room, file, folder, image, video.
If this parameter is not specified, then the current context menu item will be displayed in any file type.

### items?

```ts
optional items: Omit<IContextMenuItem, "items" | "placement">[];
```

Defined in: [interfaces/items/IContextMenuItem.ts:262](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L262)

Specifies elements as submenus.
If specified, `onItemClick` (and the deprecated `onClick`) on the parent will not work.
If none of the child elements are displayed, for example due to security or itemSecurity, the parent will also be hidden.
Max level of the menu is 2.

### usersTypes?

```ts
optional usersTypes: UsersType[];
```

Defined in: [interfaces/items/IContextMenuItem.ts:269](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L269)

The types of users who will see the current item in the context menu.
Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user.
If this parameter is not specified, then the current context menu item will be displayed for all user types.

### devices?

```ts
optional devices: Devices[];
```

Defined in: [interfaces/items/IContextMenuItem.ts:276](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L276)

The types of devices where the current item will be displayed in the context menu.
At the moment the following device types are available: mobile, tablet, desktop.
If this parameter is not specified, then the current context menu item will be displayed in any device types.

### security?

```ts
optional security: Security[];
```

Defined in: [interfaces/items/IContextMenuItem.ts:283](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L283)

The security parameters of the parent folder or room that will be checked.
If all the parameters are true, the current item will be displayed in the context menu.
If this parameter is undefined, it will be ignored.

### itemSecurity?

```ts
optional itemSecurity: (
  | FilesSecurity
  | Security)[];
```

Defined in: [interfaces/items/IContextMenuItem.ts:290](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L290)

The security parameters of the file or folder or room that will be checked.
If all the parameters are true, the current item will be displayed in the context menu.
If this parameter is undefined, it will be ignored.

### placement?

```ts
optional placement: "top" | "topLast";
```

Defined in: [interfaces/items/IContextMenuItem.ts:300](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L300)

Defines where the item appears in the context menu (top block only).
- `top` — inserted at the very beginning of the menu, before all other items in the top block.
- `topLast` — inserted at the end of the top block, just before the first separator.
- If not specified, the item is placed inside the "More Options" submenu (default behavior).

Only applies to root-level items. Nested items (`items[]`) ignore this property.

### itemId?

```ts
optional itemId: (string | number)[];
```

Defined in: [interfaces/items/IContextMenuItem.ts:307](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IContextMenuItem.ts#L307)

The identifiers of specific files, folders, or rooms where this item will be displayed in the context menu.
If specified, the item is shown only for entities whose ID is included in this list.
If this parameter is not specified, the item will be displayed for all entities (subject to other filters).

## Examples

File analysis with progress reporting

```typescript
const analyzeFile: IContextMenuItem = {
  key: "analyze-file",
  label: "Analyze File",
  icon: "analysis-icon.svg",
  onItemClick: async (fileId) => {
    try {
      const analysis = await analyzeFile(fileId);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.success,
          title: "Analysis completed successfully | Report generated | Ready to view"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.error,
          title: "Unable to analyze file | Check file access"
        }]
      };
    }
  }
};
```

Secure file sharing with clipboard integration

```typescript
const shareFile: IContextMenuItem = {
  key: "share-file",
  label: "Share File",
  icon: "share-icon.svg",
  onItemClick: async (fileId) => {
    try {
      const shareInfo = await generateShareLink(fileId);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.success,
          title: "Link generated successfully | Ready to share | Copied to clipboard"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.error,
          title: "Unable to generate share link | Check permissions"
        }]
      };
    }
  }
};
```

Nested context menu items from previous examples

```typescript
const manageFile: IContextMenuItem = {
  key: "manage-file",
  label: "Manage File",
  icon: "manage-file-icon.svg",
  items: [
    shareFile,
    analyzeFile
 ]
};
```

Group action for multiple selected items

```typescript
const exportFiles: IContextMenuItem = {
  key: "export-files",
  label: "Export Selected",
  icon: "export-icon.svg",
  isGroupAction: true,
  fileType: [FilesType.file, FilesType.folder],
  onGroupClick: async (items) => {
    const count = items.length;

    const filesIds = items
                  .filter((item) => item.itemType === "file")
                  .map((item) => item.id);

    const foldersIds = items
                  .filter((item) => item.itemType === "folder")
                  .map((item) => item.id);

    return {
      actions: [Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `Exporting ${count} items...`
      }]
    };
  }
};
```

