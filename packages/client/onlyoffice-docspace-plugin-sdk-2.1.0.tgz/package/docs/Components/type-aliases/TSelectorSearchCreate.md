# Type Alias: TSelectorSearchCreate

> **TSelectorSearchCreate** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:551](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L551)

Search and create functionality properties for selectors.

## Appearance

### withSearch?

> `optional` **withSearch**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:557](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L557)

If true, displays a search input field.

## Behavior

### withCreate?

> `optional` **withCreate**: `boolean`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:563](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L563)

If true, allows users to create new items.
