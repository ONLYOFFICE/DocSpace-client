# room-notes (with_skill)

- pluginName: `RoomNotes`  version: `1.3.0`  scopes: `["ContextMenu","InfoPanel"]`
- zip built: yes

## src/index.ts

```ts
/*
 * Eval fixture: a small plugin that already works.
 *
 * Nothing here is broken. It exists so an eval can ask for a *feature to be
 * added* rather than for a project to be created, which is the harder half of
 * the job: the plugin is a live contract, so its name, its keys and its
 * conventions have to survive the edit, and a new scope has to be declared and
 * implemented in the same breath or it does nothing at all.
 *
 * It registers one context menu item on rooms, which opens a modal holding a
 * note. The note lives in memory - there is no backend, and the eval is not
 * about persistence. A read-only view of the same note is also shown as a
 * tab in the room's info panel.
 */

import {
  Actions,
  ButtonSize,
  Components,
  FilesType,
  IBox,
  IContextMenuItem,
  IContextMenuPlugin,
  IInfoPanelItem,
  IInfoPanelPlugin,
  IPlugin,
  IMessage,
  ModalDisplayType,
  PluginLocale,
  PluginStatus,
  ToastType,
  UsersType,
} from "@onlyoffice/docspace-plugin-sdk";

import { currentLocale, setLocale, t } from "./locales";

const notes = new Map<string, string>();

let draft = "";

/**
 * The room the info panel is currently looking at. subMenu.onClick fires with
 * the selected entity's id on every selection change, so this stays current
 * while the panel is open.
 */
let currentRoomId: string | null = null;

const noteBody = (roomId: string): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  paddingProp: "16px",
  children: [
    {
      component: Components.textArea,
      props: {
        value: notes.get(roomId) ?? "",
        placeholder: t("note.placeholder"),
        onChange: (value: string) => {
          draft = value;
        },
      },
    },
    {
      component: Components.button,
      props: {
        label: t("note.save"),
        size: ButtonSize.normal,
        primary: true,
        scale: true,
        onClick: (): IMessage => {
          notes.set(roomId, draft);

          // Keep an open info panel tab in sync with what was just saved.
          refreshNoteTab();

          return {
            actions: [Actions.showToast, Actions.closeModal, Actions.updateInfoPanelItems],
            toastProps: [{ type: ToastType.success, title: t("note.saved") }],
          };
        },
      },
    },
  ],
});

const editNoteItem = (): IContextMenuItem => ({
  key: "room-notes-edit",
  label: t("note.edit"),
  icon: "icon-16.svg",
  fileType: [FilesType.room],
  usersTypes: [UsersType.owner, UsersType.docSpaceAdmin, UsersType.roomAdmin],
  onItemClick: async (id: string | number): Promise<IMessage> => {
    const roomId = String(id);
    draft = notes.get(roomId) ?? "";

    return {
      actions: [Actions.showModal],
      modalDialogProps: {
        displayType: ModalDisplayType.modal,
        dialogHeader: t("note.title"),
        dialogBody: noteBody(roomId),
        onClose: () => ({ actions: [Actions.closeModal] }),
        onLoad: async () => ({ newDialogBody: noteBody(roomId) }),
      },
    };
  },
});

/** U+00A0, non-breaking space - see the blank-line note in noteViewBody. */
const NBSP = String.fromCharCode(160);

/**
 * The read-only view of the note for the info panel tab. Editing stays in the
 * context menu modal.
 */
const noteViewBody = (): IBox => {
  const note = currentRoomId !== null ? notes.get(currentRoomId) : undefined;

  if (!note || note.trim() === "") {
    return {
      displayProp: "flex",
      flexDirection: "column",
      paddingProp: "8px 0",
      children: [
        {
          component: Components.text,
          props: { text: t("note.empty"), color: "var(--text-disable-color)" },
        },
      ],
    };
  }

  // One text block per line: text renders a <p>, so raw newlines would
  // collapse. A non-breaking space keeps blank lines from losing their height.
  return {
    displayProp: "flex",
    flexDirection: "column",
    paddingProp: "8px 0",
    children: note.split("\n").map((line) => ({
      component: Components.text,
      props: { text: line === "" ? NBSP : line, lineHeight: "20px" },
    })),
  };
};

/**
 * updateProps/updateContext are not available from subMenu.onClick, so the tab
 * is refreshed the supported way: re-register the item with a fresh body and
 * return updateInfoPanelItems so the host re-reads the map.
 */
const noteTabItem = (): IInfoPanelItem => ({
  key: "room-notes-tab",
  subMenu: {
    name: t("note.tab"),
    onClick: (id: number): IMessage => {
      currentRoomId = String(id);
      refreshNoteTab();

      return { actions: [Actions.updateInfoPanelItems] };
    },
  },
  body: noteViewBody(),
  onLoad: async (): Promise<{ body: IBox }> => ({ body: noteViewBody() }),
  filesType: [FilesType.room],
  usersTypes: [UsersType.owner, UsersType.docSpaceAdmin, UsersType.roomAdmin],
});

const refreshNoteTab = (): void => {
  plugin.updateInfoPanelItem(noteTabItem());
};

class RoomNotes implements IPlugin, IContextMenuPlugin, IInfoPanelPlugin {
  status: PluginStatus = PluginStatus.active;

  contextMenuItems: Map<string, IContextMenuItem> = new Map();

  infoPanelItems: Map<string, IInfoPanelItem> = new Map();

  onLoadCallback = async (): Promise<void> => {
    this.addContextMenuItem(editNoteItem());
    this.addInfoPanelItem(noteTabItem());
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
    this.updateContextMenuItem(editNoteItem());
    this.updateInfoPanelItem(noteTabItem());
  };

  getLanguage = (): PluginLocale => currentLocale();

  addContextMenuItem = (item: IContextMenuItem): void => {
    this.contextMenuItems.set(item.key, item);
  };

  getContextMenuItems = (): Map<string, IContextMenuItem> => this.contextMenuItems;

  getContextMenuItemsKeys = (): string[] => Array.from(this.contextMenuItems.keys());

  updateContextMenuItem = (item: IContextMenuItem): void => {
    this.contextMenuItems.set(item.key, item);
  };

  addInfoPanelItem = (item: IInfoPanelItem): void => {
    this.infoPanelItems.set(item.key, item);
  };

  getInfoPanelItems = (): Map<string, IInfoPanelItem> => this.infoPanelItems;

  updateInfoPanelItem = (item: IInfoPanelItem): void => {
    this.infoPanelItems.set(item.key, item);
  };
}

const plugin = new RoomNotes();

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.RoomNotes = plugin || {};

export default plugin;
```

## src/locales.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 */
export type TStrings = {
  "note.edit": string;
  "note.title": string;
  "note.placeholder": string;
  "note.save": string;
  "note.saved": string;
  "note.tab": string;
  "note.empty": string;
};

const en: TStrings = {
  "note.edit": "Edit room note",
  "note.title": "Room note",
  "note.placeholder": "Anything the next person should know",
  "note.save": "Save",
  "note.saved": "Note saved",
  "note.tab": "Note",
  "note.empty": "No note for this room yet",
};

const ru: TStrings = {
  "note.edit": "Изменить заметку комнаты",
  "note.title": "Заметка комнаты",
  "note.placeholder": "Что стоит знать следующему",
  "note.save": "Сохранить",
  "note.saved": "Заметка сохранена",
  "note.tab": "Заметка",
  "note.empty": "Для этой комнаты пока нет заметки",
};

const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.EN_US]: en,
  [PluginLocale.RU]: ru,
};

let locale: PluginLocale = PluginLocale.EN_US;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.EN_US;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings): string => (translations[locale] ?? en)[key];
```
