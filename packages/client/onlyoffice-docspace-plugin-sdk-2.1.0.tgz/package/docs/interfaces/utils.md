# Utils

Utility types for plugin messaging, return values, and panel navigation.

## IPostMessage

Defined in: [interfaces/utils/index.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L75)

The properties that are used to send a message to a frame.
If the frame ID is not specified or the frame with such an ID does not exist, then nothing changes.

### Properties

#### frameId

```ts
frameId: string;
```

Defined in: [interfaces/utils/index.ts:77](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L77)

Defines the frame ID

#### message

```ts
message: {
[key: string]: any;
};
```

Defined in: [interfaces/utils/index.ts:80](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L80)

Defines a message that will be sent to a frame

##### Index Signature

```ts
[key: string]: any
```

***

### Example

Document preview frame communication

```typescript
const previewMessage: IPostMessage = {
  frameId: "document-preview-frame",
  message: {
    action: "zoom",
    scale: 1.5,
    position: { x: 100, y: 200 }
  }
};
```

## IMessage

Defined in: [interfaces/utils/index.ts:148](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L148)

A message which is returned when any item interacts with a user (onClick, onChange, onSelect, etc.).

### Properties

#### actions?

```ts
optional actions: Actions[];
```

Defined in: [interfaces/utils/index.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L153)

Defines a collection of events that will be processed on the portal side.
The specified actions will be performed depending on the set of values.

#### newProps?

```ts
optional newProps: 
  | IComboBox
  | IButton
  | ICheckbox
  | IInput
  | ITextArea
  | IToggleButton;
```

Defined in: [interfaces/utils/index.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L159)

Defines the properties that update the state of the items which interact with the users.
This parameter is used only with Actions.updateProps.

#### toastProps?

```ts
optional toastProps: IToast[];
```

Defined in: [interfaces/utils/index.ts:165](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L165)

Defines the properties that display a toast notification after the user actions.
This parameter is used only with Actions.showToast.

#### contextProps?

```ts
optional contextProps: {
  name: string;
  props:   | IComboBox
     | IButton
     | ICheckbox
     | IFrame
     | IImage
     | IInput
     | ILabel
     | ISkeleton
     | IText
     | ITextArea
     | IToggleButton
     | IBox;
}[];
```

Defined in: [interfaces/utils/index.ts:173](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L173)

Defines the properties that update the state of the parent or child item after the event was executed.
Contains an array of objects with:
- name: Defines the item name
- props: Defines the new properties for the parent or child item

##### name

```ts
name: string;
```

##### props

```ts
props: 
  | IComboBox
  | IButton
  | ICheckbox
  | IFrame
  | IImage
  | IInput
  | ILabel
  | ISkeleton
  | IText
  | ITextArea
  | IToggleButton
  | IBox;
```

#### createDialogProps?

```ts
optional createDialogProps: ICreateDialog;
```

Defined in: [interfaces/utils/index.ts:194](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L194)

Defines the properties that display the default dialog box for creating a file/folder managed by the plugin.
This parameter is used only with Actions.showCreateDialogModal.

#### modalDialogProps?

```ts
optional modalDialogProps: IModalDialog;
```

Defined in: [interfaces/utils/index.ts:200](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L200)

Defines the properties that display the modal window.
This parameter is used only with Actions.showModal.

#### selectorProps?

```ts
optional selectorProps: TSelector;
```

Defined in: [interfaces/utils/index.ts:206](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L206)

Defines the properties that display the selector.
This parameter is used only with Actions.showSelector and Actions.updateSelector.

#### floatingOperationsButtonProps?

```ts
optional floatingOperationsButtonProps: IFloatingOperationsButton;
```

Defined in: [interfaces/utils/index.ts:213](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L213)

Defines the configuration for the floating operations button that displays progress of long-running operations.
Used with Actions.addFloatingOperationsButton to create a new button or Actions.updateFloatingOperationsButton to update existing one.
The button appears as a floating action button in the bottom-right corner. Multiple plugins can show operations simultaneously.

#### floatingOperationsButtonPropsId?

```ts
optional floatingOperationsButtonPropsId: string;
```

Defined in: [interfaces/utils/index.ts:220](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L220)

Unique identifier for the floating operations button to remove.
Used only with Actions.removeFloatingOperationsButton to close a specific operations panel.
The ID should match the `id` property of the IFloatingOperationsButton that was previously added.

#### postMessage?

```ts
optional postMessage: IPostMessage;
```

Defined in: [interfaces/utils/index.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L227)

Defines the properties that are used to send a message to a frame.
If the frame ID is not specified or the frame with such an ID does not exist, then nothing changes.
This parameter is used only with Actions.sendPostMessage.

#### settings?

```ts
optional settings: string;
```

Defined in: [interfaces/utils/index.ts:233](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L233)

Defines a parameter that is used to save and transfer the administrator or owner plugin settings to all the portal users.
This parameter is used only with Actions.saveSettings.

#### navigatePath?

```ts
optional navigatePath: string;
```

Defined in: [interfaces/utils/index.ts:240](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L240)

Defines the path to navigate to.
All actions listed after navigate will be called after the navigation is complete.
This parameter is used only with Actions.navigate.

#### infoPanelTab?

```ts
optional infoPanelTab: string;
```

Defined in: [interfaces/utils/index.ts:246](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L246)

Defines the info panel tab to open.
This parameter is used only with Actions.openInfoPanel.

#### mediaViewerProps?

```ts
optional mediaViewerProps: IMediaViewer;
```

Defined in: [interfaces/utils/index.ts:252](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L252)

Defines the properties for the media viewer.
This parameter is used only with Actions.showMediaViewer and Actions.updateMediaViewer.

***

### Examples

Form submission with validation and toast notification

```typescript
const formSubmissionMessage: IMessage = {
  actions: [Actions.updateProps, Actions.showToast, Actions.updateContext],
  newProps: {
    type: "input",
    id: "email-input",
    value: "user@example.com",
    isDisabled: true
  },
  toastProps: [{
    type: ToastType.success,
    title: "Your data has been saved successfully"
  }],
  contextProps: [{
    name: "submit-button",
    props: {
      type: "button",
      label: "Submitted",
      isDisabled: true
    }
  }]
};
```

Dynamic form field updates with error handling

```typescript
const fieldUpdateMessage: IMessage = {
  actions: [Actions.updateProps, Actions.showToast, Actions.updateContext],
  newProps: {
    type: "comboBox",
    id: "country-select",
    options: [
      { value: "us", label: "United States" },
      { value: "uk", label: "United Kingdom" }
    ],
    value: "us"
  },
  toastProps: [{
    type: ToastType.error,
    title: "Please complete all required fields"
  }],
  contextProps: [{
    name: "state-select",
    props: {
      type: "comboBox",
      options: [
        { value: "ca", label: "California" },
        { value: "ny", label: "New York" }
      ],
      isDisabled: false
    }
  }]
};
```

## IPostMessageCallbackMessage

Defined in: [interfaces/utils/index.ts:273](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L273)

A message which is returned from the postMessage callback.
It is similar to [IMessage](#imessage) but with a reduced set of available actions.

### Properties

#### actions?

```ts
optional actions: (
  | updateContextMenuItems
  | updateInfoPanelItems
  | updateMainButtonItems
  | updateProfileMenuItems
  | updateFileItems
  | updateEventListenerItems
  | showToast
  | showCreateDialogModal
  | showModal
  | closeModal
  | showSelector
  | addFloatingOperationsButton
  | removeFloatingOperationsButton
  | navigate
  | openInfoPanel
  | showMediaViewer
  | closeMediaViewer)[];
```

Defined in: [interfaces/utils/index.ts:283](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L283)

Defines a collection of events that will be processed on the portal side.
Only the following actions are available:
updateContextMenuItems, updateInfoPanelItems, updateMainButtonItems,
updateProfileMenuItems, updateFileItems, updateEventListenerItems,
showToast, showCreateDialogModal, showModal, closeModal, showSelector,
showMediaViewer, closeMediaViewer, addFloatingOperationsButton,
removeFloatingOperationsButton, navigate, openInfoPanel.

#### toastProps?

```ts
optional toastProps: IToast[];
```

Defined in: [interfaces/utils/index.ts:307](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L307)

Defines the properties that display a toast notification after the user actions.
This parameter is used only with Actions.showToast.

#### createDialogProps?

```ts
optional createDialogProps: ICreateDialog;
```

Defined in: [interfaces/utils/index.ts:313](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L313)

Defines the properties that display the default dialog box for creating a file/folder managed by the plugin.
This parameter is used only with Actions.showCreateDialogModal.

#### modalDialogProps?

```ts
optional modalDialogProps: IModalDialog;
```

Defined in: [interfaces/utils/index.ts:319](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L319)

Defines the properties that display the modal window.
This parameter is used only with Actions.showModal.

#### selectorProps?

```ts
optional selectorProps: TSelector;
```

Defined in: [interfaces/utils/index.ts:325](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L325)

Defines the properties that display the selector.
This parameter is used only with Actions.showSelector.

#### floatingOperationsButtonProps?

```ts
optional floatingOperationsButtonProps: IFloatingOperationsButton;
```

Defined in: [interfaces/utils/index.ts:331](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L331)

Defines the configuration for the floating operations button that displays progress of long-running operations.
Used with Actions.addFloatingOperationsButton to create a new button.

#### floatingOperationsButtonPropsId?

```ts
optional floatingOperationsButtonPropsId: string;
```

Defined in: [interfaces/utils/index.ts:338](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L338)

Unique identifier for the floating operations button to remove.
Used with Actions.removeFloatingOperationsButton to close a specific operations panel.
The ID should match the `id` property of the IFloatingOperationsButton that was previously added.

#### navigatePath?

```ts
optional navigatePath: string;
```

Defined in: [interfaces/utils/index.ts:345](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L345)

Defines the path to navigate to.
All actions listed after navigate will be called after the navigation is complete.
This parameter is used only with Actions.navigate.

#### infoPanelTab?

```ts
optional infoPanelTab: string;
```

Defined in: [interfaces/utils/index.ts:351](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L351)

Defines the info panel tab to open.
This parameter is used only with Actions.openInfoPanel.

***

### Example

Handling a postMessage callback with a toast notification

```typescript
const postMessageResponse: IPostMessageCallbackMessage = {
  actions: [Actions.showToast],
  toastProps: [{
    type: ToastType.success,
    title: "Frame message processed successfully"
  }]
};
```

## TInfoPanelTab

```ts
type TInfoPanelTab = "info_members" | "info_history" | "info_details" | "info_share" | string;
```

Defined in: [interfaces/utils/index.ts:49](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L49)

Defines the info panel tab to open.

***

## TReturnPostMessage

```ts
type TReturnPostMessage = 
  | Promise<IPostMessageCallbackMessage>
  | Promise<void>
  | void
  | IPostMessageCallbackMessage;
```

Defined in: [interfaces/utils/index.ts:357](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L357)

Describes a return message of a postMessage event handler.

***

## TReturnMessage

```ts
type TReturnMessage = 
  | Promise<IMessage>
  | Promise<void>
  | void
  | IMessage;
```

Defined in: [interfaces/utils/index.ts:366](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/utils/index.ts#L366)

Describes a return message.
