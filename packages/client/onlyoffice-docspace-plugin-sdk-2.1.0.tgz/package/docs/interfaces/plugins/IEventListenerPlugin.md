# IEventListenerPlugin

Defined in: [interfaces/plugins/IEventListenerPlugin.ts:68](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IEventListenerPlugin.ts#L68)

The plugin that is given the access to the portal events.

## Methods

### addEventListenerItem()

```ts
addEventListenerItem(item: IEventListenerItem): void;
```

Defined in: [interfaces/plugins/IEventListenerPlugin.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IEventListenerPlugin.ts#L79)

Add a new event listener item to the collection.

#### Parameters

##### item

[`IEventListenerItem`](../items/IEventListenerItem.md)

The event listener item to add, containing key, eventType, and eventHandler

#### Returns

`void`

### getEventListenerItems()

```ts
getEventListenerItems(): Map<string, IEventListenerItem>;
```

Defined in: [interfaces/plugins/IEventListenerPlugin.ts:85](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IEventListenerPlugin.ts#L85)

Get all registered event listener items.

#### Returns

`Map`\<`string`, [`IEventListenerItem`](../items/IEventListenerItem.md)\>

A Map containing all registered event listener items, where keys are item identifiers

## Properties

### eventListenerItems

```ts
eventListenerItems: Map<string, IEventListenerItem>;
```

Defined in: [interfaces/plugins/IEventListenerPlugin.ts:73](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IEventListenerPlugin.ts#L73)

Stores a collection of elements where the keys are the key parameters from the EventListenerItem objects.
A list of event listeners is generated based on this collection.

## Example

The plugin class implements `IEventListenerPlugin` and registers a listener for
the room creation event in the constructor. DocSpace calls `getEventListenerItems`
to subscribe the handlers to the portal events.

```typescript
import {
  type IEventListenerItem,
  type IEventListenerPlugin,
  Events,
  Actions,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

class Plugin implements IEventListenerPlugin {
  eventListenerItems: Map<string, IEventListenerItem> = new Map();

  constructor() {
    this.addEventListenerItem({
      key: "room-create-listener",
      eventType: Events.ROOM_CREATE,
      eventHandler: () => {
        return {
          actions: [Actions.showToast],
          toastProps: [{
            type: ToastType.success,
            title: "A new room has been created"
          }]
        };
      }
    });
  }

  addEventListenerItem = (item: IEventListenerItem): void => {
    this.eventListenerItems.set(item.key, item);
  };

  getEventListenerItems = (): Map<string, IEventListenerItem> => {
    return this.eventListenerItems;
  };
}
```

