# Type Alias: ComboBoxGroup

> **ComboBoxGroup** = `object`

Defined in: [interfaces/components/Component.ts:183](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L183)

Defines the combo box component.

## Example

```typescript
import { IComboBox, IComboBoxItem, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const comboBox: IComboBox = {
  options: [
    { key: "light", label: "Light Theme", icon: "theme-light.svg" },
    { key: "dark", label: "Dark Theme", icon: "theme-dark.svg" },
    { key: "system", label: "System Theme", icon: "theme-auto.svg" }
  ],
  selectedOption: { key: "light", label: "Light Theme", icon: "theme-light.svg" },
  onSelect: (item) => {},
  scaled: true,
  directionX: "right",
  directionY: "bottom",
  displayType: "default",
  modernView: true
};

const comboBoxGroup: Component = {
  component: Components.comboBox,
  props: comboBox,
  contextName: "themeSelector"
};
```

## Properties

### component

> **component**: [`comboBox`](../../enumerations/Components.md#combobox)

Defined in: [interfaces/components/Component.ts:185](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L185)

Defines the "comboBox" component type

***

### props

> **props**: [`IComboBox`](../interfaces/IComboBox.md)

Defined in: [interfaces/components/Component.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L187)

Defines the combo box component properties

***

### contextName?

> `optional` **contextName**: `string`

Defined in: [interfaces/components/Component.ts:189](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L189)

Defines the combo box component context name that updates the component via React context
