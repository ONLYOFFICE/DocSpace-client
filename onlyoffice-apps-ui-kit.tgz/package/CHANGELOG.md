# Change Log

## 4.0.2

### Changed

- `@onlyoffice/document-editor-react` peer raised from `2.1.1` to `2.2.0`. That release
  dropped its own `IConfig` and takes the editor configuration type, `Config`, from
  `@onlyoffice/doceditor-types`, which is now an optional peer here as well (`^9.3.1`)
- `document-editor` still exports `IConfig`, now as an alias of that `Config`
- `@onlyoffice/document-editor-react` peer raised further to `2.3.0`, and the
  `@onlyoffice/doceditor-types` peer widened to `>=9.3.1` so that its `10.0.0` line
  (the types for ONLYOFFICE Docs 10.0, which drop the deprecated `showReviewChanges`,
  `reviewDisplay` and `trackChanges` customization keys) satisfies it the same way it
  satisfies `document-editor-react` itself
- `document-editor` folds its `width`, `height` and `events_*` props into `config`
  before handing it to `document-editor-react`, which deprecated those flat props in
  2.3.0. The component's own props are unchanged; a value set in `config` wins over the
  matching prop, and `events_onAppReady` still receives the editor instance
- `@onlyoffice/ai-chat` peer requirement raised to `^1.0.4` (the composer's tool cards follow the round's context scope; files and images share one attachment cap)
- AI settings: `McpServers` takes a `toolPrefsScope` prop. Pass `"tenant"` where the viewer administers the portal, so a tool switched off there is off for every user; omitted, the page edits the viewer's own list (Bug 84381)

### Added

- Filter: a group can draw itself. An item marked `isCustom` is rendered by the new `renderCustomItem` prop, which gets the group's pending value, `onChange` to set it and `openPanel` / `closePanel` for a nested step; the value is a string key, applied and compared like any other
- Filter: a selected item can carry `chips`, drawn as one chip each under the bar. Removing one calls `removeSelectedItem` with that chip's key and the item's group; the panel still treats the item as one value

### Fixed

- AI chat: the copy buttons (message, code block, tool card) work on a portal served over plain HTTP. The platform adapter now supplies `copyToClipboard`, which falls back to `copy-to-clipboard` where the Clipboard API is unavailable outside a secure context (Bug 84481)
- Files and images share one 5-attachment cap on a message, including the Forms section's single slot (Bug 84379)
- The E2E Docker image copies the vendored ai-chat tarball before `pnpm install`
- Filter: removing a chip no longer hides a chip of another group that shares its key
- Context menu (desktop and mobile sheet) and `DropDownItem`: a string icon is fetched and inlined through `react-svg` only when it is a `.svg` on the page's own origin or, where it already was, an SVG data URL. Anything else, a cross-origin `.svg` included, is an `<img>`, so a custom action whose icon lives on the integrator's domain no longer needs CORS headers there and no longer loses its icon. The old rule looked for `images/` or `.svg` in the path and inlined such icons from any origin; a cross-origin SVG now keeps its own colours instead of taking the text colour

## 4.0.1

### Changed

- `@onlyoffice/ai-chat` peer requirement raised to `^1.0.1`

## 4.0.0

First release under its own name and from its own repository. It was `@docspace/ui-kit@0.0.1`,
a workspace package of the DocSpace client resolved to its source root; it is now
`@onlyoffice/apps-ui-kit`, built and consumed as a package. The version follows the
ONLYOFFICE Apps 4.0 line.

### Changed

- **Renamed** from `@docspace/ui-kit` to `@onlyoffice/apps-ui-kit`
- **ESM only**: `dist/esm/**` and `.d.mts` declarations in `dist/types/**`; no CJS output
- **An `exports` map decides what resolves**: `.`, `./styles.css`, `./package.json`,
  `./locales/*`, `./styles/*` and a `./*` wildcard onto `<subpath>/index.js`. A plain
  (non-module) stylesheet is reached only through the module that imports it
- **One CSS file per module**, imported by that module; `dist/styles.css` still holds the
  whole sheet
- **Dependencies split three ways**: 32 `dependencies`; `react`, `react-dom`, `i18next` and
  `react-i18next` as required peers; 15 optional peers needed only by the portal-internal
  modules (`@onlyoffice/ai-chat` `^1.0.0`, `mobx`, `mobx-react`, `axios`, `socket.io-client`,
  `react-router`, the markdown/KaTeX stack, `@onlyoffice/document-editor-react`)
- `@onlyoffice/docspace-api-sdk` comes from npm (`^3.7.0`); `react`/`react-dom` peers are
  `^19.0.0`; `i18next` 25, `react-i18next` 15, `react-svg` 16.4.2
- `providers/api` and `providers/Providers` left `providers/index.ts`; import them by subpath
- The `hooks` barrel is exported from the root
- **`Article` / `ArticleLiveChat`** drive Zendesk through the messaging API; `zendeskEmail`,
  `chatDisplayName` and `Zendesk`'s `config` are gone
- **`DocumentEditor`** takes either `documentServerUrl` + `config`, or `fileId`; with neither
  it reports through `onLoadComponentError` instead of opening file `1`
- **The section header has its height (69/61/53px) and background back.** This changes the
  portal's layout
- **`TextInput`, `Textarea`, `Checkbox`, `ComboBox`** no longer default `tabIndex` to `-1`
- **`ModalDialog`** puts `role="dialog"` and `aria-modal` on the dialog surface, not the
  overlay
- **`Aside`** is a flex column whose body fills the remaining height; only `aria-*` props go
  to the `<aside>`, everything else to the header
- `DateTimePickerProps` includes the required `translations`
- **`TwoStateToggle`** defaults name the product ONLYOFFICE Apps: `title` is
  "ONLYOFFICE Apps design", `ariaLabel` "Switch ONLYOFFICE Apps design", and `confirmBody` ends
  "…the classic ONLYOFFICE Apps view." A test querying the old accessible name fails
- `ThemeProvider` no longer fetches the portal palette (the call never worked); pass
  `colorTheme`

### Added

- `FilterInput` and `StatusMessage` as named exports
- `Text`, `Heading`, `Link`: `role`, `aria-label`, `aria-live`, `aria-hidden`
- `Textarea` and `ModalDialog`: `aria-label`, `aria-labelledby`, `aria-describedby`
- `FieldContainer`: `labelFor`
- A README for every component and public provider; `docs/getting-started.md`,
  `docs/components.md` and `docs/public-api.md`
- `docs/plugin-surface.json`: every name the root barrel exports, with its kind and module

### Fixed

- `ImageEditor` crash on render; icons keep their `viewBox`
- `Selector` no longer scrolls the page on mount
- `RoomLogoCoverDialog` fits the window on first open
- `MCPServersSelector` loads the portal logo from the `ApiProvider`'s `baseUrl`
- Secondary scaled `Tabs` no longer report false overflow
- `RoomIcon` without `logo` draws initials
- `Uploader`'s `targetId` accepts `string | number`
- `ModalDialog` no longer leaks `touchend` listeners
- `ThemeProvider` follows a `colorTheme` that arrives after the first render
- Two mounted `Toast`s no longer throw
- `AIAgentSelector` no longer disables every agent for a right the folder never carries
- Missing `locales/en` keys for `Filter` and the AI agent export labels
- Brand and constant lookups survive a second module instance

### Known issues

- The root barrel needs `mobx`, `mobx-react`, `react-router` and `axios` to build (via
  `billing` and `uploader`); import by subpath to avoid them
