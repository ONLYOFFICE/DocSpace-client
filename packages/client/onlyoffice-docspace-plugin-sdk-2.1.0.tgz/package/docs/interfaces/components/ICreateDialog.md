# ICreateDialog

Defined in: [interfaces/components/ICreateDialog.ts:110](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L110)

Modal dialog for creating certain item (file, folder, etc.).
The user gets the full access to the functionality but cannot control the layout.

To display the dialog, return an [`IMessage`](../utils.md#imessage) with
[`Actions.showCreateDialogModal`](../../enums/Actions.md#showcreatedialogmodal) in `actions`
and pass the dialog configuration in `createDialogProps`.
Use [`Actions.updateCreateDialogModal`](../../enums/Actions.md#updatecreatedialogmodal)
to update an open dialog.

![createdialog](/assets/images/docspace/createdialog.png#gh-light-mode-only)![createdialog](/assets/images/docspace/createdialog.dark.png#gh-dark-mode-only)

## Properties

### title

```ts
title: string;
```

Defined in: [interfaces/components/ICreateDialog.ts:114](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L114)

Defines the modal dialog title.

### startValue

```ts
startValue: string;
```

Defined in: [interfaces/components/ICreateDialog.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L119)

Defines the modal dialog start value.

### visible

```ts
visible: boolean;
```

Defined in: [interfaces/components/ICreateDialog.ts:124](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L124)

Specifies if the modal dialog is visible or not.

### isCreateDisabled?

```ts
optional isCreateDisabled: boolean;
```

Defined in: [interfaces/components/ICreateDialog.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L129)

Specifies if the create button is disabled.

### isCloseAfterCreate?

```ts
optional isCloseAfterCreate: boolean;
```

Defined in: [interfaces/components/ICreateDialog.ts:134](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L134)

Specifies if the modal dialog should be closed after the create action.

### options?

```ts
optional options: IComboBoxItem[];
```

Defined in: [interfaces/components/ICreateDialog.ts:139](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L139)

Defines an array of the modal dialog options.

### selectedOption?

```ts
optional selectedOption: IComboBoxItem;
```

Defined in: [interfaces/components/ICreateDialog.ts:144](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L144)

Defines the selected modal dialog option.

### errorText?

```ts
optional errorText: string;
```

Defined in: [interfaces/components/ICreateDialog.ts:149](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L149)

Error text to display when validation fails or an error occurs.

### onSelect()?

```ts
optional onSelect: (option: IComboBoxItem) => void | IMessage;
```

Defined in: [interfaces/components/ICreateDialog.ts:154](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L154)

Sets a function which is triggered whenever the modal dialog option is selected.

#### Parameters

##### option

[`IComboBoxItem`](IComboBox.md#icomboboxitem)

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### onChange()?

```ts
optional onChange: (value: string) => void | IMessage;
```

Defined in: [interfaces/components/ICreateDialog.ts:159](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L159)

Sets a function which is triggered whenever the input value changes.

#### Parameters

##### value

`string`

#### Returns

`void` \| [`IMessage`](../utils.md#imessage)

### onSave()?

```ts
optional onSave: (e: any, value: string) => 
  | void
  | Promise<void>
  | IMessage
| Promise<IMessage>;
```

Defined in: [interfaces/components/ICreateDialog.ts:164](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L164)

Sets a function which is triggered whenever the data in the modal dialog is saved.

#### Parameters

##### e

`any`

##### value

`string`

#### Returns

  `void`
  \| `Promise`\<`void`\>
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

### onCancel()?

```ts
optional onCancel: (e: any) => void;
```

Defined in: [interfaces/components/ICreateDialog.ts:172](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L172)

Sets a function which is triggered whenever an action in the modal dialog is canceled.

#### Parameters

##### e

`any`

#### Returns

`void`

### onClose()?

```ts
optional onClose: (e: any) => void;
```

Defined in: [interfaces/components/ICreateDialog.ts:177](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L177)

Sets a function which is triggered whenever the modal dialog is closed.

#### Parameters

##### e

`any`

#### Returns

`void`

### onError()?

```ts
optional onError: (e: any) => 
  | void
  | Promise<void>
  | IMessage
| Promise<IMessage>;
```

Defined in: [interfaces/components/ICreateDialog.ts:182](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L182)

Sets a function which is triggered whenever an error occurs during the onSave operation.

#### Parameters

##### e

`any`

#### Returns

  `void`
  \| `Promise`\<`void`\>
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

### isCreateDialog

```ts
isCreateDialog: boolean;
```

Defined in: [interfaces/components/ICreateDialog.ts:187](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L187)

Specifies if this modal dialog is for creating certain item (file, folder, etc.).

### isAutoFocusOnError?

```ts
optional isAutoFocusOnError: boolean;
```

Defined in: [interfaces/components/ICreateDialog.ts:192](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L192)

Specifies if this modal dialog should automatically focus on the error input field when an error occurs during the onSave operation.

### extension?

```ts
optional extension: string;
```

Defined in: [interfaces/components/ICreateDialog.ts:197](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ICreateDialog.ts#L197)

Defines an extension of an item which will be created (file, folder, etc.).

## Example

Document creation dialog with multiple format options

```typescript
const newDocumentDialog: ICreateDialog = {
  title: "Create New Document",
  startValue: "Untitled",
  visible: true,
  options: [
    {
      key: "docx",
      label: "Word Document",
      icon: "word.svg"
    },
    {
      key: "xlsx",
      label: "Excel Spreadsheet",
      icon: "excel.svg"
    },
    {
      key: "pptx",
      label: "PowerPoint Presentation",
      icon: "powerpoint.svg"
    }
  ],
  selectedOption: {
    key: "docx",
    label: "Word Document",
    icon: "word.svg"
  },
  onSelect: (option) => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        selectedOption: option,
        extension: option.key
      }
    };
  },
  onSave: async (e, value) => {
    try {
      // Create the document
      await createDocument(value, selectedOption.key);

      return {
        actions: [Actions.updateProps, Actions.showToast],
        newProps: {
          visible: false
        },
        toastProps: [{
          title: `Document "${value}" created successfully`,
          type: ToastType.success
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          title: "Failed to create document. Please try again.",
          type: ToastType.error
        }]
      };
    }
  },
  onCancel: (e) => {
    // Clean up any temporary state if needed
  },
  onClose: (e) => {
    // Additional cleanup or analytics
  },
  isCreateDialog: true,
  extension: "docx"
}
```

