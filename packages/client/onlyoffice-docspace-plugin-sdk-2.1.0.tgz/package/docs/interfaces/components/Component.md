# Component

```ts
type Component = 
  | BoxGroup
  | ButtonGroup
  | CheckboxGroup
  | ComboBoxGroup
  | IFrameGroup
  | ImageGroup
  | InputGroup
  | LabelGroup
  | SkeletonGroup
  | TextGroup
  | TextAreaGroup
  | ToggleButtonGroup
  | IconButtonGroup
  | LinkGroup;
```

Defined in: [interfaces/components/Component.ts:104](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L104)

A component that is used to add components into Box.
Only components that are embedded into DOM can be wrapped (toast, modal dialog, etc. cannot be wrapped).

## Example

```typescript
import {
  IBox,
  IText,
  IButton,
  ButtonSize,
  Components,
  Component,
  Actions,
  IToast,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

const title: IText = {
  text: "Plugin Settings",
  fontSize: "18px",
  fontWeight: 600,
};

const button: IButton = {
  label: "Save Changes",
  onClick: () => {
    return {
      actions: [Actions.showToast],
      toastProps: [{
        title: "Success",
        type: ToastType.success,
      }]
    };
  },
  size: ButtonSize.normal,
  primary: true
};

// Create a settings panel with text and button
const container: IBox = {
  paddingProp: "16px",
  backgroundProp: "#f8f9f9",
  children: [
    {
      component: Components.text,
      props: title
    },
    {
      component: Components.button,
      props: button
    }
  ]
};

// Combine components into a layout
const settingsPanel: Component = {
  component: Components.box,
  props: container
};
```

***

## BoxGroup

```ts
type BoxGroup = {
  component: box;
  props: IBox;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:149](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L149)

Defines the box component.

### Properties

#### component

```ts
component: box;
```

Defined in: [interfaces/components/Component.ts:151](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L151)

Defines the "box" component type

#### props

```ts
props: IBox;
```

Defined in: [interfaces/components/Component.ts:153](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L153)

Defines the box component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:155](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L155)

Defines the box component context name that updates the component via React context

***

### Example

```typescript
import { IBox, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const box: IBox = {
  widthProp: "200px",
  paddingProp: "16px",
  displayProp: "flex",
  flexDirection: "column",
  alignItems: "center",
  borderProp: {
    color: "#333333",
    radius: "8px",
    style: "solid",
    width: "1px"
  },
  backgroundProp: "#f8f9f9"
};

const boxGroup: Component = {
  component: Components.box,
  props: box,
  contextName: "container"
};
```

## ButtonGroup

```ts
type ButtonGroup = {
  component: button;
  props: IButton;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:180](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L180)

Defines the button component.

### Properties

#### component

```ts
component: button;
```

Defined in: [interfaces/components/Component.ts:182](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L182)

Defines the "button" component type

#### props

```ts
props: IButton;
```

Defined in: [interfaces/components/Component.ts:184](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L184)

Defines the button component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:186](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L186)

Defines the button component context name that updates the component via React context

***

### Example

```typescript
import { IButton, Components, Component, ButtonSize } from "@onlyoffice/docspace-plugin-sdk";

const button: IButton = {
  size: ButtonSize.normal,
  label: "Click me!",
  onClick: () => {
    console.log("Button clicked!");
  },
};

const buttonGroup: Component = {
  component: Components.button,
  props: button,
  contextName: "button",
};
```

## CheckboxGroup

```ts
type CheckboxGroup = {
  component: checkbox;
  props: ICheckbox;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:223](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L223)

Defines the checkbox component.

### Properties

#### component

```ts
component: checkbox;
```

Defined in: [interfaces/components/Component.ts:225](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L225)

Defines the "checkbox" component type

#### props

```ts
props: ICheckbox;
```

Defined in: [interfaces/components/Component.ts:227](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L227)

Defines the checkbox component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:229](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L229)

Defines the checkbox component context name that updates the component via React context

***

### Example

```typescript
import { ICheckbox, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const checkbox: ICheckbox = {
  isChecked: false,
  label: "Enable notifications",
  onChange: () => {
    return {
      actions: [Actions.updateProps],
      newProps: {
        isChecked: !checkbox.isChecked
      }
    };
  },
  truncate: false,
  tabIndex: 1,
  hasError: false,
  name: "notifications",
  value: "enabled",
  isDisabled: false,
  title: "Notification preferences"
};

const checkboxGroup: Component = {
  component: Components.checkbox,
  props: checkbox,
  contextName: "notificationToggle"
};
```

## ComboBoxGroup

```ts
type ComboBoxGroup = {
  component: comboBox;
  props: IComboBox;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:261](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L261)

Defines the combo box component.

### Properties

#### component

```ts
component: comboBox;
```

Defined in: [interfaces/components/Component.ts:263](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L263)

Defines the "comboBox" component type

#### props

```ts
props: IComboBox;
```

Defined in: [interfaces/components/Component.ts:265](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L265)

Defines the combo box component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:267](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L267)

Defines the combo box component context name that updates the component via React context

***

### Example

```typescript
import { IComboBox, IComboBoxItem, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const comboBox: IComboBox = {
  options: [
    { key: "light", label: "Light Theme", icon: "theme-light.svg" },
    { key: "dark", label: "Dark Theme", icon: "theme-dark.svg" },
    { key: "system", label: "System Theme", icon: "theme-auto.svg" }
  ],
  selectedOption: { key: "light", label: "Light Theme", icon: "theme-light.svg" },
  onSelect: (item) => {},
  scaled: true,
  directionX: "right",
  directionY: "bottom",
  displayType: "default",
  modernView: true
};

const comboBoxGroup: Component = {
  component: Components.comboBox,
  props: comboBox,
  contextName: "themeSelector"
};
```

## IFrameGroup

```ts
type IFrameGroup = {
  component: iFrame;
  props: IFrame;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:298](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L298)

Defines the iframe component.

### Properties

#### component

```ts
component: iFrame;
```

Defined in: [interfaces/components/Component.ts:300](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L300)

Defines the "iFrame" component type

#### props

```ts
props: IFrame;
```

Defined in: [interfaces/components/Component.ts:302](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L302)

Defines the iFrame component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:304](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L304)

Defines the iFrame component context name that updates the component via React context

***

### Example

```typescript
import { IFrame, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const iframe: IFrame = {
  src: "https://example.com/embedded-content",
  width: "100%",
  height: "500px",
  name: "content-frame",
  sandbox: "allow-scripts allow-same-origin",
  id: "content-iframe",
  style: {
    border: "1px solid #eceef1",
    borderRadius: "4px",
    backgroundColor: "#ffffff"
  }
};

const iframeGroup: Component = {
  component: Components.iFrame,
  props: iframe,
  contextName: "embeddedContent"
};
```

## ImageGroup

```ts
type ImageGroup = {
  component: img;
  props: IImage;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:335](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L335)

Defines the image component.

### Properties

#### component

```ts
component: img;
```

Defined in: [interfaces/components/Component.ts:337](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L337)

Defines the "img" component type

#### props

```ts
props: IImage;
```

Defined in: [interfaces/components/Component.ts:339](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L339)

Defines the image component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:341](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L341)

Defines the image component context name that updates the component via React context

***

### Example

```typescript
import { IImage, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const image: IImage = {
  src: "https://example.com/plugin-banner.png",
  alt: "Plugin Banner",
  width: "100%",
  height: "auto",
  name: "plugin-banner",
  id: "banner-image",
  style: {
    borderRadius: "8px",
    boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
    maxWidth: "600px"
  }
};

const imageGroup: Component = {
  component: Components.img,
  props: image,
  contextName: "bannerImage"
};
```

## InputGroup

```ts
type InputGroup = {
  component: input;
  props: IInput;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:373](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L373)

Defines the input component.

### Properties

#### component

```ts
component: input;
```

Defined in: [interfaces/components/Component.ts:375](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L375)

Defines the "input" component type

#### props

```ts
props: IInput;
```

Defined in: [interfaces/components/Component.ts:377](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L377)

Defines the input component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:379](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L379)

Defines the input component context name that updates the component via React context

***

### Example

```typescript
import { IInput, Components, Component, Actions, InputSize } from "@onlyoffice/docspace-plugin-sdk";

const input: IInput = {
  value: "",
  onChange: (value) => {},
  placeholder: "Enter text...",
  size: InputSize.middle,
  name: "search-input",
  isAutoFocused: true,
  iconName: "search",
  iconSize: 16,
  scale: true,
  onIconClick: () => {
    console.log("Search icon clicked");
  }
};

const inputGroup: Component = {
  component: Components.input,
  props: input,
  contextName: "searchInput"
};
```

## LabelGroup

```ts
type LabelGroup = {
  component: label;
  props: ILabel;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:406](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L406)

Defines the label component.

### Properties

#### component

```ts
component: label;
```

Defined in: [interfaces/components/Component.ts:408](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L408)

Defines the "label" component type

#### props

```ts
props: ILabel;
```

Defined in: [interfaces/components/Component.ts:410](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L410)

Defines the label component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:412](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L412)

Defines the label component context name that updates the component via React context

***

### Example

```typescript
import { ILabel, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const label: ILabel = {
  text: "Plugin Settings",
  isRequired: true,
  error: false,
  title: "Configure plugin settings",
  htmlFor: "settings-form",
  display: "block",
  truncate: true
};

const labelGroup: Component = {
  component: Components.label,
  props: label,
  contextName: "settingsLabel"
};
```

## SkeletonGroup

```ts
type SkeletonGroup = {
  component: skeleton;
  props: ISkeleton;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:435](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L435)

Defines the skeleton component.

### Properties

#### component

```ts
component: skeleton;
```

Defined in: [interfaces/components/Component.ts:437](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L437)

Defines the "skeleton" component type

#### props

```ts
props: ISkeleton;
```

Defined in: [interfaces/components/Component.ts:439](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L439)

Defines the skeleton component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:441](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L441)

Defines the skeleton component context name that updates the component via React context

***

### Example

```typescript
import { ISkeleton, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const skeleton: ISkeleton = {
  width: "100%",
  height: "200px",
  borderRadius: "8px"
};

const skeletonGroup: Component = {
  component: Components.skeleton,
  props: skeleton,
  contextName: "loadingState"
};
```

## TextGroup

```ts
type TextGroup = {
  component: text;
  props: IText;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:470](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L470)

Defines the text component.

### Properties

#### component

```ts
component: text;
```

Defined in: [interfaces/components/Component.ts:472](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L472)

Defines the "text" component type

#### props

```ts
props: IText;
```

Defined in: [interfaces/components/Component.ts:474](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L474)

Defines the text component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:476](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L476)

Defines the text component context name that updates the component via React context

***

### Example

```typescript
import { IText, Components, Component } from "@onlyoffice/docspace-plugin-sdk";

const text: IText = {
  text: "Welcome to DocSpace Plugin",
  fontSize: "18px",
  fontWeight: 500,
  lineHeight: "24px",
  color: "#333333",
  isBold: false,
  textAlign: "left",
  truncate: true,
  title: "Welcome to DocSpace Plugin"
};

const textGroup: Component = {
  component: Components.text,
  props: text,
  contextName: "welcomeText"
};
```

## TextAreaGroup

```ts
type TextAreaGroup = {
  component: textArea;
  props: ITextArea;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:505](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L505)

Defines the textarea component.

### Properties

#### component

```ts
component: textArea;
```

Defined in: [interfaces/components/Component.ts:507](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L507)

Defines the "textArea" component type

#### props

```ts
props: ITextArea;
```

Defined in: [interfaces/components/Component.ts:509](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L509)

Defines the textarea component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:511](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L511)

Defines the textarea component context name that updates the component via React context

***

### Example

```typescript
import { ITextArea, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const textarea: ITextArea = {
  value: "",
  onChange: (value) => {},
  placeholder: "Enter description...",
  heightTextArea: 150,
  fontSize: 14,
  isFullHeight: true,
  heightScale: true,
  maxLength: 1000,
  hasNumeration: false
};

const textAreaGroup: Component = {
  component: Components.textArea,
  props: textarea,
  contextName: "descriptionEditor"
};
```

## ToggleButtonGroup

```ts
type ToggleButtonGroup = {
  component: toggleButton;
  props: IToggleButton;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:539](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L539)

Defines the toggle button component.

### Properties

#### component

```ts
component: toggleButton;
```

Defined in: [interfaces/components/Component.ts:541](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L541)

Defines the "toggleButton" component type

#### props

```ts
props: IToggleButton;
```

Defined in: [interfaces/components/Component.ts:543](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L543)

Defines the toggle button component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:545](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L545)

Defines the toggle button component context name that updates the component via React context

***

### Example

```typescript
import { IToggleButton, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const toggleButton: IToggleButton = {
  label: "Auto-sync",
  isChecked: true,
  onChange: () => {},
  style: {
    backgroundColor: "#f8f9f9",
    padding: "8px 12px",
    borderRadius: "4px"
  }
};

const toggleButtonGroup: Component = {
  component: Components.toggleButton,
  props: toggleButton,
  contextName: "syncToggle"
};
```

## IconButtonGroup

```ts
type IconButtonGroup = {
  component: iconButton;
  props: IIconButton;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:574](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L574)

Defines the icon button component.

### Properties

#### component

```ts
component: iconButton;
```

Defined in: [interfaces/components/Component.ts:576](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L576)

Defines the "iconButton" component type

#### props

```ts
props: IIconButton;
```

Defined in: [interfaces/components/Component.ts:578](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L578)

Defines the icon button component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:580](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L580)

Defines the icon button component context name that updates the component via React context

***

### Example

```typescript
import { IIconButton, Components, Component, Actions } from "@onlyoffice/docspace-plugin-sdk";

const iconButton: IIconButton = {
  iconName: "settings.svg",
  size: 32,
  color: "#333333",
  hoverColor: "accent",
  onClick: () => {
    console.log("Settings clicked");
  },
  title: "Open settings",
  isDisabled: false
};

const iconButtonGroup: Component = {
  component: Components.iconButton,
  props: iconButton,
  contextName: "settingsButton"
};
```

## LinkGroup

```ts
type LinkGroup = {
  component: link;
  props: ILink;
  contextName?: string;
};
```

Defined in: [interfaces/components/Component.ts:607](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L607)

Defines the link component.

### Properties

#### component

```ts
component: link;
```

Defined in: [interfaces/components/Component.ts:609](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L609)

Defines the "link" component type

#### props

```ts
props: ILink;
```

Defined in: [interfaces/components/Component.ts:611](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L611)

Defines the link component properties

#### contextName?

```ts
optional contextName: string;
```

Defined in: [interfaces/components/Component.ts:613](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L613)

Defines the link component context name that updates the component via React context

### Example

```typescript
import { ILink, Components, Component, LinkType, LinkTarget } from "@onlyoffice/docspace-plugin-sdk";

const link: ILink = {
  href: "https://example.com",
  text: "Visit Example",
  type: LinkType.page,
  target: LinkTarget.blank,
  color: "accent",
  fontSize: "14px",
  isBold: false
};

const linkGroup: Component = {
  component: Components.link,
  props: link,
  contextName: "exampleLink"
};
```

