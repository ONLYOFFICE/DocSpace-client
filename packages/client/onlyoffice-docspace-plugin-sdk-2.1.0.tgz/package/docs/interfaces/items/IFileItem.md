# IFileItem

Defined in: [interfaces/items/IFileItem.ts:132](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L132)

Describes an item that will be embedded in the file list.
The file item can be displayed as a file or a folder.

![file-icon](/assets/images/docspace/file-icon.png#gh-light-mode-only)![file-icon](/assets/images/docspace/file-icon.dark.png#gh-dark-mode-only)

## Properties

### extension

```ts
extension: string;
```

Defined in: [interfaces/items/IFileItem.ts:134](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L134)

The file extension. If several plugins have the same extension, the last plugin from this list is taken

### onClick()

```ts
onClick: (item: File) => 
  | void
  | Promise<void>
  | IMessage
| Promise<IMessage>;
```

Defined in: [interfaces/items/IFileItem.ts:140](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L140)

A function that takes the File object with the file data as an argument.
This function can be asynchronous. It will be executed when the user clicks on a file with the required extension.

#### Parameters

##### item

[`File`](#file)

#### Returns

  `void`
  \| `Promise`\<`void`\>
  \| [`IMessage`](../utils.md#imessage)
  \| `Promise`\<[`IMessage`](../utils.md#imessage)\>

### usersType?

```ts
optional usersType: UsersType[];
```

Defined in: [interfaces/items/IFileItem.ts:147](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L147)

The types of users who have the access to the current item.
Currently the following user types are available: owner, docSpaceAdmin, roomAdmin, collaborator, user.
If this parameter is not specified, then the current item will be available for all user types.

### devices?

```ts
optional devices: Devices[];
```

Defined in: [interfaces/items/IFileItem.ts:154](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L154)

The types of devices where the current item will be available.
At the moment the following device types are available: mobile, tablet, desktop.
If this parameter is not specified, then the current item will be available in any device types.

### fileTypeName?

```ts
optional fileTypeName: string;
```

Defined in: [interfaces/items/IFileItem.ts:157](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L157)

A file type which is displayed in the list (for example, Document/Folder)

### fileRowIcon?

```ts
optional fileRowIcon: string;
```

Defined in: [interfaces/items/IFileItem.ts:164](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L164)

A file icon which is displayed in the table format. The icon image must be uploaded
to the assets folder. Only the image name with the extension must be specified in this field.
The preferred icon size is 32x32 px.

### fileTileIcon?

```ts
optional fileTileIcon: string;
```

Defined in: [interfaces/items/IFileItem.ts:171](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L171)

A file icon which is displayed in the tile format. The icon image must be uploaded
to the assets folder. Only the image name with the extension must be specified in this field.
The preferred icon size is 96x96 px.

### fileSecurity?

```ts
optional fileSecurity: FilesSecurity[];
```

Defined in: [interfaces/items/IFileItem.ts:178](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L178)

The security parameters of the file that will be checked.
If all the parameters are true, the onClick event will be triggered.
If this parameter is not specified, the security settings are ignored.

### security?

```ts
optional security: Security[];
```

Defined in: [interfaces/items/IFileItem.ts:185](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L185)

The security parameters of the parent folder or room that will be checked.
If all the parameters are true, the onClick event will be triggered.
If this parameter is not specified, the security settings are ignored.

***

## Examples

3D model viewer with format validation

```typescript
import { IFileItem, Actions, ToastType, Devices } from "@onlyoffice/docspace-plugin-sdk";

const modelViewer: IFileItem = {
  extension: ".obj",
  fileTypeName: "3D Model",
  fileRowIcon: "3d-model-32.svg",
  fileTileIcon: "3d-model-96.svg",
  devices: [Devices.desktop],
  onClick: async (file) => {
    try {
      await load3DModel(file.id);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.success,
          title: "3D model loaded successfully"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.error,
          title: "Unable to process the 3D model"
        }]
      };
    }
  }
}
```

Markdown content processor with error handling

```typescript
const markdownPreview: IFileItem = {
  extension: ".md",
  fileTypeName: "Markdown",
  fileRowIcon: "markdown-32.svg",
  onClick: async (file) => {
    try {
      const content = await fetchMarkdownContent(file.id);
      await saveMarkdown(file.id, content);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.success,
          title: "Markdown file processed"
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.error,
          title: "Unable to process the markdown file"
        }]
      };
    }
  }
}
```

Audio player with access restrictions

```typescript
const audioPlayer: IFileItem = {
  extension: ".mp3",
  fileTypeName: "Audio",
  fileRowIcon: "audio-32.svg",
  fileTileIcon: "audio-96.svg",
  usersType: [UsersType.docSpaceAdmin, UsersType.roomAdmin, UsersType.user],
  fileSecurity: [FilesSecurity.Read, FilesSecurity.Download],
  onClick: async (file) => {
    try {
      await playAudio(file.viewUrl);
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.success,
          title: `Playing ${file.title}`
        }]
      };
    } catch (error) {
      return {
        actions: [Actions.showToast],
        toastProps: [{
          type: ToastType.error,
          title: "Unable to play the audio file"
        }]
      };
    }
  }
}
```

## File

Defined in: [interfaces/items/IFileItem.ts:191](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L191)

Describes the file properties.

### Properties

#### folderId

```ts
folderId: number;
```

Defined in: [interfaces/items/IFileItem.ts:193](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L193)

The folder ID where the current file is located

#### fileExst

```ts
fileExst: string;
```

Defined in: [interfaces/items/IFileItem.ts:196](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L196)

The file extension

#### id

```ts
id: number;
```

Defined in: [interfaces/items/IFileItem.ts:199](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L199)

The file ID

#### rootFolderType

```ts
rootFolderType: number;
```

Defined in: [interfaces/items/IFileItem.ts:202](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L202)

The root folder type of the current file

#### rootFolderId

```ts
rootFolderId: number;
```

Defined in: [interfaces/items/IFileItem.ts:205](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L205)

The root folder ID of the current file

#### title

```ts
title: string;
```

Defined in: [interfaces/items/IFileItem.ts:208](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L208)

The file title

#### viewUrl

```ts
viewUrl: string;
```

Defined in: [interfaces/items/IFileItem.ts:211](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L211)

The URL to open the current file in the viewer

#### webUrl

```ts
webUrl: string;
```

Defined in: [interfaces/items/IFileItem.ts:214](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/items/IFileItem.ts#L214)

The absolute URL where the source viewed or edited document is stored
