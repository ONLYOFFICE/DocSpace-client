# Type Alias: Component

> **Component** = [`BoxGroup`](BoxGroup.md) \| [`ButtonGroup`](ButtonGroup.md) \| [`CheckboxGroup`](CheckboxGroup.md) \| [`ComboBoxGroup`](ComboBoxGroup.md) \| [`IFrameGroup`](IFrameGroup.md) \| [`ImageGroup`](ImageGroup.md) \| [`InputGroup`](InputGroup.md) \| [`LabelGroup`](LabelGroup.md) \| [`SkeletonGroup`](SkeletonGroup.md) \| [`TextGroup`](TextGroup.md) \| [`TextAreaGroup`](TextAreaGroup.md) \| [`ToggleButtonGroup`](ToggleButtonGroup.md)

Defined in: [interfaces/components/Component.ts:551](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Component.ts#L551)

A component that is used to add components into Box.
Only components that are embedded into DOM can be wrapped (toast, modal dialog, etc. cannot be wrapped).

## Example

```typescript
import {
  IBox,
  IText,
  IButton,
  ButtonSize,
  Components,
  Component,
  Actions
  IToast,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

const title: IText = {
  text: "Plugin Settings",
  fontSize: "18px",
  fontWeight: 600,
};

const button: IButton = {
  label: "Save Changes",
  onClick: () => {
    return {
      actions: [Actions.showToast],
      toastProps: [{
        title: "Success",
        type: ToastType.success,
      }]
    };
  },
  size: ButtonSize.normal,
  primary: true
};

// Create a settings panel with text and button
const container: IBox = {
  paddingProp: "16px",
  backgroundProp: "#f8f9f9",
  children: [
    {
      component: Components.text,
      props: title
    },
    {
      component: Components.button,
      props: button
    }
  ]
};

// Combine components into a layout
const settingsPanel: Component = {
  component: Components.box,
  props: container
};
```
