# Components

Here is a description of the module Components.

## Box

Here is a description of the category Box.

- [BoxGroup](type-aliases/BoxGroup.md)
- [IBorderProp](interfaces/IBorderProp.md)
- [IBox](interfaces/IBox.md)

## Button

Here is a description of the category Button.

- [ButtonGroup](type-aliases/ButtonGroup.md)
- [ButtonSize](enumerations/ButtonSize.md)
- [IButton](interfaces/IButton.md)

## Checkbox

Here is a description of the category Checkbox.

- [CheckboxGroup](type-aliases/CheckboxGroup.md)
- [ICheckbox](interfaces/ICheckbox.md)

## ComboBox

Here is a description of the category ComboBox.

- [ComboBoxGroup](type-aliases/ComboBoxGroup.md)
- [IComboBoxItem](interfaces/IComboBoxItem.md)
- [IComboBox](interfaces/IComboBox.md)

## Component

- [Component](type-aliases/Component.md)

## CreateDialog

Here is a description of the category CreateDialog.

- [ICreateDialog](interfaces/ICreateDialog.md)

## FloatingOperations

- [IFloatingOperationsButton](interfaces/IFloatingOperationsButton.md)
- [FloatingOperationType](enumerations/FloatingOperationType.md)
- [IFloatingOperation](interfaces/IFloatingOperation.md)

## Frame

Here is a description of the category Frame.

- [IFrameGroup](type-aliases/IFrameGroup.md)
- [IFrame](interfaces/IFrame.md)

## Image

Here is a description of the category Image.

- [ImageGroup](type-aliases/ImageGroup.md)
- [IImage](interfaces/IImage.md)

## Input

Here is a description of the category Input.

- [InputGroup](type-aliases/InputGroup.md)
- [InputSize](enumerations/InputSize.md)
- [InputAutocomplete](enumerations/InputAutocomplete.md)
- [InputType](enumerations/InputType.md)
- [IInput](interfaces/IInput.md)

## Label

Here is a description of the category Label.

- [LabelGroup](type-aliases/LabelGroup.md)
- [ILabel](interfaces/ILabel.md)

## ModalDialog

Here is a description of the category ModalDialog.

- [ModalDisplayType](enumerations/ModalDisplayType.md)
- [IModalDialog](interfaces/IModalDialog.md)

## Selector

- [TBaseSelector](type-aliases/TBaseSelector.md)
- [TSelectorItem](type-aliases/TSelectorItem.md)
- [TSelectorItemFile](type-aliases/TSelectorItemFile.md)
- [TSelectorItemInput](type-aliases/TSelectorItemInput.md)
- [TSelectorItemNew](type-aliases/TSelectorItemNew.md)
- [TBreadCrumbItem](type-aliases/TBreadCrumbItem.md)
- [TSelectorBreadCrumbs](type-aliases/TSelectorBreadCrumbs.md)
- [TSelectorPagination](type-aliases/TSelectorPagination.md)
- [TSelectorHeader](type-aliases/TSelectorHeader.md)
- [TSelectorCheckbox](type-aliases/TSelectorCheckbox.md)
- [TSelectorCancelButton](type-aliases/TSelectorCancelButton.md)
- [TSelectorBaseProps](type-aliases/TSelectorBaseProps.md)
- [TSelectorLifecycleEvents](type-aliases/TSelectorLifecycleEvents.md)
- [TSelectorEmptyScreen](type-aliases/TSelectorEmptyScreen.md)
- [TSelectorSearchCreate](type-aliases/TSelectorSearchCreate.md)
- [TSelectorSubmitButton](type-aliases/TSelectorSubmitButton.md)
- [TFilesSelector](type-aliases/TFilesSelector.md)
- [TGroupsSelector](type-aliases/TGroupsSelector.md)
- [TPeopleSelector](type-aliases/TPeopleSelector.md)
- [TRoomSelector](type-aliases/TRoomSelector.md)
- [TSelector](type-aliases/TSelector.md)

## Skeleton

Here is a description of the category Skeleton.

- [SkeletonGroup](type-aliases/SkeletonGroup.md)
- [ISkeleton](interfaces/ISkeleton.md)

## Text

Here is a description of the category Text.

- [TextGroup](type-aliases/TextGroup.md)
- [IText](interfaces/IText.md)

## TextArea

Here is a description of the category TextArea.

- [TextAreaGroup](type-aliases/TextAreaGroup.md)
- [ITextArea](interfaces/ITextArea.md)

## Toast

Here is a description of the category Toast.

- [ToastType](enumerations/ToastType.md)
- [IToast](interfaces/IToast.md)

## ToggleButton

Here is a description of the category ToggleButton.

- [ToggleButtonGroup](type-aliases/ToggleButtonGroup.md)
- [IToggleButton](interfaces/IToggleButton.md)
