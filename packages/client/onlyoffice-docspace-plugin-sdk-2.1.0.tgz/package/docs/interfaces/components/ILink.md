# ILink

Defined in: [interfaces/components/ILink.ts:45](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L45)

Defines the link component properties.

![link](/assets/images/docspace/link.png#gh-light-mode-only)![link](/assets/images/docspace/link.dark.png#gh-dark-mode-only)

## Extends

- [`IText`](IText.md)

## Properties

### href?

```ts
optional href: string;
```

Defined in: [interfaces/components/ILink.ts:47](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L47)

URL for the link

### id?

```ts
optional id: string;
```

Defined in: [interfaces/components/ILink.ts:50](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L50)

Link identifier

### isHovered?

```ts
optional isHovered: boolean;
```

Defined in: [interfaces/components/ILink.ts:53](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L53)

Sets hovered state and link effects

### isTextOverflow?

```ts
optional isTextOverflow: boolean;
```

Defined in: [interfaces/components/ILink.ts:56](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L56)

Activates text-overflow with ellipsis

### noHover?

```ts
optional noHover: boolean;
```

Defined in: [interfaces/components/ILink.ts:59](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L59)

Disables hover effect

### enableUserSelect?

```ts
optional enableUserSelect: boolean;
```

Defined in: [interfaces/components/ILink.ts:62](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L62)

Enables user selection

### type?

```ts
optional type: LinkType;
```

Defined in: [interfaces/components/ILink.ts:65](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L65)

Link type (page or action)

### target?

```ts
optional target: LinkTarget;
```

Defined in: [interfaces/components/ILink.ts:68](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L68)

Target attribute for link

### textDecoration?

```ts
optional textDecoration: 
  | "none"
  | "underline"
  | "line-through"
  | "overline"
  | "underline dotted"
  | "underline dashed";
```

Defined in: [interfaces/components/ILink.ts:71](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L71)

Text decoration style

### onClick()?

```ts
optional onClick: () => TReturnMessage;
```

Defined in: [interfaces/components/ILink.ts:80](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L80)

Click handler (for action type links)

#### Returns

[`TReturnMessage`](../utils.md#treturnmessage)

### text

```ts
text: string;
```

Defined in: [interfaces/components/IText.ts:75](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L75)

Defines the text

#### Inherited from

[`IText`](IText.md).[`text`](IText.md#text)

### title?

```ts
optional title: string;
```

Defined in: [interfaces/components/IText.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L79)

Defines the text title

#### Inherited from

[`IText`](IText.md).[`title`](IText.md#title)

### fontSize?

```ts
optional fontSize: string;
```

Defined in: [interfaces/components/IText.ts:83](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L83)

Defines the text font size

#### Inherited from

[`IText`](IText.md).[`fontSize`](IText.md#fontsize)

### fontWeight?

```ts
optional fontWeight: string | number;
```

Defined in: [interfaces/components/IText.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L87)

Defines the text font weight

#### Inherited from

[`IText`](IText.md).[`fontWeight`](IText.md#fontweight)

### truncate?

```ts
optional truncate: boolean;
```

Defined in: [interfaces/components/IText.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L91)

Specifies whether the word wrapping is set

#### Inherited from

[`IText`](IText.md).[`truncate`](IText.md#truncate)

### isBold?

```ts
optional isBold: boolean;
```

Defined in: [interfaces/components/IText.ts:95](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L95)

Specifies whether the text font weight is set to bold

#### Inherited from

[`IText`](IText.md).[`isBold`](IText.md#isbold)

### isItalic?

```ts
optional isItalic: boolean;
```

Defined in: [interfaces/components/IText.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L99)

Specifies whether the text style is set to italic

#### Inherited from

[`IText`](IText.md).[`isItalic`](IText.md#isitalic)

### isInline?

```ts
optional isInline: boolean;
```

Defined in: [interfaces/components/IText.ts:103](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L103)

Specifies whether the "display: inline-block" property is set

#### Inherited from

[`IText`](IText.md).[`isInline`](IText.md#isinline)

### textAlign?

```ts
optional textAlign: string;
```

Defined in: [interfaces/components/IText.ts:107](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L107)

Specifies whether the "text-align" property is set

#### Inherited from

[`IText`](IText.md).[`textAlign`](IText.md#textalign)

### noSelect?

```ts
optional noSelect: boolean;
```

Defined in: [interfaces/components/IText.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L111)

Specifies whether the text selection is disabled

#### Inherited from

[`IText`](IText.md).[`noSelect`](IText.md#noselect)

### display?

```ts
optional display: string;
```

Defined in: [interfaces/components/IText.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L115)

Specifies whether the "display" property is set

#### Inherited from

[`IText`](IText.md).[`display`](IText.md#display)

### lineHeight?

```ts
optional lineHeight: string;
```

Defined in: [interfaces/components/IText.ts:119](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L119)

Defines the text line height

#### Inherited from

[`IText`](IText.md).[`lineHeight`](IText.md#lineheight)

### color?

```ts
optional color: string;
```

Defined in: [interfaces/components/IText.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L123)

Defines the text color

#### Inherited from

[`IText`](IText.md).[`color`](IText.md#color)

### className?

```ts
optional className: string;
```

Defined in: [interfaces/components/IText.ts:129](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IText.ts#L129)

Defines the CSS class for styling the component.
Can be used to override or extend the default component styles.

#### Inherited from

[`IText`](IText.md).[`className`](IText.md#classname)

## Example

```typescript
import { ILink, LinkType, LinkTarget } from "@onlyoffice/docspace-plugin-sdk";

const link: ILink = {
  href: "https://example.com",
  text: "Visit Example",
  type: LinkType.page,
  target: LinkTarget.blank,
  isBold: false,
  color: "accent",
  fontSize: "14px",
  onClick: () => {
    console.log("Link clicked");
  }
};
```

## LinkType

Defined in: [interfaces/components/ILink.ts:86](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L86)

Defines the link type.

### Enumeration Members

#### page

```ts
page: "page";
```

Defined in: [interfaces/components/ILink.ts:88](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L88)

Regular page link

#### action

```ts
action: "action";
```

Defined in: [interfaces/components/ILink.ts:90](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L90)

Action link (clickable but not navigating)

***

## LinkTarget

Defined in: [interfaces/components/ILink.ts:96](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L96)

Defines the link target attribute.

### Enumeration Members

#### blank

```ts
blank: "_blank";
```

Defined in: [interfaces/components/ILink.ts:98](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L98)

Opens in a new tab

#### self

```ts
self: "_self";
```

Defined in: [interfaces/components/ILink.ts:100](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L100)

Opens in the same frame

#### parent

```ts
parent: "_parent";
```

Defined in: [interfaces/components/ILink.ts:102](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L102)

Opens in the parent frame

#### top

```ts
top: "_top";
```

Defined in: [interfaces/components/ILink.ts:104](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/ILink.ts#L104)

Opens in the full body of the window

