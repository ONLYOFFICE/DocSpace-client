# Type Alias: TSelectorBaseProps

> **TSelectorBaseProps** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:491](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L491)

Common base properties shared across all selector types.

## Appearance

### id?

> `optional` **id**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:497](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L497)

A unique identifier for the selector component.

***

### className?

> `optional` **className**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:503](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L503)

A CSS class name to apply to the selector component.
