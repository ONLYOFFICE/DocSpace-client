# Type Alias: TSelectorItemFile

> **TSelectorItemFile** = `object`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:198](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L198)

Defines properties for an item that represents a file.

## Content

### icon

> **icon**: `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:204](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L204)

The URL or identifier for the item's icon.

***

### fileExst

> **fileExst**: [`FilesExst`](../../enumerations/FilesExst.md) \| `string`

Defined in: [interfaces/components/Selector/IBaseSelector.ts:210](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L210)

The file extension (e.g., 'docx', 'pdf').

***

### fileType

> **fileType**: [`FilesType`](../../enumerations/FilesType.md)

Defined in: [interfaces/components/Selector/IBaseSelector.ts:216](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L216)

The general type of the file (e.g., 'text', 'spreadsheet').

## State

### security

> **security**: [`FilesSecurity`](../../enumerations/FilesSecurity.md)

Defined in: [interfaces/components/Selector/IBaseSelector.ts:222](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IBaseSelector.ts#L222)

The security or access level of the file.
