# Building UI

A plugin never renders anything itself. It returns a **description** of a UI, and the portal renders it with its own React components. There is no DOM, no React and no CSS-in-JS in your bundle — which is also why the UI automatically matches the portal's theme.

## The shape

Every node is a discriminated union of a component kind and its props:

```ts
type Component = {
  component: Components;      // enum
  props: IBox | IButton | IText | …;
  contextName?: string;       // addressable name, see "Updating" below
};
```

Containers nest through `IBox.children`. Only components that render inline can be nested — a toast or a modal is triggered by an action, not placed in a tree.

```ts
const body: IBox = {
  displayProp: "flex",
  flexDirection: "column",
  paddingProp: "16px",
  children: [
    { component: Components.text, props: { text: "Nothing here yet.", fontSize: "13px" } },
    {
      component: Components.button,
      props: { label: "Refresh", size: ButtonSize.normal, scale: true, onClick: async () => ({ /* IMessage */ }) },
    },
  ],
};
```

## Available components

`box`, `button`, `checkbox`, `comboBox`, `iconButton`, `iFrame`, `img`, `input`, `label`, `link`, `skeleton`, `text`, `textArea`, `toggleButton`.

Required props, since a missing one throws during render — and an exception there takes down the whole portal shell, not just your panel:

| Component | Required props |
|---|---|
| `button` | `label`, `size` (`ButtonSize`), `onClick` |
| `input` | `value`, `onChange` |
| `textArea` | `value`, `onChange` |
| `checkbox` / `toggleButton` | `isChecked`, `onChange` |
| `comboBox` | `options`, `selectedOption` |
| `text` / `label` | `text` |
| `img` | `src`, `alt` |
| `iFrame` | `src` |
| `skeleton` | `width`, `height` |
| `box`, `iconButton`, `link` | none |

`ButtonSize` and `InputSize` are `const enum`s — use `ButtonSize.normal`, not the string `"normal"`. TypeScript rejects the bare string.

## Styling

Styling is props, not stylesheets: `widthProp`, `heightProp`, `paddingProp`, `marginProp`, `displayProp`, `flexDirection`, `alignItems`, `justifyContent`, `flexWrap`, `borderProp`, `backgroundProp`, `overflowProp`, `textAlign`, plus `fontSize`, `fontWeight`, `color`, `isBold` on text.

`borderProp` is either a CSS shorthand string or `{ color, radius, style, width }` — all four required in the object form.

For colours, prefer the portal's CSS variables so the result follows the active theme:

```ts
{ color: "var(--error-color, var(--input-error-color))" }
```

Real CSS is possible — webpack can emit a `plugin.css` that gets packed when non-empty — but no official plugin ships one, and the stylesheet is injected unscoped into the portal's own document, so any selector you write can restyle the whole portal. Prefer props.

## Returning behaviour

Callbacks return an `IMessage`. Nothing happens directly; the host performs the listed actions:

```ts
onClick: async () => ({
  actions: [Actions.showToast],
  toastProps: [{ type: ToastType.success, title: "Saved" }],
})
```

The full action-to-payload table is in [host-behavior.md](host-behavior.md). Two rules worth repeating here, because they shape how you design a panel:

- **`updateProps` / `updateContext` only work from inside a rendered plugin tree** — a button in a modal, an input in settings. From a context-menu or main-button callback they do nothing (and `updateContext` actually throws). To change something from a menu item, open a modal and update from within it.
- Ordering matters; anything after `navigate` runs only once navigation completes.

## Updating a live panel

Two mechanisms, and the distinction matters:

**Self-update** — change the props of the element whose callback is running:

```ts
onChange: (value: string) => ({ actions: [Actions.updateProps], newProps: { value } })
```

**Sibling update** — change another element, addressed by the `contextName` you gave it:

```ts
// declaration
{ component: Components.text, contextName: "error", props: { text: "" } }

// from another element's callback
{
  actions: [Actions.updateContext],
  contextProps: [{ name: "error", props: { text: "URL is not valid" } }],
}
```

This is how live validation is built: the input's `onChange` updates itself with `updateProps` and the error label with `updateContext`, in one message.

## Modals

```ts
{
  actions: [Actions.showModal],
  modalDialogProps: {
    displayType: ModalDisplayType.modal,   // or .aside
    dialogHeader: "Title",
    dialogBody: body,
    dialogFooter: footer,
    onClose: () => ({ actions: [Actions.closeModal] }),
    onLoad: async () => ({ newDialogBody: body }),   // required, even if trivial
  },
}
```

`onLoad` is **not** optional on `IModalDialog`. Return the body you already built if there is nothing async to do.

## Async content

`InfoPanel`, `ArticleButton`, `Settings` items and modals all accept an `onLoad` returning a promise. Use it for anything that fetches: build the item with a `skeleton` placeholder, then resolve with real content. Doing the fetch in `onLoadCallback` instead delays installation of the entire plugin — and an exception there aborts it silently.
