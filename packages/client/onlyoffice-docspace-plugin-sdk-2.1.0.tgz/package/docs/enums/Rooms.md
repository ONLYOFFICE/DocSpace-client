# Rooms

Enumerations for DocSpace room types and search scopes.

## RoomSearchArea

Defined in: [enums/Rooms.ts:9](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L9)

Defines the available search scopes for rooms within a room selector.

### Enumeration Members

#### Any

```ts
Any: "Any";
```

Defined in: [enums/Rooms.ts:11](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L11)

Search across all available rooms.

#### Active

```ts
Active: "Active";
```

Defined in: [enums/Rooms.ts:13](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L13)

Search only within active rooms.

#### Archive

```ts
Archive: "Archive";
```

Defined in: [enums/Rooms.ts:15](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L15)

Search only within archived rooms.

#### Templates

```ts
Templates: "Templates";
```

Defined in: [enums/Rooms.ts:17](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L17)

Search only within room templates.

***

## RoomsType

Defined in: [enums/Rooms.ts:23](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L23)

Defines the different types of rooms available in the system.

### Enumeration Members

#### PublicRoom

```ts
PublicRoom: "public-room";
```

Defined in: [enums/Rooms.ts:25](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L25)

A public room accessible to a wide audience.

#### FormRoom

```ts
FormRoom: "form-room";
```

Defined in: [enums/Rooms.ts:27](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L27)

A room designed for filling out forms.

#### EditingRoom

```ts
EditingRoom: "editing-room";
```

Defined in: [enums/Rooms.ts:29](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L29)

A room focused on collaborative document editing.

#### VirtualDataRoom

```ts
VirtualDataRoom: "virtual-data-room";
```

Defined in: [enums/Rooms.ts:31](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L31)

A secure room for data storage and review.

#### CustomRoom

```ts
CustomRoom: "custom-room";
```

Defined in: [enums/Rooms.ts:33](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/enums/Rooms.ts#L33)

A room with custom permissions and settings.
