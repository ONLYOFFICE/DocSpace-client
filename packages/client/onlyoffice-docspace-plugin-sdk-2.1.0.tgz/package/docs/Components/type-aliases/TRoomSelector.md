# Type Alias: TRoomSelector

> **TRoomSelector** = [`TSelectorHeader`](TSelectorHeader.md) & [`TSelectorCancelButton`](TSelectorCancelButton.md) & [`TSelectorBaseProps`](TSelectorBaseProps.md) & [`TSelectorLifecycleEvents`](TSelectorLifecycleEvents.md) & [`TSelectorEmptyScreen`](TSelectorEmptyScreen.md) & [`TSelectorSearchCreate`](TSelectorSearchCreate.md) & `Pick`\<[`TSelectorSubmitButton`](TSelectorSubmitButton.md), `"submitButtonLabel"`\> & `object`

Defined in: [interfaces/components/Selector/IRoomSelector.ts:91](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/Selector/IRoomSelector.ts#L91)

Defines the properties for a room selector component.

## Type Declaration

### isMultiSelect?

> `optional` **isMultiSelect**: `boolean`

If true, allows multiple rooms to be selected.

### roomType?

> `optional` **roomType**: [`RoomsType`](../../enumerations/RoomsType.md) \| [`RoomsType`](../../enumerations/RoomsType.md)[]

The type of rooms to display (e.g., 'collaboration', 'custom'). Can be a single type or an array of types.

### searchArea?

> `optional` **searchArea**: [`RoomSearchArea`](../../enumerations/RoomSearchArea.md)

The area to search for rooms within (e.g., 'myRooms', 'allRooms').

### excludeItems?

> `optional` **excludeItems**: (`number` \| `string` \| `undefined`)[]

An array of room IDs to exclude from the list.

### createDefineRoomLabel?

> `optional` **createDefineRoomLabel**: `string`

The label for the 'create new room' option.

### createDefineRoomType?

> `optional` **createDefineRoomType**: [`RoomsType`](../../enumerations/RoomsType.md)

The default type for newly created rooms.

### onSubmit()?

> `optional` **onSubmit**: (`selectedIds`) => `TReturnMessage`

A callback function that is triggered when the submit button is clicked.

#### Parameters

##### selectedIds

(`string` \| `number`)[]

#### Returns

`TReturnMessage`

## Example

```typescript
// This example demonstrates how to create a room selector that allows users to
// select multiple public or custom rooms. It includes search and create functionalities.

const roomSelectorProps: TRoomSelector = {
  // Defines the text and visibility of the header.
  withHeader: true,
  headerProps: {
    label: "Select a Room",
  },

  // The text to display on the main action button.
  submitButtonLabel: "Open Rooms",
  // Enables and sets the text for the cancel button.
  withCancelButton: true,
  cancelButtonLabel: "Close",

  // Custom text to display when no rooms are found.
  emptyScreenHeader: "No Rooms Available",
  emptyScreenDescription: "You can create a new room or try a different search.",

  // Allows the selection of multiple rooms.
  isMultiSelect: true,
  // Filters the list to show only public and custom rooms.
  roomType: [RoomsType.PublicRoom, RoomsType.CustomRoom],
  // Sets the search scope to active rooms.
  searchArea: RoomSearchArea.Active,

  // Enables the search bar and the create room button.
  withCreate: true,
  withSearch: true,
  // Label for the create room button.
  createDefineRoomLabel: "Create a new collaboration room",
  // Default type for a newly created room.
  createDefineRoomType: RoomsType.Collaboration,

  // A callback function that is executed when the user clicks the submit button.
  onSubmit: (selectedIds) => {
    // The `selectedIds` parameter is an array of the selected room IDs.
    console.log("Selected rooms:", selectedIds);

    // After submission, close the selector and show a success message.
    return {
      actions: [Actions.closeSelector, Actions.showToast],
      toastProps: [{
        type: ToastType.success,
        title: `${selectedIds.length} rooms selected`,
      }],
    };
  },
};
```
