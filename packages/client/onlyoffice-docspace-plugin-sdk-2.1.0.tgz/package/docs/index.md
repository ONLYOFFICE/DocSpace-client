# @onlyoffice/docspace-plugin-sdk v2.0.0

## Modules

- [Components](Components/index.md)

## Enumerations

- [Actions](enumerations/Actions.md)
- [Components](enumerations/Components.md)
- [Devices](enumerations/Devices.md)
- [Events](enumerations/Events.md)
- [FilesType](enumerations/FilesType.md)
- [FilesExst](enumerations/FilesExst.md)
- [FilesSecurity](enumerations/FilesSecurity.md)
- [PluginStatus](enumerations/PluginStatus.md)
- [PluginLocale](enumerations/PluginLocale.md)
- [RoomSearchArea](enumerations/RoomSearchArea.md)
- [RoomsType](enumerations/RoomsType.md)
- [Security](enumerations/Security.md)
- [SelectorType](enumerations/SelectorType.md)
- [UsersType](enumerations/UsersType.md)
