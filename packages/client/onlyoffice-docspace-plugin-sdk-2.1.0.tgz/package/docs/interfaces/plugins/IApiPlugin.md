# IApiPlugin

Defined in: [interfaces/plugins/IApiPlugin.ts:79](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L79)

The plugin that is provided with the origin, proxy, and prefix to make requests to the portal server.

## Methods

### setOrigin()

```ts
setOrigin(origin: string): void;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:93](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L93)

Update the origin parameter of the DocSpace portal.

#### Parameters

##### origin

`string`

The new origin parameter

#### Returns

`void`

### setProxy()

```ts
setProxy(proxy: string): void;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:99](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L99)

Update the proxy parameter of the DocSpace portal.

#### Parameters

##### proxy

`string`

The new proxy parameter

#### Returns

`void`

### setPrefix()

```ts
setPrefix(prefix: string): void;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:105](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L105)

Update the prefix parameter of the DocSpace portal.

#### Parameters

##### prefix

`string`

The new prefix parameter

#### Returns

`void`

### getOrigin()

```ts
getOrigin(): string;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:111](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L111)

Get the origin parameter of the DocSpace portal.

#### Returns

`string`

The current origin parameter

### getProxy()

```ts
getProxy(): string;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:117](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L117)

Get the proxy parameter of the DocSpace portal.

#### Returns

`string`

The current proxy parameter

### getPrefix()

```ts
getPrefix(): string;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L123)

Get the prefix parameter of the DocSpace portal to access the server side.

#### Returns

`string`

The current prefix parameter

### setAPI()

```ts
setAPI(
   origin: string, 
   proxy: string, 
   prefix: string): void;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L131)

Update all the API parameters of the DocSpace portal in one request.

#### Parameters

##### origin

`string`

The new origin parameter

##### proxy

`string`

The new proxy parameter

##### prefix

`string`

The new prefix parameter

#### Returns

`void`

### getAPI()

```ts
getAPI(): {
  origin: string;
  proxy: string;
  prefix: string;
};
```

Defined in: [interfaces/plugins/IApiPlugin.ts:137](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L137)

Get all the API parameters of the DocSpace portal in one request.

#### Returns

```ts
{
  origin: string;
  proxy: string;
  prefix: string;
}
```

An object containing the current origin, proxy, and prefix parameters

##### origin

```ts
origin: string;
```

##### proxy

```ts
proxy: string;
```

##### prefix

```ts
prefix: string;
```

## Properties

### origin

```ts
origin: string;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:81](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L81)

Stores the origin parameter of the DocSpace portal

### proxy

```ts
proxy: string;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:84](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L84)

Stores the proxy parameter of the DocSpace portal

### prefix

```ts
prefix: string;
```

Defined in: [interfaces/plugins/IApiPlugin.ts:87](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/plugins/IApiPlugin.ts#L87)

Stores the prefix parameter of the DocSpace portal to access the server side

## Example

The plugin class implements `IApiPlugin`. DocSpace fills in the API parameters
via `setOrigin`/`setProxy`/`setPrefix` (or `setAPI`) when the plugin is loaded;
the plugin then uses `getAPI` to build request URLs to the portal.

```typescript
import { type IApiPlugin } from "@onlyoffice/docspace-plugin-sdk";

class Plugin implements IApiPlugin {
  origin = "";
  proxy = "";
  prefix = "";

  setOrigin = (origin: string): void => {
    this.origin = origin;
  };

  setProxy = (proxy: string): void => {
    this.proxy = proxy;
  };

  setPrefix = (prefix: string): void => {
    this.prefix = prefix;
  };

  getOrigin = (): string => {
    return this.origin;
  };

  getProxy = (): string => {
    return this.proxy;
  };

  getPrefix = (): string => {
    return this.prefix;
  };

  setAPI = (origin: string, proxy: string, prefix: string): void => {
    this.origin = origin;
    this.proxy = proxy;
    this.prefix = prefix;
  };

  getAPI = (): { origin: string; proxy: string; prefix: string } => {
    return { origin: this.origin, proxy: this.proxy, prefix: this.prefix };
  };

  // Example of a custom method that uses the API parameters to call the portal
  getUsersList = async (): Promise<unknown> => {
    const { origin, proxy, prefix } = this.getAPI();
    const response = await fetch(`${origin}${proxy}${prefix}/people`);
    return response.json();
  };
}
```

