# Аудит плагина `room-stats`

Плагин: `skill-workspace/iteration-2/eval-2-audit-broken-plugin/without_skill/project`
SDK: `@onlyoffice/docspace-plugin-sdk` 2.1.0 (проверено по опубликованным типам и по `npx/buildPlugin.js`)

Исходники плагина не изменялись.

---

## Короткий ответ

Плагин собирается и устанавливается, но портал его **никогда не находит**: объект регистрируется в
`window.Plugins` под именем `RoomStatistics`, а в `package.json` объявлено `pluginName: "RoomStats"`.
Портал ищет ровно `window.Plugins["RoomStats"]`, получает `undefined` — и ни один пункт меню не
появляется. Это и есть причина «в интерфейсе вообще ничего нет».

Кроме этого блокера есть ещё три дефекта, которые проявились бы сразу после его исправления.

---

## 1. БЛОКЕР — имя глобальной регистрации не совпадает с `pluginName`

`src/index.ts:98`

```ts
window.Plugins.RoomStatistics = plugin || {};
```

`package.json:10`

```json
"pluginName": "RoomStats"
```

Как это работает на самом деле. Скрипт сборки `build-docspace-plugin` (`npx/buildPlugin.js`)
кладёт в `plugin.zip` файл `config.json`, куда переносит поле `pluginName` из `package.json`
один в один:

```js
pluginName: jsonDataObj.pluginName || "",
```

Портал загружает `plugin.js`, затем берёт `config.json.pluginName` и достаёт объект плагина
из глобального реестра по этому ключу. Каноничный шаблон SDK (`npx/createTemplate.js`)
генерирует строку `window.Plugins.NameIns = plugin || {};`, где `NameIns` — это ровно
значение `pluginName`.

Здесь имена разошлись: в `window.Plugins` лежит `RoomStatistics`, портал спрашивает `RoomStats`.

Почему это молча проходит сборку: `Window.Plugins` объявлен в `src/index.ts:92-96` как
`Record<string, unknown>`, поэтому любое имя свойства валидно для TypeScript. Ошибки нет ни
на компиляции, ни на упаковке, ни на загрузке в портал — плагин просто мёртв в рантайме.
`|| {}` тоже вводит в заблуждение: `plugin` — это всегда объект класса, ветка `{}` недостижима
и никакой защиты не даёт.

**Исправление:** привести имена к одному значению — либо `window.Plugins.RoomStats = plugin;`,
либо `"pluginName": "RoomStatistics"` в `package.json`.

---

## 2. `usersType` — такого поля в `IContextMenuItem` нет

`src/index.ts:40`

```ts
usersType: [UsersType.roomAdmin, UsersType.docSpaceAdmin],
```

В интерфейсе `IContextMenuItem` (SDK 2.1.0) поле называется **`usersTypes`** (множественное число):

```ts
usersTypes?: UsersType[];
```

`usersType` порталом не читается и просто игнорируется. По документации SDK, если фильтр по
типам пользователей не задан, пункт показывается **всем** типам пользователей. То есть замысел
«только админы комнаты и админы DocSpace» не реализован: после починки дефекта №1 пункт увидят
в том числе обычные пользователи и коллабораторы.

Почему компилятор промолчал: литерал сначала присваивается в `const roomStatsItem` без
аннотации типа (`src/index.ts:35`), поэтому проверка лишних свойств (excess property check)
не срабатывает, а в `addContextMenuItem(item: IContextMenuItem)` уходит уже выведенный тип —
он структурно совместим. Аннотация `const roomStatsItem: IContextMenuItem = {...}` поймала бы
опечатку на этапе сборки.

---

## 3. `Actions.showModal` без `modalDialogProps` — клик ничего не открывает

`src/index.ts:41-47`

```ts
onItemClick: async (id: string | number) => {
  const total = await Promise.resolve(id);

  return {
    actions: [Actions.showModal],
  };
},
```

В `IMessage` свойство `modalDialogProps?: IModalDialog` и снабжено прямым указанием:
*«This parameter is used only with `Actions.showModal`»*. Плагин просит портал показать
модальное окно, но не передаёт ни заголовка, ни тела, ни кнопок — рисовать нечего. Пользователь
жмёт пункт меню, и визуально не происходит ничего (симптом «кнопка мёртвая»).

Рядом — вторая проблема того же куска: `total` вычисляется из `await Promise.resolve(id)`
(то есть это просто сам `id`) и никуда не используется. Никакой статистики комнаты, заявленной
в `description`, здесь не считается — тело обработчика по сути пустое.

**Исправление:** вернуть `{ actions: [Actions.showModal], modalDialogProps: { ... } }` с
реальными `IModalDialog`-пропсами.

---

## 4. Локализация подписи «замерзает» на английском

`src/index.ts:26-38`

```ts
let locale: PluginLocale = PluginLocale.EN_US;
const t = (): string => labels[locale] ?? labels["en-US"];

const roomStatsItem = {
  ...
  label: t(),      // <- вычисляется на этапе загрузки модуля
```

и `src/index.ts:90` — `plugin.addContextMenuItem(roomStatsItem)` тоже вызывается на уровне
модуля.

Порядок на портале такой: сначала выполняется `plugin.js` (здесь уже посчитан `label` при
`locale === EN_US`), и только потом портал вызывает `setLanguage(...)` и `onLoadCallback()`.
`setLanguage` (`src/index.ts:69-71`) меняет переменную `locale`, но уже зарегистрированный
пункт не пересобирает — `label` остался строкой `"Room statistics"` навсегда. Русский вариант
из `labels` недостижим, хотя ключ `"ru"` совпадает с `PluginLocale.RU = "ru"` и сам по себе
корректен.

**Исправление:** регистрировать пункты в `onLoadCallback` (он вызывается уже после установки
языка) и/или в `setLanguage` пересобирать пункт и звать `updateContextMenuItem(...)` —
метод для этого в `IContextMenuPlugin` есть и в классе реализован, но нигде не используется.

Побочно: `onLoadCallback` (`src/index.ts:55-57`) — пустая заглушка `return;`, то есть
единственная штатная точка инициализации не задействована.

---

## Что проверено и оказалось в порядке

- `"scopes": ["ContextMenu"]` — строка корректная, именно её ждёт SDK (`scopes.includes("ContextMenu")`).
- `logo: "logo.svg"` и `icon: "icon-16.svg"` — оба файла лежат в `assets/`, упаковщик их положит в zip.
- Класс `RoomStats` полностью реализует `IPlugin` и `IContextMenuPlugin`: все обязательные методы на месте.
- `PluginStatus.active` — правильный член перечисления (в некоторых примерах документации SDK написано `PluginStatus.Active`, это опечатка документации, а не кода).
- `onItemClick` — актуальное имя колбэка; устаревший `onClick` (только `number`) использовать не нужно.
- Точка входа webpack (`./src/index.ts`) и выход `dist/plugin.js` совпадают с тем, что ищет `build-docspace-plugin`.

## Мелочи, на симптом не влияющие

- `webpack.config.js` — в отличие от шаблона SDK, здесь нет `MiniCssExtractPlugin` / `css-loader`
  / `CssMinimizerPlugin`. Пока в плагине нет CSS, это безвредно, но `dist/plugin.css` не сможет
  собраться, если стили появятся.
- `package.json:8` — `"main": "index.ts"`, хотя реальная точка входа `src/index.ts`.
  На сборку не влияет (webpack задаёт `entry` явно), но вводит в заблуждение.
- `tsconfig.json` — `"target": "es5"` при `Map`/`Promise`/async в коде: типы берутся из `lib`,
  так что компиляция проходит, полифилы для современных браузеров не нужны, но комбинация странная.

---

## Порядок исправления

1. Синхронизировать `window.Plugins.<имя>` с `package.json:pluginName` — **без этого остальное не проверить**.
2. `usersType` → `usersTypes`; заодно проаннотировать литерал как `IContextMenuItem`, чтобы такие опечатки ловились компилятором.
3. Добавить `modalDialogProps` к `Actions.showModal` и реально посчитать статистику в `onItemClick`.
4. Перенести регистрацию пункта в `onLoadCallback`, а в `setLanguage` вызывать `updateContextMenuItem`.
