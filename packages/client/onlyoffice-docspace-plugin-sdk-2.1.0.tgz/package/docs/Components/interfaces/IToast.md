# Interface: IToast

Defined in: [interfaces/components/IToast.ts:104](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L104)

Toast notification component for displaying temporary messages.

## Examples

Auto-dismissing success notification

```typescript
const saveSuccess: IToast = {
  type: ToastType.success,
  title: "Changes saved successfully",
  withCross: false,
  timeout: 3000 // Dismiss after 3 seconds
}
```

Persistent error notification with manual dismiss

```typescript
const errorToast: IToast = {
  type: ToastType.error,
  title: "Failed to upload file. Please try again.",
  withCross: true,
  timeout: 0 // Stay until manually dismissed
}
```

Session expiration warning with medium duration

```typescript
const warningToast: IToast = {
  type: ToastType.warning,
  title: "Your session will expire in 5 minutes",
  withCross: true,
  timeout: 5000
}
```

Temporary update notification

```typescript
const infoToast: IToast = {
  type: ToastType.info,
  title: "New updates are available",
  withCross: false,
  timeout: 4000
}
```

## Appearance

Properties that control the toast's type, color scheme, and visual presentation.

### type

> **type**: [`ToastType`](../enumerations/ToastType.md)

Defined in: [interfaces/components/IToast.ts:109](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L109)

Defines the toast type, which determines the toast color and icon

## Behavior

Properties that control the toast's dismissal behavior, timeout, and close button visibility.

### withCross?

> `optional` **withCross**: `boolean`

Defined in: [interfaces/components/IToast.ts:123](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L123)

Specifies whether the "Close" button will be displayed in the toast to close it (true).
Otherwise, the toast will disappear after clicking on any toast area (false).

***

### timeout?

> `optional` **timeout**: `number`

Defined in: [interfaces/components/IToast.ts:131](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L131)

Defines the time (in milliseconds) for showing the toast.
Setting the value to 0 allows the toast to be displayed continuously until clicking on it.

## Content

Properties that define the toast's title and message content.

### title

> **title**: `string`

Defined in: [interfaces/components/IToast.ts:115](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IToast.ts#L115)

Defines the toast title
