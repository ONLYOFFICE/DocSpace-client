# webhook-settings (with_skill)

- pluginName: `WebhookSettings`  version: `1.0.0`  scopes: `["Settings"]`
- zip built: yes

## src/index.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  IPlugin,
  ISettings,
  ISettingsPlugin,
  PluginLocale,
  PluginStatus,
} from "@onlyoffice/docspace-plugin-sdk";

import { currentLocale, setLocale } from "./locales";
import { applyStoredSettings, createPluginSettings } from "./settings";


class WebhookSettings
  implements
    IPlugin,
    ISettingsPlugin
{
  status: PluginStatus = PluginStatus.active;


  adminPluginSettings: ISettings | null = null;

  setAdminPluginSettings = (settings: ISettings | null): void => {
    this.adminPluginSettings = settings;
  };

  // The portal hands settings back as the raw string the plugin saved earlier,
  // and it arrives *after* installation - so parse defensively.
  setAdminPluginSettingsValue = (settings: string | null): void => {
    applyStoredSettings(settings);
  };

  getAdminPluginSettings = (): ISettings | null => this.adminPluginSettings;

  // Register items here rather than at module scope. Both are read in time, but
  // setLanguage and setAPI only run after the bundle executes - so a factory that
  // translates a label or calls getAPI() at module scope would capture empty values.
  onLoadCallback = async (): Promise<void> => {
    this.setAdminPluginSettings(createPluginSettings());
  };

  updateStatus = (status: PluginStatus): void => {
    this.status = status;
  };

  getStatus = (): PluginStatus => this.status;

  setOnLoadCallback = (callback: () => Promise<void>): void => {
    this.onLoadCallback = callback;
  };

  // The portal calls this when the interface language changes. Labels were
  // captured when the items were built, so the items have to be rebuilt.
  setLanguage = (language: PluginLocale): void => {
    setLocale(language);
    this.setAdminPluginSettings(createPluginSettings());
  };

  getLanguage = (): PluginLocale => currentLocale();

}

const plugin = new WebhookSettings();

declare global {
  interface Window {
    Plugins: Record<string, unknown>;
  }
}

window.Plugins.WebhookSettings = plugin || {};

export default plugin;
```

## src/locales.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { PluginLocale } from "@onlyoffice/docspace-plugin-sdk";

/**
 * Plain typed strings rather than an i18n library: the bundle stays small and a
 * missing key is a compile error instead of a blank label at runtime.
 */
export type TStrings = {
  "settings.urlLabel": string;
  "settings.invalidUrl": string;
  "settings.envLabel": string;
  "settings.envProduction": string;
  "settings.envStaging": string;
  "settings.sendNotifications": string;
  "settings.save": string;
  "settings.saved": string;
};

const en: TStrings = {
  "settings.urlLabel": "Webhook URL",
  "settings.invalidUrl": "Enter a valid URL starting with http:// or https://",
  "settings.envLabel": "Environment",
  "settings.envProduction": "Production",
  "settings.envStaging": "Staging",
  "settings.sendNotifications": "Send notifications",
  "settings.save": "Save",
  "settings.saved": "Webhook settings saved.",
};

const ru: TStrings = {
  "settings.urlLabel": "Webhook URL",
  "settings.invalidUrl": "Введите корректный URL, начинающийся с http:// или https://",
  "settings.envLabel": "Окружение",
  "settings.envProduction": "Production",
  "settings.envStaging": "Staging",
  "settings.sendNotifications": "Отправлять уведомления",
  "settings.save": "Сохранить",
  "settings.saved": "Настройки вебхука сохранены.",
};

const translations: Partial<Record<string, TStrings>> = {
  [PluginLocale.EN_US]: en,
  [PluginLocale.RU]: ru,
};

let locale: PluginLocale = PluginLocale.EN_US;

export const setLocale = (next: PluginLocale): void => {
  locale = translations[next] ? next : PluginLocale.EN_US;
};

export const currentLocale = (): PluginLocale => locale;

export const t = (key: keyof TStrings): string => (translations[locale] ?? en)[key];
```

## src/settings.ts

```ts
/*
 * (c) Copyright Ascensio System SIA 2026
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  Actions,
  ButtonSize,
  Component,
  Components,
  IBox,
  IComboBox,
  IComboBoxItem,
  IInput,
  IMessage,
  InputSize,
  InputType,
  ISettings,
  IText,
  IToggleButton,
  ToastType,
} from "@onlyoffice/docspace-plugin-sdk";

import { t } from "./locales";

/**
 * Settings travel to the portal as one opaque JSON string - the plugin owns the
 * format, the portal only stores it. Every field is re-validated on the way back.
 */
export type TEnvironment = "production" | "staging";

export type TWebhookSettings = {
  webhookUrl: string;
  environment: TEnvironment;
  sendNotifications: boolean;
};

const defaultSettings: TWebhookSettings = {
  webhookUrl: "",
  environment: "production",
  sendNotifications: true,
};

let current: TWebhookSettings = { ...defaultSettings };

// Prefixed with the plugin name out of the same habit that names item keys -
// collisions are silent.
const CTX_URL_INPUT = "webhook-settings-url-input";
const CTX_URL_ERROR = "webhook-settings-url-error";

const URL_PLACEHOLDER = "https://example.com/hooks/docspace";

/**
 * Stored settings arrive as the raw string handed to saveSettings earlier, and
 * only *after* installation. Disabling the plugin wipes them to ""/null, so an
 * empty value resets to defaults, and a malformed one must never throw.
 */
export const applyStoredSettings = (raw: string | null): void => {
  if (!raw) {
    current = { ...defaultSettings };
    return;
  }

  try {
    const parsed = JSON.parse(raw) as Partial<TWebhookSettings>;

    current = {
      webhookUrl:
        typeof parsed.webhookUrl === "string"
          ? parsed.webhookUrl
          : defaultSettings.webhookUrl,
      environment: parsed.environment === "staging" ? "staging" : "production",
      sendNotifications:
        typeof parsed.sendNotifications === "boolean"
          ? parsed.sendNotifications
          : defaultSettings.sendNotifications,
    };
  } catch {
    // Keep the previous values rather than breaking installation on a bad string.
  }
};

const isValidWebhookUrl = (value: string): boolean =>
  /^https?:\/\/\S+$/i.test(value);

const urlHasError = (): boolean => {
  const trimmed = current.webhookUrl.trim();
  return trimmed.length > 0 && !isValidWebhookUrl(trimmed);
};

/*
 * updateProps REPLACES an element's props rather than merging, so every element
 * gets a factory returning its complete prop set, and callbacks answer with a
 * fresh factory call instead of a partial patch.
 */

const urlErrorTextProps = (): IText => ({
  text: urlHasError() ? t("settings.invalidUrl") : "",
  // --input-error-color is the real token; --error-color does not exist on the
  // portal, and hardcoded hex would break in the other theme.
  color: "var(--input-error-color)",
  fontSize: "12px",
  lineHeight: "16px",
});

const urlErrorContext = () => ({
  name: CTX_URL_ERROR,
  props: urlErrorTextProps(),
});

const urlInputProps = (): IInput => ({
  value: current.webhookUrl,
  placeholder: URL_PLACEHOLDER,
  type: InputType.text,
  size: InputSize.base, // with scale the size only sets font/padding; big/huge are dead host-side
  scale: true,
  tabIndex: 0, // the host default is -1, which skips keyboard users
  maxLength: "2048", // the host default caps at 255 - short for real webhook URLs
  hasError: urlHasError(),
  onChange: (value: string): IMessage => {
    current = { ...current, webhookUrl: value };

    // Self-update keeps the field editable; the sibling update shows the error.
    // Both are legal here because this callback runs inside the rendered tree.
    return {
      actions: [Actions.updateProps, Actions.updateContext],
      newProps: urlInputProps(),
      contextProps: [urlErrorContext()],
    };
  },
});

const environmentOptions = (): IComboBoxItem[] => [
  // Labels must stay unique - the host matches options by label, not key.
  { key: "production", label: t("settings.envProduction") },
  { key: "staging", label: t("settings.envStaging") },
];

const selectedEnvironmentOption = (): IComboBoxItem => {
  const options = environmentOptions();
  return options.find((option) => option.key === current.environment) ?? options[0];
};

const environmentComboBoxProps = (): IComboBox => ({
  options: environmentOptions(),
  selectedOption: selectedEnvironmentOption(),
  scaled: true, // fill the row, like the input above it
  scaledOptions: true, // otherwise the dropdown is 200px regardless of the control
  onSelect: (option: IComboBoxItem): IMessage => {
    current = {
      ...current,
      environment: option.key === "staging" ? "staging" : "production",
    };

    // Selection does not repaint the control on its own - answer with new props.
    return { actions: [Actions.updateProps], newProps: environmentComboBoxProps() };
  },
});

const notificationsToggleProps = (): IToggleButton => ({
  label: t("settings.sendNotifications"),
  isChecked: current.sendNotifications,
  // The host passes nothing to onChange - flip our own state and answer with it.
  onChange: (): IMessage => {
    current = { ...current, sendNotifications: !current.sendNotifications };
    return { actions: [Actions.updateProps], newProps: notificationsToggleProps() };
  },
});

// label renders 13px/600 - the portal's native field-caption look in both themes.
const fieldLabelRow = (text: string, marginProp: string): Component => ({
  component: Components.box,
  props: {
    marginProp,
    children: [{ component: Components.label, props: { text } }],
  },
});

const settingsBody = (): IBox => ({
  displayProp: "flex",
  flexDirection: "column",
  children: [
    fieldLabelRow(t("settings.urlLabel"), "0 0 4px 0"),
    {
      component: Components.input,
      contextName: CTX_URL_INPUT,
      props: urlInputProps(),
    },
    {
      component: Components.text,
      contextName: CTX_URL_ERROR,
      props: urlErrorTextProps(),
    },
    fieldLabelRow(t("settings.envLabel"), "16px 0 4px 0"),
    { component: Components.comboBox, props: environmentComboBoxProps() },
    {
      // A toggleButton has no intrinsic size (its inner label is absolutely
      // positioned), so it needs a row of its own with an explicit height.
      component: Components.box,
      props: {
        marginProp: "16px 0 0 0",
        heightProp: "20px",
        displayProp: "flex",
        alignItems: "center",
        children: [
          { component: Components.toggleButton, props: notificationsToggleProps() },
        ],
      },
    },
  ],
});

const onSaveClick = async (): Promise<IMessage> => {
  const webhookUrl = current.webhookUrl.trim();

  if (webhookUrl.length > 0 && !isValidWebhookUrl(webhookUrl)) {
    // Keep the draft as typed; surface the error on the field and below it.
    return {
      actions: [Actions.updateContext],
      contextProps: [{ name: CTX_URL_INPUT, props: urlInputProps() }, urlErrorContext()],
    };
  }

  current = { ...current, webhookUrl };

  // saveSettings is legal from a button only - this is that button. The trimmed
  // URL is pushed back into the field via updateContext in the same message.
  return {
    actions: [Actions.saveSettings, Actions.updateContext, Actions.showToast],
    settings: JSON.stringify(current),
    contextProps: [{ name: CTX_URL_INPUT, props: urlInputProps() }, urlErrorContext()],
    toastProps: [{ type: ToastType.success, title: t("settings.saved") }],
  };
};

export const createPluginSettings = (): ISettings => ({
  settings: settingsBody(),
  saveButton: {
    component: Components.button,
    // The host renders this in the settings aside footer and forces its look
    // (localized "Save", normal size, primary, scaled) - what stays ours is
    // onClick and the loading flags.
    props: {
      label: t("settings.save"),
      size: ButtonSize.normal,
      primary: true,
      scale: true,
      withLoadingAfterClick: true,
      disableWhileRequestRunning: true,
      onClick: onSaveClick,
    },
  },
  // The aside re-runs this on open. By then the stored settings string has
  // arrived (it lands only after installation), so rebuild from current state.
  onLoad: async () => ({ settings: settingsBody() }),
});
```
