# Аудит плагина `room-stats` (RoomStats)

Проект: `C:\Users\Abobadance\docspace-plugin-sdk\skill-workspace\iteration-2\eval-2-audit-broken-plugin\with_skill\project`

Что сделано: `npm install` + `npm run build` (успешно, `dist/plugin.zip` собирается), затем
`node skills/docspace-plugin/scripts/validate-plugin.mjs <project> --invoke`.
Валидатор загружает собранный бандл в песочнице и проверяет ровно то, что проверяет портал.

Исходники плагина **не изменялись**. Чтобы увидеть дефекты, спрятанные за ошибкой регистрации,
проект был скопирован во временный каталог, там исправлена **только** строка регистрации,
и копия пересобрана и проверена повторно.

---

## 1. Молчаливая поломка — собирается, ставится, в интерфейсе не появляется ничего

### 1.1. Плагин регистрируется под чужим именем — это и есть причина «ничего нет»

`src/index.ts:98`

```ts
window.Plugins.RoomStatistics = plugin || {};
```

В `package.json:10` объявлено `"pluginName": "RoomStats"`. Портал после загрузки бандла
делает примерно `{ ...pluginRecord, ...iframeWindow.Plugins[pluginName] }`, то есть ищет
именно `window.Plugins.RoomStats`. Такого свойства нет — портал получает пустой объект
плагина: ни статуса, ни геттеров, ни items. Ошибок в консоли при этом нет никаких.

Вывод валидатора:

```
ERROR [registration] no "window.Plugins.RoomStats = ..." in src/
ERROR [runtime] the bundle did not register window.Plugins.RoomStats (it registered: RoomStatistics)
```

Это единственный дефект, который объясняет симптом «в интерфейсе от него вообще ничего нет»
целиком. Остальные три проявятся сразу после того, как имя будет исправлено, поэтому
чинить их надо в одном заходе — иначе пользователь получит вторую итерацию «опять ничего».

**Что увидит пользователь:** плагин в списке установленных, переключатель включён, в контекстном
меню комнаты — пусто.

### 1.2. Клик по пункту меню мёртв — `showModal` без `modalDialogProps`

`src/index.ts:41-47`

```ts
onItemClick: async (id: string | number) => {
  const total = await Promise.resolve(id);
  return {
    actions: [Actions.showModal],
  };
},
```

Хост проходит по `actions` и для большинства действий ничего не делает, если рядом нет
соответствующего поля с полезной нагрузкой. Для `showModal` обязателен `modalDialogProps`
(и сам диалог не откроется без `onLoad`, `onClose` и `dialogBody`). Здесь нагрузки нет вовсе —
действие молча пропускается.

Вывод валидатора на исправленной копии:

```
ERROR [message] ContextMenu item "room-stats-context-menu" returns action "show-modal"
                without modalDialogProps - the host silently skips it
```

**Что увидит пользователь:** пункт «Room statistics» в меню есть, нажатие ничего не делает —
ни модалки, ни тоста, ни ошибки.

Попутно: `total` вычисляется (`await Promise.resolve(id)`) и никуда не используется —
статистика по комнате нигде не считается. Область `API` в `package.json:14` не объявлена,
так что запросить размер комнаты у портала плагин в текущем виде и не может. То есть даже
после починки контракта функциональность, заявленную в `description`, ещё предстоит написать.

---

## 2. Неверное поведение — работает, но не так, как задумано

### 2.1. Фильтр по типу пользователя игнорируется — `usersType` вместо `usersTypes`

`src/index.ts:40`

```ts
usersType: [UsersType.roomAdmin, UsersType.docSpaceAdmin],
```

Имя поля фильтра различается по областям — это причуда портала, а не опечатка, которую можно
не заметить:

| Поле | Области |
|---|---|
| `usersTypes` (мн. ч.) | ContextMenu, InfoPanel, EventListener, ArticleButton |
| `usersType` (ед. ч.) | MainButton, ProfileMenu, File |

Для `ContextMenu` хост читает `usersTypes`. Поле `usersType` он просто не смотрит, и пункт
показывается **всем** типам пользователей, включая `user` и `collaborator` — то есть ровно
наоборот к замыслу.

```
ERROR [item] ContextMenu item "room-stats-context-menu" uses usersType
             but the host reads usersTypes for ContextMenu - the filter is silently ignored
```

Почему это прошло компиляцию: объект на `src/index.ts:35` объявлен без аннотации типа
(`const roomStatsItem = {...}`), а не как `const roomStatsItem: IContextMenuItem = {...}`.
Проверка лишних свойств в TypeScript срабатывает только на литерале, присваиваемом напрямую
типизированной цели; через промежуточную переменную она не срабатывает, и `usersType` проехал
молча. Явная аннотация типа поймала бы это на этапе сборки.

### 2.2. Локализованная подпись не работает — элемент собран до `setLanguage`

`src/index.ts:31-33`, `35-36`, `90`

```ts
let locale: PluginLocale = PluginLocale.EN_US;
const t = (): string => labels[locale] ?? labels["en-US"];

const roomStatsItem = {
  ...
  label: t(),          // вычисляется на уровне модуля
};
...
plugin.addContextMenuItem(roomStatsItem);   // тоже на уровне модуля
```

Порядок загрузки на портале: сначала выполняется код бандла, потом `setLanguage(locale)`,
потом `setAPI(...)`, и только потом `await onLoadCallback()`; карты элементов читаются в
самом конце. Регистрация на уровне модуля сама по себе не дефект — элемент успевает попасть
в карту, и часть официальных плагинов делает именно так. Дефект в том, что `label: t()`
вычисляется **до** шага `setLanguage`, когда `locale` ещё равен значению по умолчанию
`EN_US`. `setLanguage` на `src/index.ts:69-71` меняет переменную позже, но подпись уже
зафиксирована строкой.

**Что увидит пользователь:** русскоязычный интерфейс, а пункт меню всё равно «Room statistics».
Строка `"Статистика комнаты"` (`src/index.ts:28`) не появится никогда.

Лечится переносом создания и регистрации элемента внутрь `onLoadCallback`
(`src/index.ts:55-57`, сейчас он пустой) — к этому моменту и язык, и URL-ы API уже установлены.
Та же ловушка ждёт любой вызов `getAPI()` из модульной области: он вернёт пустые строки.

---

## 3. Хрупкость

- **`onItemClick` без `try/catch`** (`src/index.ts:41-47`). Портал не оборачивает
  пользовательские колбэки — необработанное отклонение промиса даёт мёртвый клик, а исключение
  во время рендера плагинного дерева заменяет весь портал экраном ошибки. Как только в обработчике
  появится реальный запрос за статистикой, ошибку надо ловить и показывать через `showToast`.
- **`window.Plugins.RoomStatistics = plugin || {}`** (`src/index.ts:98`). `plugin` — только что
  созданный экземпляр класса, `|| {}` не может сработать никогда; конструкция маскирует опечатку
  в имени, вместо того чтобы её обнажить.
- Ключ `room-stats-context-menu` (`src/index.ts:36`) — **корректен**: карты элементов общие на весь
  портал, и префикс именем плагина здесь на месте. Коллизий с чужими плагинами не будет.

---

## 4. Гигиена

- **`version` в `package.json:3` — `1.0.0`.** Перед каждой повторной загрузкой архива его надо
  поднимать, иначе портал отдаёт закешированный бандл (иконки кешируются как `?hash=<version>`),
  и исправления выглядят как «ничего не изменилось».
- **SDK 2.1.0, `minDocSpaceVersion` 3.5.0** — валидатор расхождений (`sdk-drift`) не нашёл.
- **Скрипт сборки** `webpack && npx build-docspace-plugin` (`package.json:16`) — актуальная форма,
  устаревший `node ./scripts/createZip.js` здесь не используется.
- **Устаревших членов SDK нет**: используется `onItemClick`, а не отменённый `onClick`.
- **Ассеты** (`assets/icon-16.svg`, `assets/logo.svg`) резолвятся, лимиты не превышены,
  упакованный `config.json` не расходится с `package.json`.

---

## Порядок починки

1. `src/index.ts:98` -> `window.Plugins.RoomStats = plugin;` — без этого остальное не проверить.
2. `src/index.ts:40` -> `usersTypes`, и типизировать объект как `IContextMenuItem`,
   чтобы компилятор ловил такое сам.
3. `src/index.ts:44-46` -> добавить `modalDialogProps` (с `onLoad`, `onClose`, `dialogBody`)
   либо вернуть `showToast` с `toastProps`.
4. Перенести создание и `addContextMenuItem` внутрь `onLoadCallback` (`src/index.ts:55-57`).
5. Поднять `version` в `package.json`, пересобрать, перепроверить валидатором до нуля ошибок,
   загрузить заново и **полностью перезагрузить страницу** портала.