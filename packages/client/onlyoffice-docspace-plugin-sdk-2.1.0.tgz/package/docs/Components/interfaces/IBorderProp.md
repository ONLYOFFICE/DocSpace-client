# Interface: IBorderProp

Defined in: [interfaces/components/IBox.ts:40](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L40)

Defines the border properties for a box element.

## Example

Border properties with custom styling

```typescript
const borderProps: IBorderProp = {
  color: "blue",
  radius: "10px",
  style: "solid",
  width: "2px"
}
```

## Properties

### color

> **color**: `string`

Defined in: [interfaces/components/IBox.ts:42](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L42)

Defines the border color of the element area

***

### radius

> **radius**: `string`

Defined in: [interfaces/components/IBox.ts:45](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L45)

Defines the border radius of the element area

***

### style

> **style**: `string`

Defined in: [interfaces/components/IBox.ts:48](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L48)

Defines the border style of the element area

***

### width

> **width**: `string`

Defined in: [interfaces/components/IBox.ts:51](https://github.com/ONLYOFFICE/docspace-plugin-sdk/blob/feature/typedoc/src/interfaces/components/IBox.ts#L51)

Defines the border width of the element area
